
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.OrderStatusApiController;
import com.cvs.specialty.ordermaintenance.service.OrderStatusService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class OrderStatusApiControllerTest {

  @InjectMocks
  OrderStatusApiController OrderStatusApiController;

  @Mock
  OrderStatusService orderStatService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void updateOrderStatusTest() throws OrderMaintenanceException, BindException, Exception {

    ResponseEntity<Void> result = new ResponseEntity<Void>(HttpStatus.OK);
    when(orderStatService.updateOrderStatus(12L)).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<Void> responseEntity = OrderStatusApiController
      .updateOrderStatus("Test", "Token", 12L, request, response);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
