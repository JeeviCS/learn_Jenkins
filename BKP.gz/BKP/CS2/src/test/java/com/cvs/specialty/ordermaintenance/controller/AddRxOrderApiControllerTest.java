/*
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.AddRxOrderApiController;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.AddRxOrderService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class AddRxOrderApiControllerTest {

  @InjectMocks
  AddRxOrderApiController orderApiController;

  @Mock
  AddRxOrderService addRxOrderService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Test
  public void addRxOrderTest() throws OrderMaintenanceException, BindException, Exception {

    RxDetailsList orderList = new RxDetailsList();
    orderList.setDiversion("diversion");
    List<RxDetailsList> rxDetailsList = new ArrayList();
    rxDetailsList.add(orderList);
    
    Integer preOrderID = 1234;

    ResponseEntity<Void> result = new ResponseEntity<>(HttpStatus.OK);
    when(addRxOrderService.addRxorder(rxDetailsList, 1234L)).thenReturn(result);
    
    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id","1234");
    request.setAttribute("message-id","testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<Void> responseEntity = orderApiController.addRxOrderPost("Test", "Token", rxDetailsList, preOrderID, request, response);
     

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
*/