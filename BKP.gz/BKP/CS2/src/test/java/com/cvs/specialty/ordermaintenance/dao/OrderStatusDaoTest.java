/*package com.cvs.specialty.ordermaintenance.dao;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.impl.AddRxOrderDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.ItemEO;
import com.cvs.specialty.ordermaintenance.entity.PreOrderDetailEO;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionDispensesEO;
import com.cvs.specialty.ordermaintenance.model.*;
import com.cvs.specialty.ordermaintenance.repository.ItemsRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderDetailRepo;
import com.cvs.specialty.ordermaintenance.repository.PrescriptionDispensesRepo;

@RunWith(MockitoJUnitRunner.class)
public class OrderStatusDaoTest {

  @InjectMocks
  private AddRxOrderDaoImpl addRxORderDaoImpl;

  @Mock
  PreOrderDetailRepo preOrderDetailRepo;

  @Mock
  ItemsRepo itemsRepo;
  
  @Mock
  SpecialtyLogger Logger;
  
  @Mock
  PrescriptionDispensesRepo prescriptionDispensesRepo;
  
  @Test
  public void addRxOrderTest() {

    List<RxDetailsList> rxList = createRxDetailsList();
    long preOrderId = 1234;

    ItemEO itemEO = createItemEO();
    PrescriptionDispensesEO prescriptionDispensesEO = createPrescriptionDispensesEO();



    //when(addRxORderDaoImpl.addRxorder(rxList, preOrderId)).thenReturn(rxList);
    //when(itemsRepo.findByItemName(drugName)).thenReturn(itemEO);
    //when(itemsRepo.findByItemNameAndStrengthTxt(drugName, drugStrength)).thenReturn(itemEO);

    when(itemsRepo.findByItemName(rxList.get(0).getDrug().getDrugName())).thenReturn(itemEO);
    when(itemsRepo.findByItemNameAndStrengthTxt(
        rxList.get(0).getDrug().getDrugName(),
        rxList.get(0).getDrug().getDrugStrengthText())).thenReturn(itemEO);
    when(prescriptionDispensesRepo.findById(rxList.get(0).getPrescriptionDispense().getPrescriptionDispenseIdentifier())).
    thenReturn(prescriptionDispensesEO);


    PreOrderDetailEO preOrderDetailEO = new PreOrderDetailEO();
    preOrderDetailEO.setRxId(new BigDecimal(rxList.get(0).getPrescription().getPrescriberIdentifier()));
    preOrderDetailEO.setPrescriptionDispens(prescriptionDispensesEO);
    preOrderDetailEO.setPreOrdrHdrId(new BigDecimal(preOrderId));
    preOrderDetailEO.setItem(itemEO);
    
    when(preOrderDetailRepo.save(preOrderDetailEO)).thenReturn(null);
    
    
    assertNull(addRxORderDaoImpl.addRxorder(rxList, preOrderId));
    
    //List<RxDetailsList> rxListResponse = addRxORderDaoImpl.addRxorder(rxList, preOrderId);
    //assertEquals(rxList.get(0).getDrug().getDrugName(),rxListResponse.get(0).getDrug().getDrugName()) ;



  }

  private PrescriptionDispensesEO createPrescriptionDispensesEO() {
    
    PrescriptionDispensesEO prescriptionDispensesEO = new PrescriptionDispensesEO();
    
    return prescriptionDispensesEO;
  }

  private ItemEO createItemEO() {
    ItemEO itemEO = new ItemEO();
    
    return itemEO;
  }

  private List<RxDetailsList> createRxDetailsList() {
    List<RxDetailsList> rxList = new ArrayList();
    
    RxDetailsList rxDetails = new RxDetailsList();
    
    Drug drug = createDrug();
    PrescriptionDispense prescriptionDispense = createPrescriptionDispense();
    Prescription prescription = createPrescription();
    
    rxDetails.setDrug(drug);
    rxDetails.setPrescriptionDispense(prescriptionDispense);
    rxDetails.setPrescription(prescription);
    rxList.add(rxDetails);
    
    return rxList;
  }
  
  private Prescription createPrescription() {
    Prescription prescription = new Prescription();
    prescription.setPrescriberIdentifier(1345L);
    return prescription;
  }

  private PrescriptionDispense createPrescriptionDispense() {
    PrescriptionDispense prescriptionDispense = new PrescriptionDispense();
    prescriptionDispense.setPrescriptionDispenseIdentifier(12345L);
    return prescriptionDispense;
  }

  private Drug createDrug() {
    Drug drug = new Drug();
    drug.setDrugName("testdrugname");
    drug.setDrugStrengthText("20mg");
    return drug;
  }
}
*/