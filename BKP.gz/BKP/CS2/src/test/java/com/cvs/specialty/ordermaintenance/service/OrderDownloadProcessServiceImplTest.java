
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.OrderDownloadProcessDao;
import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;
import com.cvs.specialty.ordermaintenance.service.impl.OrderDownloadProcessServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class OrderDownloadProcessServiceImplTest {

  @InjectMocks
  OrderDownloadProcessServiceImpl orderDownloadProcessService;

  @Mock
  OrderDownloadProcessDao orderDownloadProcessDao;

  @Mock
  SpecialtyLogger Logger;

  @SuppressWarnings({
      "unchecked", "rawtypes"
  })
  @Test
  public void createInstanceIdTest() {

    SbpEntityBpmProcessMap sbpEntityBpmProcessMap = new SbpEntityBpmProcessMap();
    sbpEntityBpmProcessMap.setBpmPrcsInstanceId(new BigDecimal(1234));
    sbpEntityBpmProcessMap.setBpmPrcsStusCd("O");

    ResponseEntity<SbpEntityBpmProcessMap> response = new ResponseEntity(
      sbpEntityBpmProcessMap,
      HttpStatus.OK);

    when(orderDownloadProcessDao.createProcessInstanceId(new BigDecimal(12), new BigDecimal(1234)))
      .thenReturn(response);
    ResponseEntity<SbpEntityBpmProcessMap> responseEntity = orderDownloadProcessService
      .createInstanceId(new BigDecimal(12), new BigDecimal(1234));

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
