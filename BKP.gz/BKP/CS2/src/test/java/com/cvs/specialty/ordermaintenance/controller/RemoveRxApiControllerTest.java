
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.RemoveRxApiController;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.RemoveRxService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class RemoveRxApiControllerTest {

  @InjectMocks
  RemoveRxApiController removeRxController;

  @Mock
  RemoveRxService removeRxService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void removeRxDeleteTest() throws OrderMaintenanceException, BindException, Exception {

    RxDetailsList orderList = new RxDetailsList();
    orderList.setDiversion("diversion");
    List<RxDetailsList> rxDetailsList = new ArrayList<>();
    rxDetailsList.add(orderList);

    ResponseEntity<Void> result = new ResponseEntity<>(HttpStatus.OK);
    when(removeRxService.removeRx(123, rxDetailsList)).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<Void> responseEntity = removeRxController
      .removeRxDelete("test", "testtoken", 123, rxDetailsList, request, response);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
