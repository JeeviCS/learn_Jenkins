package com.cvs.specialty.ordermaintenance.dao;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.cvs.specialty.ordermaintenance.dao.impl.OrderNotesDaoImpl;
import com.cvs.specialty.ordermaintenance.dao.impl.UnTagOrderDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.entity.PreOrderNote;
import com.cvs.specialty.ordermaintenance.model.Drug;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;
import com.cvs.specialty.ordermaintenance.model.Prescription;
import com.cvs.specialty.ordermaintenance.model.PrescriptionDispense;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.model.UntagReasonCodes;
import com.cvs.specialty.ordermaintenance.repository.ItemsRepo;
import com.cvs.specialty.ordermaintenance.repository.OrderNotesRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderDetailRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;
import com.cvs.specialty.ordermaintenance.repository.PrescriptionDispensesRepo;
import com.cvs.specialty.ordermaintenance.repository.PrescriptionRepo;
import com.cvs.specialty.ordermaintenance.repository.UntagReasonRepo;

/**
 * Junit for UnTagOrder DAO
 * 
 * @author 
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class UnTagOrderDaoTest {

	@InjectMocks
	private UnTagOrderDaoImpl unTagOrderDaoImpl;

	@Mock
	PreOrderDetailRepo preOrderDetailRepo;
	@Mock
	PreOrderHeaderRepo preOrderHeaderRepo;
	@Mock
	PrescriptionRepo prescriptionRepo;
	@Mock
	ItemsRepo itemsRepo;
	@Mock
	PrescriptionDispensesRepo prescriptionDispensesRepo;
	@Mock
	UntagReasonRepo untagReasonRepo;
	
	@Test
	public void testGetUntagReasonCodes() {
		
		List<CgRefCode> untagReasonCodesList = mockUntagReasons();
		List<CgRefCode> untagReasonCodes = untagReasonRepo.findByRvDomain("UNTAG_REASON_CODE");
		when(untagReasonCodes).thenReturn(untagReasonCodesList);
	  Assert.assertNotNull(untagReasonCodesList); 
		
	}

	@Test
	public void testunTagRxOrder() {
		Long preOrderId = 12345L;
		UnTagOrderDaoImpl unTagOrderDaoImpl = mock(UnTagOrderDaoImpl.class);
		unTagOrderDaoImpl.unTagRxorder(createUntagOrder(), preOrderId, new BigDecimal(02));
		verify(unTagOrderDaoImpl,times(1)).unTagRxorder(createUntagOrder(),preOrderId,new BigDecimal(02));
	}

	
	/**
	 * Set the mock UnTagOrder
	 * @return
	 */
	private List<CgRefCode> mockUntagReasons() {
		CgRefCode CgRefCode = new CgRefCode();
		List<CgRefCode> UntagReasonCodeslist = new ArrayList<CgRefCode>();
		
		for(int i=0;i<5;i++) {
			CgRefCode.setRvLowValue(Integer.toString(i));
			CgRefCode.setRvAbbreviation("Test"+i+" Desc");
			UntagReasonCodeslist.add(CgRefCode);
		}
		
		return UntagReasonCodeslist;
	}
	
	/**
	 * Set the mock request object for untag order
	 * 
	 * @return
	 */
	private List<RxDetailsList> createUntagOrder() {
		
		List<RxDetailsList> rxDetailsList = new ArrayList<RxDetailsList>();
		
		RxDetailsList rxDetails = new RxDetailsList();
		Drug drug = new Drug();
		Prescription presc = new Prescription();
		PrescriptionDispense prescDisp = new PrescriptionDispense();
		
		//---------DRUG-------------------
		drug.setDrugIdentifier(57084);
		drug.setDrugName("GABAPENTIN # (GREENSTONE)");
		drug.setDrugStrengthText("600MG");
		drug.setMetricQuantity((float)0);
		drug.setUnitsQuantity(100);
		
		//------PRESCRIPTION----------------
		presc.setDrugIdentifier("57084");
		presc.setPrescriptionIdentifier(400325);
		presc.setPrescriptionNumber(new BigDecimal(26));
		
		//-----PRESCRIPTION DISPENSE--------
		prescDisp.setPrescriptionDispenseIdentifier(11341461);
		prescDisp.setUntagReasonCode(new BigDecimal( 02));
		
		//-------RxDetails-------------------
		rxDetails.setDrug(drug);
		rxDetails.setPrescription(presc);
		rxDetails.setPrescriptionDispense(prescDisp);
		rxDetails.setQuantityOnHand(15);
		rxDetails.setRx_copay(0);
		rxDetails.setRx_daySupply(5);
		rxDetails.setRx_medication("GABAPENTIN # (GREENSTONE)");
		rxDetails.setRx_onHand(15);
		rxDetails.setRx_quantity(5);
		rxDetails.setRx_rxNumber(26);
		rxDetails.setRx_strength("600MG");
		
		rxDetailsList.add(rxDetails);
		
		return rxDetailsList;
		
	}
	
}
