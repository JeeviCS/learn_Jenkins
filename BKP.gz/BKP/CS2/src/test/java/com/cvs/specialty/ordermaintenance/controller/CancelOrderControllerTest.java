/*package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.CancelOrderApiController;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
import com.cvs.specialty.ordermaintenance.service.CancelOrderService;

@RunWith(MockitoJUnitRunner.class)
public class CancelOrderControllerTest {
	@InjectMocks
	CancelOrderApiController cancelOrderApiController;

	@Mock
	CancelOrderService cancelOrderService;
	
	@Mock
	SpecialtyLogger serviceLogger;
	
	@Mock
	MockHttpServletRequest request;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void cancelOrderTest() {

		OrderCancelRequest orderCancelRequest = createOrderCancelRequest();
		CancelOrderResponse response = new CancelOrderResponse();
		response.setOrderId(1234L);
		response.setMessage("success");
		when(cancelOrderService.submitCancelOrder(orderCancelRequest, "12345")).thenReturn(response);

		ResponseEntity<CancelOrderResponse> responseEntity = cancelOrderApiController
				.cancelOrderPut("123", "12345",  "testToken","12345", orderCancelRequest);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(response,responseEntity.getBody());
	}

	@Test
	public void cancelOrderTest_null() {

		when(request.getAttribute("user-id")).thenReturn("sysAdmin");
		CancelOrderResponse response = new CancelOrderResponse();
		when(cancelOrderService.submitCancelOrder(null, "12345", "testToken", "12345")).thenReturn(response);

		ResponseEntity<CancelOrderResponse> responseEntity = cancelOrderApiController
				.cancelOrderPut("testToken","12345", null, request);


		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
	}


@Test
	public void cancelOrderTest_else() {

		when(request.getAttribute("user-id")).thenReturn("sysAdmin");
		CancelOrderResponse response = new CancelOrderResponse();
		when(cancelOrderService.submitCancelOrder(null, null, null, null)).thenReturn(response);

		ResponseEntity<CancelOrderResponse> responseEntity = cancelOrderApiController
				.cancelOrderPut(null,null, null,request);


		assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
	}

	@Test
	public void cancelOrderTestTwo_Exception() {

		CancelOrderResponse response = new CancelOrderResponse();
		OrderCancelRequest orderCancelRequest = createOrderCancelRequest();
		when(request.getAttribute("user-id")).thenReturn("sysAdmin");
		when(cancelOrderService.submitCancelOrder(orderCancelRequest, "12345", "testToken", "12345")).thenReturn(response);
		when(cancelOrderApiController
				.cancelOrderPut("testToken","12345", orderCancelRequest, request)).thenThrow(new DataAccessException("test") {});

		ResponseEntity<CancelOrderResponse> responseEntity = cancelOrderApiController
				.cancelOrderPut("testToken","12345", orderCancelRequest, request);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
	}
	
	private OrderCancelRequest createOrderCancelRequest() {
		OrderCancelRequest orderCancelRequest =new OrderCancelRequest();
		orderCancelRequest.setOrderId(1234L);
		orderCancelRequest.setPatientId(1234l);
		orderCancelRequest.setMdNotifiedFlag(true);
		orderCancelRequest.setPatientNotifiedFlag(true);
		orderCancelRequest.setOrderCancelReason("reason");
		return orderCancelRequest;
	}

}
*/