
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.SplitRxOrderDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.impl.SplitRxOrderServiceImpl;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class SplitRxOrderServiceImplTest {

  @InjectMocks
  SplitRxOrderServiceImpl splitRxOrderService;

  @Mock
  SplitRxOrderDao splitRxOrderDao;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Test
  public void splitRxorderTest() throws OrderMaintenanceException, BindException, Exception {

    RxDetailsList orderList = new RxDetailsList();
    orderList.setDiversion("diversion");
    List<RxDetailsList> rxDetailsList = new ArrayList();
    rxDetailsList.add(orderList);

    Integer preOrderID = 1234;

    when(splitRxOrderDao.splitRxorder(rxDetailsList, preOrderID)).thenReturn(rxDetailsList);

    ResponseEntity<Void> responseEntity = splitRxOrderService
      .splitRxorder(rxDetailsList, preOrderID);

    assertNull(responseEntity);
  }

}
