
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.RxDetailsApiController;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.RxDetailsService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class RxDetailsApiControllerTest {
  @InjectMocks
  RxDetailsApiController rxDetailsController;

  @Mock
  RxDetailsService rxDetailsService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void rxDetailsGetTest() throws OrderMaintenanceException, BindException, Exception {

    RxDetailsList rxDetailsList = new RxDetailsList();
    rxDetailsList.setRx_rxNumber(1234L);
    rxDetailsList.setRx_medication("TYLANOL");
    rxDetailsList.setRx_strength("20Mg");
    rxDetailsList.setRx_quantity(10);
    rxDetailsList.setRx_daySupply(5);
    rxDetailsList.setRx_onHand(2);
    rxDetailsList.setRx_copay(20);
    rxDetailsList.setDiversion("testdiversion");
    List<RxDetailsList> rxDetailslist = new ArrayList<RxDetailsList>();
    rxDetailslist.add(rxDetailsList);
    ResponseEntity<List<RxDetailsList>> result;
    result = new ResponseEntity<List<RxDetailsList>>(rxDetailslist, HttpStatus.OK);
    when(rxDetailsService.rxDetailsListGet(3, 12)).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<List<RxDetailsList>> responseEntity = rxDetailsController
      .rxDetailsGet("123", "testtoken", 3, 12, request, response);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(result.getBody(), responseEntity.getBody());
  }

}
