
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.CancelDownloadDao;
import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.service.impl.CancelDownloadServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class CancelDownloadServiceImplTest {

  @InjectMocks
  CancelDownloadServiceImpl cancelDownloadService;

  @Mock
  CancelDownloadDao cancelDownloadDao;

  @Mock
  SpecialtyLogger Logger;

  @Test
  public void cancelDownloadGetTest() {
    CanceDownloadReasonCodes cancelDownloadReasonCodes = new CanceDownloadReasonCodes();

    cancelDownloadReasonCodes.setCode("O");

    List<CanceDownloadReasonCodes> code = new ArrayList<CanceDownloadReasonCodes>();
    code.add(cancelDownloadReasonCodes);

    when(cancelDownloadDao.cancelDownloadGet(123)).thenReturn(code);

    ResponseEntity<List<CanceDownloadReasonCodes>> responseEntity = cancelDownloadService
      .cancelDownloadGet(123);

    assertEquals(code, responseEntity.getBody());

  }

}
