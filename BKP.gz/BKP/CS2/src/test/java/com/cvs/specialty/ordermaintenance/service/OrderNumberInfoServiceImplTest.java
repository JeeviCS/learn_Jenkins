
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.OrderNumberInfoDao;
import com.cvs.specialty.ordermaintenance.model.OrderSatCode;
import com.cvs.specialty.ordermaintenance.model.PrescriptionDispOrders;
import com.cvs.specialty.ordermaintenance.service.impl.OrderNumberInfoServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class OrderNumberInfoServiceImplTest {

  @InjectMocks
  OrderNumberInfoServiceImpl orderNumberService;

  @Mock
  OrderNumberInfoDao orderInfoDao;

  @Mock
  SpecialtyLogger Logger;

  @Test
  public void getOrderInfoTest() {

    OrderSatCode orderStatCode = new OrderSatCode();
    List<PrescriptionDispOrders> hbsNumber = new ArrayList<PrescriptionDispOrders>();
    PrescriptionDispOrders dispOrdeers = new PrescriptionDispOrders();
    dispOrdeers.setOrderNumber("445678");
    dispOrdeers.setOrderStatus("Open");
    dispOrdeers.setShipmentNumber("2468");
    orderStatCode.setOrderStatusCode("O");
    orderStatCode.setOrderStatusReasonCode("OPEN");
    orderStatCode.setPatientIdentifier("1234");
    hbsNumber.add(dispOrdeers);
    orderStatCode.setHbsNumber(hbsNumber);

    when(orderInfoDao.getOrderInfo( 456)).thenReturn(orderStatCode);

    ResponseEntity<OrderSatCode> responseEntity = orderNumberService.getOrderInfo(456);

    assertEquals(orderStatCode, responseEntity.getBody());

  }

}
