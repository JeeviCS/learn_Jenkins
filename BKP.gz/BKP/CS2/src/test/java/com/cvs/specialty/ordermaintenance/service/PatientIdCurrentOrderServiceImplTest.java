
package com.cvs.specialty.ordermaintenance.service;

import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.ordermaintenance.dao.PatientIdCurrentOrdersDAO;
import com.cvs.specialty.ordermaintenance.mapper.PatientIdCurrentOrdersMapper;
import com.cvs.specialty.ordermaintenance.model.CurrentOrders;
import com.cvs.specialty.ordermaintenance.service.impl.PatientIdCurrentOrdersServiceImpl;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.class)
public class PatientIdCurrentOrderServiceImplTest {

  @InjectMocks
  PatientIdCurrentOrdersServiceImpl patientIdCurrentOrdersService;

  @Mock
  PatientIdCurrentOrdersMapper mapper;

  @Mock
  PatientIdCurrentOrdersDAO patientIdCurrentOrdersDAO;

  @Test
  public void testAddRxOrder() {

    CurrentOrders currentOrders = new CurrentOrders();
    currentOrders.setDeliverySchedule("deliverySchedule");
    currentOrders.setHcpFirstName("hcpFirstName");
    currentOrders.setHcpID("hcpID");
    currentOrders.setHcpLastName("hcpLastName");
    currentOrders.setHcpNPI("hcpNPI");
    currentOrders.setItemsCount(new BigDecimal(3456));
    currentOrders.setNeedsBy("needsBy");
    currentOrders.setOrderDate("orderDate");
    currentOrders.setOrderNumber(new BigDecimal(3456));
    currentOrders.setShipDate("shipDate");
    currentOrders.setStatus("status");

    List<CurrentOrders> currentOrdersList = new ArrayList<>();
    currentOrdersList.add(currentOrders);

    when(patientIdCurrentOrdersDAO.getCurrentOrderDetails(123366L)).thenReturn(currentOrdersList);
    List<CurrentOrders> currentOrdersLists = patientIdCurrentOrdersService
      .getCurrentOrders("123366");
    Assert.assertEquals(currentOrdersList, currentOrdersLists);
  }

}
