
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.AutoDownloadEligibilityApiController;
import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;
import com.cvs.specialty.ordermaintenance.model.Diversion;
import com.cvs.specialty.ordermaintenance.service.AutoDownloadEligibilityService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class AutoDownloadEligibilityApiControllerTest {

  @InjectMocks
  AutoDownloadEligibilityApiController autoDownloadEligibilityController;

  @Mock
  AutoDownloadEligibilityService autoDownloadEligibilityService;

  @Mock
  SpecialtyLogger LOGGER;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void autoDownloadEligibilityGetTest()
      throws OrderMaintenanceException, BindException, Exception {
    AutoDownloadError autoDownloadError = new AutoDownloadError();
    autoDownloadError.setActionId("actionId");
    autoDownloadError.setCallingService("callingService");
    autoDownloadError.setDiversions(null);
    autoDownloadError.setDivertRequired("divertRequired");
    autoDownloadError.setEntityId(1234L);
    autoDownloadError.setEntityType("entityType");
    //autoDownloadError.setFollowUpDate(new Date());
    autoDownloadError.setNbdTooFarIndicator("nbdTooFarIndicator");
    autoDownloadError.setNbdWaitPeriod(456);
    autoDownloadError.setOutcomeId("outcomeId");
    autoDownloadError.setPatientId(1233667L);
    autoDownloadError.setTaskId(7890L);
    autoDownloadError.setTaskType("taskType");
    Diversion diversion = new Diversion();
    diversion.setDiversionId(6789L);
    diversion.setDiversionType("diversionType");
    diversion.setReasonCode("reasonCode");
    List<Diversion> diversions = new ArrayList<Diversion>();
    diversions.add(diversion);
    ResponseEntity<AutoDownloadError> result = new ResponseEntity<>(HttpStatus.OK);
    when(autoDownloadEligibilityService.validateAutoDownloadEligibilityRules(12L, 1233667L))
      .thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<AutoDownloadError> responseEntity = autoDownloadEligibilityController
      .autoDownloadEligibilityGet("test", "testtoken", 12L, 1233667L, request, response);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
