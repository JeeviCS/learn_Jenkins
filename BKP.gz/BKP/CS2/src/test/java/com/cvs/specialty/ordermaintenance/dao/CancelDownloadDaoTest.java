package com.cvs.specialty.ordermaintenance.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.impl.CancelDownloadDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.repository.CancelDownloadRepo;

@RunWith(MockitoJUnitRunner.class)
public class CancelDownloadDaoTest {

  @InjectMocks
  private CancelDownloadDaoImpl cancelDownloadDaoImpl;

  @Mock
  private CancelDownloadRepo cancelDownloadRepo;
  
  @Mock
  SpecialtyLogger serviceLogger;
  
  @Test
  public void cancelDownloadGetTest() {
    
    long orderId = 1234;
    
    List<CgRefCode> cgRefCodes = createCgRefCodes();
    
    when(cancelDownloadRepo.findByRvDomain("CANCL_DWNLD_RSN_CODE")).thenReturn(cgRefCodes);
    
    List<CanceDownloadReasonCodes> response = cancelDownloadDaoImpl.cancelDownloadGet(orderId);
    
    CanceDownloadReasonCodes canceDownloadReasonCodes = createCancelDownloadReasonCodes(cgRefCodes);
    assertEquals(canceDownloadReasonCodes.getCode(), response.get(0).getCode());
  }

  private CanceDownloadReasonCodes createCancelDownloadReasonCodes(List<CgRefCode> cgRefCodes) {
    CanceDownloadReasonCodes canceDownloadReasonCodes = new CanceDownloadReasonCodes();
    canceDownloadReasonCodes.setCode(cgRefCodes.get(0).getRvAbbreviation());
    return canceDownloadReasonCodes;
  }

  private List<CgRefCode> createCgRefCodes() {
    List<CgRefCode> cgRefCodes = new ArrayList();
    
    CgRefCode cgRefCode = new CgRefCode();
    cgRefCode.setRvAbbreviation("testabbreviation");
    
    cgRefCodes.add(cgRefCode);
    
    return cgRefCodes;
  }

}
