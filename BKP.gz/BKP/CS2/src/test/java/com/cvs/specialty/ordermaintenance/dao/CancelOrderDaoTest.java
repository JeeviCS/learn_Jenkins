package com.cvs.specialty.ordermaintenance.dao;


import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataAccessException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.common.OrderCancelConstant;
import com.cvs.specialty.ordermaintenance.dao.impl.CancelOrderDaoImpl;
import com.cvs.specialty.ordermaintenance.dao.impl.TaskManualDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
import com.cvs.specialty.ordermaintenance.model.TaskLists;
import com.cvs.specialty.ordermaintenance.repository.CancelListOfTasksRepo;
import com.cvs.specialty.ordermaintenance.repository.CancelOrderReasonRepo;
import com.cvs.specialty.ordermaintenance.repository.CancelOrderRepo;

@RunWith(MockitoJUnitRunner.class)
public class CancelOrderDaoTest {
	@InjectMocks
	private CancelOrderDaoImpl cancelOrderDaoImpl;

	@Mock
	CancelOrderReasonRepo cancelOrderReasonRepo;

	@Mock
	CancelOrderRepo cancelOrderRepo;
	
	@Mock
	SpecialtyLogger serviceLogger;

	@Mock
	CancelListOfTasksRepo cancelListOfTasksRepo;

	@Mock 
	TaskManualDaoImpl taskManualDaoImpl;

	@Test
	public void getCancelReasonTest()
	{

		List<CgRefCode> response =new  ArrayList<>();
		CgRefCode cgRefCode =new CgRefCode();
		cgRefCode.setRvAbbreviation("Renewal");
		cgRefCode.setRvLowValue("CANCEL_REASON_RENEWAL");
		response.add(cgRefCode);
		when(cancelOrderReasonRepo.findByRvDomainAndRvHighValue( OrderCancelConstant.PreferenceTextCgLowValues.DOMAIN,  OrderCancelConstant.PreferenceTextCgLowValues.CANCELREASON_HIGH_VALUE)).thenReturn(response);
		List<CgRefCode> responseEntity=cancelOrderDaoImpl.getCancelReason("RCC_SP_TASK_MANUAL", "CANCEL_REASON");
		assertEquals(response, responseEntity);
	}
	@Test
	public void updateCancelOrder()
	{
		OrderCancelRequest orderCancelRequest =getOrderCancelRequest();
		String patFlag="Y";
		String MDFlag="Y";
		String status="CANCELLED";
		Long order_id=1234L;



		String cancel_reason="reason";
		String userId="12345";

		List<TaskLists> task_list=getListOfTaskId();

		when(taskManualDaoImpl.getListofTasks("1234")).thenReturn(task_list);
		when(cancelOrderRepo.updateCancelOrder(patFlag,MDFlag,status,order_id,cancel_reason,userId)).thenReturn(1);
		CancelOrderResponse responseEntity	=cancelOrderDaoImpl.submitCancelOrder(orderCancelRequest, "12345");
		CancelOrderResponse cancelOrderResponse= new CancelOrderResponse();
		cancelOrderResponse.setOrderId(1234L);
		cancelOrderResponse.setMessage("success");

		assertEquals(cancelOrderResponse,responseEntity);
	}
	@Test
	public void updateCancelOrder_false()
	{
		OrderCancelRequest orderCancelRequest =getOrderCancelRequest();
		String patFlag="N";
		String MDFlag="N";
		String status="CANCELLED";
		Long order_id=1234L;
		String cancel_reason="reason";
		String userId="12345";
		orderCancelRequest.setOrderId(1234L);
		orderCancelRequest.setPatientId(1234l);
		orderCancelRequest.setMdNotifiedFlag(false);
		orderCancelRequest.setPatientNotifiedFlag(false);
		orderCancelRequest.setOrderCancelReason("reason");
		List<TaskLists> task_list=getListOfTaskId();
		when(taskManualDaoImpl.getListofTasks("1234")).thenReturn(task_list);
		when(cancelOrderRepo.updateCancelOrder(patFlag,MDFlag,status,order_id,cancel_reason,userId)).thenReturn(1);
		CancelOrderResponse responseEntity	=cancelOrderDaoImpl.submitCancelOrder(orderCancelRequest, "12345");
		CancelOrderResponse cancelOrderResponse= new CancelOrderResponse();
		cancelOrderResponse.setOrderId(1234L);
		cancelOrderResponse.setMessage("success");

		assertEquals(cancelOrderResponse,responseEntity);
	}
	@Test
	public void updateCancelOrder_else()
	{

		OrderCancelRequest orderCancelRequest =new OrderCancelRequest();
		orderCancelRequest.setOrderId(null);
		orderCancelRequest.setPatientId(null);
		orderCancelRequest.setMdNotifiedFlag(false);
		orderCancelRequest.setPatientNotifiedFlag(false);
		orderCancelRequest.setOrderCancelReason("reason");

		when(taskManualDaoImpl.getListofTasks("1234")).thenReturn(null);
		cancelOrderDaoImpl.submitCancelOrder(orderCancelRequest, "12345");

	}
	@SuppressWarnings("serial")
	@Test
	public void updateCancelOrderException() {
		OrderCancelRequest orderCancelRequest =new OrderCancelRequest();
		orderCancelRequest.setOrderId(1234L);
		orderCancelRequest.setPatientId(1234l);
		orderCancelRequest.setMdNotifiedFlag(false);
		orderCancelRequest.setPatientNotifiedFlag(false);
		orderCancelRequest.setOrderCancelReason("reason");

		when(taskManualDaoImpl.getListofTasks("1234")).thenThrow(new DataAccessException("test") {});
		when(cancelOrderDaoImpl.submitCancelOrder(orderCancelRequest, "12345")).thenThrow(new DataAccessException("test fail") {});

	}


	private List<TaskLists> getListOfTaskId()
	{
		TaskLists taskList=getTaskLists() ;
		List<TaskLists> tasklist=new ArrayList<>();
		tasklist.add(taskList);
		return tasklist;
	}
	private TaskLists getTaskLists() {
		TaskLists task=new TaskLists();
		task.setBpmTaskInstanceId(123L);
		task.setQueueTaskStatusCode("reason");
		task.setProcessInstanceMapId(123L);
		//task.setFlupTs(new Timestamp(new Date(0).getTime()));
		task.setComments("comment");
		return task;
	}
	private OrderCancelRequest getOrderCancelRequest() {

		OrderCancelRequest orderCancelRequest =new OrderCancelRequest();
		orderCancelRequest.setOrderId(1234L);
		orderCancelRequest.setPatientId(123l);
		orderCancelRequest.setMdNotifiedFlag(true);
		orderCancelRequest.setPatientNotifiedFlag(true);
		orderCancelRequest.setOrderCancelReason("reason");
		return orderCancelRequest;
	}

}
