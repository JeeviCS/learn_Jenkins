
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.OrderNotesDao;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;
import com.cvs.specialty.ordermaintenance.service.impl.OrderNoteServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class OrderNoteServiceImplTest {

  @InjectMocks
  OrderNoteServiceImpl orderNoteService;

  @Mock
  OrderNotesDao orderNotesDao;

  @Mock
  SpecialtyLogger Logger;

  @Test
  public void getOrderNotesTest() {

    OrderNotes orderNotes = new OrderNotes();
    orderNotes.setAudit(null);
    orderNotes.setNoteType("noteType");
    orderNotes.setPatientIndetifier(new BigDecimal(1234));
    orderNotes.setPreOrderHeaderIdentifier(78890L);
    orderNotes.setPreOrderNoteIdentifier(1233897L);
    orderNotes.setPreOrderNoteText("preOrderNoteText");
    orderNotes.setSourceSystemName("sourceSystemName");
    orderNotes.setSourceSystemNoteIdentifier(new BigDecimal(67890));
    List<OrderNotes> orderNotesList = new ArrayList<OrderNotes>();
    orderNotesList.add(orderNotes);
    // ResponseEntity<List<OrderNotes>> result = new ResponseEntity<>(orderNotesList,
    // HttpStatus.OK);

    when(orderNotesDao.getOrderNotes(1234)).thenReturn(orderNotesList);
    ResponseEntity<List<OrderNotes>> responseEntity = orderNoteService.getOrderNotes(1234);
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(orderNotesList, responseEntity.getBody());
  }

  @SuppressWarnings("null")
  @Test
  public void createOrderNotesTest() {
    OrderNotes orderNotes = new OrderNotes();

    orderNotes.setNoteType("noteType");
    orderNotes.setPatientIndetifier(new BigDecimal(1234));
    orderNotes.setPreOrderHeaderIdentifier(78890L);
    orderNotes.setPreOrderNoteIdentifier(1233897L);
    orderNotes.setPreOrderNoteText("preOrderNoteText");
    orderNotes.setSourceSystemName("sourceSystemName");
    orderNotes.setSourceSystemNoteIdentifier(new BigDecimal(67890));
    when(orderNotesDao.createOrderNotes(12L, "preOrderNoteText")).thenReturn(null);
    ResponseEntity<Void> responseEntity = orderNoteService
      .createOrderNotes(12L, "preOrderNoteText");
    assertNull(responseEntity);

  }

}
