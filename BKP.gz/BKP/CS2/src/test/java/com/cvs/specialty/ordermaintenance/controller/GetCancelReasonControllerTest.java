
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.GetCancelReasonApiController;
import com.cvs.specialty.ordermaintenance.model.CancelReason;
import com.cvs.specialty.ordermaintenance.service.impl.CancelOrderServiceImpl;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

/**
 * @author z242512
 *
 */

@RunWith(MockitoJUnitRunner.class)
public class GetCancelReasonControllerTest {
  @InjectMocks
  GetCancelReasonApiController getCancelReasonApiController;

  @Mock
  CancelOrderServiceImpl cancelOrderService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testGetCancelReasonOne() throws OrderMaintenanceException, Exception {

    CancelReason cancelReason = new CancelReason();
    List<CancelReason> result = new ArrayList<CancelReason>();
    when(cancelOrderService.getCancelReason()).thenReturn(result);
    cancelReason.put("RV_ABBREVIATION", "Renewal");
    cancelReason.put("RV_LOW_VALUE", "CANCEL_REASON_RENEWAL");
    result.add(cancelReason);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<List<CancelReason>> responseEntity = getCancelReasonApiController
      .getCancelReasonGet("testtoken", "12345", request, response);

    assertEquals(result, responseEntity.getBody());
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
