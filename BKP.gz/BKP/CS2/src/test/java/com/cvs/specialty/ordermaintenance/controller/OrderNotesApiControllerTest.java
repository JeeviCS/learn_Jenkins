
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.OrderNotesApiController;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;
import com.cvs.specialty.ordermaintenance.service.OrderNoteService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class OrderNotesApiControllerTest {

  @InjectMocks
  OrderNotesApiController OrderNotesController;

  @Mock
  OrderNoteService orderNoteService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Test
  public void orderNotesGetTest() throws OrderMaintenanceException, BindException, Exception {

    OrderNotes orderNotes = new OrderNotes();
    orderNotes.setAudit(null);
    orderNotes.setNoteType("noteType");
    orderNotes.setPatientIndetifier(new BigDecimal(1234));
    orderNotes.setPreOrderHeaderIdentifier(78890L);
    orderNotes.setPreOrderNoteIdentifier(1233897L);
    orderNotes.setPreOrderNoteText("preOrderNoteText");
    orderNotes.setSourceSystemName("sourceSystemName");
    orderNotes.setSourceSystemNoteIdentifier(new BigDecimal(67890));
    List<OrderNotes> orderNotesList = new ArrayList<OrderNotes>();
    orderNotesList.add(orderNotes);
    ResponseEntity<List<OrderNotes>> result = new ResponseEntity<>(orderNotesList, HttpStatus.OK);
    when(orderNoteService.getOrderNotes(1234)).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<List<OrderNotes>> responseEntity = OrderNotesController
      .orderNotesGet("tes", "testtoken", 1234, request, response);

    assertEquals(result.getBody(), responseEntity.getBody());
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  public void orderNotesPostTest() throws OrderMaintenanceException, BindException, Exception {
    OrderNotes orderNotes = new OrderNotes();
    orderNotes.setAudit(null);
    orderNotes.setNoteType("noteType");
    orderNotes.setPatientIndetifier(new BigDecimal(1234));
    orderNotes.setPreOrderHeaderIdentifier(78890L);
    orderNotes.setPreOrderNoteIdentifier(1233897L);
    orderNotes.setPreOrderNoteText("preOrderNoteText");
    orderNotes.setSourceSystemName("sourceSystemName");
    orderNotes.setSourceSystemNoteIdentifier(new BigDecimal(67890));
    ResponseEntity<Void> result = new ResponseEntity<>(null, HttpStatus.OK);
    when(orderNoteService.createOrderNotes(1234, "preOrderNoteText")).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<Void> responseEntity = OrderNotesController
      .orderNotesPost("tes", "testtoken", 1234, "preOrderNoteText", request, response);

    // assertEquals(result.getBody(), responseEntity.getBody());
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
