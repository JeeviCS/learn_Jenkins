package com.cvs.specialty.ordermaintenance.service;
import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.impl.CancelOrderDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.mapper.OrderCancelMapper;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.CancelReason;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
import com.cvs.specialty.ordermaintenance.service.impl.CancelOrderServiceImpl;



@RunWith(MockitoJUnitRunner.class)
public class CancelOrderServiceTest {

	@InjectMocks
	CancelOrderServiceImpl cancelOrderServiceImpl;
	
	@Mock
	CancelOrderDaoImpl cancelOrderdao;
	
	@Mock
	SpecialtyLogger serviceLogger;

	@Mock
	OrderCancelMapper orderCancelMapper;
	@Test
	public void testGetCancelReason()  {
		CancelReason cancelReason= new CancelReason();
		List<CancelReason> response = new ArrayList<CancelReason>();
		cancelReason.put("RV_ABBREVIATION", "DUE TO INSURANCE");
		cancelReason.put("RV_LOW_VALUE", "Cancel_Reaosn");
		response.add(cancelReason);
		List<CancelReason> cancelReasonList= new ArrayList<>();
		CancelReason map=new CancelReason();
		map.put("RV_LOW_VALUE", "Cancel_Reaosn");
		map.put("RV_ABBREVIATION", "DUE TO INSURANCE");
		cancelReasonList.add(map);


		when(cancelOrderdao.getCancelReason(any(), any()))
		.thenReturn(mockedCancelReasonCgRefCodeData());

		when(orderCancelMapper.getCancelReason(any())).thenReturn(cancelReasonList);
		List<CancelReason> responseEntity = cancelOrderServiceImpl.getCancelReason();
		assertEquals(response,responseEntity);
	}

	@Test
	public void updateCancelOrder_Exception() {

		when(cancelOrderdao.submitCancelOrder(null, "12345")).thenThrow(new RuntimeException() );

		CancelOrderResponse responseEntity = cancelOrderServiceImpl.submitCancelOrder(null, "12345", "testToken", "12345");

	}
	
	/*@Test
	public void updateCancelOrder_pass() {

		OrderCancelRequest orderCancelRequest = createOrderCancelRequest();
		CancelOrderResponse response = new CancelOrderResponse();
		response.setOrderId(1234L);
		response.setMessage("success");
		when(cancelOrderdao.submitCancelOrder(orderCancelRequest, "12345")).thenReturn(response);
		CancelOrderResponse responseEntity = cancelOrderServiceImpl.submitCancelOrder(orderCancelRequest, "12345", "testToken", "12345");
		assertEquals(response,responseEntity);
	}*/

	private OrderCancelRequest createOrderCancelRequest() {
		OrderCancelRequest orderCancelRequest =new OrderCancelRequest();
		orderCancelRequest.setOrderId(1234L);
		orderCancelRequest.setPatientId(1234l);
		orderCancelRequest.setMdNotifiedFlag(true);
		orderCancelRequest.setPatientNotifiedFlag(true);
		orderCancelRequest.setOrderCancelReason("reason");
		return orderCancelRequest;
	}
	
	private List<CgRefCode> mockedCancelReasonCgRefCodeData() {
		CgRefCode objOneCgRefCode = new CgRefCode();
		objOneCgRefCode.setRvLowValue("Cancel_Reaosn");
		CgRefCode objTwoCgRefCode = new CgRefCode();
		objTwoCgRefCode.setRvAbbreviation("DUE TO INSURANCE");
		List<CgRefCode> licgRefCode = new ArrayList<CgRefCode>();
		licgRefCode.add(objOneCgRefCode);
		licgRefCode.add(objTwoCgRefCode);
		return licgRefCode;
	}


}
