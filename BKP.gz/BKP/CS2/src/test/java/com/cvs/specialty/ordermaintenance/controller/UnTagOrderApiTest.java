
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.UnTagOrderApiController;
import com.cvs.specialty.ordermaintenance.model.*;
import com.cvs.specialty.ordermaintenance.service.UnTagOrderService;
import com.cvs.specialty.ordermaintenance.service.impl.UnTagOrderServiceImpl;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

/**
 * UnTagOrder Controller test class
 * 
 * @author
 *
 */

@RunWith(MockitoJUnitRunner.class)
public class UnTagOrderApiTest {

  @InjectMocks
  UnTagOrderApiController unTagOrderApiController;

  @Mock
  UnTagOrderService unTagOrderService;

  @Mock
  UnTagOrderServiceImpl unTagOrderServiceImpl;

  @Mock
  SpecialtyLogger LOGGER;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testUnTagOrderGet() throws OrderMaintenanceException, BindException, Exception {

    ResponseEntity<List<UntagReasonCodes>> result = getUntagReasonsList();

    Integer preOrderId = 127460;
    String reasonCode = "02";
    when(unTagOrderService.getUntagReasonCodes(preOrderId, reasonCode))
      .thenReturn(getUntagReasonsList());

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<List<UntagReasonCodes>> responseEntity = unTagOrderApiController
      .unTagOrderGet("1", "1", preOrderId, reasonCode, request, response);

    Assert.assertNotNull("Service response is not null", responseEntity.getBody());
    Assert.assertTrue("Reason Codes found", responseEntity.getStatusCode() == HttpStatus.OK);

  }

  @Test
  public void testUnTagOrderPost() throws OrderMaintenanceException, BindException, Exception {

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<Void> responseEntity = unTagOrderApiController
      .unTagOrderPost("1", "1", 1, new BigDecimal(02), createUntagOrder(), request, response);
    Assert.assertNotNull("Service response is not null", responseEntity);
    assertEquals(200, Integer.parseInt(responseEntity.getStatusCode().toString()));

  }

  /**
   * Get the mock UntagReasons List
   * 
   * @return
   */

  private ResponseEntity<List<UntagReasonCodes>> getUntagReasonsList() {

    List<UntagReasonCodes> unTagReasonsList = getUntagReasons();

    return new ResponseEntity<List<UntagReasonCodes>>(unTagReasonsList, HttpStatus.OK);
  }

  private List<UntagReasonCodes> getUntagReasons() {
    List<UntagReasonCodes> unTagReasonCodes = new ArrayList<UntagReasonCodes>();

    UntagReasonCodes unTagReasons = new UntagReasonCodes();
    unTagReasons.setUntagReasonCode("01");
    unTagReasons.setUntagReasonDesc("TEST CODE");
    unTagReasonCodes.add(unTagReasons);
    return unTagReasonCodes;
  }

  /**
   * Set the mock request object for UnTagOrder
   * 
   * @return
   */
  private List<RxDetailsList> createUntagOrder() {

    List<RxDetailsList> rxDetailsList = new ArrayList<RxDetailsList>();

    RxDetailsList rxDetails = new RxDetailsList();
    Drug drug = new Drug();
    Prescription presc = new Prescription();
    PrescriptionDispense prescDisp = new PrescriptionDispense();

    // ---------DRUG------------------- drug.setDrugIdentifier(57084);
    drug.setDrugName("GABAPENTIN # (GREENSTONE)");
    drug.setDrugStrengthText("600MG");
    drug.setMetricQuantity((float) 0);
    drug.setUnitsQuantity(100);

    // ------PRESCRIPTION---------------- presc.setDrugIdentifier("57084");
    presc.setPrescriptionIdentifier(4003250);
    presc.setPrescriptionNumber(new BigDecimal(26));

    // -----PRESCRIPTION DISPENSE--------
    prescDisp.setPrescriptionDispenseIdentifier(11341461);
    prescDisp.setUntagReasonCode(new BigDecimal(02));

    // -------RxDetails------------------- rxDetails.setDrug(drug);
    rxDetails.setPrescription(presc);
    rxDetails.setPrescriptionDispense(prescDisp);
    rxDetails.setQuantityOnHand(15);
    rxDetails.setRx_copay(0);
    rxDetails.setRx_daySupply(5);
    rxDetails.setRx_medication("GABAPENTIN # (GREENSTONE)");
    rxDetails.setRx_onHand(15);
    rxDetails.setRx_quantity(5);
    rxDetails.setRx_rxNumber(26);
    rxDetails.setRx_strength("600MG");

    rxDetailsList.add(rxDetails);

    return rxDetailsList;

  }
}
