
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.ShippingDetailsDao;
import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;
import com.cvs.specialty.ordermaintenance.service.impl.ShippingDetailsServiceImpl;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class ShippingDetailsServiceImplTest {

  @InjectMocks
  ShippingDetailsServiceImpl shippingDetailsService;

  @Mock
  ShippingDetailsDao shippingDetailsDao;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void getShippingDetailsTest() throws OrderMaintenanceException, BindException, Exception {

    ShipmentDetails shipmentDetails = new ShipmentDetails();
    shipmentDetails.setAddress1("address");
    shipmentDetails.setAnticipatedDate(new Date());
    shipmentDetails.setCity("city");
    shipmentDetails.setShippedLocation("shippedLocation");

    when(shippingDetailsDao.getShippingDetails(12L, "status", "1234")).thenReturn(shipmentDetails);

    ResponseEntity<ShipmentDetails> responseEntity = shippingDetailsService
      .getShippingDetails(12L, "status", "1234");

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(shipmentDetails, responseEntity.getBody());
  }

}
