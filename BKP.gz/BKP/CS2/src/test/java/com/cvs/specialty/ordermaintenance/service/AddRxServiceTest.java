/*
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.AddRxOrderDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.impl.AddRxOrderServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class AddRxServiceTest {

  @InjectMocks
  AddRxOrderServiceImpl addRxOrderServiceImpl;

  @Mock
  AddRxOrderDao addRxOrderDao;

  @Mock
  SpecialtyLogger Logger;

  @Test
  public void testAddRxOrder() {

    RxDetailsList orderList = new RxDetailsList();
    orderList.setDiversion("diversion");
    List<RxDetailsList> rxDetailsList = new ArrayList<RxDetailsList>();
    rxDetailsList.add(orderList);

    // ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.OK);

    List<RxDetailsList> rxDetailsResponse = new ArrayList<RxDetailsList>();

    when(addRxOrderDao.addRxorder(rxDetailsList, 1234L)).thenReturn(rxDetailsResponse);
    // assertEquals(rxDetailsResponse,addRxOrderServiceImpl.addRxorder(rxDetailsList, 1234L));
    assertNull(addRxOrderServiceImpl.addRxorder(rxDetailsList, 1234L));
  }

}
*/