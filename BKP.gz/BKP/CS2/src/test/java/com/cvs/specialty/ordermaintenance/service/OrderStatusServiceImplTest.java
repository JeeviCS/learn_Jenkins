
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.OrderStatusDao;
import com.cvs.specialty.ordermaintenance.service.impl.OrderStatusServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class OrderStatusServiceImplTest {

  @InjectMocks
  OrderStatusServiceImpl orderStatusService;

  @Mock
  OrderStatusDao orderstat;

  @Mock
  SpecialtyLogger Logger;

  @Test
  public void updateOrderStatusTest() {

    when(orderstat.updateOrderStatus(12L)).thenReturn(null);

    ResponseEntity<Void> responseEntity = orderStatusService.updateOrderStatus(12L);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
