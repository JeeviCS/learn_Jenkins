
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.ShippingInformationApiController;
import com.cvs.specialty.ordermaintenance.model.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.service.ShippingInformationService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class ShippingInformationApiControllerTest {

  @InjectMocks
  ShippingInformationApiController shippingInformationController;

  @Mock
  ShippingInformationService shippingInformationService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void shippingInformationGetTest()
      throws OrderMaintenanceException, BindException, Exception {

    PreOrderHeader preOrderHeader = new PreOrderHeader();

    preOrderHeader.setActiveIndicator("activeIndicator");
    preOrderHeader.setCompanyIdentifier("companyIdentifier");
    preOrderHeader.setHbsNumber("hbsNumber");
    preOrderHeader.setShipmentNumber("shipmentNumber");

    ResponseEntity<PreOrderHeader> result = new ResponseEntity<>(

      HttpStatus.OK);
    when(shippingInformationService.getShippingInfo(12L, 1L)).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<PreOrderHeader> responseEntity = shippingInformationController
      .shippingInformationGet("Test", "Token", 12L, 1L, request, response);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @SuppressWarnings("unused")
  @Test
  public void shippingInformationPutTest()
      throws OrderMaintenanceException, BindException, Exception {

    PreOrderHeader preOrderHeader = new PreOrderHeader();
    List<PreOrderHeader> preOrderHeaderList = new ArrayList<>();
    preOrderHeader.setActiveIndicator("activeIndicator");
    preOrderHeader.setCompanyIdentifier("companyIdentifier");
    preOrderHeader.setHbsNumber("hbsNumber");
    preOrderHeader.setShipmentNumber("shipmentNumber");

    ResponseEntity<Void> result = new ResponseEntity<>(HttpStatus.OK);

    when(shippingInformationService.updateShippingDetails(12L, 1L, preOrderHeader))
      .thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<Void> responseEntity = shippingInformationController
      .shippingInformationPut("Test", "Token", 12L, 1L, preOrderHeader, request, response);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

  }

}
