
package com.cvs.specialty.ordermaintenance.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.RxDetailsDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.impl.RxDetailsServiceImpl;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.class)
public class RxDetailsServiceImplTest {

  @InjectMocks
  RxDetailsServiceImpl rxDetailsService;

  @Mock
  RxDetailsDao rxDetailsDao;

  @Mock
  SpecialtyLogger LOGGER;

  @Test
  public void rxDetailsListGetTest() {

    RxDetailsList rxDetailsList = new RxDetailsList();
    rxDetailsList.setRx_rxNumber(1234L);
    rxDetailsList.setRx_medication("TYLANOL");
    rxDetailsList.setRx_strength("20Mg");
    rxDetailsList.setRx_quantity(10);
    rxDetailsList.setRx_daySupply(5);
    rxDetailsList.setRx_onHand(2);
    rxDetailsList.setRx_copay(20);
    rxDetailsList.setDiversion("testdiversion");
    List<RxDetailsList> rxDetailslist = new ArrayList<RxDetailsList>();
    rxDetailslist.add(rxDetailsList);

    when(rxDetailsDao.rxDetailsGet(3, 12)).thenReturn(rxDetailslist);
    ResponseEntity<List<RxDetailsList>> result = rxDetailsService.rxDetailsListGet(3, 12);
    Assert.assertEquals(rxDetailslist, result.getBody());
    Assert.assertEquals(HttpStatus.OK, result.getStatusCode());
  }

}
