
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.ShippingInformationDao;
import com.cvs.specialty.ordermaintenance.model.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.service.impl.ShippingInformationServiceImpl;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class ShippingInformationServiceImplTest {

  @InjectMocks
  ShippingInformationServiceImpl shippingInformationService;

  @Mock
  ShippingInformationDao shippingInformationDao;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void getShippingDetailsTest() throws OrderMaintenanceException, BindException, Exception {

    PreOrderHeader preOrderHeader = new PreOrderHeader();
    List<PreOrderHeader> preOrderHeaderList = new ArrayList<>();
    preOrderHeader.setActiveIndicator("activeIndicator");
    preOrderHeader.setCompanyIdentifier("companyIdentifier");
    preOrderHeader.setHbsNumber("hbsNumber");
    preOrderHeader.setShipmentNumber("shipmentNumber");
    preOrderHeaderList.add(preOrderHeader);

    when(shippingInformationDao.getShippingDetails(12L, "status")).thenReturn(preOrderHeaderList);

    ResponseEntity<List<PreOrderHeader>> responseEntity = shippingInformationService
      .getShippingDetails(12L, "status");

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(preOrderHeaderList, responseEntity.getBody());
  }

  @SuppressWarnings("unused")
  @Test
  public void updateShippingDetailsTest()
      throws OrderMaintenanceException, BindException, Exception {

    PreOrderHeader preOrderHeader = new PreOrderHeader();
    List<PreOrderHeader> preOrderHeaderList = new ArrayList<>();
    preOrderHeader.setActiveIndicator("activeIndicator");
    preOrderHeader.setCompanyIdentifier("companyIdentifier");
    preOrderHeader.setHbsNumber("hbsNumber");
    preOrderHeader.setShipmentNumber("shipmentNumber");

    when(shippingInformationDao.updateShippingDetails(12L, preOrderHeader)).thenReturn(null);

    ResponseEntity<Void> responseEntity = shippingInformationService
      .updateShippingDetails(12L, 1234L, preOrderHeader);

    assertNull(responseEntity);

  }

  @Test
  public void getShippingInfoTest() throws OrderMaintenanceException, BindException, Exception {

    PreOrderHeader preOrderHeader = new PreOrderHeader();

    preOrderHeader.setActiveIndicator("activeIndicator");
    preOrderHeader.setCompanyIdentifier("companyIdentifier");
    preOrderHeader.setHbsNumber("hbsNumber");
    preOrderHeader.setShipmentNumber("shipmentNumber");

    when(shippingInformationDao.getShippingInfo(12L, 1L)).thenReturn(preOrderHeader);

    ResponseEntity<PreOrderHeader> responseEntity = shippingInformationService
      .getShippingInfo(12L, 1L);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(preOrderHeader, responseEntity.getBody());
  }

}
