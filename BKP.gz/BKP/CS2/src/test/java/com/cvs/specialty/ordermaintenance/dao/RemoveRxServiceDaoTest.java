package com.cvs.specialty.ordermaintenance.dao;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.impl.RemoveRxServiceDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.ItemEO;
import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionEO;
import com.cvs.specialty.ordermaintenance.repository.*;

@RunWith(MockitoJUnitRunner.class)
public class RemoveRxServiceDaoTest {

  @InjectMocks
  private RemoveRxServiceDaoImpl removeRxServiceDaoImpl;

  @Mock
  private PreOrderDetailRepo preOrderDetailRepo;

  @Mock
  private PrescriptionRepo prescriptionRepo;
  
  @Mock
  SpecialtyLogger LOGGER;

  @Mock
  private ItemsRepo itemsRepo;

  @Mock
  private PreOrderHeaderRepo preOrderHeaderRepo;
  
  @Test
  public void removeRxTest() {
    
    long preOrderId = 1234;
    long rxNumber = 1243;
    String medication = "testmedication";
    String strength = "teststrength";
    
    PreOrderHeader preOrderHeader = createPreOrderHeader();
    ItemEO itemEO = createItemEO();
    PrescriptionEO prescriptionEO = createPrescriptionEO();
    BigDecimal patientId = preOrderHeader.getPtntId();
    
    when(preOrderHeaderRepo.findByPreOrdrHdrId(preOrderId)).thenReturn(preOrderHeader);
    when(itemsRepo.findByItemNameAndStrengthTxt(medication, strength)).thenReturn(itemEO);
    when(prescriptionRepo.findByRxNumberAndPatientId(new BigDecimal(rxNumber), patientId)).thenReturn(prescriptionEO);
    //when(preOrderDetailRepo.deleteByPreOrdrHdrIdAndRxIdAndItem(new BigDecimal(preOrderId), new BigDecimal(prescriptionEO.getId()), itemEO)).thenReturn(null);
    
    //assertNull(removeRxServiceDaoImpl.removeRx(preOrderId, rxNumber, medication, strength));
    
  }

  private PrescriptionEO createPrescriptionEO() {
    PrescriptionEO prescriptionEO = new PrescriptionEO();
    prescriptionEO.setId(1234L);
    return prescriptionEO;
  }

  private PreOrderHeader createPreOrderHeader() {

    PreOrderHeader preOrderHeader = new PreOrderHeader();
    preOrderHeader.setOrdrStusCd("testorderstatus");
    preOrderHeader.setOrdrStusRsnCd("testorderstatusreason");
    preOrderHeader.setPtntId(new BigDecimal(1234));
    //preOrderHeader.set();
    return preOrderHeader;
  }
  
  private ItemEO createItemEO() {
    ItemEO itemEO = new ItemEO();
    
    return itemEO;
  }
}