
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.validation.BindException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.ShippingDetailsApiController;
import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;
import com.cvs.specialty.ordermaintenance.service.ShippingDetailsService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@RunWith(MockitoJUnitRunner.class)
public class ShippingDetailsApiControllerTest {

  @InjectMocks
  ShippingDetailsApiController shippingDetailsController;

  @Mock
  ShippingDetailsService shippingDetailsService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

 
  @Test
  public void shippingDetailsGetTest() throws OrderMaintenanceException, BindException, Exception {

    ShipmentDetails shipmentDetails = new ShipmentDetails();
    shipmentDetails.setAddress1("address");
    shipmentDetails.setAnticipatedDate(new Date());
    shipmentDetails.setCity("city");
    shipmentDetails.setShippedLocation("shippedLocation");

    ResponseEntity<ShipmentDetails> result = new ResponseEntity<>(shipmentDetails, HttpStatus.OK);
    when(shippingDetailsService.getShippingDetails(12L, "status", "1234")).thenReturn(result);

    HttpServletRequest request = (HttpServletRequest) new MockHttpServletRequest();
    request.setAttribute("user-id", "1234");
    request.setAttribute("message-id", "testmessageid");
    HttpServletResponse response = (HttpServletResponse) new MockHttpServletResponse();

    ResponseEntity<ShipmentDetails> responseEntity = shippingDetailsController
      .shippingDetailsGet("test", "testtoken", 12L, "status", "1234", request, response);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

}
