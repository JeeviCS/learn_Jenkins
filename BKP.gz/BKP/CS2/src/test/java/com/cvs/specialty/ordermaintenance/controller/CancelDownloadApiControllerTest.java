/*
package com.cvs.specialty.ordermaintenance.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.api.CancelDownloadApiController;
import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.service.CancelDownloadService;

@RunWith(MockitoJUnitRunner.class)
public class CancelDownloadApiControllerTest {

  @InjectMocks
  CancelDownloadApiController cancelDownloadController;

  @Mock
  CancelDownloadService cancelDownloadService;

  @Mock
  SpecialtyLogger serviceLogger;

  @Before
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

 
  @Test
  public void cancelDownloadGetTest() {

    CanceDownloadReasonCodes cancelDownloadReasonCodes = new CanceDownloadReasonCodes();

    cancelDownloadReasonCodes.setCode("O");

    List<CanceDownloadReasonCodes> code = new ArrayList<CanceDownloadReasonCodes>();
    code.add(cancelDownloadReasonCodes);

    ResponseEntity<List<CanceDownloadReasonCodes>> response;
    response = new ResponseEntity<List<CanceDownloadReasonCodes>>(code, HttpStatus.OK);
    when(cancelDownloadService.cancelDownloadGet(123)).thenReturn(response);

    ResponseEntity<List<CanceDownloadReasonCodes>> responseEntity = cancelDownloadController
      .cancelDownloadGet("123", "456", "test", 123);

    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    assertEquals(response.getBody(), responseEntity.getBody());
  }

}
*/