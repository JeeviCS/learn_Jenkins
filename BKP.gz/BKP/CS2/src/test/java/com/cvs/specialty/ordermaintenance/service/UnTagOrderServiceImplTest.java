package com.cvs.specialty.ordermaintenance.service;

import static org.mockito.Mockito.doReturn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.dao.impl.UnTagOrderDaoImpl;
import com.cvs.specialty.ordermaintenance.model.Drug;
import com.cvs.specialty.ordermaintenance.model.Prescription;
import com.cvs.specialty.ordermaintenance.model.PrescriptionDispense;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.model.UntagReasonCodes;
import com.cvs.specialty.ordermaintenance.service.impl.UnTagOrderServiceImpl;


/**
 * UnTagOrder Service test cases
 * @author 
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class UnTagOrderServiceImplTest {

	@Rule
    public ExpectedException thrown = ExpectedException.none();
	
	 @Mock
	 UnTagOrderServiceImpl unTagOrderServiceImpl;
	
	 @Mock
	 UnTagOrderDaoImpl unTagOrderDaoImpl;

	@Test
	public void testUnTagRxorder() {
		
		
		ResponseEntity<?> response = unTagOrderServiceImpl.unTagRxorder(createUntagOrder(), 1, new BigDecimal(02));
		
		Assert.assertNull("Response not null", response);
	}
	
	@Test
	public void testGetUntagReasonCodes() {

		doReturn(getUntagReasonsList()).when(unTagOrderServiceImpl).getUntagReasonCodes(1, "shipped");
		
		ResponseEntity<List<UntagReasonCodes>> response = unTagOrderServiceImpl.getUntagReasonCodes(1, "shipped");
		
		Assert.assertNotNull("Service response is not null", response);
		Assert.assertTrue("Reason Codes found", response.getStatusCode() == HttpStatus.OK);
	}
	

	/**
	 * Get the mock UntagReasons List
	 * 
	 * @return
	 */
	private ResponseEntity<List<UntagReasonCodes>> getUntagReasonsList() {

		List<UntagReasonCodes> unTagReasonsList = getUntagReasons();

		return new ResponseEntity<List<UntagReasonCodes>>(unTagReasonsList, HttpStatus.OK);
	}

	private List<UntagReasonCodes> getUntagReasons() {
		List<UntagReasonCodes> unTagReasonCodes = new ArrayList<UntagReasonCodes>();
		
		UntagReasonCodes unTagReasons = new UntagReasonCodes();
		for(int i=0;i<5;i++) {
			unTagReasons.setUntagReasonCode(Integer.toString(i));
			unTagReasons.setUntagReasonDesc("TEST"+i+" Desc");	
			unTagReasonCodes.add(unTagReasons);
		}
		
		
		return unTagReasonCodes;
	}

	/**
	 * Set the mock request object for untag order
	 * 
	 * @return
	 */
	private List<RxDetailsList> createUntagOrder() {
		
		List<RxDetailsList> rxDetailsList = new ArrayList<RxDetailsList>();
		
		RxDetailsList rxDetails = new RxDetailsList();
		Drug drug = new Drug();
		Prescription presc = new Prescription();
		PrescriptionDispense prescDisp = new PrescriptionDispense();
		
		//---------DRUG-------------------
		drug.setDrugIdentifier(57084);
		drug.setDrugName("GABAPENTIN # (GREENSTONE)");
		drug.setDrugStrengthText("600MG");
		drug.setMetricQuantity((float)0);
		drug.setUnitsQuantity(100);
		
		//------PRESCRIPTION----------------
		presc.setDrugIdentifier("57084");
		presc.setPrescriptionIdentifier(4003250);
		presc.setPrescriptionNumber(new BigDecimal(26));
		
		//-----PRESCRIPTION DISPENSE--------
		prescDisp.setPrescriptionDispenseIdentifier(11341461);
		prescDisp.setUntagReasonCode(new BigDecimal( 02));
		
		//-------RxDetails-------------------
		rxDetails.setDrug(drug);
		rxDetails.setPrescription(presc);
		rxDetails.setPrescriptionDispense(prescDisp);
		rxDetails.setQuantityOnHand(15);
		rxDetails.setRx_copay(0);
		rxDetails.setRx_daySupply(5);
		rxDetails.setRx_medication("GABAPENTIN # (GREENSTONE)");
		rxDetails.setRx_onHand(15);
		rxDetails.setRx_quantity(5);
		rxDetails.setRx_rxNumber(26);
		rxDetails.setRx_strength("600MG");
		
		rxDetailsList.add(rxDetails);
		
		return rxDetailsList;
		
	}
}

