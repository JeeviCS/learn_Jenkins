
package com.cvs.specialty.ordermaintenance.service;

import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.RemoveRxServiceDao;
import com.cvs.specialty.ordermaintenance.service.impl.RemoveRxServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class RemoveRxServiceImplTest {

  @InjectMocks
  RemoveRxServiceImpl removeRxService;

  @Mock
  RemoveRxServiceDao removeRxServiceDao;

  @Mock
  SpecialtyLogger serviceLogger;

  @Test
  public void removeRxTest() {

    Void response1 = null;
 /*   List<RxDetailsList> list = new ArrayList<RxDetailsList>();
    when(removeRxServiceDao.removeRx(123, 456, "TYLANOL", "20Mg")).thenReturn(response1);
    assertNull(removeRxServiceDao.removeRx(123, 456, "TYLANOL", "20Mg"));
    assertNull(removeRxService.removeRx(123, 456, "TYLANOL", "20Mg"));
*/
  }
}
