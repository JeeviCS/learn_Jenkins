
package com.cvs.specialty.ordermaintenance.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.impl.OrderNumberInfoDaoImpl;
import com.cvs.specialty.ordermaintenance.model.OrderSatCode;
import com.cvs.specialty.ordermaintenance.repository.OrderNumberInfoRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;

@RunWith(MockitoJUnitRunner.class)
public class OrderNumberInfoDaoTest {

  @InjectMocks
  private OrderNumberInfoDaoImpl orderNumberInfoDaoImpl;

  @Mock
  private OrderNumberInfoRepo orderInfoRepo;

  @SuppressWarnings("rawtypes")
  @Mock
  private PreOrderHeaderRepo preOrderHeaderRepo;

  @Mock
  SpecialtyLogger LOGGER;

  @Test
  public void getOrderInfoTest() {

    long orderGuideNumber = 1234;
    long preOrderId = 1324;
    List<Object> prescriptionDispOrders = createPrescriptionDispOrders();
    Object preOrderHeader = createPreOrderHeader();

    when(orderInfoRepo.findByOrderGudieNumber2(new BigDecimal(orderGuideNumber)))
      .thenReturn(prescriptionDispOrders);
    when(preOrderHeaderRepo.findordersatcode(preOrderId)).thenReturn(preOrderHeader);

    OrderSatCode response = orderNumberInfoDaoImpl.getOrderInfo(preOrderId);

    OrderSatCode orderSatCode = createOrderSatCode(preOrderHeader, prescriptionDispOrders);

    assertEquals(orderSatCode.getOrderStatusCode(), response.getOrderStatusCode());
  }

  private
      OrderSatCode
      createOrderSatCode(Object preOrderHeader, List<Object> prescriptionDispOrders) {

    Object[] obj = (Object[]) preOrderHeader;

    OrderSatCode orderSatCodes = new OrderSatCode();
    orderSatCodes.setOrderStatusCode(String.valueOf(obj[1]));
    orderSatCodes.setOrderStatusReasonCode(String.valueOf(obj[2]));
    orderSatCodes.setPatientIdentifier(String.valueOf(obj[0]));

    return orderSatCodes;
  }

  private Object createPreOrderHeader() {
    Object[] preOrderHeader = new Object[4];

    preOrderHeader[0] = "testorderstatus";
    preOrderHeader[1] = "testorderstatusreasoncode";
    preOrderHeader[2] = "testpatientid";
    preOrderHeader[3] = "testhbs";

    return preOrderHeader;
  }

  private List<Object> createPrescriptionDispOrders() {

    List<Object> prescriptionDispOrders = new ArrayList<Object>();

    Object[] prescriptionDispOrder = new Object[3];
    prescriptionDispOrder[0] = "testordernumber";
    prescriptionDispOrder[1] = "testshipemntnumber";
    prescriptionDispOrder[2] = "testorderstatus";
    prescriptionDispOrders.add(prescriptionDispOrder);

    return prescriptionDispOrders;
  }

}
