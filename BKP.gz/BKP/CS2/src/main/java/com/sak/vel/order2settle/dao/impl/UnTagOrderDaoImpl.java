
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.UnTagOrderDao;
import com.cvs.specialty.ordermaintenance.entity.*;
import com.cvs.specialty.ordermaintenance.model.PrescriptionDispense;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.model.UntagReasonCodes;
import com.cvs.specialty.ordermaintenance.repository.*;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class UnTagOrderDaoImpl implements UnTagOrderDao {

	@Autowired
	PreOrderDetailRepo preOrderDetailRepo;

	@SuppressWarnings("rawtypes")
	@Autowired
	PreOrderHeaderRepo preOrderHeaderRepo;
	@Autowired
	PrescriptionRepo prescriptionRepo;
	@Autowired
	ItemsRepo itemsRepo;
	@Autowired
	PrescriptionDispensesRepo prescriptionDispensesRepo;
	@Autowired
	UntagReasonRepo untagReasonRepo;

	@Autowired
	SpecialtyLogger LOGGER;

	@Override
	public List<UntagReasonCodes> getUntagReasonCodes(long preOrderId, String status) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		List<UntagReasonCodes> response = new ArrayList<UntagReasonCodes>();
		try {

			List<CgRefCode> cgRefCode = new ArrayList<CgRefCode>();

			cgRefCode = untagReasonRepo.findByRvDomain("UNTAG_REASON_CODE");

			System.out.println(cgRefCode);

			for (int i = 0; i < cgRefCode.size(); i++) {
				UntagReasonCodes untagReasonCodes = new UntagReasonCodes();
				untagReasonCodes.setUntagReasonCode(cgRefCode.get(i).getRvLowValue());
				untagReasonCodes.setUntagReasonDesc(cgRefCode.get(i).getRvAbbreviation());
				response.add(untagReasonCodes);
			}
			// return response;
		} catch (DataAccessException e) {
			System.out.println("Failed to get the Untag Reasons " + e.getMessage());
		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return response;
	}

	@SuppressWarnings({ "unused", "unchecked" })
	@Override
	public List<RxDetailsList> unTagRxorder(List<RxDetailsList> unTagRx, long orderId, BigDecimal reasonCode) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		for (int i = 0; i < unTagRx.size(); i++) {

			PreOrderDetailEO preOrderDetailEO = new PreOrderDetailEO();

			PrescriptionDispensesEO prescriptionDispensesEO = new PrescriptionDispensesEO();

			PreOrderHeader preOrderHeader = new PreOrderHeader();

			PrescriptionEO prescriptionEo = new PrescriptionEO();

			PrescriptionDispense prescDisp = new PrescriptionDispense();

			try {
				// fetch the existing pre_order_header entity
				preOrderHeader = preOrderHeaderRepo.findByPreOrdrHdrId(orderId);

				System.out.println("Drug Name: " + unTagRx.get(i).getRx_medication() + "\nDrug Strength"
						+ unTagRx.get(i).getRx_strength());

				System.out.println("PreHeader order ID: " + orderId);

				// if order is open then only do split
				if (preOrderHeader.getOrdrStusCd().equalsIgnoreCase("s")) {
					ItemEO itemEO = itemsRepo.findByItemId(unTagRx.get(i).getRx_drugIdentifier());

					prescriptionEo = prescriptionRepo.findByRxNumberAndPatientId(
							new BigDecimal(unTagRx.get(i).getRx_rxNumber()), preOrderHeader.getPtntId());

					System.out.println("Prescription ID: " + prescriptionEo.getId());

					// getting a Prescription_dispenses ID
					// getting a Prescription_dispenses ID
					prescriptionDispensesEO = prescriptionDispensesRepo
							.findById(unTagRx.get(i).getRx_PrescriptionDispenseIdentifier());

					System.out.println("Prescription Dispense ID: " + prescriptionDispensesEO.getId());
					// fetching the preOrderDetailEO record
					preOrderDetailEO = preOrderDetailRepo.findByPreOrdrHdrIdAndRxIdAndItemAndPrescriptionDispens(
							new BigDecimal(orderId), new BigDecimal(prescriptionEo.getId()), itemEO,
							prescriptionDispensesEO);

					// deleting the pre-order-detail
					preOrderDetailRepo.delete(preOrderDetailEO);

					// saving the Rx's with new Pre-order-header-id /////////////////////////////

					// copying the conetent to new entity
					PreOrderHeader2 preOrderHeader2 = new PreOrderHeader2();

					preOrderHeader2.setPatAddrId(preOrderHeader.getPatAddrId());
					preOrderHeader2.setArvOnByCd(preOrderHeader.getArvOnByCd());
					preOrderHeader2.setCmpnyId(preOrderHeader.getCmpnyId());
					preOrderHeader2.setCnfrmDlvryToAddrIn(preOrderHeader.getCnfrmDlvryToAddrIn());
					preOrderHeader2.setCrteTs(preOrderHeader.getCrteTs());
					preOrderHeader2.setCrteUsrNm(preOrderHeader.getCrteUsrNm());
					preOrderHeader2.setExhstDt(preOrderHeader.getExhstDt());
					preOrderHeader2.setFlupDt(preOrderHeader.getFlupDt());
					preOrderHeader2.setInqRsltId(preOrderHeader.getInqRsltId());
					preOrderHeader2.setOrdrRqstCmpltnDt(preOrderHeader.getOrdrRqstCmpltnDt());
					preOrderHeader2.setOrdrSchdId(preOrderHeader.getOrdrSchdId());
					preOrderHeader2.setOrdrSchdPrcsStusId(preOrderHeader.getOrdrSchdPrcsStusId());
					preOrderHeader2.setOrdrStusCd("O");
					preOrderHeader2.setOrdrStusRsnCd(preOrderHeader.getOrdrStusRsnCd());
					preOrderHeader2.setPhmcyId(preOrderHeader.getPhmcyId());
					// preOrderHeader2.setPreOrderNotes(preOrderHeader.getPreOrderNotes());

					// adding new
					// preOrderHeader2.setPreOrdrHdrId(preOrderHeader.getPreOrdrHdrId()+1);

					preOrderHeader2.setPtntId(preOrderHeader.getPtntId());
					preOrderHeader2.setPtntSgntrRqrdIn(preOrderHeader.getPtntSgntrRqrdIn());
					preOrderHeader2.setShipmentNumber(preOrderHeader.getShipmentNumber());
					preOrderHeader2.setShpmtMthdCd(preOrderHeader.getShpmtMthdCd());
					preOrderHeader2.setSrcOrdrNbTx(preOrderHeader.getSrcOrdrNbTx());
					preOrderHeader2.setSrcSystmId(preOrderHeader.getSrcSystmId());
					preOrderHeader2.setUpdTs(preOrderHeader.getUpdTs());
					preOrderHeader2.setUpdUsrNm(preOrderHeader.getCrteUsrNm());
					preOrderHeader2.setSrcSystmNm(preOrderHeader.getSrcSystmNm());

					// saving new entity
					// preOrderHeaderRepo.flush();
					preOrderHeaderRepo.save(preOrderHeader2);

					preOrderDetailEO.setRxId(new BigDecimal(prescriptionEo.getId()));
					// unTagRx.get(i).getPrescriptionDispense().getUntagReasonCode()
					prescriptionDispensesEO.setUntagReasonCode(reasonCode);
					preOrderDetailEO.setPrescriptionDispens(prescriptionDispensesEO);

					// preOrderDetailEO.setPreOrdrHdrId(new BigDecimal(preOrderId+1));

					System.out.println(preOrderHeaderRepo.count() + "--- " + preOrderHeader2.getPreOrdrHdrId());
					preOrderDetailEO.setPreOrdrHdrId(new BigDecimal(preOrderHeader2.getPreOrdrHdrId()));

					preOrderDetailEO.setItem(itemEO);

					if (itemEO != null && prescriptionDispensesEO != null) {
						System.out.println(
								"Item and Prescription dispenses are not null ; preOrderDetail's preOrderheaderId : "
										+ preOrderDetailEO.getPreOrdrHdrId());
						preOrderDetailRepo.save(preOrderDetailEO);
					} else {
						if (itemEO == null) {
							System.out.println("itemEO is null");
						} else {
							System.out.println("Prescription dispense is null");
						}
					}

				} // end-if
			} catch (Exception e) {
				System.out.println(e.getMessage());
				throw new OrderMaintenanceException(e, "Exception");
			}
		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return null;
	}

}
