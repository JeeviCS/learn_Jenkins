package com.cvs.specialty.ordermaintenance.service;

import java.math.BigDecimal;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;

public interface  OrderDownloadProcessService {

	ResponseEntity<SbpEntityBpmProcessMap> createInstanceId(BigDecimal orderId, BigDecimal instanceId);
}
