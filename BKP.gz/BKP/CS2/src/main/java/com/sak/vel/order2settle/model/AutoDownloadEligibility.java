
package com.cvs.specialty.ordermaintenance.model;

import java.util.Date;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AutoDownloadEligibility
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class AutoDownloadEligibility {
  
	@JsonProperty("openDiversionIndicator")
	private Boolean openDiversionIndicator = null;

	@JsonProperty("rdsmIndicator")
	private String rdsmIndicator = null;
	
	@JsonProperty("arvOnByCd")
	private String arvOnByCd;

	@JsonProperty("dateIndicator")
	private Boolean dateIndicator = null;

	@JsonProperty("isMAJ")
	private String isMAJ = null;
	
	@JsonProperty("benefitCheckComplnIn")
	private String benefitCheckComplnIn = null;
	
	@JsonProperty("eligCheckIn")
	private String eligCheckIn = null;
	
	@JsonProperty("rxInfoCheckComplnIn")
	private String rxInfoCheckComplnIn = null;
	
	@JsonProperty("readyToFill")
	private String readyToFill = null;
	
	public String getIsMAJ() {
		return isMAJ;
	}

	public void setIsMAJ(String isMAJ) {
		this.isMAJ = isMAJ;
	}

	public String getBenefitCheckComplnIn() {
		return benefitCheckComplnIn;
	}

	public void setBenefitCheckComplnIn(String benefitCheckComplnIn) {
		this.benefitCheckComplnIn = benefitCheckComplnIn;
	}

	public String getEligCheckIn() {
		return eligCheckIn;
	}

	public void setEligCheckIn(String eligCheckIn) {
		this.eligCheckIn = eligCheckIn;
	}

	public String getRxInfoCheckComplnIn() {
		return rxInfoCheckComplnIn;
	}

	public void setRxInfoCheckComplnIn(String rxInfoCheckComplnIn) {
		this.rxInfoCheckComplnIn = rxInfoCheckComplnIn;
	}

	public String getReadyToFill() {
		return readyToFill;
	}

	public void setReadyToFill(String readyToFill) {
		this.readyToFill = readyToFill;
	}

	public String getRxVerifyFlag() {
		return rxVerifyFlag;
	}

	public void setRxVerifyFlag(String rxVerifyFlag) {
		this.rxVerifyFlag = rxVerifyFlag;
	}


	@JsonProperty("majStepsCompletionIndicator")
	private Boolean majStepsCompletionIndicator = null;

	@JsonProperty("claimIndicator")
	private Boolean claimIndicator = null;

	@JsonProperty("quantityDispensed")
	private Integer quantityDispensed = null;
	
	@JsonProperty("patientAddressId")
	private Integer patientAddressId = null;
	
	@JsonProperty("discontinueDate")
	private Date discontinueDate = null;
	
	@JsonProperty("patientSiteId")
	private Integer patientSiteId;
	
	@JsonProperty("prescriptionSiteId")
	private Integer prescriptionSiteId;
	
	public Integer getPatientSiteId() {
		return patientSiteId;
	}

	public void setPatientSiteId(Integer patientSiteId) {
		this.patientSiteId = patientSiteId;
	}

	public Integer getPrescriptionSiteId() {
		return prescriptionSiteId;
	}

	public void setPrescriptionSiteId(Integer prescriptionSiteId) {
		this.prescriptionSiteId = prescriptionSiteId;
	}

	public Integer getpatientSiteId() {
		return patientSiteId;
	}

	public void setpatientSiteId(Integer patientSiteId) {
		this.patientSiteId = patientSiteId;
	}

	public Date getDiscontinueDate() {
		return discontinueDate;
	}

	public void setDiscontinueDate(Date discontinueDate) {
		this.discontinueDate = discontinueDate;
	}


	@JsonProperty("address1")
  private String address1 = null;
	
	@JsonProperty("address2")
  private String address2 = null;
	
  @JsonProperty("state")
  private String state = null;
  
  @JsonProperty("zip")
  private Integer zip = null;
  
  @JsonProperty("prescriptionsOrderIndicator")
  private Boolean prescriptionsOrderIndicator = null;

  @JsonProperty("downloadExceptionPayorIndicator")
  private Boolean downloadExceptionPayorIndicator = null;

  @JsonProperty("downloadExceptionPatientTypeIndicator")
  private Boolean downloadExceptionPatientTypeIndicator = null;

  @JsonProperty("downloadExceptionDrugIndicator")
  private Boolean downloadExceptionDrugIndicator = null;

  @JsonProperty("exceptionSACIndicator")
  private Boolean exceptionSACIndicator = null;

  @JsonProperty("requiredMDOShipIndicator")
  private Boolean requiredMDOShipIndicator = null;

  @JsonProperty("physiciansOfficeIndicator")
  private Boolean physiciansOfficeIndicator = null;

  @JsonProperty("dispenseQtyIndicator")
  private Boolean dispenseQtyIndicator = null;

  @JsonProperty("npiRxPharmaIndicator")
  private Boolean npiRxPharmaIndicator = null;

  @JsonProperty("medispanStatusIndicator")
  private String medispanStatusIndicator = null;

  @JsonProperty("billingStatusCode")
  private String billingStatusCode = null;

  @JsonProperty("rxVerifyFlag")
  private String rxVerifyFlag = null;

  @JsonProperty("controlledSubstance")
  private String controlledSubstance = null;

  @JsonProperty("isDEAValid")
  private Boolean isDEAValid = null;

  @JsonProperty("isRestrictedPrescriber")
  private Boolean isRestrictedPrescriber = null;

  @JsonProperty("prescriptionVerifyFlag")
  private String prescriptionVerifyFlag = null;

  @JsonProperty("pegaEditsIndicator")
  private Boolean pegaEditsIndicator = null;

  @JsonProperty("allowDownloadIndicator")
  private Boolean allowDownloadIndicator = null;

  @JsonProperty("sigValid")
  private String sigValid = null;

  @JsonProperty("ndcNumber")
  private Integer ndcNumber;

  @JsonProperty("isTraceleer")
  private Boolean isTraceleer = null;

  @JsonProperty("isTraceleerFlagSetComplete")
  private Boolean isTraceleerFlagSetComplete = null;

  @JsonProperty("refrigInd")
  private String refrigInd = null;

  @JsonProperty("patientShipMismatchIndicator")
  private Boolean patientShipMismatchIndicator = null;

  @JsonProperty("dispenseEditEnginePassIndicator")
  private Boolean dispenseEditEnginePassIndicator = null;

  @JsonProperty("isAddresscorrect")
  private Boolean isAddresscorrect = null;

  @JsonProperty("isPrescriptionActive")
  private Boolean isPrescriptionActive = null;

  @JsonProperty("buMatchIndicator")
  private Boolean buMatchIndicator = null;

  @JsonProperty("isDrugValid")
  private String isDrugValid = null;

  @JsonProperty("isNeedsDateValid")
  private Date isNeedsDateValid = null;

  @JsonProperty("prescriptionCountIndicator")
  private Boolean prescriptionCountIndicator = null;

  @JsonProperty("prescriptionNeedsDateIndicator")
  private Boolean prescriptionNeedsDateIndicator = null;
  
  @JsonProperty("dxStatus")
  private String dxStatus = null;
  
  @JsonProperty("directions")
  private String directions = null;
  
  @JsonProperty("city")
  private String city = null;

  public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public String getDirections() {
	return directions;
}

public void setDirections(String directions) {
	this.directions = directions;
}

public Integer getNdcNumber() {
	return ndcNumber;
}

public void setNdcNumber(Integer ndcNumber) {
	this.ndcNumber = ndcNumber;
}

public String getDxStatus() {
	return dxStatus;
}

public void setDxStatus(String dxStatus) {
	this.dxStatus = dxStatus;
}

public String getSigValid() {
	return sigValid;
}

public void setSigValid(String sigValid) {
	this.sigValid = sigValid;
}


public String getAddressCategory() {
	return addressCategory;
}

public void setAddressCategory(String addressCategory) {
	this.addressCategory = addressCategory;
}


@JsonProperty("autoDownloadSwitchIndicator")
  private Boolean autoDownloadSwitchIndicator = null;
  
  @JsonProperty("addressCategory")
  private String addressCategory = null;

  public String getArvOnByCd() {
    return arvOnByCd;
  }

  public void setArvOnByCd(String arvOnByCd) {
    this.arvOnByCd = arvOnByCd;
  }

  public Integer getPatientAddressId() {
    return patientAddressId;
  }

  public void setPatientAddressId(Integer patientAddressId) {
    this.patientAddressId = patientAddressId;
  }

  public String getAddress1() {
    return address1;
  }

  public void setAddress1(String address1) {
    this.address1 = address1;
  }

  public String getAddress2() {
    return address2;
  }

  public void setAddress2(String address2) {
    this.address2 = address2;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public Integer getZip() {
    return zip;
  }

  public void setZip(Integer zip) {
    this.zip = zip;
  }

	public Integer getQuantityDispensed() {
		return quantityDispensed;
	}

	public void setQuantityDispensed(Integer quantityDispensed) {
		this.quantityDispensed = quantityDispensed;
	}

	public String getBillingStatusCode() {
		return billingStatusCode;
	}

	public void setBillingStatusCode(String billingStatusCode) {
		this.billingStatusCode = billingStatusCode;
	}

	public AutoDownloadEligibility openDiversionIndicator(Boolean openDiversionIndicator) {
		this.openDiversionIndicator = openDiversionIndicator;
		return this;
	}

	/**
	 * Get openDiversionIndicator
	 * 
	 * @return openDiversionIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getOpenDiversionIndicator() {
		return openDiversionIndicator;
	}

	public void setOpenDiversionIndicator(Boolean openDiversionIndicator) {
		this.openDiversionIndicator = openDiversionIndicator;
	}

	public String getRdsmIndicator() {
		return rdsmIndicator;
	}

	public void setRdsmIndicator(String rdsmIndicator) {
		this.rdsmIndicator = rdsmIndicator;
	}

	/**
	 * Get rdsmIndicator
	 * 
	 * @return rdsmIndicator
	 **/
	@ApiModelProperty(value = "")

	public AutoDownloadEligibility dateIndicator(Boolean dateIndicator) {
		this.dateIndicator = dateIndicator;
		return this;
	}

	/**
	 * Get dateIndicator
	 * 
	 * @return dateIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getDateIndicator() {
		return dateIndicator;
	}

	public void setDateIndicator(Boolean dateIndicator) {
		this.dateIndicator = dateIndicator;
	}

	public AutoDownloadEligibility isMAJ(String isMAJ) {
		this.isMAJ = isMAJ;
		return this;
	}

	/**
	 * Get isMAJ
	 * 
	 * @return isMAJ
	 **/
	@ApiModelProperty(value = "")

	public String getisMAJ() {
		return isMAJ;
	}

	public void setisMAJ(String isMAJ) {
		this.isMAJ = isMAJ;
	}

	public AutoDownloadEligibility majStepsCompletionIndicator(Boolean majStepsCompletionIndicator) {
		this.majStepsCompletionIndicator = majStepsCompletionIndicator;
		return this;
	}

	/**
	 * Get majStepsCompletionIndicator
	 * 
	 * @return majStepsCompletionIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getMajStepsCompletionIndicator() {
		return majStepsCompletionIndicator;
	}

	public void setMajStepsCompletionIndicator(Boolean majStepsCompletionIndicator) {
		this.majStepsCompletionIndicator = majStepsCompletionIndicator;
	}

	public AutoDownloadEligibility claimIndicator(Boolean claimIndicator) {
		this.claimIndicator = claimIndicator;
		return this;
	}

	/**
	 * Get claimIndicator
	 * 
	 * @return claimIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getClaimIndicator() {
		return claimIndicator;
	}

	public void setClaimIndicator(Boolean claimIndicator) {
		this.claimIndicator = claimIndicator;
	}

	public AutoDownloadEligibility prescriptionsOrderIndicator(Boolean prescriptionsOrderIndicator) {
		this.prescriptionsOrderIndicator = prescriptionsOrderIndicator;
		return this;
	}

	/**
	 * Get prescriptionsOrderIndicator
	 * 
	 * @return prescriptionsOrderIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getPrescriptionsOrderIndicator() {
		return prescriptionsOrderIndicator;
	}

	public void setPrescriptionsOrderIndicator(Boolean prescriptionsOrderIndicator) {
		this.prescriptionsOrderIndicator = prescriptionsOrderIndicator;
	}

	public AutoDownloadEligibility downloadExceptionPayorIndicator(Boolean downloadExceptionPayorIndicator) {
		this.downloadExceptionPayorIndicator = downloadExceptionPayorIndicator;
		return this;
	}

	/**
	 * Get downloadExceptionPayorIndicator
	 * 
	 * @return downloadExceptionPayorIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getDownloadExceptionPayorIndicator() {
		return downloadExceptionPayorIndicator;
	}

	public void setDownloadExceptionPayorIndicator(Boolean downloadExceptionPayorIndicator) {
		this.downloadExceptionPayorIndicator = downloadExceptionPayorIndicator;
	}

	public AutoDownloadEligibility downloadExceptionPatientTypeIndicator(
			Boolean downloadExceptionPatientTypeIndicator) {
		this.downloadExceptionPatientTypeIndicator = downloadExceptionPatientTypeIndicator;
		return this;
	}

	/**
	 * Get downloadExceptionPatientTypeIndicator
	 * 
	 * @return downloadExceptionPatientTypeIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getDownloadExceptionPatientTypeIndicator() {
		return downloadExceptionPatientTypeIndicator;
	}

	public void setDownloadExceptionPatientTypeIndicator(Boolean downloadExceptionPatientTypeIndicator) {
		this.downloadExceptionPatientTypeIndicator = downloadExceptionPatientTypeIndicator;
	}

	public AutoDownloadEligibility downloadExceptionDrugIndicator(Boolean downloadExceptionDrugIndicator) {
		this.downloadExceptionDrugIndicator = downloadExceptionDrugIndicator;
		return this;
	}

	/**
	 * Get downloadExceptionDrugIndicator
	 * 
	 * @return downloadExceptionDrugIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getDownloadExceptionDrugIndicator() {
		return downloadExceptionDrugIndicator;
	}

	public void setDownloadExceptionDrugIndicator(Boolean downloadExceptionDrugIndicator) {
		this.downloadExceptionDrugIndicator = downloadExceptionDrugIndicator;
	}

	public AutoDownloadEligibility exceptionSACIndicator(Boolean exceptionSACIndicator) {
		this.exceptionSACIndicator = exceptionSACIndicator;
		return this;
	}

	/**
	 * Get exceptionSACIndicator
	 * 
	 * @return exceptionSACIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getExceptionSACIndicator() {
		return exceptionSACIndicator;
	}

	public void setExceptionSACIndicator(Boolean exceptionSACIndicator) {
		this.exceptionSACIndicator = exceptionSACIndicator;
	}

	public AutoDownloadEligibility requiredMDOShipIndicator(Boolean requiredMDOShipIndicator) {
		this.requiredMDOShipIndicator = requiredMDOShipIndicator;
		return this;
	}

	/**
	 * Get requiredMDOShipIndicator
	 * 
	 * @return requiredMDOShipIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getRequiredMDOShipIndicator() {
		return requiredMDOShipIndicator;
	}

	public void setRequiredMDOShipIndicator(Boolean requiredMDOShipIndicator) {
		this.requiredMDOShipIndicator = requiredMDOShipIndicator;
	}

	public AutoDownloadEligibility physiciansOfficeIndicator(Boolean physiciansOfficeIndicator) {
		this.physiciansOfficeIndicator = physiciansOfficeIndicator;
		return this;
	}

	/**
	 * Get physiciansOfficeIndicator
	 * 
	 * @return physiciansOfficeIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getPhysiciansOfficeIndicator() {
		return physiciansOfficeIndicator;
	}

	public void setPhysiciansOfficeIndicator(Boolean physiciansOfficeIndicator) {
		this.physiciansOfficeIndicator = physiciansOfficeIndicator;
	}

	public AutoDownloadEligibility dispenseQtyIndicator(Boolean dispenseQtyIndicator) {
		this.dispenseQtyIndicator = dispenseQtyIndicator;
		return this;
	}

	/**
	 * Get dispenseQtyIndicator
	 * 
	 * @return dispenseQtyIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getDispenseQtyIndicator() {
		return dispenseQtyIndicator;
	}

	public void setDispenseQtyIndicator(Boolean dispenseQtyIndicator) {
		this.dispenseQtyIndicator = dispenseQtyIndicator;
	}

	public AutoDownloadEligibility npiRxPharmaIndicator(Boolean npiRxPharmaIndicator) {
		this.npiRxPharmaIndicator = npiRxPharmaIndicator;
		return this;
	}

	/**
	 * Get npiRxPharmaIndicator
	 * 
	 * @return npiRxPharmaIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getNpiRxPharmaIndicator() {
		return npiRxPharmaIndicator;
	}

	public void setNpiRxPharmaIndicator(Boolean npiRxPharmaIndicator) {
		this.npiRxPharmaIndicator = npiRxPharmaIndicator;
	}

	public AutoDownloadEligibility medispanStatusIndicator(String medispanStatusIndicator) {
		this.medispanStatusIndicator = medispanStatusIndicator;
		return this;
	}

	/**
	 * Get medispanStatusIndicator
	 * 
	 * @return medispanStatusIndicator
	 **/
	@ApiModelProperty(value = "")

	public String getMedispanStatusIndicator() {
		return medispanStatusIndicator;
	}

	public void setMedispanStatusIndicator(String medispanStatusIndicator) {
		this.medispanStatusIndicator = medispanStatusIndicator;
	}

	public AutoDownloadEligibility billingStatusCode(String billingStatusCode) {
		this.billingStatusCode = billingStatusCode;
		return this;
	}

	/**
	 * Get billingStatusCode
	 * 
	 * @return billingStatusCode
	 **/
	@ApiModelProperty(value = "")

	public String getbillingStatusCode() {
		return billingStatusCode;
	}

	public void setbillingStatusCode(String billingStatusCode) {
		this.billingStatusCode = billingStatusCode;
	}

	public AutoDownloadEligibility rxVerifyFlag(String rxVerifyFlag) {
		this.rxVerifyFlag = rxVerifyFlag;
		return this;
	}

	/**
	 * Get rxVerifyFlag
	 * 
	 * @return rxVerifyFlag
	 **/
	@ApiModelProperty(value = "")

	public String getrxVerifyFlag() {
		return rxVerifyFlag;
	}

	public void setrxVerifyFlag(String rxVerifyFlag) {
		this.rxVerifyFlag = rxVerifyFlag;
	}

	public AutoDownloadEligibility controlledSubstance(String controlledSubstance) {
		this.controlledSubstance = controlledSubstance;
		return this;
	}

	/**
	 * Get isControlledSubstance
	 * 
	 * @return isControlledSubstance
	 **/
	@ApiModelProperty(value = "")

	public String getControlledSubstance() {
		return controlledSubstance;
	}

	public void setControlledSubstance(String controlledSubstance) {
		this.controlledSubstance = controlledSubstance;
	}

	public AutoDownloadEligibility isDEAValid(Boolean isDEAValid) {
		this.isDEAValid = isDEAValid;
		return this;
	}

	/**
	 * Get isDEAValid
	 * 
	 * @return isDEAValid
	 **/
	@ApiModelProperty(value = "")

	public Boolean getIsDEAValid() {
		return isDEAValid;
	}

	public void setIsDEAValid(Boolean isDEAValid) {
		this.isDEAValid = isDEAValid;
	}

	public AutoDownloadEligibility isRestrictedPrescriber(Boolean isRestrictedPrescriber) {
		this.isRestrictedPrescriber = isRestrictedPrescriber;
		return this;
	}

	/**
	 * Get isRestrictedPrescriber
	 * 
	 * @return isRestrictedPrescriber
	 **/
	@ApiModelProperty(value = "")

	public Boolean getIsRestrictedPrescriber() {
		return isRestrictedPrescriber;
	}

	public void setIsRestrictedPrescriber(Boolean isRestrictedPrescriber) {
		this.isRestrictedPrescriber = isRestrictedPrescriber;
	}

	public AutoDownloadEligibility prescriptionVerifyFlag(String prescriptionVerifyFlag) {
		this.prescriptionVerifyFlag = prescriptionVerifyFlag;
		return this;
	}

	/**
	 * Get prescriptionVerifyFlag
	 * 
	 * @return prescriptionVerifyFlag
	 **/
	@ApiModelProperty(value = "")

	public String getPrescriptionVerifyFlag() {
		return prescriptionVerifyFlag;
	}

	public void setPrescriptionVerifyFlag(String prescriptionVerifyFlag) {
		this.prescriptionVerifyFlag = prescriptionVerifyFlag;
	}

	public AutoDownloadEligibility pegaEditsIndicator(Boolean pegaEditsIndicator) {
		this.pegaEditsIndicator = pegaEditsIndicator;
		return this;
	}

	/**
	 * Get pegaEditsIndicator
	 * 
	 * @return pegaEditsIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getPegaEditsIndicator() {
		return pegaEditsIndicator;
	}

	public void setPegaEditsIndicator(Boolean pegaEditsIndicator) {
		this.pegaEditsIndicator = pegaEditsIndicator;
	}

	public AutoDownloadEligibility allowDownloadIndicator(Boolean allowDownloadIndicator) {
		this.allowDownloadIndicator = allowDownloadIndicator;
		return this;
	}

	/**
	 * Get allowDownloadIndicator
	 * 
	 * @return allowDownloadIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getAllowDownloadIndicator() {
		return allowDownloadIndicator;
	}

	public void setAllowDownloadIndicator(Boolean allowDownloadIndicator) {
		this.allowDownloadIndicator = allowDownloadIndicator;
	}

	public AutoDownloadEligibility SIGValid(String sigValid) {
		this.sigValid = sigValid;
		return this;
	}

	/**
	 * Get isSIGValid
	 * 
	 * @return isSIGValid
	 **/
	@ApiModelProperty(value = "")

	public String getSIGValid() {
		return sigValid;
	}

	public void setSIGValid(String isSIGValid) {
		this.sigValid = isSIGValid;
	}

	public AutoDownloadEligibility ndcNumber(Integer ndcNumber) {
		this.ndcNumber = ndcNumber;
		return this;
	}

	public AutoDownloadEligibility isTraceleer(Boolean isTraceleer) {
		this.isTraceleer = isTraceleer;
		return this;
	}

	/**
	 * Get isTraceleer
	 * 
	 * @return isTraceleer
	 **/
	@ApiModelProperty(value = "")

	public Boolean getIsTraceleer() {
		return isTraceleer;
	}

	public void setIsTraceleer(Boolean isTraceleer) {
		this.isTraceleer = isTraceleer;
	}

	public AutoDownloadEligibility isTraceleerFlagSetComplete(Boolean isTraceleerFlagSetComplete) {
		this.isTraceleerFlagSetComplete = isTraceleerFlagSetComplete;
		return this;
	}

	/**
	 * Get isTraceleerFlagSetComplete
	 * 
	 * @return isTraceleerFlagSetComplete
	 **/
	@ApiModelProperty(value = "")

	public Boolean getIsTraceleerFlagSetComplete() {
		return isTraceleerFlagSetComplete;
	}

	public void setIsTraceleerFlagSetComplete(Boolean isTraceleerFlagSetComplete) {
		this.isTraceleerFlagSetComplete = isTraceleerFlagSetComplete;
	}

	public AutoDownloadEligibility patientShipMismatchIndicator(Boolean patientShipMismatchIndicator) {
		this.patientShipMismatchIndicator = patientShipMismatchIndicator;
		return this;
	}

	/**
	 * Get patientShipMismatchIndicator
	 * 
	 * @return patientShipMismatchIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getPatientShipMismatchIndicator() {
		return patientShipMismatchIndicator;
	}

	public void setPatientShipMismatchIndicator(Boolean patientShipMismatchIndicator) {
		this.patientShipMismatchIndicator = patientShipMismatchIndicator;
	}

	public AutoDownloadEligibility dispenseEditEnginePassIndicator(Boolean dispenseEditEnginePassIndicator) {
		this.dispenseEditEnginePassIndicator = dispenseEditEnginePassIndicator;
		return this;
	}

	/**
	 * Get dispenseEditEnginePassIndicator
	 * 
	 * @return dispenseEditEnginePassIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getDispenseEditEnginePassIndicator() {
		return dispenseEditEnginePassIndicator;
	}

	public void setDispenseEditEnginePassIndicator(Boolean dispenseEditEnginePassIndicator) {
		this.dispenseEditEnginePassIndicator = dispenseEditEnginePassIndicator;
	}

	public AutoDownloadEligibility isAddresscorrect(Boolean isAddresscorrect) {
		this.isAddresscorrect = isAddresscorrect;
		return this;
	}

	/**
	 * Get isAddresscorrect
	 * 
	 * @return isAddresscorrect
	 **/
	@ApiModelProperty(value = "")

	public Boolean getIsAddresscorrect() {
		return isAddresscorrect;
	}

	public void setIsAddresscorrect(Boolean isAddresscorrect) {
		this.isAddresscorrect = isAddresscorrect;
	}

	public AutoDownloadEligibility isPrescriptionActive(Boolean isPrescriptionActive) {
		this.isPrescriptionActive = isPrescriptionActive;
		return this;
	}

	/**
	 * Get isPrescriptionActive
	 * 
	 * @return isPrescriptionActive
	 **/
	@ApiModelProperty(value = "")

	public Boolean getIsPrescriptionActive() {
		return isPrescriptionActive;
	}

	public void setIsPrescriptionActive(Boolean isPrescriptionActive) {
		this.isPrescriptionActive = isPrescriptionActive;
	}

	public AutoDownloadEligibility buMatchIndicator(Boolean buMatchIndicator) {
		this.buMatchIndicator = buMatchIndicator;
		return this;
	}

	/**
	 * Get buMatchIndicator
	 * 
	 * @return buMatchIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getBuMatchIndicator() {
		return buMatchIndicator;
	}

	public void setBuMatchIndicator(Boolean buMatchIndicator) {
		this.buMatchIndicator = buMatchIndicator;
	}

	public AutoDownloadEligibility isDrugValid(String isDrugValid) {
		this.isDrugValid = isDrugValid;
		return this;
	}

	/**
	 * Get isDrugValid
	 * 
	 * @return isDrugValid
	 **/
	@ApiModelProperty(value = "")

	public String getIsDrugValid() {
		return isDrugValid;
	}

	public void setIsDrugValid(String isDrugValid) {
		this.isDrugValid = isDrugValid;
	}

	public Date getIsNeedsDateValid() {
		return isNeedsDateValid;
	}

	public void setIsNeedsDateValid(Date isNeedsDateValid) {
		this.isNeedsDateValid = isNeedsDateValid;
	}

	public AutoDownloadEligibility prescriptionCountIndicator(Boolean prescriptionCountIndicator) {
		this.prescriptionCountIndicator = prescriptionCountIndicator;
		return this;
	}

	/**
	 * Get prescriptionCountIndicator
	 * 
	 * @return prescriptionCountIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getPrescriptionCountIndicator() {
		return prescriptionCountIndicator;
	}

	public void setPrescriptionCountIndicator(Boolean prescriptionCountIndicator) {
		this.prescriptionCountIndicator = prescriptionCountIndicator;
	}

	public AutoDownloadEligibility prescriptionNeedsDateIndicator(Boolean prescriptionNeedsDateIndicator) {
		this.prescriptionNeedsDateIndicator = prescriptionNeedsDateIndicator;
		return this;
	}

	/**
	 * Get prescriptionNeedsDateIndicator
	 * 
	 * @return prescriptionNeedsDateIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getPrescriptionNeedsDateIndicator() {
		return prescriptionNeedsDateIndicator;
	}

	public void setPrescriptionNeedsDateIndicator(Boolean prescriptionNeedsDateIndicator) {
		this.prescriptionNeedsDateIndicator = prescriptionNeedsDateIndicator;
	}

	public AutoDownloadEligibility autoDownloadSwitchIndicator(Boolean autoDownloadSwitchIndicator) {
		this.autoDownloadSwitchIndicator = autoDownloadSwitchIndicator;
		return this;
	}

	/**
	 * Get autoDownloadSwitchIndicator
	 * 
	 * @return autoDownloadSwitchIndicator
	 **/
	@ApiModelProperty(value = "")

	public Boolean getAutoDownloadSwitchIndicator() {
		return autoDownloadSwitchIndicator;
	}

	public void setAutoDownloadSwitchIndicator(Boolean autoDownloadSwitchIndicator) {
		this.autoDownloadSwitchIndicator = autoDownloadSwitchIndicator;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		AutoDownloadEligibility autoDownloadEligibility = (AutoDownloadEligibility) o;
		return Objects.equals(this.openDiversionIndicator, autoDownloadEligibility.openDiversionIndicator)
				&& Objects.equals(this.rdsmIndicator, autoDownloadEligibility.rdsmIndicator)
				&& Objects.equals(this.dateIndicator, autoDownloadEligibility.dateIndicator)
				&& Objects.equals(this.isMAJ, autoDownloadEligibility.isMAJ)
				&& Objects.equals(this.majStepsCompletionIndicator, autoDownloadEligibility.majStepsCompletionIndicator)
				&& Objects.equals(this.claimIndicator, autoDownloadEligibility.claimIndicator)
				&& Objects.equals(this.prescriptionsOrderIndicator, autoDownloadEligibility.prescriptionsOrderIndicator)
				&& Objects.equals(this.downloadExceptionPayorIndicator,
						autoDownloadEligibility.downloadExceptionPayorIndicator)
				&& Objects.equals(this.downloadExceptionPatientTypeIndicator,
						autoDownloadEligibility.downloadExceptionPatientTypeIndicator)
				&& Objects.equals(this.downloadExceptionDrugIndicator,
						autoDownloadEligibility.downloadExceptionDrugIndicator)
				&& Objects.equals(this.exceptionSACIndicator, autoDownloadEligibility.exceptionSACIndicator)
				&& Objects.equals(this.requiredMDOShipIndicator, autoDownloadEligibility.requiredMDOShipIndicator)
				&& Objects.equals(this.physiciansOfficeIndicator, autoDownloadEligibility.physiciansOfficeIndicator)
				&& Objects.equals(this.dispenseQtyIndicator, autoDownloadEligibility.dispenseQtyIndicator)
				&& Objects.equals(this.npiRxPharmaIndicator, autoDownloadEligibility.npiRxPharmaIndicator)
				&& Objects.equals(this.medispanStatusIndicator, autoDownloadEligibility.medispanStatusIndicator)
				&& Objects.equals(this.billingStatusCode, autoDownloadEligibility.billingStatusCode)
				&& Objects.equals(this.rxVerifyFlag, autoDownloadEligibility.rxVerifyFlag)
				&& Objects.equals(this.controlledSubstance, autoDownloadEligibility.controlledSubstance)
				&& Objects.equals(this.isDEAValid, autoDownloadEligibility.isDEAValid)
				&& Objects.equals(this.isRestrictedPrescriber, autoDownloadEligibility.isRestrictedPrescriber)
				&& Objects.equals(this.prescriptionVerifyFlag, autoDownloadEligibility.prescriptionVerifyFlag)
				&& Objects.equals(this.pegaEditsIndicator, autoDownloadEligibility.pegaEditsIndicator)
				&& Objects.equals(this.allowDownloadIndicator, autoDownloadEligibility.allowDownloadIndicator)
				&& Objects.equals(this.sigValid, autoDownloadEligibility.sigValid)
				&& Objects.equals(this.ndcNumber, autoDownloadEligibility.ndcNumber)
				&& Objects.equals(this.isTraceleer, autoDownloadEligibility.isTraceleer)
				&& Objects.equals(this.isTraceleerFlagSetComplete, autoDownloadEligibility.isTraceleerFlagSetComplete)
				&& Objects.equals(this.refrigInd, autoDownloadEligibility.refrigInd)
				&& Objects.equals(this.patientShipMismatchIndicator,
						autoDownloadEligibility.patientShipMismatchIndicator)
				&& Objects.equals(this.dispenseEditEnginePassIndicator,
						autoDownloadEligibility.dispenseEditEnginePassIndicator)
				&& Objects.equals(this.isAddresscorrect, autoDownloadEligibility.isAddresscorrect)
				&& Objects.equals(this.isPrescriptionActive, autoDownloadEligibility.isPrescriptionActive)
				&& Objects.equals(this.buMatchIndicator, autoDownloadEligibility.buMatchIndicator)
				&& Objects.equals(this.isDrugValid, autoDownloadEligibility.isDrugValid)
				&& Objects.equals(this.isNeedsDateValid, autoDownloadEligibility.isNeedsDateValid)
				&& Objects.equals(this.prescriptionCountIndicator, autoDownloadEligibility.prescriptionCountIndicator)
				&& Objects.equals(this.prescriptionNeedsDateIndicator,
						autoDownloadEligibility.prescriptionNeedsDateIndicator)
				&& Objects.equals(this.autoDownloadSwitchIndicator,
						autoDownloadEligibility.autoDownloadSwitchIndicator);
	}

	@Override
	public int hashCode() {
		return Objects.hash(openDiversionIndicator, rdsmIndicator, dateIndicator, isMAJ,
				majStepsCompletionIndicator, claimIndicator, prescriptionsOrderIndicator,
				downloadExceptionPayorIndicator, downloadExceptionPatientTypeIndicator, downloadExceptionDrugIndicator,
				exceptionSACIndicator, requiredMDOShipIndicator, physiciansOfficeIndicator, dispenseQtyIndicator,
				npiRxPharmaIndicator, medispanStatusIndicator, billingStatusCode, rxVerifyFlag,
				controlledSubstance, isDEAValid, isRestrictedPrescriber, prescriptionVerifyFlag, pegaEditsIndicator,
				allowDownloadIndicator, sigValid, ndcNumber, isTraceleer, isTraceleerFlagSetComplete, refrigInd,
				patientShipMismatchIndicator, dispenseEditEnginePassIndicator, isAddresscorrect, isPrescriptionActive,
				buMatchIndicator, isDrugValid, isNeedsDateValid, prescriptionCountIndicator,
				prescriptionNeedsDateIndicator, autoDownloadSwitchIndicator);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class AutoDownloadEligibility {\n");

		sb.append("    openDiversionIndicator: ").append(toIndentedString(openDiversionIndicator)).append("\n");
		sb.append("    rdsmIndicator: ").append(toIndentedString(rdsmIndicator)).append("\n");
		sb.append("    dateIndicator: ").append(toIndentedString(dateIndicator)).append("\n");
		sb.append("    isMAJ: ").append(toIndentedString(isMAJ)).append("\n");
		sb.append("    majStepsCompletionIndicator: ").append(toIndentedString(majStepsCompletionIndicator))
				.append("\n");
		sb.append("    claimIndicator: ").append(toIndentedString(claimIndicator)).append("\n");
		sb.append("    prescriptionsOrderIndicator: ").append(toIndentedString(prescriptionsOrderIndicator))
				.append("\n");
		sb.append("    downloadExceptionPayorIndicator: ").append(toIndentedString(downloadExceptionPayorIndicator))
				.append("\n");
		sb.append("    downloadExceptionPatientTypeIndicator: ")
				.append(toIndentedString(downloadExceptionPatientTypeIndicator)).append("\n");
		sb.append("    downloadExceptionDrugIndicator: ").append(toIndentedString(downloadExceptionDrugIndicator))
				.append("\n");
		sb.append("    exceptionSACIndicator: ").append(toIndentedString(exceptionSACIndicator)).append("\n");
		sb.append("    requiredMDOShipIndicator: ").append(toIndentedString(requiredMDOShipIndicator)).append("\n");
		sb.append("    physiciansOfficeIndicator: ").append(toIndentedString(physiciansOfficeIndicator)).append("\n");
		sb.append("    dispenseQtyIndicator: ").append(toIndentedString(dispenseQtyIndicator)).append("\n");
		sb.append("    npiRxPharmaIndicator: ").append(toIndentedString(npiRxPharmaIndicator)).append("\n");
		sb.append("    medispanStatusIndicator: ").append(toIndentedString(medispanStatusIndicator)).append("\n");
		sb.append("    billingStatusCode: ").append(toIndentedString(billingStatusCode)).append("\n");
		sb.append("    rxVerifyFlag: ").append(toIndentedString(rxVerifyFlag)).append("\n");
		sb.append("    controlledSubstance: ").append(toIndentedString(controlledSubstance)).append("\n");
		sb.append("    isDEAValid: ").append(toIndentedString(isDEAValid)).append("\n");
		sb.append("    isRestrictedPrescriber: ").append(toIndentedString(isRestrictedPrescriber)).append("\n");
		sb.append("    prescriptionVerifyFlag: ").append(toIndentedString(prescriptionVerifyFlag)).append("\n");
		sb.append("    pegaEditsIndicator: ").append(toIndentedString(pegaEditsIndicator)).append("\n");
		sb.append("    allowDownloadIndicator: ").append(toIndentedString(allowDownloadIndicator)).append("\n");
		sb.append("    sigValid: ").append(toIndentedString(sigValid)).append("\n");
		sb.append("    isndcNumber: ").append(toIndentedString(ndcNumber)).append("\n");
		sb.append("    isTraceleer: ").append(toIndentedString(isTraceleer)).append("\n");
		sb.append("    isTraceleerFlagSetComplete: ").append(toIndentedString(isTraceleerFlagSetComplete)).append("\n");
		sb.append("    isNeedsOnSet: ").append(toIndentedString(refrigInd)).append("\n");
		sb.append("    patientShipMismatchIndicator: ").append(toIndentedString(patientShipMismatchIndicator))
				.append("\n");
		sb.append("    dispenseEditEnginePassIndicator: ").append(toIndentedString(dispenseEditEnginePassIndicator))
				.append("\n");
		sb.append("    isAddresscorrect: ").append(toIndentedString(isAddresscorrect)).append("\n");
		sb.append("    isPrescriptionActive: ").append(toIndentedString(isPrescriptionActive)).append("\n");
		sb.append("    buMatchIndicator: ").append(toIndentedString(buMatchIndicator)).append("\n");
		sb.append("    isDrugValid: ").append(toIndentedString(isDrugValid)).append("\n");
		sb.append("    isNeedsDateValid: ").append(toIndentedString(isNeedsDateValid)).append("\n");
		sb.append("    prescriptionCountIndicator: ").append(toIndentedString(prescriptionCountIndicator)).append("\n");
		sb.append("    prescriptionNeedsDateIndicator: ").append(toIndentedString(prescriptionNeedsDateIndicator))
				.append("\n");
		sb.append("    autoDownloadSwitchIndicator: ").append(toIndentedString(autoDownloadSwitchIndicator))
				.append("\n");
		sb.append("}");
		return sb.toString();
	}

	public String getRefrigInd() {
		return refrigInd;
	}

	public void setRefrigInd(String refrigInd) {
		this.refrigInd = refrigInd;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
