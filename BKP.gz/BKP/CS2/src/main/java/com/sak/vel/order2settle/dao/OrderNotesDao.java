package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.OrderNotes;

public interface OrderNotesDao {

	List<OrderNotes> getOrderNotes(long orderId);

	Void createOrderNotes(long preOrderId,String orderNotes);
}
