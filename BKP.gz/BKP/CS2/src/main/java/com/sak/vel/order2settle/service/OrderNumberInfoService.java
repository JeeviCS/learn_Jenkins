
package com.cvs.specialty.ordermaintenance.service;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.OrderSatCode;

public interface OrderNumberInfoService {

  ResponseEntity<OrderSatCode> getOrderInfo(long preOrderId);
}
