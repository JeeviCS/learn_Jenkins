package com.cvs.specialty.ordermaintenance.common;

public class OrderCancelConstant {


	public class PreferenceTextCgLowValues {
		public static final String DOMAIN = "RCC_SP_TASK_MANUAL";
		public static final String CANCELREASON_HIGH_VALUE = "CANCEL_REASON";
		public static final String LOW_VALUE = "RV_LOW_VALUE";
		public static final String ABBREVIATION = "RV_ABBREVIATION";
		public static final String TASKREASON_PATIENT_NOTIFIED = "TASK_REASON_CR_CONTACT_PATIENT";
		public static final String TASKREASON_MD_NOTIFIED = "TASK_REASON_CR_CONTACT_MD";
		public static final String TASKSOURCE = "SOURCE_NAME_ORDER";
		public static final String USERNAME = "TEST";
		public static final String USERROLE = "RPX";
		public static final String COMMENT_PATIENT_NOTIFIED = " was cancelled and user did not indicate patient has been notified. Please inform the patient of this order cancellation";
		public static final String COMMENT_MD_NOTIFIED = " was cancelled and user did not indicate prescriber has been notified. Please inform the prescriber of this order cancellation";
		public static final String ENTITY_TYPE = "ORDER";
		public static final String CALLING_SERVICE = "ORDER CANCEL SERVICE";
		public static final String TARGET_MD_TASK_NAME = "Contact MD, follow-up needed";
		public static final String TARGET_PT_TASK_NAME = "contact patient follow-up needed";
		public static final String TASK_TYPE = "OTHER";
	
		
	}

}
