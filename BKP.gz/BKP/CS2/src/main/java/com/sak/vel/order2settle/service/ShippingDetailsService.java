
package com.cvs.specialty.ordermaintenance.service;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;

public interface ShippingDetailsService {

  ResponseEntity<ShipmentDetails>
      getShippingDetails(Long preOrderId, String status, String shipmentNumber);

}
