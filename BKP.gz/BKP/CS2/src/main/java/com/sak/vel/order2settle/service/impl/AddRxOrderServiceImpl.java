
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.AddRxOrderDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.AddRxOrderService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;
import com.cvs.specialty.ordermaintenance.util.ValidationError;

@Repository
public class AddRxOrderServiceImpl implements AddRxOrderService {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	AddRxOrderDao addRxOrderDao;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseEntity<Void> addRxorder(List<RxDetailsList> rxDetailsList, long preOrderId) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		ValidationError error = validateInput(rxDetailsList, preOrderId);
		if (error != null)
			return new ResponseEntity(error, HttpStatus.NOT_ACCEPTABLE);
		try {
			addRxOrderDao.addRxorder(rxDetailsList, preOrderId);
			LOGGER.info(LogMsgConstants.METHOD_EXIT);
			return  new ResponseEntity("Order Added successfuly", HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			throw new OrderMaintenanceException( "Invalid drugs added to patient");
			
		}

	}

	private ValidationError validateInput(List<RxDetailsList> rxDetailsList, long preOrderId) {
		boolean validPreOrderId = validatePreOderId(preOrderId);
		boolean validRxDetailList = validateRXDetailList(rxDetailsList);
		ValidationError error = null;

		if (!validPreOrderId) {
			error = new ValidationError("Invalid Pre Order Id", "preOrderId");
			return error;
		}

		if (!validRxDetailList) {
			error = new ValidationError("RxDetails cannot be empty", "rxDetailsList");
			return error;
		}

		return null;
	}

	private boolean validateRXDetailList(List<RxDetailsList> rxDetailsList) {
		if (rxDetailsList == null)
			return false;
		else if (rxDetailsList.size() == 0)
			return false;
		else
			return true;
	}

	private boolean validatePreOderId(long preOrderId) {
		if (0L == preOrderId || preOrderId < 0)
			return false;
		else
			return true;
	}
}
