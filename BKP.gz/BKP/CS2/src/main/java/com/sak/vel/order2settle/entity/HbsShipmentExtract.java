package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the HBS_SHIPMENT_EXTRACT database table.
 * 
 */
@Entity
@Table(name="HBS_SHIPMENT_EXTRACT")
@NamedQuery(name="HbsShipmentExtract.findAll", query="SELECT h FROM HbsShipmentExtract h")
public class HbsShipmentExtract implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="SHP_PATNO")
	private String shpPatno;

	@Column(name="SHP_NO")
	private String shpNo;

	@Temporal(TemporalType.DATE)
	@Column(name="ACTUAL_IN_STORE_PICKUP_DATE")
	private Date actualInStorePickupDate;

	@Column(name="ADDRESS_CATEGORY")
	private String addressCategory;

	@Temporal(TemporalType.DATE)
	@Column(name="ANTICIPATED_PICKUP_DATE")
	private Date anticipatedPickupDate;

	@Column(name="BARCODE_NO")
	private String barcodeNo;

	@Column(name="CREATE_BY")
	private String createBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_DATE")
	private Date createDate;

	@Column(name="ELECTRONIC_SIGNATURE_CAPTURED")
	private String electronicSignatureCaptured;

	private String filler;

	@Temporal(TemporalType.DATE)
	@Column(name="INSTR_FORM_FAX_BY_STORE_DATE")
	private Date instrFormFaxByStoreDate;

	@Column(name="OFFER_TO_COUNSEL_INDICATOR")
	private String offerToCounselIndicator;

	@Column(name="PATIENT_PAY_COLLECTED")
	private BigDecimal patientPayCollected;

	@Column(name="SHIPPED_TO_STORE_NUMBER")
	private Long shippedToStoreNumber;

	@Column(name="SHP_ACT_CARR_MOD")
	private String shpActCarrMod;

	@Column(name="SHP_ACT_DATE")
	private String shpActDate;

	@Temporal(TemporalType.DATE)
	@Column(name="SHP_ACT_DATE_DT")
	private Date shpActDateDt;

	@Column(name="SHP_ADDR1")
	private String shpAddr1;

	@Column(name="SHP_ADDR2")
	private String shpAddr2;

	@Column(name="SHP_APT")
	private String shpApt;

	@Column(name="SHP_BLD")
	private String shpBld;

	@Column(name="SHP_CITY")
	private String shpCity;

	@Column(name="SHP_COST")
	private String shpCost;

	@Column(name="SHP_COST_NUM")
	private BigDecimal shpCostNum;

	@Temporal(TemporalType.DATE)
	@Column(name="SHP_CREATE_DATETM")
	private Date shpCreateDatetm;

	@Column(name="SHP_CREATE_DT_TM")
	private String shpCreateDtTm;

	@Column(name="SHP_NEEDS_DT")
	private String shpNeedsDt;

	@Column(name="SHP_PHONE")
	private String shpPhone;

	@Column(name="SHP_RECV_DATE")
	private String shpRecvDate;

	@Column(name="SHP_RPH")
	private String shpRph;

	@Column(name="SHP_SENT_DATE")
	private String shpSentDate;

	@Column(name="SHP_SHIP_LOC")
	private String shpShipLoc;

	@Column(name="SHP_STAT")
	private String shpStat;

	@Column(name="SHP_STATE")
	private String shpState;

	@Column(name="SHP_STATUS_IND")
	private String shpStatusInd;

	@Column(name="SHP_TRACK1")
	private String shpTrack1;

	@Column(name="SHP_TRACK2")
	private String shpTrack2;

	@Column(name="SHP_TRACK3")
	private String shpTrack3;

	@Column(name="SHP_WEIGHT")
	private String shpWeight;

	@Column(name="SHP_ZIP")
	private String shpZip;

	@Column(name="UPDATE_BY")
	private String updateBy;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATE_DATE")
	private Date updateDate;

	public HbsShipmentExtract() {
	}
	
	public String getShpPatno() {
		return shpPatno;
	}

	public void setShpPatno(String shpPatno) {
		this.shpPatno = shpPatno;
	}

	public String getShpNo() {
		return shpNo;
	}

	public void setShpNo(String shpNo) {
		this.shpNo = shpNo;
	}

	public Date getActualInStorePickupDate() {
		return this.actualInStorePickupDate;
	}

	public void setActualInStorePickupDate(Date actualInStorePickupDate) {
		this.actualInStorePickupDate = actualInStorePickupDate;
	}

	public String getAddressCategory() {
		return this.addressCategory;
	}

	public void setAddressCategory(String addressCategory) {
		this.addressCategory = addressCategory;
	}

	public Date getAnticipatedPickupDate() {
		return this.anticipatedPickupDate;
	}

	public void setAnticipatedPickupDate(Date anticipatedPickupDate) {
		this.anticipatedPickupDate = anticipatedPickupDate;
	}

	public String getBarcodeNo() {
		return this.barcodeNo;
	}

	public void setBarcodeNo(String barcodeNo) {
		this.barcodeNo = barcodeNo;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getElectronicSignatureCaptured() {
		return this.electronicSignatureCaptured;
	}

	public void setElectronicSignatureCaptured(String electronicSignatureCaptured) {
		this.electronicSignatureCaptured = electronicSignatureCaptured;
	}

	public String getFiller() {
		return this.filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public Date getInstrFormFaxByStoreDate() {
		return this.instrFormFaxByStoreDate;
	}

	public void setInstrFormFaxByStoreDate(Date instrFormFaxByStoreDate) {
		this.instrFormFaxByStoreDate = instrFormFaxByStoreDate;
	}

	public String getOfferToCounselIndicator() {
		return this.offerToCounselIndicator;
	}

	public void setOfferToCounselIndicator(String offerToCounselIndicator) {
		this.offerToCounselIndicator = offerToCounselIndicator;
	}

	public BigDecimal getPatientPayCollected() {
		return this.patientPayCollected;
	}

	public void setPatientPayCollected(BigDecimal patientPayCollected) {
		this.patientPayCollected = patientPayCollected;
	}

	public Long getShippedToStoreNumber() {
		return this.shippedToStoreNumber;
	}

	public void setShippedToStoreNumber(Long shippedToStoreNumber) {
		this.shippedToStoreNumber = shippedToStoreNumber;
	}

	public String getShpActCarrMod() {
		return this.shpActCarrMod;
	}

	public void setShpActCarrMod(String shpActCarrMod) {
		this.shpActCarrMod = shpActCarrMod;
	}

	public String getShpActDate() {
		return this.shpActDate;
	}

	public void setShpActDate(String shpActDate) {
		this.shpActDate = shpActDate;
	}

	public Date getShpActDateDt() {
		return this.shpActDateDt;
	}

	public void setShpActDateDt(Date shpActDateDt) {
		this.shpActDateDt = shpActDateDt;
	}

	public String getShpAddr1() {
		return this.shpAddr1;
	}

	public void setShpAddr1(String shpAddr1) {
		this.shpAddr1 = shpAddr1;
	}

	public String getShpAddr2() {
		return this.shpAddr2;
	}

	public void setShpAddr2(String shpAddr2) {
		this.shpAddr2 = shpAddr2;
	}

	public String getShpApt() {
		return this.shpApt;
	}

	public void setShpApt(String shpApt) {
		this.shpApt = shpApt;
	}

	public String getShpBld() {
		return this.shpBld;
	}

	public void setShpBld(String shpBld) {
		this.shpBld = shpBld;
	}

	public String getShpCity() {
		return this.shpCity;
	}

	public void setShpCity(String shpCity) {
		this.shpCity = shpCity;
	}

	public String getShpCost() {
		return this.shpCost;
	}

	public void setShpCost(String shpCost) {
		this.shpCost = shpCost;
	}

	public BigDecimal getShpCostNum() {
		return this.shpCostNum;
	}

	public void setShpCostNum(BigDecimal shpCostNum) {
		this.shpCostNum = shpCostNum;
	}

	public Date getShpCreateDatetm() {
		return this.shpCreateDatetm;
	}

	public void setShpCreateDatetm(Date shpCreateDatetm) {
		this.shpCreateDatetm = shpCreateDatetm;
	}

	public String getShpCreateDtTm() {
		return this.shpCreateDtTm;
	}

	public void setShpCreateDtTm(String shpCreateDtTm) {
		this.shpCreateDtTm = shpCreateDtTm;
	}

	public String getShpNeedsDt() {
		return this.shpNeedsDt;
	}

	public void setShpNeedsDt(String shpNeedsDt) {
		this.shpNeedsDt = shpNeedsDt;
	}

	public String getShpPhone() {
		return this.shpPhone;
	}

	public void setShpPhone(String shpPhone) {
		this.shpPhone = shpPhone;
	}

	public String getShpRecvDate() {
		return this.shpRecvDate;
	}

	public void setShpRecvDate(String shpRecvDate) {
		this.shpRecvDate = shpRecvDate;
	}

	public String getShpRph() {
		return this.shpRph;
	}

	public void setShpRph(String shpRph) {
		this.shpRph = shpRph;
	}

	public String getShpSentDate() {
		return this.shpSentDate;
	}

	public void setShpSentDate(String shpSentDate) {
		this.shpSentDate = shpSentDate;
	}

	public String getShpShipLoc() {
		return this.shpShipLoc;
	}

	public void setShpShipLoc(String shpShipLoc) {
		this.shpShipLoc = shpShipLoc;
	}

	public String getShpStat() {
		return this.shpStat;
	}

	public void setShpStat(String shpStat) {
		this.shpStat = shpStat;
	}

	public String getShpState() {
		return this.shpState;
	}

	public void setShpState(String shpState) {
		this.shpState = shpState;
	}

	public String getShpStatusInd() {
		return this.shpStatusInd;
	}

	public void setShpStatusInd(String shpStatusInd) {
		this.shpStatusInd = shpStatusInd;
	}

	public String getShpTrack1() {
		return this.shpTrack1;
	}

	public void setShpTrack1(String shpTrack1) {
		this.shpTrack1 = shpTrack1;
	}

	public String getShpTrack2() {
		return this.shpTrack2;
	}

	public void setShpTrack2(String shpTrack2) {
		this.shpTrack2 = shpTrack2;
	}

	public String getShpTrack3() {
		return this.shpTrack3;
	}

	public void setShpTrack3(String shpTrack3) {
		this.shpTrack3 = shpTrack3;
	}

	public String getShpWeight() {
		return this.shpWeight;
	}

	public void setShpWeight(String shpWeight) {
		this.shpWeight = shpWeight;
	}

	public String getShpZip() {
		return this.shpZip;
	}

	public void setShpZip(String shpZip) {
		this.shpZip = shpZip;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}