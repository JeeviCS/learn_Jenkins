package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PATIENT_ADDRESS database table.
 * 
 */
@Entity
@Table(name="PATIENT_ADDRESS")
public class PatientAddressEO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PATIENT_ADDRESS_ID")
	private long patientAddressId;

	@Column(name="ADDRESS_1")
	private String address1;

	@Column(name="ADDRESS_2")
	private String address2;

	@Column(name="ADDRESS_CATEGORY")
	private String addressCategory;

	@Column(name="ADDRESS_TYPE_ID")
	private BigDecimal addressTypeId;

	private String city;
	
	@Transient
	private String flag;

	@Column(name="CONTACT_FIRST_NAME")
	private String contactFirstName;

	@Column(name="CONTACT_LAST_NAME")
	private String contactLastName;

	@Column(name="CONTACT_MIDDLE_INITIAL")
	private String contactMiddleInitial;

	@Column(name="COUNTRY_CD")
	private String countryCd;

	@Column(name="CREATE_BY")
	private String createBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_DATE")
	private Date createDate;

	@Column(name="DAY_PHONE_NUMBER")
	private BigDecimal dayPhoneNumber;

	private String directions;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_DATE")
	private Date effectiveDate;

	@Column(name="EVE_PHONE_NUMBER")
	private BigDecimal evePhoneNumber;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRATION_DATE")
	private Date expirationDate;

	@Column(name="FRI_IND")
	private String friInd;

	@Column(name="LINE_NUMBER")
	private BigDecimal lineNumber;

	@Column(name="MON_IND")
	private String monInd;

	@Column(name="PATIENT_ID")
	private BigDecimal patientId;

	@Column(name="RELATION_TYPE_ID")
	private BigDecimal relationTypeId;

	@Column(name="SAT_IND")
	private String satInd;

	@Column(name="STATE")
	private String state;

	@Column(name="STORE_ID")
	private BigDecimal storeId;

	@Column(name="SUN_IND")
	private String sunInd;

	@Column(name="THU_IND")
	private String thuInd;

	@Column(name="TUE_IND")
	private String tueInd;

	@Column(name="UPDATE_BY")
	private String updateBy;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATE_DATE")
	private Date updateDate;

	@Column(name="WED_IND")
	private String wedInd;

	@Column(name="ZIP_1")
	private String zip1;

	@Column(name="ZIP_2")
	private String zip2;
	
	// bi-directional many-to-one association to Patient
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PATIENT_ID", insertable = false, updatable = false)
	/*private PatientEO patient;

	public PatientAddress() {
	}*/

	public long getPatientAddressId() {
		return this.patientAddressId;
	}

	public void setPatientAddressId(long patientAddressId) {
		this.patientAddressId = patientAddressId;
	}

	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddressCategory() {
		return this.addressCategory;
	}

	public void setAddressCategory(String addressCategory) {
		this.addressCategory = addressCategory;
	}

	public BigDecimal getAddressTypeId() {
		return this.addressTypeId;
	}

	public void setAddressTypeId(BigDecimal addressTypeId) {
		this.addressTypeId = addressTypeId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContactFirstName() {
		return this.contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return this.contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public String getContactMiddleInitial() {
		return this.contactMiddleInitial;
	}

	public void setContactMiddleInitial(String contactMiddleInitial) {
		this.contactMiddleInitial = contactMiddleInitial;
	}

	public String getCountryCd() {
		return this.countryCd;
	}

	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public BigDecimal getDayPhoneNumber() {
		return this.dayPhoneNumber;
	}

	public void setDayPhoneNumber(BigDecimal dayPhoneNumber) {
		this.dayPhoneNumber = dayPhoneNumber;
	}

	public String getDirections() {
		return this.directions;
	}

	public void setDirections(String directions) {
		this.directions = directions;
	}

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public BigDecimal getEvePhoneNumber() {
		return this.evePhoneNumber;
	}

	public void setEvePhoneNumber(BigDecimal evePhoneNumber) {
		this.evePhoneNumber = evePhoneNumber;
	}

	public Date getExpirationDate() {
		return this.expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getFriInd() {
		return this.friInd;
	}

	public void setFriInd(String friInd) {
		this.friInd = friInd;
	}

	public BigDecimal getLineNumber() {
		return this.lineNumber;
	}

	public void setLineNumber(BigDecimal lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getMonInd() {
		return this.monInd;
	}

	public void setMonInd(String monInd) {
		this.monInd = monInd;
	}

	public BigDecimal getPatientId() {
		return this.patientId;
	}

	public void setPatientId(BigDecimal patientId) {
		this.patientId = patientId;
	}

	public BigDecimal getRelationTypeId() {
		return this.relationTypeId;
	}

	public void setRelationTypeId(BigDecimal relationTypeId) {
		this.relationTypeId = relationTypeId;
	}

	public String getSatInd() {
		return this.satInd;
	}

	public void setSatInd(String satInd) {
		this.satInd = satInd;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public BigDecimal getStoreId() {
		return this.storeId;
	}

	public void setStoreId(BigDecimal storeId) {
		this.storeId = storeId;
	}

	public String getSunInd() {
		return this.sunInd;
	}

	public void setSunInd(String sunInd) {
		this.sunInd = sunInd;
	}

	public String getThuInd() {
		return this.thuInd;
	}

	public void setThuInd(String thuInd) {
		this.thuInd = thuInd;
	}

	public String getTueInd() {
		return this.tueInd;
	}

	public void setTueInd(String tueInd) {
		this.tueInd = tueInd;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getWedInd() {
		return this.wedInd;
	}

	public void setWedInd(String wedInd) {
		this.wedInd = wedInd;
	}

	public String getZip1() {
		return this.zip1;
	}

	public void setZip1(String zip1) {
		this.zip1 = zip1;
	}

	public String getZip2() {
		return this.zip2;
	}

	public void setZip2(String zip2) {
		this.zip2 = zip2;
	}

/*	public PatientEO getPatient() {
		return patient;
	}

	public void setPatient(PatientEO patient) {
		this.patient = patient;
	}*/

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}
}
