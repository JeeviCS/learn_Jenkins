package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.RxDetailsList;

public interface RxDetailsService {
	
	ResponseEntity<List<RxDetailsList>> rxDetailsListGet(long orderId, long patientID);
}
