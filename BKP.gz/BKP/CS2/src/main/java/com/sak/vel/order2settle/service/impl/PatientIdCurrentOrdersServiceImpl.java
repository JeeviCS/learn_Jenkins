package com.cvs.specialty.ordermaintenance.service.impl;
/**
 * 
 */

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cvs.specialty.ordermaintenance.dao.PatientIdCurrentOrdersDAO;
import com.cvs.specialty.ordermaintenance.mapper.PatientIdCurrentOrdersMapper;
import com.cvs.specialty.ordermaintenance.model.CurrentOrders;
import com.cvs.specialty.ordermaintenance.service.PatientIdCurrentOrdersService;

@Service
public class PatientIdCurrentOrdersServiceImpl implements PatientIdCurrentOrdersService {
	private static final Logger logger = LoggerFactory.getLogger(PatientIdCurrentOrdersServiceImpl.class);

	@Autowired
	PatientIdCurrentOrdersMapper mapper;

	@Autowired
	PatientIdCurrentOrdersDAO patientIdCurrentOrdersDAO;

	
	@Override
	public List<CurrentOrders> getCurrentOrders(String patientId) throws DataAccessException {
		List<CurrentOrders> currentOrdersList=patientIdCurrentOrdersDAO.getCurrentOrderDetails(Long.valueOf(patientId));
		return currentOrdersList;
	}

}
