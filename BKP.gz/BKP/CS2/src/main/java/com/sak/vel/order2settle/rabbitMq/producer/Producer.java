package com.cvs.specialty.ordermaintenance.rabbitMq.producer;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cvs.specialty.ordermaintenance.model.CancelOrderDownloadSuccess;

@Component
public class Producer { 
  
  @Autowired
  private AmqpTemplate amqpTemplate;
  
  @Value("${jsa.rabbitmq.exchange}")
  private String exchange;
  
  @Value("${jsa.rabbitmq.routingkey}")
  private String routingkey;

  public void produce(CancelOrderDownloadSuccess message){
    amqpTemplate.convertAndSend(exchange, routingkey, message);
    System.out.println("Send msg = " + message);
  }
}
