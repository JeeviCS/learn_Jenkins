
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.*;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.service.OrderStatusService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/")
public class OrderStatusApiController implements OrderStatusApi {

  @Autowired
  OrderStatusService orderStatService;

  @Autowired
  SpecialtyLogger LOGGER;

  public ResponseEntity<Void> updateOrderStatus(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @ApiParam(value = "preOrderHeaderId") @RequestParam Long preOrderHeaderId,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");
    try {
      orderStatService.updateOrderStatus(preOrderHeaderId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }

  }

}
