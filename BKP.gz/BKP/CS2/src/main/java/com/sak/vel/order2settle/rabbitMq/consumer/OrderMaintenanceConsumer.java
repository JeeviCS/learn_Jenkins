
package com.cvs.specialty.ordermaintenance.rabbitMq.consumer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.ProcessServicesClient;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.model.OrderReadyJmsQueuePost;
import com.cvs.specialty.ordermaintenance.rabbitMq.producer.RabbitMQSender;
import com.cvs.specialty.ordermaintenance.util.KieServiceUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class OrderMaintenanceConsumer {

/*	@Autowired
	RabbitMQSender rabbitMQSender;

	@Value("${specialty.bpm.url}")
	private String bmpUrl;

	@Value("${specialty.bpm.download.container.id}")
	private String bmpContainerId;

	@Value("${specialty.bpm.download.process.id}")
	private String bmpProcessId;

	@Value("${specialty.bpm.username}")
	private String bmpUsername;

	@Value("${specialty.bpm.password}")
	private String bmpPassword;

	OrderReadyJmsQueuePost orderSchedulingMessage;

	@Autowired
	SpecialtyLogger LOGGER;

	@RabbitListener(queues = "${jsa.rabbitmq.queue}", containerFactory = "jsaFactory")
	public <T> void recievedMessage(Message<T> message) throws JSONException, IOException, ParseException {

		System.out.println("Messages payload ----> " + message.getPayload());
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

		try {
			JSONParser parser = new JSONParser();

			String json = mapper.writeValueAsString(message.getPayload());

			Object obj = parser.parse(json);

			JSONObject jsonObject = (JSONObject) obj;

			Object payload = parser.parse(jsonObject.get("payload").toString());

			JSONObject payload_Json = (JSONObject) payload;

			Long preOrderHeaderId = (Long) payload_Json.get("preOrderHeaderId");

			Long patientId = (Long) payload_Json.get("patientId");

			String status = (String) payload_Json.get("status");

			startBPMProcess(preOrderHeaderId, patientId);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void startBPMProcess(long preOrderHeaderId, long patientId) {

		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("preOrderHeaderId", preOrderHeaderId);
			params.put("patientId", patientId);
			KieServicesClient client = KieServiceUtil.configure(bmpUrl, bmpUsername, bmpPassword, false);
			ProcessServicesClient processServicesClient = client.getServicesClient(ProcessServicesClient.class);
			Long processInstanceId = processServicesClient.startProcess(bmpContainerId, bmpProcessId, params);
			System.out.println("processInstanceId -->" + processInstanceId);

			sendToBpmTable(processInstanceId, preOrderHeaderId);

		} catch (Exception e) {

			System.out.println(e);
			e.printStackTrace();
		}

	}

	private void sendToBpmTable(long processInstanceId, long preOrderHeaderId) {
		try {
			RestTemplate restTemplate = new RestTemplate();

			String orderStatusURL = "http://localhost:8070/v1/OrderDownloadProcess";
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(orderStatusURL);

			UriComponents components = builder.build();
			String fullyQualifiedURL = components.toString();

			MultiValueMap<String, String> headerParams = new LinkedMultiValueMap<String, String>();

			headerParams.add("Content-Type", "application/json");
			headerParams.add("Accept", "application/json");
			headerParams.add("access-token", "1");
			headerParams.add("message-id", "1");

			HttpEntity<?> entity = new HttpEntity<Object>(headerParams);
			// Add Path Params to URL
			fullyQualifiedURL += "?orderId=" + preOrderHeaderId + "&instanceId=" + processInstanceId;

			System.out.println("\nfullyQualifiedURL ---> " + fullyQualifiedURL + "\n");
			restTemplate.exchange(fullyQualifiedURL, HttpMethod.POST, entity, String.class);
		} catch (

		Exception e) {
			e.printStackTrace();
		}
	}

	public OrderReadyJmsQueuePost getSchedulingMessage() {
		return this.orderSchedulingMessage;

	}*/

}
