package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;

public interface  OrderDownloadEngineService {
	
	ResponseEntity<OrderDownloadEngine> getPatientShippingInfo(long preOrderId, long patientID);
}
