
package com.cvs.specialty.ordermaintenance.model;

import java.sql.Date;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ShippingDetails
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-07T22:33:22.947Z")

public class ShippingDetails {
  @JsonProperty("shippingDetailIdentifier")
  private Long shippingDetailIdentifier = null;

  @JsonProperty("partyAddressIdentifier")
  private Long partyAddressIdentifier = null;

  @JsonProperty("shippingMethodCode")
  private String shippingMethodCode = null;

  @JsonProperty("addressCategoryCode")
  private String addressCategoryCode = null;

  @JsonProperty("addressType")
  private String addressType = null;

  @JsonProperty("addressLine1Text")
  private String addressLine1Text = null;

  @JsonProperty("addressLine2Text")
  private String addressLine2Text = null;

  @JsonProperty("addressLine3Text")
  private String addressLine3Text = null;

  @JsonProperty("cityText")
  private String cityText = null;

  @JsonProperty("stateCode")
  private String stateCode = null;

  @JsonProperty("zipCode")
  private String zipCode = null;

  @JsonProperty("zipExtensionCode")
  private String zipExtensionCode = null;

  @JsonProperty("countryText")
  private String countryText = null;

  @JsonProperty("countyText")
  private String countyText = null;

  @JsonProperty("addressSeqNo")
  private Long addressSeqNo = null;

  @JsonProperty("addressTypeCd")
  private String addressTypeCd = null;

  @JsonProperty("addressRank")
  private Long addressRank = null;

  @JsonProperty("monInd")
  private String monInd = null;

  @JsonProperty("tueInd")
  private String tueInd = null;

  @JsonProperty("wedInd")
  private String wedInd = null;

  @JsonProperty("thuInd")
  private String thuInd = null;

  @JsonProperty("friInd")
  private String friInd = null;

  @JsonProperty("satInd")
  private String satInd = null;

  @JsonProperty("sunInd")
  private String sunInd = null;

  @JsonProperty("createDt")
  private Date createDt = null;

  @JsonProperty("createBy")
  private String createBy = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public ShippingDetails shippingDetailIdentifier(Long shippingDetailIdentifier) {
    this.shippingDetailIdentifier = shippingDetailIdentifier;
    return this;
  }

  /**
   * Get shippingDetailIdentifier
   * 
   * @return shippingDetailIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getShippingDetailIdentifier() {
    return shippingDetailIdentifier;
  }

  public void setShippingDetailIdentifier(Long shippingDetailIdentifier) {
    this.shippingDetailIdentifier = shippingDetailIdentifier;
  }

  public ShippingDetails partyAddressIdentifier(Long partyAddressIdentifier) {
    this.partyAddressIdentifier = partyAddressIdentifier;
    return this;
  }

  /**
   * Get partyAddressIdentifier
   * 
   * @return partyAddressIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getPartyAddressIdentifier() {
    return partyAddressIdentifier;
  }

  public void setPartyAddressIdentifier(Long partyAddressIdentifier) {
    this.partyAddressIdentifier = partyAddressIdentifier;
  }

  public ShippingDetails shippingMethodCode(String shippingMethodCode) {
    this.shippingMethodCode = shippingMethodCode;
    return this;
  }

  /**
   * Get shippingMethodCode
   * 
   * @return shippingMethodCode
   **/
  @ApiModelProperty(value = "")

  public String getShippingMethodCode() {
    return shippingMethodCode;
  }

  public void setShippingMethodCode(String shippingMethodCode) {
    this.shippingMethodCode = shippingMethodCode;
  }

  public ShippingDetails addressCategoryCode(String addressCategoryCode) {
    this.addressCategoryCode = addressCategoryCode;
    return this;
  }

  /**
   * Get addressCategoryCode
   * 
   * @return addressCategoryCode
   **/
  @ApiModelProperty(value = "")

  public String getAddressCategoryCode() {
    return addressCategoryCode;
  }

  public void setAddressCategoryCode(String addressCategoryCode) {
    this.addressCategoryCode = addressCategoryCode;
  }

  public ShippingDetails addressType(String addressType) {
    this.addressType = addressType;
    return this;
  }

  /**
   * Get addressType
   * 
   * @return addressType
   **/
  @ApiModelProperty(value = "")

  public String getAddressType() {
    return addressType;
  }

  public void setAddressType(String addressType) {
    this.addressType = addressType;
  }

  public ShippingDetails addressLine1Text(String addressLine1Text) {
    this.addressLine1Text = addressLine1Text;
    return this;
  }

  /**
   * Get addressLine1Text
   * 
   * @return addressLine1Text
   **/
  @ApiModelProperty(value = "")

  public String getAddressLine1Text() {
    return addressLine1Text;
  }

  public void setAddressLine1Text(String addressLine1Text) {
    this.addressLine1Text = addressLine1Text;
  }

  public ShippingDetails addressLine2Text(String addressLine2Text) {
    this.addressLine2Text = addressLine2Text;
    return this;
  }

  /**
   * Get addressLine2Text
   * 
   * @return addressLine2Text
   **/
  @ApiModelProperty(value = "")

  public String getAddressLine2Text() {
    return addressLine2Text;
  }

  public void setAddressLine2Text(String addressLine2Text) {
    this.addressLine2Text = addressLine2Text;
  }

  public ShippingDetails addressLine3Text(String addressLine3Text) {
    this.addressLine3Text = addressLine3Text;
    return this;
  }

  /**
   * Get addressLine3Text
   * 
   * @return addressLine3Text
   **/
  @ApiModelProperty(value = "")

  public String getAddressLine3Text() {
    return addressLine3Text;
  }

  public void setAddressLine3Text(String addressLine3Text) {
    this.addressLine3Text = addressLine3Text;
  }

  public ShippingDetails cityText(String cityText) {
    this.cityText = cityText;
    return this;
  }

  /**
   * Get cityText
   * 
   * @return cityText
   **/
  @ApiModelProperty(value = "")

  public String getCityText() {
    return cityText;
  }

  public void setCityText(String cityText) {
    this.cityText = cityText;
  }

  public ShippingDetails stateCode(String stateCode) {
    this.stateCode = stateCode;
    return this;
  }

  /**
   * Get stateCode
   * 
   * @return stateCode
   **/
  @ApiModelProperty(value = "")

  public String getStateCode() {
    return stateCode;
  }

  public void setStateCode(String stateCode) {
    this.stateCode = stateCode;
  }

  public ShippingDetails zipCode(String zipCode) {
    this.zipCode = zipCode;
    return this;
  }

  /**
   * Get zipCode
   * 
   * @return zipCode
   **/
  @ApiModelProperty(value = "")

  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public ShippingDetails zipExtensionCode(String zipExtensionCode) {
    this.zipExtensionCode = zipExtensionCode;
    return this;
  }

  /**
   * Get zipExtensionCode
   * 
   * @return zipExtensionCode
   **/
  @ApiModelProperty(value = "")

  public String getZipExtensionCode() {
    return zipExtensionCode;
  }

  public void setZipExtensionCode(String zipExtensionCode) {
    this.zipExtensionCode = zipExtensionCode;
  }

  public ShippingDetails countryText(String countryText) {
    this.countryText = countryText;
    return this;
  }

  /**
   * Get countryText
   * 
   * @return countryText
   **/
  @ApiModelProperty(value = "")

  public String getCountryText() {
    return countryText;
  }

  public void setCountryText(String countryText) {
    this.countryText = countryText;
  }

  public ShippingDetails countyText(String countyText) {
    this.countyText = countyText;
    return this;
  }

  /**
   * Get countyText
   * 
   * @return countyText
   **/
  @ApiModelProperty(value = "")

  public String getCountyText() {
    return countyText;
  }

  public void setCountyText(String countyText) {
    this.countyText = countyText;
  }

  public ShippingDetails addressSeqNo(Long addressSeqNo) {
    this.addressSeqNo = addressSeqNo;
    return this;
  }

  /**
   * Get addressSeqNo
   * 
   * @return addressSeqNo
   **/
  @ApiModelProperty(value = "")

  public Long getAddressSeqNo() {
    return addressSeqNo;
  }

  public void setAddressSeqNo(Long addressSeqNo) {
    this.addressSeqNo = addressSeqNo;
  }

  public ShippingDetails addressTypeCd(String addressTypeCd) {
    this.addressTypeCd = addressTypeCd;
    return this;
  }

  /**
   * Get addressTypeCd
   * 
   * @return addressTypeCd
   **/
  @ApiModelProperty(value = "")

  public String getAddressTypeCd() {
    return addressTypeCd;
  }

  public void setAddressTypeCd(String addressTypeCd) {
    this.addressTypeCd = addressTypeCd;
  }

  public ShippingDetails addressRank(Long addressRank) {
    this.addressRank = addressRank;
    return this;
  }

  /**
   * Get addressRank
   * 
   * @return addressRank
   **/
  @ApiModelProperty(value = "")

  public Long getAddressRank() {
    return addressRank;
  }

  public void setAddressRank(Long addressRank) {
    this.addressRank = addressRank;
  }

  public ShippingDetails monInd(String monInd) {
    this.monInd = monInd;
    return this;
  }

  /**
   * Get monInd
   * 
   * @return monInd
   **/
  @ApiModelProperty(value = "")

  public String getMonInd() {
    return monInd;
  }

  public void setMonInd(String monInd) {
    this.monInd = monInd;
  }

  public ShippingDetails tueInd(String tueInd) {
    this.tueInd = tueInd;
    return this;
  }

  /**
   * Get tueInd
   * 
   * @return tueInd
   **/
  @ApiModelProperty(value = "")

  public String getTueInd() {
    return tueInd;
  }

  public void setTueInd(String tueInd) {
    this.tueInd = tueInd;
  }

  public ShippingDetails wedInd(String wedInd) {
    this.wedInd = wedInd;
    return this;
  }

  /**
   * Get wedInd
   * 
   * @return wedInd
   **/
  @ApiModelProperty(value = "")

  public String getWedInd() {
    return wedInd;
  }

  public void setWedInd(String wedInd) {
    this.wedInd = wedInd;
  }

  public ShippingDetails thuInd(String thuInd) {
    this.thuInd = thuInd;
    return this;
  }

  /**
   * Get thuInd
   * 
   * @return thuInd
   **/
  @ApiModelProperty(value = "")

  public String getThuInd() {
    return thuInd;
  }

  public void setThuInd(String thuInd) {
    this.thuInd = thuInd;
  }

  public ShippingDetails friInd(String friInd) {
    this.friInd = friInd;
    return this;
  }

  /**
   * Get friInd
   * 
   * @return friInd
   **/
  @ApiModelProperty(value = "")

  public String getFriInd() {
    return friInd;
  }

  public void setFriInd(String friInd) {
    this.friInd = friInd;
  }

  public ShippingDetails satInd(String satInd) {
    this.satInd = satInd;
    return this;
  }

  /**
   * Get satInd
   * 
   * @return satInd
   **/
  @ApiModelProperty(value = "")

  public String getSatInd() {
    return satInd;
  }

  public void setSatInd(String satInd) {
    this.satInd = satInd;
  }

  public ShippingDetails sunInd(String sunInd) {
    this.sunInd = sunInd;
    return this;
  }

  /**
   * Get sunInd
   * 
   * @return sunInd
   **/
  @ApiModelProperty(value = "")

  public String getSunInd() {
    return sunInd;
  }

  public void setSunInd(String sunInd) {
    this.sunInd = sunInd;
  }

  public ShippingDetails createDt(Date createDt) {
    this.createDt = createDt;
    return this;
  }

  /**
   * Get createDt
   * 
   * @return createDt
   **/
  @ApiModelProperty(value = "")

  public Date getCreateDt() {
    return createDt;
  }

  public void setCreateDt(Date createDt) {
    this.createDt = createDt;
  }

  public ShippingDetails createBy(String createBy) {
    this.createBy = createBy;
    return this;
  }

  /**
   * Get createBy
   * 
   * @return createBy
   **/
  @ApiModelProperty(value = "")

  public String getCreateBy() {
    return createBy;
  }

  public void setCreateBy(String createBy) {
    this.createBy = createBy;
  }

  public ShippingDetails audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingDetails shippingDetails = (ShippingDetails) o;
    return Objects.equals(this.shippingDetailIdentifier, shippingDetails.shippingDetailIdentifier)
        && Objects.equals(this.partyAddressIdentifier, shippingDetails.partyAddressIdentifier)
        && Objects.equals(this.shippingMethodCode, shippingDetails.shippingMethodCode)
        && Objects.equals(this.addressCategoryCode, shippingDetails.addressCategoryCode)
        && Objects.equals(this.addressType, shippingDetails.addressType)
        && Objects.equals(this.addressLine1Text, shippingDetails.addressLine1Text)
        && Objects.equals(this.addressLine2Text, shippingDetails.addressLine2Text)
        && Objects.equals(this.addressLine3Text, shippingDetails.addressLine3Text)
        && Objects.equals(this.cityText, shippingDetails.cityText)
        && Objects.equals(this.stateCode, shippingDetails.stateCode)
        && Objects.equals(this.zipCode, shippingDetails.zipCode)
        && Objects.equals(this.zipExtensionCode, shippingDetails.zipExtensionCode)
        && Objects.equals(this.countryText, shippingDetails.countryText)
        && Objects.equals(this.countyText, shippingDetails.countyText)
        && Objects.equals(this.addressSeqNo, shippingDetails.addressSeqNo)
        && Objects.equals(this.addressTypeCd, shippingDetails.addressTypeCd)
        && Objects.equals(this.addressRank, shippingDetails.addressRank)
        && Objects.equals(this.monInd, shippingDetails.monInd)
        && Objects.equals(this.tueInd, shippingDetails.tueInd)
        && Objects.equals(this.wedInd, shippingDetails.wedInd)
        && Objects.equals(this.thuInd, shippingDetails.thuInd)
        && Objects.equals(this.friInd, shippingDetails.friInd)
        && Objects.equals(this.satInd, shippingDetails.satInd)
        && Objects.equals(this.sunInd, shippingDetails.sunInd)
        && Objects.equals(this.createDt, shippingDetails.createDt)
        && Objects.equals(this.createBy, shippingDetails.createBy)
        && Objects.equals(this.audit, shippingDetails.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      shippingDetailIdentifier,
      partyAddressIdentifier,
      shippingMethodCode,
      addressCategoryCode,
      addressType,
      addressLine1Text,
      addressLine2Text,
      addressLine3Text,
      cityText,
      stateCode,
      zipCode,
      zipExtensionCode,
      countryText,
      countyText,
      addressSeqNo,
      addressTypeCd,
      addressRank,
      monInd,
      tueInd,
      wedInd,
      thuInd,
      friInd,
      satInd,
      sunInd,
      createDt,
      createBy,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingDetails {\n");

    sb
      .append("    shippingDetailIdentifier: ")
      .append(toIndentedString(shippingDetailIdentifier))
      .append("\n");
    sb
      .append("    partyAddressIdentifier: ")
      .append(toIndentedString(partyAddressIdentifier))
      .append("\n");
    sb.append("    shippingMethodCode: ").append(toIndentedString(shippingMethodCode)).append("\n");
    sb.append("    addressCategoryCode: ").append(toIndentedString(addressCategoryCode)).append(
      "\n");
    sb.append("    addressType: ").append(toIndentedString(addressType)).append("\n");
    sb.append("    addressLine1Text: ").append(toIndentedString(addressLine1Text)).append("\n");
    sb.append("    addressLine2Text: ").append(toIndentedString(addressLine2Text)).append("\n");
    sb.append("    addressLine3Text: ").append(toIndentedString(addressLine3Text)).append("\n");
    sb.append("    cityText: ").append(toIndentedString(cityText)).append("\n");
    sb.append("    stateCode: ").append(toIndentedString(stateCode)).append("\n");
    sb.append("    zipCode: ").append(toIndentedString(zipCode)).append("\n");
    sb.append("    zipExtensionCode: ").append(toIndentedString(zipExtensionCode)).append("\n");
    sb.append("    countryText: ").append(toIndentedString(countryText)).append("\n");
    sb.append("    countyText: ").append(toIndentedString(countyText)).append("\n");
    sb.append("    addressSeqNo: ").append(toIndentedString(addressSeqNo)).append("\n");
    sb.append("    addressTypeCd: ").append(toIndentedString(addressTypeCd)).append("\n");
    sb.append("    addressRank: ").append(toIndentedString(addressRank)).append("\n");
    sb.append("    monInd: ").append(toIndentedString(monInd)).append("\n");
    sb.append("    tueInd: ").append(toIndentedString(tueInd)).append("\n");
    sb.append("    wedInd: ").append(toIndentedString(wedInd)).append("\n");
    sb.append("    thuInd: ").append(toIndentedString(thuInd)).append("\n");
    sb.append("    friInd: ").append(toIndentedString(friInd)).append("\n");
    sb.append("    satInd: ").append(toIndentedString(satInd)).append("\n");
    sb.append("    sunInd: ").append(toIndentedString(sunInd)).append("\n");
    sb.append("    createDt: ").append(toIndentedString(createDt)).append("\n");
    sb.append("    createBy: ").append(toIndentedString(createBy)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
