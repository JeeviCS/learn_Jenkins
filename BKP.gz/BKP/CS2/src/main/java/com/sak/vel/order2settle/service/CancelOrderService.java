/**
 * 
 */
package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.CancelReason;
//import com.cvs.specialty.ordermaintenance.model.ListofTasks;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;

/**
 * @author Z242512
 *
 */
public interface CancelOrderService {

	public List<CancelReason> getCancelReason();

	//ResponseEntity<ListofTasks> getListofTasks(String patientId,String orderId);

	CancelOrderResponse submitCancelOrder(OrderCancelRequest cancelOrder, String userId, String accessToken, String messageId);

}
