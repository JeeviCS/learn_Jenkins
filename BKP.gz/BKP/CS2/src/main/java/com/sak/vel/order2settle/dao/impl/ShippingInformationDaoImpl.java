
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.ShippingInformationDao;
import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.model.ShippingDetails;
import com.cvs.specialty.ordermaintenance.repository.PatientAddressRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;
import com.cvs.specialty.ordermaintenance.repository.ShippingInformationRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class ShippingInformationDaoImpl implements ShippingInformationDao {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	ShippingInformationRepo shippingInformationRepo;
	@SuppressWarnings("rawtypes")
	@Autowired
	PreOrderHeaderRepo preOrderHeaderRepo;
	@Autowired
	PatientAddressRepo patientAddressRepo;

	@Autowired
	DataSource dataSource;

	/**
	 * Get a database connection from the registered data source in the servlet
	 * container.
	 *
	 * @return a database connection
	 */
	private Connection getConnection() {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return conn;
	}

	public com.cvs.specialty.ordermaintenance.model.PreOrderHeader getShippingInfo(Long preOrderHeaderId,
			Long patientId) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);

		Connection con = null;
		PreparedStatement pStatement = null;

		com.cvs.specialty.ordermaintenance.model.PreOrderHeader preOrderHeader = new com.cvs.specialty.ordermaintenance.model.PreOrderHeader();
		ShippingDetails shippingDetails = new ShippingDetails();
		PreOrderHeader preOrderHeaderEntity = preOrderHeaderRepo.findByPreOrdrHdrId(preOrderHeaderId);
		if (preOrderHeaderEntity != null) {
			try {

				con = getConnection();
				String query = "select pa.city,pa.state,pa.zip_1,pa.zip_2,pa.address_category,ph.ARV_ON_BY_CD,ph.PTNT_SGNTR_RQRD_IN,ph.SHPMT_MTHD_CD from pre_order_header ph, patient_address pa \n"
						+ "where ph.ptnt_id = pa.patient_id and ph.patient_address_id = pa.patient_address_id\n"
						+ "and ph.pre_ordr_hdr_id = ? and pa.patient_id = ?";
				pStatement = con.prepareStatement(query);
				pStatement.setLong(1, preOrderHeaderId);
				pStatement.setLong(2, patientId);
				ResultSet rs = pStatement.executeQuery();

				while (rs.next()) {
					shippingDetails.setCityText(rs.getString(1));
					shippingDetails.setStateCode(rs.getString(2));
					shippingDetails.setZipCode(rs.getString(3));
					shippingDetails.setAddressCategoryCode(rs.getString(5));
					preOrderHeader.setArriveOnBy(rs.getString(6));
					preOrderHeader.setPatientSignatureRequired(rs.getString(7));
					preOrderHeader.setShippingDetails(shippingDetails);
				}
				rs.close();
				con.close();
			} catch (Exception e) {
				LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
				throw new OrderMaintenanceException(e, "SQLException");
			}

		}
		return preOrderHeader;
	}

	// @Override
	// public List<com.cvs.specialty.ordermaintenance.model.PreOrderHeader>
	// getShippingDetails(long preOrderId,
	// String status) {
	// LOGGER.info(LogMsgConstants.METHOD_ENTRY);
	//
	// List<com.cvs.specialty.ordermaintenance.model.PreOrderHeader>
	// shippingDetailsList = new
	// ArrayList<com.cvs.specialty.ordermaintenance.model.PreOrderHeader>();
	//
	// // PatientAddress patientAddressEntity = new PatientAddress();
	// try {
	//
	// PreOrderHeader preOrderHeaderEntity =
	// preOrderHeaderRepo.findByPreOrdrHdrId(preOrderId);
	// BigDecimal patientId = preOrderHeaderEntity.getPtntId();
	// if (null != preOrderHeaderEntity) {
	// List<PatientAddress> patientAddressEntity =
	// patientAddressRepo.findByPatientId(patientId);
	// // List<PatientAddress>
	// if (null != patientAddressEntity) {
	// // com.cvs.specialty.ordermaintenance.model.PreOrderHeader shippingDetails =
	// new
	// // com.cvs.specialty.ordermaintenance.model.PreOrderHeader();
	// for (int i = 0; i < patientAddressEntity.size(); i++) {
	// ShippingDetails addressDetails = new ShippingDetails();
	//
	// com.cvs.specialty.ordermaintenance.model.PreOrderHeader shippingDetails = new
	// com.cvs.specialty.ordermaintenance.model.PreOrderHeader();
	// addressDetails.setAddressLine1Text(patientAddressEntity.get(i).getAddress1());
	// addressDetails.setAddressLine2Text(patientAddressEntity.get(i).getAddress2());
	// //
	// addressDetails.setAddressCategoryCode(patientAddressEntity.getAddressCategory());
	// addressDetails.setCityText(patientAddressEntity.get(i).getCity());
	// // addressDetails.setCountryText(patientAddressEntity.get(i).());
	// addressDetails.setZipCode(patientAddressEntity.get(i).getZip1());
	// addressDetails.setShippingMethodCode(preOrderHeaderEntity.getShpmtMthdCd());
	// shippingDetails.setShippingDetails(addressDetails);
	// shippingDetails.setArriveOnBy(preOrderHeaderEntity.getArvOnByCd());
	// shippingDetails.setPatientSignatureRequired(preOrderHeaderEntity.getPtntSgntrRqrdIn());
	// shippingDetails.setConfirmDeliverAddressIndicator(preOrderHeaderEntity.getCnfrmDlvryToAddrIn());
	// shippingDetailsList.add(i, shippingDetails);
	//
	// }
	// }
	// }
	// } catch (DataAccessException e) {
	// LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
	// throw new OrderMaintenanceException(e, "DATAAccessException");
	// }
	// LOGGER.info(LogMsgConstants.METHOD_EXIT);
	// return shippingDetailsList;
	// }

	@Override
	@Transactional
	public Void updateShippingDetails(long orderId,
			com.cvs.specialty.ordermaintenance.model.PreOrderHeader shippingDetails) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		try {
			PreOrderHeader preOrderHeader = preOrderHeaderRepo.findByPreOrdrHdrId(orderId);
			preOrderHeaderRepo.updateShippingDetailforPreOrd(shippingDetails.getArriveOnBy(),
					shippingDetails.getPatientSignatureRequired(), shippingDetails.getConfirmDeliverAddressIndicator(),
					shippingDetails.getShippingDetails().getShippingMethodCode(), orderId);
			patientAddressRepo.updateShippingDetailforPtnt(Long.valueOf(String.valueOf(preOrderHeader.getPatAddrId())),
					shippingDetails.getShippingDetails().getAddressLine1Text(),
					shippingDetails.getShippingDetails().getAddressLine2Text(),
					shippingDetails.getShippingDetails().getCityText(),
					shippingDetails.getShippingDetails().getAddressCategoryCode(),
					shippingDetails.getShippingDetails().getMonInd(), shippingDetails.getShippingDetails().getTueInd(),
					shippingDetails.getShippingDetails().getWedInd(), shippingDetails.getShippingDetails().getThuInd(),
					shippingDetails.getShippingDetails().getFriInd(), shippingDetails.getShippingDetails().getSatInd(),
					shippingDetails.getShippingDetails().getSunInd(),
					shippingDetails.getShippingDetails().getCreateBy());

		} catch (DataAccessException e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			throw new OrderMaintenanceException(e, "DataAccessException");
		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return null;
	}

	@Override
	public List<com.cvs.specialty.ordermaintenance.model.PreOrderHeader> getShippingDetails(long preOrderId,
			String status) {
		// TODO Auto-generated method stub
		return null;
	}

}
