
package com.cvs.specialty.ordermaintenance.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PreOrderHeader
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class PreOrderHeader {
  @JsonProperty("preOrderHeaderIdentifier")
  private long preOrderHeaderIdentifier;

  @JsonProperty("companyIdentifier")
  private String companyIdentifier = null;

  @JsonProperty("patientIdentifier")
  private String patientIdentifier = null;

  @JsonProperty("inquiryResultsIdentifier")
  private String inquiryResultsIdentifier = null;

  @JsonProperty("orderRequestedCompletionTimestamp")
  private String orderRequestedCompletionTimestamp = null;

  @JsonProperty("confirmDeliverAddressIndicator")
  private String confirmDeliverAddressIndicator = null;

  @JsonProperty("pharmacyIdentifier")
  private String pharmacyIdentifier = null;

  @JsonProperty("manualSchedulingIndicator")
  private String manualSchedulingIndicator = null;

  @JsonProperty("exhaustDate")
  private String exhaustDate = null;

  @JsonProperty("followUpDate")
  private String followUpDate = null;

  @JsonProperty("orderNumber")
  private String orderNumber = null;

  @JsonProperty("processStatus")
  private String processStatus = null;

  @JsonProperty("orderStatusCode")
  private String orderStatusCode = null;

  @JsonProperty("orderStatusReasonCode")
  private String orderStatusReasonCode = null;

  @JsonProperty("escalatedDiversion")
  private Boolean escalatedDiversion = null;

  @JsonProperty("shippingMethodValidIndicator")
  private Boolean shippingMethodValidIndicator = null;

  @JsonProperty("itemsProcessedIndicator")
  private String itemsProcessedIndicator = null;

  @JsonProperty("shippingDetails")
  private ShippingDetails shippingDetails = null;

  @JsonProperty("needsByDate")
  private String needsByDate = null;

  @JsonProperty("arriveOnBy")
  private String arriveOnBy = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("patientSignatureRequired")
  private String patientSignatureRequired = null;

  @JsonProperty("preOrderDetails")
  private List<PreOrderDetails> preOrderDetails = null;

  @JsonProperty("hbsNumber")
  private String hbsNumber = null;

  @JsonProperty("shipmentNumber")
  private String shipmentNumber = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public PreOrderHeader preOrderHeaderIdentifier(long preOrderHeaderIdentifier) {
    this.preOrderHeaderIdentifier = preOrderHeaderIdentifier;
    return this;
  }

  /**
   * Get preOrderHeaderIdentifier
   * 
   * @return preOrderHeaderIdentifier
   **/
  @ApiModelProperty(value = "")

  public PreOrderHeader companyIdentifier(String companyIdentifier) {
    this.companyIdentifier = companyIdentifier;
    return this;
  }

  public long getPreOrderHeaderIdentifier() {
    return preOrderHeaderIdentifier;
  }

  public void setPreOrderHeaderIdentifier(long preOrderHeaderIdentifier) {
    this.preOrderHeaderIdentifier = preOrderHeaderIdentifier;
  }

  public String getHbsNumber() {
    return hbsNumber;
  }

  public void setHbsNumber(String hbsNumber) {
    this.hbsNumber = hbsNumber;
  }

  public String getShipmentNumber() {
    return shipmentNumber;
  }

  public void setShipmentNumber(String shipmentNumber) {
    this.shipmentNumber = shipmentNumber;
  }

  /**
   * Get companyIdentifier
   * 
   * @return companyIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getCompanyIdentifier() {
    return companyIdentifier;
  }

  public void setCompanyIdentifier(String companyIdentifier) {
    this.companyIdentifier = companyIdentifier;
  }

  public PreOrderHeader patientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public PreOrderHeader inquiryResultsIdentifier(String inquiryResultsIdentifier) {
    this.inquiryResultsIdentifier = inquiryResultsIdentifier;
    return this;
  }

  /**
   * Get inquiryResultsIdentifier
   * 
   * @return inquiryResultsIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getInquiryResultsIdentifier() {
    return inquiryResultsIdentifier;
  }

  public void setInquiryResultsIdentifier(String inquiryResultsIdentifier) {
    this.inquiryResultsIdentifier = inquiryResultsIdentifier;
  }

  public PreOrderHeader orderRequestedCompletionTimestamp(
      String orderRequestedCompletionTimestamp) {
    this.orderRequestedCompletionTimestamp = orderRequestedCompletionTimestamp;
    return this;
  }

  /**
   * Get orderRequestedCompletionTimestamp
   * 
   * @return orderRequestedCompletionTimestamp
   **/
  @ApiModelProperty(value = "")

  public String getOrderRequestedCompletionTimestamp() {
    return orderRequestedCompletionTimestamp;
  }

  public void setOrderRequestedCompletionTimestamp(String orderRequestedCompletionTimestamp) {
    this.orderRequestedCompletionTimestamp = orderRequestedCompletionTimestamp;
  }

  public PreOrderHeader confirmDeliverAddressIndicator(String confirmDeliverAddressIndicator) {
    this.confirmDeliverAddressIndicator = confirmDeliverAddressIndicator;
    return this;
  }

  /**
   * Get confirmDeliverAddressIndicator
   * 
   * @return confirmDeliverAddressIndicator
   **/
  @ApiModelProperty(value = "")

  public String getConfirmDeliverAddressIndicator() {
    return confirmDeliverAddressIndicator;
  }

  public void setConfirmDeliverAddressIndicator(String confirmDeliverAddressIndicator) {
    this.confirmDeliverAddressIndicator = confirmDeliverAddressIndicator;
  }

  public PreOrderHeader pharmacyIdentifier(String pharmacyIdentifier) {
    this.pharmacyIdentifier = pharmacyIdentifier;
    return this;
  }

  /**
   * Get pharmacyIdentifier
   * 
   * @return pharmacyIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPharmacyIdentifier() {
    return pharmacyIdentifier;
  }

  public void setPharmacyIdentifier(String pharmacyIdentifier) {
    this.pharmacyIdentifier = pharmacyIdentifier;
  }

  public PreOrderHeader manualSchedulingIndicator(String manualSchedulingIndicator) {
    this.manualSchedulingIndicator = manualSchedulingIndicator;
    return this;
  }

  /**
   * Get manualSchedulingIndicator
   * 
   * @return manualSchedulingIndicator
   **/
  @ApiModelProperty(value = "")

  public String getManualSchedulingIndicator() {
    return manualSchedulingIndicator;
  }

  public void setManualSchedulingIndicator(String manualSchedulingIndicator) {
    this.manualSchedulingIndicator = manualSchedulingIndicator;
  }

  public PreOrderHeader exhaustDate(String exhaustDate) {
    this.exhaustDate = exhaustDate;
    return this;
  }

  /**
   * Get exhaustDate
   * 
   * @return exhaustDate
   **/
  @ApiModelProperty(value = "")

  public String getExhaustDate() {
    return exhaustDate;
  }

  public void setExhaustDate(String exhaustDate) {
    this.exhaustDate = exhaustDate;
  }

  public PreOrderHeader followUpDate(String followUpDate) {
    this.followUpDate = followUpDate;
    return this;
  }

  /**
   * Get followUpDate
   * 
   * @return followUpDate
   **/
  @ApiModelProperty(value = "")

  public String getFollowUpDate() {
    return followUpDate;
  }

  public void setFollowUpDate(String followUpDate) {
    this.followUpDate = followUpDate;
  }

  public PreOrderHeader orderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
    return this;
  }

  /**
   * Get orderNumber
   * 
   * @return orderNumber
   **/
  @ApiModelProperty(value = "")

  public String getOrderNumber() {
    return orderNumber;
  }

  public void setOrderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
  }

  public PreOrderHeader processStatus(String processStatus) {
    this.processStatus = processStatus;
    return this;
  }

  /**
   * Get processStatus
   * 
   * @return processStatus
   **/
  @ApiModelProperty(value = "")

  public String getProcessStatus() {
    return processStatus;
  }

  public void setProcessStatus(String processStatus) {
    this.processStatus = processStatus;
  }

  public PreOrderHeader orderStatusCode(String orderStatusCode) {
    this.orderStatusCode = orderStatusCode;
    return this;
  }

  /**
   * Get orderStatusCode
   * 
   * @return orderStatusCode
   **/
  @ApiModelProperty(value = "")

  public String getOrderStatusCode() {
    return orderStatusCode;
  }

  public void setOrderStatusCode(String orderStatusCode) {
    this.orderStatusCode = orderStatusCode;
  }

  public PreOrderHeader orderStatusReasonCode(String orderStatusReasonCode) {
    this.orderStatusReasonCode = orderStatusReasonCode;
    return this;
  }

  /**
   * Get orderStatusReasonCode
   * 
   * @return orderStatusReasonCode
   **/
  @ApiModelProperty(value = "")

  public String getOrderStatusReasonCode() {
    return orderStatusReasonCode;
  }

  public void setOrderStatusReasonCode(String orderStatusReasonCode) {
    this.orderStatusReasonCode = orderStatusReasonCode;
  }

  public PreOrderHeader escalatedDiversion(Boolean escalatedDiversion) {
    this.escalatedDiversion = escalatedDiversion;
    return this;
  }

  /**
   * Get escalatedDiversion
   * 
   * @return escalatedDiversion
   **/
  @ApiModelProperty(value = "")

  public Boolean getEscalatedDiversion() {
    return escalatedDiversion;
  }

  public void setEscalatedDiversion(Boolean escalatedDiversion) {
    this.escalatedDiversion = escalatedDiversion;
  }

  public PreOrderHeader shippingMethodValidIndicator(Boolean shippingMethodValidIndicator) {
    this.shippingMethodValidIndicator = shippingMethodValidIndicator;
    return this;
  }

  /**
   * Get shippingMethodValidIndicator
   * 
   * @return shippingMethodValidIndicator
   **/
  @ApiModelProperty(value = "")

  public Boolean getShippingMethodValidIndicator() {
    return shippingMethodValidIndicator;
  }

  public void setShippingMethodValidIndicator(Boolean shippingMethodValidIndicator) {
    this.shippingMethodValidIndicator = shippingMethodValidIndicator;
  }

  public PreOrderHeader itemsProcessedIndicator(String itemsProcessedIndicator) {
    this.itemsProcessedIndicator = itemsProcessedIndicator;
    return this;
  }

  /**
   * Get itemsProcessedIndicator
   * 
   * @return itemsProcessedIndicator
   **/
  @ApiModelProperty(value = "")

  public String getItemsProcessedIndicator() {
    return itemsProcessedIndicator;
  }

  public void setItemsProcessedIndicator(String itemsProcessedIndicator) {
    this.itemsProcessedIndicator = itemsProcessedIndicator;
  }

  public PreOrderHeader shippingDetails(ShippingDetails shippingDetails) {
    this.shippingDetails = shippingDetails;
    return this;
  }

  /**
   * Get shippingDetails
   * 
   * @return shippingDetails
   **/
  @ApiModelProperty(value = "")

  @Valid

  public ShippingDetails getShippingDetails() {
    return shippingDetails;
  }

  public void setShippingDetails(ShippingDetails shippingDetails) {
    this.shippingDetails = shippingDetails;
  }

  public PreOrderHeader needsByDate(String needsByDate) {
    this.needsByDate = needsByDate;
    return this;
  }

  /**
   * Get needsByDate
   * 
   * @return needsByDate
   **/
  @ApiModelProperty(value = "")

  public String getNeedsByDate() {
    return needsByDate;
  }

  public void setNeedsByDate(String needsByDate) {
    this.needsByDate = needsByDate;
  }

  public PreOrderHeader arriveOnBy(String arriveOnBy) {
    this.arriveOnBy = arriveOnBy;
    return this;
  }

  /**
   * Get arriveOnBy
   * 
   * @return arriveOnBy
   **/
  @ApiModelProperty(value = "")

  public String getArriveOnBy() {
    return arriveOnBy;
  }

  public void setArriveOnBy(String arriveOnBy) {
    this.arriveOnBy = arriveOnBy;
  }

  public PreOrderHeader activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public PreOrderHeader patientSignatureRequired(String patientSignatureRequired) {
    this.patientSignatureRequired = patientSignatureRequired;
    return this;
  }

  /**
   * Get patientSignatureRequired
   * 
   * @return patientSignatureRequired
   **/
  @ApiModelProperty(value = "")

  public String getPatientSignatureRequired() {
    return patientSignatureRequired;
  }

  public void setPatientSignatureRequired(String patientSignatureRequired) {
    this.patientSignatureRequired = patientSignatureRequired;
  }

  public PreOrderHeader preOrderDetails(List<PreOrderDetails> preOrderDetails) {
    this.preOrderDetails = preOrderDetails;
    return this;
  }

  public PreOrderHeader addPreOrderDetailsItem(PreOrderDetails preOrderDetailsItem) {
    if (this.preOrderDetails == null) {
      this.preOrderDetails = new ArrayList<PreOrderDetails>();
    }
    this.preOrderDetails.add(preOrderDetailsItem);
    return this;
  }

  /**
   * Get preOrderDetails
   * 
   * @return preOrderDetails
   **/
  @ApiModelProperty(value = "")

  @Valid

  public List<PreOrderDetails> getPreOrderDetails() {
    return preOrderDetails;
  }

  public void setPreOrderDetails(List<PreOrderDetails> preOrderDetails) {
    this.preOrderDetails = preOrderDetails;
  }

  public PreOrderHeader audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PreOrderHeader preOrderHeader = (PreOrderHeader) o;
    return Objects.equals(this.preOrderHeaderIdentifier, preOrderHeader.preOrderHeaderIdentifier)
        && Objects.equals(this.companyIdentifier, preOrderHeader.companyIdentifier)
        && Objects.equals(this.patientIdentifier, preOrderHeader.patientIdentifier)
        && Objects.equals(this.inquiryResultsIdentifier, preOrderHeader.inquiryResultsIdentifier)
        && Objects.equals(
          this.orderRequestedCompletionTimestamp,
          preOrderHeader.orderRequestedCompletionTimestamp)
        && Objects.equals(
          this.confirmDeliverAddressIndicator,
          preOrderHeader.confirmDeliverAddressIndicator)
        && Objects.equals(this.pharmacyIdentifier, preOrderHeader.pharmacyIdentifier)
        && Objects.equals(this.manualSchedulingIndicator, preOrderHeader.manualSchedulingIndicator)
        && Objects.equals(this.exhaustDate, preOrderHeader.exhaustDate)
        && Objects.equals(this.followUpDate, preOrderHeader.followUpDate)
        && Objects.equals(this.orderNumber, preOrderHeader.orderNumber)
        && Objects.equals(this.processStatus, preOrderHeader.processStatus)
        && Objects.equals(this.orderStatusCode, preOrderHeader.orderStatusCode)
        && Objects.equals(this.orderStatusReasonCode, preOrderHeader.orderStatusReasonCode)
        && Objects.equals(this.escalatedDiversion, preOrderHeader.escalatedDiversion)
        && Objects
          .equals(this.shippingMethodValidIndicator, preOrderHeader.shippingMethodValidIndicator)
        && Objects.equals(this.itemsProcessedIndicator, preOrderHeader.itemsProcessedIndicator)
        && Objects.equals(this.shippingDetails, preOrderHeader.shippingDetails)
        && Objects.equals(this.needsByDate, preOrderHeader.needsByDate)
        && Objects.equals(this.arriveOnBy, preOrderHeader.arriveOnBy)
        && Objects.equals(this.activeIndicator, preOrderHeader.activeIndicator)
        && Objects.equals(this.patientSignatureRequired, preOrderHeader.patientSignatureRequired)
        && Objects.equals(this.preOrderDetails, preOrderHeader.preOrderDetails)
        && Objects.equals(this.audit, preOrderHeader.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      preOrderHeaderIdentifier,
      companyIdentifier,
      patientIdentifier,
      inquiryResultsIdentifier,
      orderRequestedCompletionTimestamp,
      confirmDeliverAddressIndicator,
      pharmacyIdentifier,
      manualSchedulingIndicator,
      exhaustDate,
      followUpDate,
      orderNumber,
      processStatus,
      orderStatusCode,
      orderStatusReasonCode,
      escalatedDiversion,
      shippingMethodValidIndicator,
      itemsProcessedIndicator,
      shippingDetails,
      needsByDate,
      arriveOnBy,
      activeIndicator,
      patientSignatureRequired,
      preOrderDetails,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PreOrderHeader {\n");

    sb
      .append("    preOrderHeaderIdentifier: ")
      .append(toIndentedString(preOrderHeaderIdentifier))
      .append("\n");
    sb.append("    companyIdentifier: ").append(toIndentedString(companyIdentifier)).append("\n");
    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb
      .append("    inquiryResultsIdentifier: ")
      .append(toIndentedString(inquiryResultsIdentifier))
      .append("\n");
    sb
      .append("    orderRequestedCompletionTimestamp: ")
      .append(toIndentedString(orderRequestedCompletionTimestamp))
      .append("\n");
    sb
      .append("    confirmDeliverAddressIndicator: ")
      .append(toIndentedString(confirmDeliverAddressIndicator))
      .append("\n");
    sb.append("    pharmacyIdentifier: ").append(toIndentedString(pharmacyIdentifier)).append("\n");
    sb
      .append("    manualSchedulingIndicator: ")
      .append(toIndentedString(manualSchedulingIndicator))
      .append("\n");
    sb.append("    exhaustDate: ").append(toIndentedString(exhaustDate)).append("\n");
    sb.append("    followUpDate: ").append(toIndentedString(followUpDate)).append("\n");
    sb.append("    orderNumber: ").append(toIndentedString(orderNumber)).append("\n");
    sb.append("    processStatus: ").append(toIndentedString(processStatus)).append("\n");
    sb.append("    orderStatusCode: ").append(toIndentedString(orderStatusCode)).append("\n");
    sb.append("    orderStatusReasonCode: ").append(toIndentedString(orderStatusReasonCode)).append(
      "\n");
    sb.append("    escalatedDiversion: ").append(toIndentedString(escalatedDiversion)).append("\n");
    sb
      .append("    shippingMethodValidIndicator: ")
      .append(toIndentedString(shippingMethodValidIndicator))
      .append("\n");
    sb
      .append("    itemsProcessedIndicator: ")
      .append(toIndentedString(itemsProcessedIndicator))
      .append("\n");
    sb.append("    shippingDetails: ").append(toIndentedString(shippingDetails)).append("\n");
    sb.append("    needsByDate: ").append(toIndentedString(needsByDate)).append("\n");
    sb.append("    arriveOnBy: ").append(toIndentedString(arriveOnBy)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb
      .append("    patientSignatureRequired: ")
      .append(toIndentedString(patientSignatureRequired))
      .append("\n");
    sb.append("    preOrderDetails: ").append(toIndentedString(preOrderDetails)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
