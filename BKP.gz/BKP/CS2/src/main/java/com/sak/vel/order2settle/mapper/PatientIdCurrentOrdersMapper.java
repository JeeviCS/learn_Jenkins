package com.cvs.specialty.ordermaintenance.mapper;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.cvs.specialty.ordermaintenance.model.CurrentOrders;

/**
 * 
 * @author Z226695
 *
 *         Enterprise Patient Request Mapper class is used to map request object
 */

@Component
public class PatientIdCurrentOrdersMapper {

	private static Logger logger = LogManager.getLogger(PatientIdCurrentOrdersMapper.class);

	public CurrentOrders mappingCurrentOrdersEntityToModel(Map<String, Object> row) {
		CurrentOrders currentOrdersVO = new CurrentOrders();

		String orderNumber = row.get("ORDER_NUMBER") != null ? row.get("ORDER_NUMBER").toString() : " ";
		String hcpLastName = row.get("LAST_NAME") != null ? row.get("LAST_NAME").toString() : " ";
		String status = row.get("ORDR_STUS_CD") != null ? row.get("ORDR_STUS_CD").toString() : " ";
		String shipDate = row.get("SHIPPED_DATE") != null ? row.get("SHIPPED_DATE").toString() : " ";
		String deliverySchedule = row.get("ARV_ON_BY_CD") != null ? row.get("ARV_ON_BY_CD").toString() : " ";
		String needsBy = row.get("NEEDS_DT") != null ? row.get("NEEDS_DT").toString() : " ";
		String itemsCount = row.get("QUANTITY_WRITTEN") != null ? row.get("QUANTITY_WRITTEN").toString() : " ";
	
		currentOrdersVO.setOrderNumber(new BigDecimal(orderNumber));
		currentOrdersVO.setHcpLastName(hcpLastName);
		currentOrdersVO.setStatus(status);
		currentOrdersVO.setShipDate(shipDate);
		currentOrdersVO.setDeliverySchedule(deliverySchedule);
		currentOrdersVO.setNeedsBy(needsBy);
		currentOrdersVO.setItemsCount(new BigDecimal(itemsCount));

		return currentOrdersVO;
	}

}
