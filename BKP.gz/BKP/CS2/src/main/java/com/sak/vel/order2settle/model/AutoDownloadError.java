package com.cvs.specialty.ordermaintenance.model;

import java.time.ZonedDateTime;
import java.util.Date;
import java.util.List;

import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeDeserializer;
import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeSerializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class AutoDownloadError {
	
/*	List<RuleCodeErrors> ruleCodeErrors;

	public List<RuleCodeErrors> getRuleCodeErrors() {
		return ruleCodeErrors;
	}

	public void setRuleCodeErrors(List<RuleCodeErrors> ruleCodeErrors) {
		this.ruleCodeErrors = ruleCodeErrors;
	}*/
  @JsonProperty("nbdTooFarIndicator")
  private String nbdTooFarIndicator = null;
  
  @JsonProperty("divertRequired")
  private String divertRequired= null;
  
  @JsonProperty("taskType")
  private String taskType= null;
  
  @JsonProperty("entityId")
  private Long entityId = null;
  
  @JsonProperty("entityType")
  private String entityType = null;
  
  @JsonProperty("patientId")
  private Long patientId = null;
  
  @JsonProperty("followUpDate")
  @JsonSerialize(using = ZonedDateTimeSerializer.class)
  @JsonDeserialize(using = ZonedDateTimeDeserializer.class)
  private Date followUpDate = null;
  
  @JsonProperty("diversions")
  private List<Diversion> diversions;
  
  @JsonProperty("taskId")
  private Long taskId = null;
  
  @JsonProperty("callingService")
  private String callingService = null;
  
  @JsonProperty("actionId")
  private String actionId = null;
  
  @JsonProperty("outcomeId")
  private String outcomeId = null;
  
  @JsonProperty("nbdWaitPeriod")
  private Integer nbdWaitPeriod = 14;
  
  public String getNbdTooFarIndicator() {
    return nbdTooFarIndicator;
  }
  public void setNbdTooFarIndicator(String nbdTooFarIndicator) {
    this.nbdTooFarIndicator = nbdTooFarIndicator;
  }
  public String getDivertRequired() {
    return divertRequired;
  }
  public void setDivertRequired(String divertRequired) {
    this.divertRequired = divertRequired;
  }
  public String getTaskType() {
    return taskType;
  }
  public void setTaskType(String taskType) {
    this.taskType = taskType;
  }
  public Long getEntityId() {
    return entityId;
  }
  public void setEntityId(Long entityId) {
    this.entityId = entityId;
  }
  public String getEntityType() {
    return entityType;
  }
  public void setEntityType(String entityType) {
    this.entityType = entityType;
  }
  public Long getPatientId() {
    return patientId;
  }
  public void setPatientId(Long patientId) {
    this.patientId = patientId;
  }
  public Date getFollowUpDate() {
	return followUpDate;
}
public void setFollowUpDate(Date followUpDate) {
	this.followUpDate = followUpDate;
}
public List<Diversion> getDiversions() {
    return diversions;
  }
  public void setDiversions(List<Diversion> diversions) {
    this.diversions = diversions;
  }
  public Long getTaskId() {
    return taskId;
  }
  public void setTaskId(Long taskId) {
    this.taskId = taskId;
  }
  public String getCallingService() {
    return callingService;
  }
  public void setCallingService(String callingService) {
    this.callingService = callingService;
  }
  public String getActionId() {
    return actionId;
  }
  public void setActionId(String actionId) {
    this.actionId = actionId;
  }
  public String getOutcomeId() {
    return outcomeId;
  }
  public void setOutcomeId(String outcomeId) {
    this.outcomeId = outcomeId;
  }
  public Integer getNbdWaitPeriod() {
    return nbdWaitPeriod;
  }
  public void setNbdWaitPeriod(Integer nbdWaitPeriod) {
    this.nbdWaitPeriod = nbdWaitPeriod;
  }

  
}
