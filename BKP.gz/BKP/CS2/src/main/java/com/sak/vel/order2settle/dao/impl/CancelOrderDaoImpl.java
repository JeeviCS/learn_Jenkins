/**
 * 
 */

package com.cvs.specialty.ordermaintenance.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.CancelOrderDao;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
import com.cvs.specialty.ordermaintenance.model.TaskLists;
import com.cvs.specialty.ordermaintenance.repository.CancelListOfTasksRepo;
import com.cvs.specialty.ordermaintenance.repository.CancelOrderReasonRepo;
import com.cvs.specialty.ordermaintenance.repository.CancelOrderRepo;
import com.cvs.specialty.ordermaintenance.repository.ListOfTasksRepo;

/**
 * @author Z242512
 *
 */
@Component
public class CancelOrderDaoImpl implements CancelOrderDao {
	@Autowired
	SpecialtyLogger serviceLogger;

	@Autowired
	CancelOrderReasonRepo cancelOrderReasonRepo;

	@Autowired
	CancelOrderRepo cancelOrderRepo;


	@Autowired
	CancelListOfTasksRepo cancelListOfTasksRepo;


	/* (non-Javadoc)
	 * @see com.cvs.specialty.ordermaintenance.dao.CancelOrderDao#getCancelReason(java.lang.String)
	 * This method is used to get cancel resaons for orders
	 */
	public List<CgRefCode> getCancelReason(String rvDomain, String rvHighValue) {
		return cancelOrderReasonRepo.findByRvDomainAndRvHighValue( rvDomain,  rvHighValue);
	}


	/* (non-Javadoc)
	 * @see com.cvs.specialty.ordermaintenance.dao.CancelOrderDao#getListofTasks(java.lang.String, java.lang.String)
	 * This method is used to get list of tasks for given order id and patient id
	 */
	/*public List<Task> getListofTasks(String patientId,String orderId) {
		List<Task> tasklist = new ArrayList<Task>();
		try {
			LOG.info("Getting list of tasks");
			List<Object[]> resultSet = listOfTasksRepo.findBypreOrdrHdrId(new BigDecimal(patientId), Long.parseLong(orderId));
			if (!resultSet.isEmpty()) {
				for (Object[] entity : resultSet) {

					Task task =new Task();
					if(entity[0]!=null)  {task.setTaskId((Long.valueOf(entity[0].toString())));
					}if(entity[1]!=null)    {task.setPrtyIn((String) entity[1]);
					}if(entity[2]!=null)  {task.setSbpQueTaskStusRsnCd((String) entity[2]);
					}if(entity[3]!=null)  {task.setFlupTs(Timestamp.valueOf(entity[3].toString()));
					}if(entity[4]!=null)  {task.setUsrCmntTx((String) entity[4]);
					}
					tasklist.add(task);				}
			} else {
				LOG.error("no records found");
			}

		} catch (DataAccessException ex) {
			LOG.error("Failed to get list of tasks ", ex.getMessage());
		}
		return tasklist;
	}*/


	/* (non-Javadoc)
	 * @see com.cvs.specialty.ordermaintenance.dao.CancelOrderDao#submitCancelOrder(com.cvs.specialty.ordermaintenance.model.OrderCancelRequest, java.lang.String)
	 * This method is used to cancel order and its related tasks
	 */
	public CancelOrderResponse submitCancelOrder(OrderCancelRequest cancelOrder, String userId) {
		String patFlag=null;
		String MDFlag=null;
		String status="CANCELLED";
		Long order_id;
		Long patientId=cancelOrder.getPatientId();
		Long task_id;
		String cancel_reason=cancelOrder.getOrderCancelReason();
		CancelOrderResponse cancelOrderResponse=new CancelOrderResponse();
		int k=0;
		try {

			serviceLogger.info("Updating order cancel");
			order_id=cancelOrder.getOrderId();

			if(cancelOrder.getPatientNotifiedFlag()==true)
				patFlag = "Y";
			else
				patFlag = "N";

			if(cancelOrder.getMdNotifiedFlag()==true)
				MDFlag="Y";
			else
				MDFlag="N";   
			if(patientId!=null && order_id!=null) {
				k=1; //cancelOrderRepo.updateCancelOrder(patFlag,MDFlag,status,order_id,cancel_reason,userId);
			}
			if(k==1) {
				cancelOrderResponse.setOrderId(order_id);
				cancelOrderResponse.setMessage("Success");
			}else {
				serviceLogger.error("Order id and patient id should not be null");
			}

		} catch (DataAccessException ex) {
			serviceLogger.error("Failed to Update order cancel"+ ex.getMessage());

		}
		return cancelOrderResponse;	
	}

}
