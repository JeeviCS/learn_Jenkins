package com.cvs.specialty.ordermaintenance.model;

import java.math.BigDecimal;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CurrentOrders
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-15T18:07:17.630Z")

public class CurrentOrders   {
	
  @JsonProperty("orderNumber")
  @JsonInclude(Include.NON_NULL)  
  private BigDecimal orderNumber = null;

  @JsonProperty("orderDate")
  @JsonInclude(Include.NON_NULL) 
  private String orderDate = null;

  @JsonProperty("status")
  @JsonInclude(Include.NON_NULL) 
  private String status = null;

  @JsonProperty("shipDate")
  @JsonInclude(Include.NON_NULL) 
  private String shipDate = null;

  @JsonProperty("deliverySchedule")
  @JsonInclude(Include.NON_NULL) 
  private String deliverySchedule = null;

  @JsonProperty("needsBy")
  @JsonInclude(Include.NON_NULL) 
  private String needsBy = null;

  @JsonProperty("itemsCount")
  @JsonInclude(Include.NON_NULL) 
  private BigDecimal itemsCount = null;

  @JsonProperty("hcpID")
  private String hcpID = null;

  @JsonProperty("hcpLastName")
  private String hcpLastName = null;

  @JsonProperty("hcpFirstName")
  private String hcpFirstName = null;

  @JsonProperty("hcpNPI")
  private String hcpNPI = null;

  public CurrentOrders orderNumber(BigDecimal orderNumber) {
    this.orderNumber = orderNumber;
    return this;
  }

  /**
   * Get orderNumber
   * @return orderNumber
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BigDecimal getOrderNumber() {
    return orderNumber;
  }

  public void setOrderNumber(BigDecimal orderNumber) {
    this.orderNumber = orderNumber;
  }

  public CurrentOrders orderDate(String orderDate) {
    this.orderDate = orderDate;
    return this;
  }

  /**
   * Get orderDate
   * @return orderDate
  **/
  @ApiModelProperty(value = "")


  public String getOrderDate() {
    return orderDate;
  }

  public void setOrderDate(String orderDate) {
    this.orderDate = orderDate;
  }

  public CurrentOrders status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public CurrentOrders shipDate(String shipDate) {
    this.shipDate = shipDate;
    return this;
  }

  /**
   * Get shipDate
   * @return shipDate
  **/
  @ApiModelProperty(value = "")


  public String getShipDate() {
    return shipDate;
  }

  public void setShipDate(String shipDate) {
    this.shipDate = shipDate;
  }

  public CurrentOrders deliverySchedule(String deliverySchedule) {
    this.deliverySchedule = deliverySchedule;
    return this;
  }

  /**
   * Get deliverySchedule
   * @return deliverySchedule
  **/
  @ApiModelProperty(value = "")


  public String getDeliverySchedule() {
    return deliverySchedule;
  }

  public void setDeliverySchedule(String deliverySchedule) {
    this.deliverySchedule = deliverySchedule;
  }

  public CurrentOrders needsBy(String needsBy) {
    this.needsBy = needsBy;
    return this;
  }

  /**
   * Get needsBy
   * @return needsBy
  **/
  @ApiModelProperty(value = "")


  public String getNeedsBy() {
    return needsBy;
  }

  public void setNeedsBy(String needsBy) {
    this.needsBy = needsBy;
  }

  public CurrentOrders itemsCount(BigDecimal itemsCount) {
    this.itemsCount = itemsCount;
    return this;
  }

  /**
   * Get itemsCount
   * @return itemsCount
  **/
  @ApiModelProperty(value = "")

  @Valid

  public BigDecimal getItemsCount() {
    return itemsCount;
  }

  public void setItemsCount(BigDecimal itemsCount) {
    this.itemsCount = itemsCount;
  }

  public CurrentOrders hcpID(String hcpID) {
    this.hcpID = hcpID;
    return this;
  }

  /**
   * Get hcpID
   * @return hcpID
  **/
  @ApiModelProperty(value = "")


  public String getHcpID() {
    return hcpID;
  }

  public void setHcpID(String hcpID) {
    this.hcpID = hcpID;
  }

  public CurrentOrders hcpLastName(String hcpLastName) {
    this.hcpLastName = hcpLastName;
    return this;
  }

  /**
   * Get hcpLastName
   * @return hcpLastName
  **/
  @ApiModelProperty(value = "")


  public String getHcpLastName() {
    return hcpLastName;
  }

  public void setHcpLastName(String hcpLastName) {
    this.hcpLastName = hcpLastName;
  }

  public CurrentOrders hcpFirstName(String hcpFirstName) {
    this.hcpFirstName = hcpFirstName;
    return this;
  }

  /**
   * Get hcpFirstName
   * @return hcpFirstName
  **/
  @ApiModelProperty(value = "")


  public String getHcpFirstName() {
    return hcpFirstName;
  }

  public void setHcpFirstName(String hcpFirstName) {
    this.hcpFirstName = hcpFirstName;
  }

  public CurrentOrders hcpNPI(String hcpNPI) {
    this.hcpNPI = hcpNPI;
    return this;
  }

  /**
   * Get hcpNPI
   * @return hcpNPI
  **/
  @ApiModelProperty(value = "")


  public String getHcpNPI() {
    return hcpNPI;
  }

  public void setHcpNPI(String hcpNPI) {
    this.hcpNPI = hcpNPI;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CurrentOrders currentOrders = (CurrentOrders) o;
    return Objects.equals(this.orderNumber, currentOrders.orderNumber) &&
        Objects.equals(this.orderDate, currentOrders.orderDate) &&
        Objects.equals(this.status, currentOrders.status) &&
        Objects.equals(this.shipDate, currentOrders.shipDate) &&
        Objects.equals(this.deliverySchedule, currentOrders.deliverySchedule) &&
        Objects.equals(this.needsBy, currentOrders.needsBy) &&
        Objects.equals(this.itemsCount, currentOrders.itemsCount) &&
        Objects.equals(this.hcpID, currentOrders.hcpID) &&
        Objects.equals(this.hcpLastName, currentOrders.hcpLastName) &&
        Objects.equals(this.hcpFirstName, currentOrders.hcpFirstName) &&
        Objects.equals(this.hcpNPI, currentOrders.hcpNPI);
  }

  @Override
  public int hashCode() {
    return Objects.hash(orderNumber, orderDate, status, shipDate, deliverySchedule, needsBy, itemsCount, hcpID, hcpLastName, hcpFirstName, hcpNPI);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CurrentOrders {\n");
    
    sb.append("    orderNumber: ").append(toIndentedString(orderNumber)).append("\n");
    sb.append("    orderDate: ").append(toIndentedString(orderDate)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    shipDate: ").append(toIndentedString(shipDate)).append("\n");
    sb.append("    deliverySchedule: ").append(toIndentedString(deliverySchedule)).append("\n");
    sb.append("    needsBy: ").append(toIndentedString(needsBy)).append("\n");
    sb.append("    itemsCount: ").append(toIndentedString(itemsCount)).append("\n");
    sb.append("    hcpID: ").append(toIndentedString(hcpID)).append("\n");
    sb.append("    hcpLastName: ").append(toIndentedString(hcpLastName)).append("\n");
    sb.append("    hcpFirstName: ").append(toIndentedString(hcpFirstName)).append("\n");
    sb.append("    hcpNPI: ").append(toIndentedString(hcpNPI)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

