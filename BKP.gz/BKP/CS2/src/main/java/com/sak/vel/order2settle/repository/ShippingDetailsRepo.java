
package com.cvs.specialty.ordermaintenance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.HbsShipmentExtract;

@Repository
@Transactional
public interface ShippingDetailsRepo extends JpaRepository<HbsShipmentExtract, Long> {

  HbsShipmentExtract findByShpNo(String shipmentNumber);

}
