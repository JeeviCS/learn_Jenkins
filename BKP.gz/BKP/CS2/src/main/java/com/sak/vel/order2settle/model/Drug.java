
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Drug
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class Drug {
  @JsonProperty("drugIdentifier")
  private long drugIdentifier;

  @JsonProperty("drugName")
  private String drugName = null;

  @JsonProperty("drugSourceName")
  private String drugSourceName = null;

  @JsonProperty("nationalDrugCodeIdentifier")
  private String nationalDrugCodeIdentifier = null;

  @JsonProperty("genericProductIdentifier")
  private String genericProductIdentifier = null;

  @JsonProperty("drugStrengthText")
  private String drugStrengthText = null;

  @JsonProperty("drugFormType")
  private String drugFormType = null;

  @JsonProperty("unitsQuantity")
  private Integer unitsQuantity = null;

  @JsonProperty("metricQuantity")
  private Float metricQuantity = null;

  @JsonProperty("drugUnitPackagingCode")
  private String drugUnitPackagingCode = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("drugRouteOfAdministrationCode")
  private String drugRouteOfAdministrationCode = null;

  @JsonProperty("refrigeratedIndicator")
  private Boolean refrigeratedIndicator = null;

  @JsonProperty("compoundIndicator")
  private Boolean compoundIndicator = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public Drug drugIdentifier(long drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
    return this;
  }

  /**
   * Get drugIdentifier
   * 
   * @return drugIdentifier
   **/
  @ApiModelProperty(value = "")

  public long getDrugIdentifier() {
    return drugIdentifier;
  }

  public void setDrugIdentifier(long drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
  }

  public Drug drugName(String drugName) {
    this.drugName = drugName;
    return this;
  }

  /**
   * Get drugName
   * 
   * @return drugName
   **/
  @ApiModelProperty(value = "")

  public String getDrugName() {
    return drugName;
  }

  public void setDrugName(String drugName) {
    this.drugName = drugName;
  }

  public Drug drugSourceName(String drugSourceName) {
    this.drugSourceName = drugSourceName;
    return this;
  }

  /**
   * Get drugSourceName
   * 
   * @return drugSourceName
   **/
  @ApiModelProperty(value = "")

  public String getDrugSourceName() {
    return drugSourceName;
  }

  public void setDrugSourceName(String drugSourceName) {
    this.drugSourceName = drugSourceName;
  }

  public Drug nationalDrugCodeIdentifier(String nationalDrugCodeIdentifier) {
    this.nationalDrugCodeIdentifier = nationalDrugCodeIdentifier;
    return this;
  }

  /**
   * Get nationalDrugCodeIdentifier
   * 
   * @return nationalDrugCodeIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getNationalDrugCodeIdentifier() {
    return nationalDrugCodeIdentifier;
  }

  public void setNationalDrugCodeIdentifier(String nationalDrugCodeIdentifier) {
    this.nationalDrugCodeIdentifier = nationalDrugCodeIdentifier;
  }

  public Drug genericProductIdentifier(String genericProductIdentifier) {
    this.genericProductIdentifier = genericProductIdentifier;
    return this;
  }

  /**
   * Get genericProductIdentifier
   * 
   * @return genericProductIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getGenericProductIdentifier() {
    return genericProductIdentifier;
  }

  public void setGenericProductIdentifier(String genericProductIdentifier) {
    this.genericProductIdentifier = genericProductIdentifier;
  }

  public Drug drugStrengthText(String drugStrengthText) {
    this.drugStrengthText = drugStrengthText;
    return this;
  }

  /**
   * Get drugStrengthText
   * 
   * @return drugStrengthText
   **/
  @ApiModelProperty(value = "")

  public String getDrugStrengthText() {
    return drugStrengthText;
  }

  public void setDrugStrengthText(String drugStrengthText) {
    this.drugStrengthText = drugStrengthText;
  }

  public Drug drugFormType(String drugFormType) {
    this.drugFormType = drugFormType;
    return this;
  }

  /**
   * Get drugFormType
   * 
   * @return drugFormType
   **/
  @ApiModelProperty(value = "")

  public String getDrugFormType() {
    return drugFormType;
  }

  public void setDrugFormType(String drugFormType) {
    this.drugFormType = drugFormType;
  }

  public Drug unitsQuantity(Integer unitsQuantity) {
    this.unitsQuantity = unitsQuantity;
    return this;
  }

  /**
   * Get unitsQuantity
   * 
   * @return unitsQuantity
   **/
  @ApiModelProperty(value = "")

  public Integer getUnitsQuantity() {
    return unitsQuantity;
  }

  public void setUnitsQuantity(Integer unitsQuantity) {
    this.unitsQuantity = unitsQuantity;
  }

  public Drug metricQuantity(Float metricQuantity) {
    this.metricQuantity = metricQuantity;
    return this;
  }

  /**
   * Get metricQuantity
   * 
   * @return metricQuantity
   **/
  @ApiModelProperty(value = "")

  public Float getMetricQuantity() {
    return metricQuantity;
  }

  public void setMetricQuantity(Float metricQuantity) {
    this.metricQuantity = metricQuantity;
  }

  public Drug drugUnitPackagingCode(String drugUnitPackagingCode) {
    this.drugUnitPackagingCode = drugUnitPackagingCode;
    return this;
  }

  /**
   * Get drugUnitPackagingCode
   * 
   * @return drugUnitPackagingCode
   **/
  @ApiModelProperty(value = "")

  public String getDrugUnitPackagingCode() {
    return drugUnitPackagingCode;
  }

  public void setDrugUnitPackagingCode(String drugUnitPackagingCode) {
    this.drugUnitPackagingCode = drugUnitPackagingCode;
  }

  public Drug activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public Drug drugRouteOfAdministrationCode(String drugRouteOfAdministrationCode) {
    this.drugRouteOfAdministrationCode = drugRouteOfAdministrationCode;
    return this;
  }

  /**
   * Get drugRouteOfAdministrationCode
   * 
   * @return drugRouteOfAdministrationCode
   **/
  @ApiModelProperty(value = "")

  public String getDrugRouteOfAdministrationCode() {
    return drugRouteOfAdministrationCode;
  }

  public void setDrugRouteOfAdministrationCode(String drugRouteOfAdministrationCode) {
    this.drugRouteOfAdministrationCode = drugRouteOfAdministrationCode;
  }

  public Drug refrigeratedIndicator(Boolean refrigeratedIndicator) {
    this.refrigeratedIndicator = refrigeratedIndicator;
    return this;
  }

  /**
   * Get refrigeratedIndicator
   * 
   * @return refrigeratedIndicator
   **/
  @ApiModelProperty(value = "")

  public Boolean getRefrigeratedIndicator() {
    return refrigeratedIndicator;
  }

  public void setRefrigeratedIndicator(Boolean refrigeratedIndicator) {
    this.refrigeratedIndicator = refrigeratedIndicator;
  }

  public Drug compoundIndicator(Boolean compoundIndicator) {
    this.compoundIndicator = compoundIndicator;
    return this;
  }

  /**
   * Get compoundIndicator
   * 
   * @return compoundIndicator
   **/
  @ApiModelProperty(value = "")

  public Boolean getCompoundIndicator() {
    return compoundIndicator;
  }

  public void setCompoundIndicator(Boolean compoundIndicator) {
    this.compoundIndicator = compoundIndicator;
  }

  public Drug audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Drug drug = (Drug) o;
    return Objects.equals(this.drugIdentifier, drug.drugIdentifier)
        && Objects.equals(this.drugName, drug.drugName)
        && Objects.equals(this.drugSourceName, drug.drugSourceName)
        && Objects.equals(this.nationalDrugCodeIdentifier, drug.nationalDrugCodeIdentifier)
        && Objects.equals(this.genericProductIdentifier, drug.genericProductIdentifier)
        && Objects.equals(this.drugStrengthText, drug.drugStrengthText)
        && Objects.equals(this.drugFormType, drug.drugFormType)
        && Objects.equals(this.unitsQuantity, drug.unitsQuantity)
        && Objects.equals(this.metricQuantity, drug.metricQuantity)
        && Objects.equals(this.drugUnitPackagingCode, drug.drugUnitPackagingCode)
        && Objects.equals(this.activeIndicator, drug.activeIndicator)
        && Objects.equals(this.drugRouteOfAdministrationCode, drug.drugRouteOfAdministrationCode)
        && Objects.equals(this.refrigeratedIndicator, drug.refrigeratedIndicator)
        && Objects.equals(this.compoundIndicator, drug.compoundIndicator)
        && Objects.equals(this.audit, drug.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      drugIdentifier,
      drugName,
      drugSourceName,
      nationalDrugCodeIdentifier,
      genericProductIdentifier,
      drugStrengthText,
      drugFormType,
      unitsQuantity,
      metricQuantity,
      drugUnitPackagingCode,
      activeIndicator,
      drugRouteOfAdministrationCode,
      refrigeratedIndicator,
      compoundIndicator,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Drug {\n");

    sb.append("    drugIdentifier: ").append(toIndentedString(drugIdentifier)).append("\n");
    sb.append("    drugName: ").append(toIndentedString(drugName)).append("\n");
    sb.append("    drugSourceName: ").append(toIndentedString(drugSourceName)).append("\n");
    sb
      .append("    nationalDrugCodeIdentifier: ")
      .append(toIndentedString(nationalDrugCodeIdentifier))
      .append("\n");
    sb
      .append("    genericProductIdentifier: ")
      .append(toIndentedString(genericProductIdentifier))
      .append("\n");
    sb.append("    drugStrengthText: ").append(toIndentedString(drugStrengthText)).append("\n");
    sb.append("    drugFormType: ").append(toIndentedString(drugFormType)).append("\n");
    sb.append("    unitsQuantity: ").append(toIndentedString(unitsQuantity)).append("\n");
    sb.append("    metricQuantity: ").append(toIndentedString(metricQuantity)).append("\n");
    sb.append("    drugUnitPackagingCode: ").append(toIndentedString(drugUnitPackagingCode)).append(
      "\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb
      .append("    drugRouteOfAdministrationCode: ")
      .append(toIndentedString(drugRouteOfAdministrationCode))
      .append("\n");
    sb.append("    refrigeratedIndicator: ").append(toIndentedString(refrigeratedIndicator)).append(
      "\n");
    sb.append("    compoundIndicator: ").append(toIndentedString(compoundIndicator)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
