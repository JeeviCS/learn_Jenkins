
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;
import com.cvs.specialty.ordermaintenance.service.OrderDownloadEngineService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-19T16:52:21.883Z")

@Controller
public class OrderDownloadEngineApiController implements OrderDownloadEngineApi {

  @Autowired
  OrderDownloadEngineService orderDownloadEngineService;

  @Autowired
  SpecialtyLogger LOGGER;

  public ResponseEntity<String> orderDownloadEngineGet(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "preOrderId", required = true) @RequestParam(value = "preOrderId", required = true) long preOrderId,
      @NotNull @ApiParam(value = "patientId", required = true) @RequestParam(value = "patientId", required = true) long patientId,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    LOGGER.info("At controller :");
    LOGGER.info("preOrderId :" + preOrderId + "patientId :" + patientId);
    try {
      ResponseEntity<OrderDownloadEngine> resp = orderDownloadEngineService
        .getPatientShippingInfo(preOrderId, patientId);

      if (resp != null) {
        ResponseEntity<String> result = new ResponseEntity<String>(
          "Message sent to Order Download MQ",
          HttpStatus.CREATED);
        LOGGER.info("Message sent to Order Download MQ");
        LOGGER.info("---->" + result.getBody());
        return result;
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<String>(
        "Message sent to Order Download MQ failed",
        HttpStatus.NOT_IMPLEMENTED);
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
    }

  }

}
