package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * The persistent class for the CG_REF_CODES database table.
 * 
 */
@Entity
@Table(name = "CG_REF_CODES")
@NamedQuery(name = "CgRefCode.findAll", query = "SELECT c FROM CgRefCode c")
public class CgRefCode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "ACTIVE_INDICATOR")
	private String activeIndicator;

	@Column(name = "CREATE_BY")
	private String createBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Column(name = "PHARMACY_INDICATOR")
	private String pharmacyIndicator;

	@Column(name = "RV_ABBREVIATION")
	private String rvAbbreviation;

	@Column(name = "RV_DOMAIN")
	private String rvDomain;

	@Column(name = "RV_HIGH_VALUE")
	private String rvHighValue;

	@Column(name = "RV_LOW_VALUE")
	private String rvLowValue;

	@Column(name = "RV_MEANING")
	private String rvMeaning;

	@Column(name = "TEXT_1")
	private String text1;

	@Column(name = "TEXT_2")
	private String text2;

	@Column(name = "TEXT_3")
	private String text3;

	@Column(name = "TEXT_4")
	private String text4;

	@Column(name = "UPDATE_BY")
	private String updateBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "UPDATE_DATE")
	private Date updateDate;

	// bi-directional many-to-one association to CgRefCode
	@ManyToOne
	@JoinColumn(name = "PARENT_LINK")
	private CgRefCode cgRefCode;

	// bi-directional many-to-one association to CgRefCode
	@OneToMany(mappedBy = "cgRefCode")
	private List<CgRefCode> cgRefCodes;

	public CgRefCode() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getActiveIndicator() {
		return this.activeIndicator;
	}

	public void setActiveIndicator(String activeIndicator) {
		this.activeIndicator = activeIndicator;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getPharmacyIndicator() {
		return this.pharmacyIndicator;
	}

	public void setPharmacyIndicator(String pharmacyIndicator) {
		this.pharmacyIndicator = pharmacyIndicator;
	}

	public String getRvAbbreviation() {
		return this.rvAbbreviation;
	}

	public void setRvAbbreviation(String rvAbbreviation) {
		this.rvAbbreviation = rvAbbreviation;
	}

	public String getRvDomain() {
		return this.rvDomain;
	}

	public void setRvDomain(String rvDomain) {
		this.rvDomain = rvDomain;
	}

	public String getRvHighValue() {
		return this.rvHighValue;
	}

	public void setRvHighValue(String rvHighValue) {
		this.rvHighValue = rvHighValue;
	}

	public String getRvLowValue() {
		return this.rvLowValue;
	}

	public void setRvLowValue(String rvLowValue) {
		this.rvLowValue = rvLowValue;
	}

	public String getRvMeaning() {
		return this.rvMeaning;
	}

	public void setRvMeaning(String rvMeaning) {
		this.rvMeaning = rvMeaning;
	}

	public String getText1() {
		return this.text1;
	}

	public void setText1(String text1) {
		this.text1 = text1;
	}

	public String getText2() {
		return this.text2;
	}

	public void setText2(String text2) {
		this.text2 = text2;
	}

	public String getText3() {
		return this.text3;
	}

	public void setText3(String text3) {
		this.text3 = text3;
	}

	public String getText4() {
		return this.text4;
	}

	public void setText4(String text4) {
		this.text4 = text4;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public CgRefCode getCgRefCode() {
		return this.cgRefCode;
	}

	public void setCgRefCode(CgRefCode cgRefCode) {
		this.cgRefCode = cgRefCode;
	}

	public List<CgRefCode> getCgRefCodes() {
		return this.cgRefCodes;
	}

	public void setCgRefCodes(List<CgRefCode> cgRefCodes) {
		this.cgRefCodes = cgRefCodes;
	}

	public CgRefCode addCgRefCode(CgRefCode cgRefCode) {
		getCgRefCodes().add(cgRefCode);
		cgRefCode.setCgRefCode(this);

		return cgRefCode;
	}

	public CgRefCode removeCgRefCode(CgRefCode cgRefCode) {
		getCgRefCodes().remove(cgRefCode);
		cgRefCode.setCgRefCode(null);

		return cgRefCode;
	}
}