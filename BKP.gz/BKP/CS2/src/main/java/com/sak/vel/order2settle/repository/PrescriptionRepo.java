
package com.cvs.specialty.ordermaintenance.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cvs.specialty.ordermaintenance.entity.PrescriptionEO;

public interface PrescriptionRepo extends JpaRepository<PrescriptionEO, Long> {

  PrescriptionEO findByRxNumberAndPatientId(BigDecimal rxNumber, BigDecimal bigDecimal);
  
  PrescriptionEO findById(long rxId);

}
