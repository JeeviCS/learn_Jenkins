package com.cvs.specialty.ordermaintenance.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.ordermaintenance.entity.CgRefCode;


@Repository
public interface CancelOrderReasonRepo extends CrudRepository<CgRefCode, Long> {
	
		List<CgRefCode> findByRvDomainAndRvHighValue(String rvDomain,  String rvHighValue);	
		
}
