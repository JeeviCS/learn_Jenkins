package com.cvs.specialty.ordermaintenance.rabbitMq.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;
import com.cvs.specialty.ordermaintenance.model.OrderReadyJmsQueuePost;
import com.cvs.specialty.ordermaintenance.model.OrderStatus;

import org.json.JSONObject;
@RestController
@RequestMapping(value = "/javainuse-rabbitmq")
public class RabbitMQController {

	@Autowired
	RabbitMQSender rabbitMQSender;

	@GetMapping(value = "/producer")
	public String producer(@RequestParam("orderNumber") long orderNumber) {

		OrderReadyJmsQueuePost orderSchedulingSenderMessage = new OrderReadyJmsQueuePost();

		orderSchedulingSenderMessage.setPreOrderHeaderId(99L);
		orderSchedulingSenderMessage.setPatientId(12345999L);
		
		//rabbitMQSender.send(orderSchedulingSenderMessage);
		
		OrderStatus orderStatus = new OrderStatus();
		
		orderStatus.setOrderGuideNumber(orderNumber);
		
		rabbitMQSender.sendToOrderStatus(orderStatus);
		return "Message sent to Rabbit Order maintence MQ Succesfully ";
	}
	

}
