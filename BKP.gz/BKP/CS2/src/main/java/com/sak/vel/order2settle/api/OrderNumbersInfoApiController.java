
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.ResourceAccessException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.OrderSatCode;
import com.cvs.specialty.ordermaintenance.service.OrderNumberInfoService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-28T19:24:55.695Z")

@RestController
@RequestMapping("/")
public class OrderNumbersInfoApiController implements OrderNumbersInfoApi {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	OrderNumberInfoService orderNumberInfoService;

	/*
	 * public ResponseEntity<PreOrderHeader> orderNumbersInfoGet(@ApiParam(value =
	 * "Unique identifier for this service"
	 * ,required=true) @RequestHeader(value="serviceId", required=true) String
	 * serviceId,
	 * 
	 * @ApiParam(value = "Logged in user Id"
	 * ,required=true) @RequestHeader(value="userId", required=true) String userId,
	 * 
	 * @ApiParam(value = "Unique identifier for the message"
	 * ,required=true) @RequestHeader(value="messageId", required=true) String
	 * messageId,
	 * 
	 * @ApiParam(value = "Access token to Validate the Request"
	 * ,required=true) @RequestHeader(value="access-token", required=true) String
	 * accessToken,
	 * 
	 * @NotNull@ApiParam(value = "order Id", required = true) @RequestParam(value =
	 * "orderId", required = true) Integer orderId) {
	 * 
	 * ResponseEntity<PreOrderHeader> response = null;
	 * 
	 * try { response = orderNumberInfoService.getOrderInfo(orderId); } catch
	 * (ResourceAccessException rae) {
	 * 
	 * } return response; }
	 */

	public ResponseEntity<OrderSatCode> orderNumbersInfoGet(
			@ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
			@ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
			@NotNull @ApiParam(value = " preOrder Id", required = true) @RequestParam(value = " preOrderId", required = true) Integer preOrderId,
			HttpServletRequest request, HttpServletResponse response)
			throws OrderMaintenanceException, BindException, Exception {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);

		@SuppressWarnings("unused")
		String userId = null;
		if (request.getAttribute("user-id") != null)
			userId = (String) request.getAttribute("user-id");
		if (request.getAttribute("message-id") != null)
			messageId = (String) request.getAttribute("message-id");

		ResponseEntity<OrderSatCode> result = null;

		try {
			result = orderNumberInfoService.getOrderInfo( preOrderId);
			LOGGER.info(LogMsgConstants.METHOD_EXIT);
			return result;
		} catch (ResourceAccessException rae) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, rae);
			return new ResponseEntity<OrderSatCode>(HttpStatus.BAD_REQUEST);
		}

	}

}
