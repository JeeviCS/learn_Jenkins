
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.RemoveRxServiceDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.RemoveRxService;

@Repository
public class RemoveRxServiceImpl implements RemoveRxService {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	RemoveRxServiceDao removeRxServiceDao;

	@Override
	public ResponseEntity<Void> removeRx(Integer preOrderId, List<RxDetailsList> removeRxList) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		try {
			removeRxServiceDao.removeRx(preOrderId, removeRxList);
			LOGGER.info(LogMsgConstants.METHOD_EXIT);
			return null;
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}

	}

}
