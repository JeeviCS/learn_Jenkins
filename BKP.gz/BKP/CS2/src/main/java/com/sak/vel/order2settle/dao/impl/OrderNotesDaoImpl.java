
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderNotesDao;
import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.entity.PreOrderNote;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;
import com.cvs.specialty.ordermaintenance.repository.OrderNotesRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class OrderNotesDaoImpl implements OrderNotesDao {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  OrderNotesRepo orderNotesRepo;

  @SuppressWarnings("rawtypes")
  @Autowired
  PreOrderHeaderRepo preOrderHeaderRepo;

  @Override
  public List<OrderNotes> getOrderNotes(long preOrderId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    List<OrderNotes> orderNotesList = new ArrayList<OrderNotes>();

    List<PreOrderNote> orderNotesEntity = new ArrayList<PreOrderNote>();

    try {

      PreOrderHeader preOrderHeader = preOrderHeaderRepo.findByPreOrdrHdrId(preOrderId);

      if (null != preOrderHeader) {

        orderNotesEntity = orderNotesRepo.findByPreOrderHeader(preOrderHeader);

        if (null != orderNotesEntity) {
          for (int i = 0; i < orderNotesEntity.size(); i++) {
            OrderNotes orderNotes = new OrderNotes();
            orderNotes.setPreOrderNoteText(orderNotesEntity.get(i).getPreOrdrNoteTx());
            orderNotes.setNoteType(orderNotesEntity.get(i).getNoteTyp());
            orderNotes.setPatientIndetifier(orderNotesEntity.get(i).getPtntId());

            orderNotes.setPreOrderHeaderIdentifier(
              orderNotesEntity.get(i).getPreOrderHeader().getPreOrdrHdrId());
            orderNotes.setPreOrderNoteIdentifier(orderNotesEntity.get(i).getPreOrdrNoteId());
            orderNotes.setSourceSystemName(orderNotesEntity.get(i).getSrcSystmNm());
            orderNotes.setSourceSystemNoteIdentifier(orderNotesEntity.get(i).getSrcSystmNoteId());

            orderNotesList.add(i, orderNotes);

          }
        }
      }
    } catch (DataAccessException e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "DataAccessException");

    } catch (Exception e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "Exception");
    }
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return orderNotesList;
  }

  @Override
  @Transactional
  public Void createOrderNotes(long preOrderId, String preOrderNotes) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    try {
      PreOrderHeader preOrderHeader = preOrderHeaderRepo.findByPreOrdrHdrId(preOrderId);

      PreOrderNote preOrderNote = new PreOrderNote();

      if (null != preOrderHeader) {

        preOrderNote.setPreOrdrNoteTx(preOrderNotes);
        preOrderNote.setPtntId(preOrderHeader.getPtntId());
        preOrderNote.setPreOrderHeader(preOrderHeader);
        preOrderNote.setCrteTs(new Timestamp(System.currentTimeMillis()));

      }

      orderNotesRepo.save(preOrderNote);

    } catch (DataAccessException dae) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, dae);
      throw new OrderMaintenanceException(dae, "DataAccessException");
    }
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return null;
  }
}
