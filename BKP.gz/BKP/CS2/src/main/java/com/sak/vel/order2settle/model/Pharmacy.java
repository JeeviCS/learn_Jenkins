
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Pharmacy
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class Pharmacy {
  @JsonProperty("pharmacyIdentifier")
  private Long pharmacyIdentifier = null;

  @JsonProperty("sourceSystemPharmacyIdentifier")
  private Long sourceSystemPharmacyIdentifier = null;

  @JsonProperty("sourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("pharmacyType")
  private String pharmacyType = null;

  @JsonProperty("pharmacyName")
  private String pharmacyName = null;

  @JsonProperty("pharmacyManagerFirstName")
  private String pharmacyManagerFirstName = null;

  @JsonProperty("pharmacyManagerLastName")
  private String pharmacyManagerLastName = null;

  @JsonProperty("pharmacySiteLocationCode")
  private String pharmacySiteLocationCode = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public Pharmacy pharmacyIdentifier(Long pharmacyIdentifier) {
    this.pharmacyIdentifier = pharmacyIdentifier;
    return this;
  }

  /**
   * Get pharmacyIdentifier
   * 
   * @return pharmacyIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getPharmacyIdentifier() {
    return pharmacyIdentifier;
  }

  public void setPharmacyIdentifier(Long pharmacyIdentifier) {
    this.pharmacyIdentifier = pharmacyIdentifier;
  }

  public Pharmacy sourceSystemPharmacyIdentifier(Long sourceSystemPharmacyIdentifier) {
    this.sourceSystemPharmacyIdentifier = sourceSystemPharmacyIdentifier;
    return this;
  }

  /**
   * Get sourceSystemPharmacyIdentifier
   * 
   * @return sourceSystemPharmacyIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getSourceSystemPharmacyIdentifier() {
    return sourceSystemPharmacyIdentifier;
  }

  public void setSourceSystemPharmacyIdentifier(Long sourceSystemPharmacyIdentifier) {
    this.sourceSystemPharmacyIdentifier = sourceSystemPharmacyIdentifier;
  }

  public Pharmacy sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * 
   * @return sourceSystemName
   **/
  @ApiModelProperty(value = "")

  public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public Pharmacy pharmacyType(String pharmacyType) {
    this.pharmacyType = pharmacyType;
    return this;
  }

  /**
   * Get pharmacyType
   * 
   * @return pharmacyType
   **/
  @ApiModelProperty(value = "")

  public String getPharmacyType() {
    return pharmacyType;
  }

  public void setPharmacyType(String pharmacyType) {
    this.pharmacyType = pharmacyType;
  }

  public Pharmacy pharmacyName(String pharmacyName) {
    this.pharmacyName = pharmacyName;
    return this;
  }

  /**
   * Get pharmacyName
   * 
   * @return pharmacyName
   **/
  @ApiModelProperty(value = "")

  public String getPharmacyName() {
    return pharmacyName;
  }

  public void setPharmacyName(String pharmacyName) {
    this.pharmacyName = pharmacyName;
  }

  public Pharmacy pharmacyManagerFirstName(String pharmacyManagerFirstName) {
    this.pharmacyManagerFirstName = pharmacyManagerFirstName;
    return this;
  }

  /**
   * Get pharmacyManagerFirstName
   * 
   * @return pharmacyManagerFirstName
   **/
  @ApiModelProperty(value = "")

  public String getPharmacyManagerFirstName() {
    return pharmacyManagerFirstName;
  }

  public void setPharmacyManagerFirstName(String pharmacyManagerFirstName) {
    this.pharmacyManagerFirstName = pharmacyManagerFirstName;
  }

  public Pharmacy pharmacyManagerLastName(String pharmacyManagerLastName) {
    this.pharmacyManagerLastName = pharmacyManagerLastName;
    return this;
  }

  /**
   * Get pharmacyManagerLastName
   * 
   * @return pharmacyManagerLastName
   **/
  @ApiModelProperty(value = "")

  public String getPharmacyManagerLastName() {
    return pharmacyManagerLastName;
  }

  public void setPharmacyManagerLastName(String pharmacyManagerLastName) {
    this.pharmacyManagerLastName = pharmacyManagerLastName;
  }

  public Pharmacy pharmacySiteLocationCode(String pharmacySiteLocationCode) {
    this.pharmacySiteLocationCode = pharmacySiteLocationCode;
    return this;
  }

  /**
   * Get pharmacySiteLocationCode
   * 
   * @return pharmacySiteLocationCode
   **/
  @ApiModelProperty(value = "")

  public String getPharmacySiteLocationCode() {
    return pharmacySiteLocationCode;
  }

  public void setPharmacySiteLocationCode(String pharmacySiteLocationCode) {
    this.pharmacySiteLocationCode = pharmacySiteLocationCode;
  }

  public Pharmacy activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public Pharmacy audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Pharmacy pharmacy = (Pharmacy) o;
    return Objects.equals(this.pharmacyIdentifier, pharmacy.pharmacyIdentifier)
        && Objects
          .equals(this.sourceSystemPharmacyIdentifier, pharmacy.sourceSystemPharmacyIdentifier)
        && Objects.equals(this.sourceSystemName, pharmacy.sourceSystemName)
        && Objects.equals(this.pharmacyType, pharmacy.pharmacyType)
        && Objects.equals(this.pharmacyName, pharmacy.pharmacyName)
        && Objects.equals(this.pharmacyManagerFirstName, pharmacy.pharmacyManagerFirstName)
        && Objects.equals(this.pharmacyManagerLastName, pharmacy.pharmacyManagerLastName)
        && Objects.equals(this.pharmacySiteLocationCode, pharmacy.pharmacySiteLocationCode)
        && Objects.equals(this.activeIndicator, pharmacy.activeIndicator)
        && Objects.equals(this.audit, pharmacy.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      pharmacyIdentifier,
      sourceSystemPharmacyIdentifier,
      sourceSystemName,
      pharmacyType,
      pharmacyName,
      pharmacyManagerFirstName,
      pharmacyManagerLastName,
      pharmacySiteLocationCode,
      activeIndicator,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Pharmacy {\n");

    sb.append("    pharmacyIdentifier: ").append(toIndentedString(pharmacyIdentifier)).append("\n");
    sb
      .append("    sourceSystemPharmacyIdentifier: ")
      .append(toIndentedString(sourceSystemPharmacyIdentifier))
      .append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    pharmacyType: ").append(toIndentedString(pharmacyType)).append("\n");
    sb.append("    pharmacyName: ").append(toIndentedString(pharmacyName)).append("\n");
    sb
      .append("    pharmacyManagerFirstName: ")
      .append(toIndentedString(pharmacyManagerFirstName))
      .append("\n");
    sb
      .append("    pharmacyManagerLastName: ")
      .append(toIndentedString(pharmacyManagerLastName))
      .append("\n");
    sb
      .append("    pharmacySiteLocationCode: ")
      .append(toIndentedString(pharmacySiteLocationCode))
      .append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
