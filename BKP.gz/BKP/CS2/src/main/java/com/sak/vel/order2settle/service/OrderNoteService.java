package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;

public interface OrderNoteService {

	ResponseEntity<List<OrderNotes>> getOrderNotes(long preOrderId);

	ResponseEntity<Void> createOrderNotes(long preOrderId,String preOrderNotes);

}
