
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderNotesDao;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;
import com.cvs.specialty.ordermaintenance.service.OrderNoteService;
import com.cvs.specialty.ordermaintenance.util.Constants;
import com.cvs.specialty.ordermaintenance.util.ValidationException;

@Repository
public class OrderNoteServiceImpl implements OrderNoteService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  OrderNotesDao orderNotesDao;

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Override
  public ResponseEntity<List<OrderNotes>> getOrderNotes(long preOrderId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    ResponseEntity<List<OrderNotes>> response = null;

    long verifiedpreOrderId = validatePreOrderId(preOrderId);

    try {
      List<OrderNotes> response_list = orderNotesDao.getOrderNotes(verifiedpreOrderId);

      if (response_list == null) {
        response = new ResponseEntity(response_list, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response_list, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<List<OrderNotes>>(HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public ResponseEntity<Void> createOrderNotes(long preOrderId, String orderNotes) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    try {
      orderNotesDao.createOrderNotes(preOrderId, orderNotes);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return null;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);

    }

  }

  /**
   * @param intakeId
   * @return
   * @throws Exception
   */
  private long validatePreOrderId(Long preOrderId) throws ValidationException {
    if (0L == preOrderId) {
      throw new ValidationException(Constants.MISSING_PRE_ORDER_ID, Constants.PRE_ORDER_ID);
    }
    return preOrderId;
  }

}
