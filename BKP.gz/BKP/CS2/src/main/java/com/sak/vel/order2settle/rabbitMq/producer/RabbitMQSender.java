package com.cvs.specialty.ordermaintenance.rabbitMq.producer;

import org.json.JSONObject;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;
import com.cvs.specialty.ordermaintenance.model.OrderReadyJmsQueuePost;
import com.cvs.specialty.ordermaintenance.model.OrderStatus;


@Service
public class RabbitMQSender {

	@Autowired
	private AmqpTemplate rabbitTemplate;
	
	@Value("${jsa.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${jsa.rabbitmq.routingKey}")
	private String routingKey;
	
	@Value("${orderDownloadEngine.rabbitmq.exchange}")
	private String orderDownloadEngineExchange;
	
	@Value("${orderDownloadEngine.rabbitmq.routingKey}")
	private String orderDownloadEngineRoutingKey;
	
	@Value("${orderStatus.rabbitmq.exchange}")
	private String orderStatusExchange;
	
	@Value("${orderStatus.rabbitmq.routingKey}")
	private String orderStatusRoutingKey;
	
	
	public void send(OrderReadyJmsQueuePost message) {
		rabbitTemplate.convertAndSend(exchange,routingKey,message);
	}
	
	public void sendToOrderDownloadEngine(OrderDownloadEngine orderDownload) {
		rabbitTemplate.convertAndSend(orderDownloadEngineExchange,orderDownloadEngineRoutingKey,orderDownload);
		System.out.println("sendToOrderDownloadEngine is hit");
	}
	
	
	public void sendToOrderStatus(OrderStatus orderStatus) {
		rabbitTemplate.convertAndSend(orderStatusExchange,orderStatusRoutingKey,orderStatus);
		System.out.println("send To Order status is hit");
	}
}
