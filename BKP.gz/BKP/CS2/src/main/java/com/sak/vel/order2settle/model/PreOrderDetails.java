
package com.cvs.specialty.ordermaintenance.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PreOrderDetails
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class PreOrderDetails {
  @JsonProperty("preOrderDetailIdentifier")
  private String preOrderDetailIdentifier = null;

  @JsonProperty("preOrderHeaderIdentifier")
  private String preOrderHeaderIdentifier = null;

  @JsonProperty("targetDate")
  private String targetDate = null;

  @JsonProperty("workFlowLocation")
  private String workFlowLocation = null;

  @JsonProperty("quantityOnHand")
  private String quantityOnHand = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("drug")
  private Drug drug = null;

  @JsonProperty("prescription")
  private Prescription prescription = null;

  @JsonProperty("prescriptionDispense")
  private PrescriptionDispense prescriptionDispense = null;

  @JsonProperty("prescriptionRequest")
  private PrescriptionRequest prescriptionRequest = null;

  @JsonProperty("prescriber")
  private Prescriber prescriber = null;

  @JsonProperty("alerts")
  private List<AlertsLog> alerts = null;

  public PreOrderDetails preOrderDetailIdentifier(String preOrderDetailIdentifier) {
    this.preOrderDetailIdentifier = preOrderDetailIdentifier;
    return this;
  }

  /**
   * Get preOrderDetailIdentifier
   * 
   * @return preOrderDetailIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPreOrderDetailIdentifier() {
    return preOrderDetailIdentifier;
  }

  public void setPreOrderDetailIdentifier(String preOrderDetailIdentifier) {
    this.preOrderDetailIdentifier = preOrderDetailIdentifier;
  }

  public PreOrderDetails preOrderHeaderIdentifier(String preOrderHeaderIdentifier) {
    this.preOrderHeaderIdentifier = preOrderHeaderIdentifier;
    return this;
  }

  /**
   * Get preOrderHeaderIdentifier
   * 
   * @return preOrderHeaderIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPreOrderHeaderIdentifier() {
    return preOrderHeaderIdentifier;
  }

  public void setPreOrderHeaderIdentifier(String preOrderHeaderIdentifier) {
    this.preOrderHeaderIdentifier = preOrderHeaderIdentifier;
  }

  public PreOrderDetails targetDate(String targetDate) {
    this.targetDate = targetDate;
    return this;
  }

  /**
   * Get targetDate
   * 
   * @return targetDate
   **/
  @ApiModelProperty(value = "")

  public String getTargetDate() {
    return targetDate;
  }

  public void setTargetDate(String targetDate) {
    this.targetDate = targetDate;
  }

  public PreOrderDetails workFlowLocation(String workFlowLocation) {
    this.workFlowLocation = workFlowLocation;
    return this;
  }

  /**
   * Get workFlowLocation
   * 
   * @return workFlowLocation
   **/
  @ApiModelProperty(value = "")

  public String getWorkFlowLocation() {
    return workFlowLocation;
  }

  public void setWorkFlowLocation(String workFlowLocation) {
    this.workFlowLocation = workFlowLocation;
  }

  public PreOrderDetails quantityOnHand(String quantityOnHand) {
    this.quantityOnHand = quantityOnHand;
    return this;
  }

  /**
   * Get quantityOnHand
   * 
   * @return quantityOnHand
   **/
  @ApiModelProperty(value = "")

  public String getQuantityOnHand() {
    return quantityOnHand;
  }

  public void setQuantityOnHand(String quantityOnHand) {
    this.quantityOnHand = quantityOnHand;
  }

  public PreOrderDetails activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public PreOrderDetails drug(Drug drug) {
    this.drug = drug;
    return this;
  }

  /**
   * Get drug
   * 
   * @return drug
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Drug getDrug() {
    return drug;
  }

  public void setDrug(Drug drug) {
    this.drug = drug;
  }

  public PreOrderDetails prescription(Prescription prescription) {
    this.prescription = prescription;
    return this;
  }

  /**
   * Get prescription
   * 
   * @return prescription
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Prescription getPrescription() {
    return prescription;
  }

  public void setPrescription(Prescription prescription) {
    this.prescription = prescription;
  }

  public PreOrderDetails prescriptionDispense(PrescriptionDispense prescriptionDispense) {
    this.prescriptionDispense = prescriptionDispense;
    return this;
  }

  /**
   * Get prescriptionDispense
   * 
   * @return prescriptionDispense
   **/
  @ApiModelProperty(value = "")

  @Valid

  public PrescriptionDispense getPrescriptionDispense() {
    return prescriptionDispense;
  }

  public void setPrescriptionDispense(PrescriptionDispense prescriptionDispense) {
    this.prescriptionDispense = prescriptionDispense;
  }

  public PreOrderDetails prescriptionRequest(PrescriptionRequest prescriptionRequest) {
    this.prescriptionRequest = prescriptionRequest;
    return this;
  }

  /**
   * Get prescriptionRequest
   * 
   * @return prescriptionRequest
   **/
  @ApiModelProperty(value = "")

  @Valid

  public PrescriptionRequest getPrescriptionRequest() {
    return prescriptionRequest;
  }

  public void setPrescriptionRequest(PrescriptionRequest prescriptionRequest) {
    this.prescriptionRequest = prescriptionRequest;
  }

  public PreOrderDetails prescriber(Prescriber prescriber) {
    this.prescriber = prescriber;
    return this;
  }

  /**
   * Get prescriber
   * 
   * @return prescriber
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Prescriber getPrescriber() {
    return prescriber;
  }

  public void setPrescriber(Prescriber prescriber) {
    this.prescriber = prescriber;
  }

  public PreOrderDetails alerts(List<AlertsLog> alerts) {
    this.alerts = alerts;
    return this;
  }

  public PreOrderDetails addAlertsItem(AlertsLog alertsItem) {
    if (this.alerts == null) {
      this.alerts = new ArrayList<AlertsLog>();
    }
    this.alerts.add(alertsItem);
    return this;
  }

  /**
   * Get alerts
   * 
   * @return alerts
   **/
  @ApiModelProperty(value = "")

  @Valid

  public List<AlertsLog> getAlerts() {
    return alerts;
  }

  public void setAlerts(List<AlertsLog> alerts) {
    this.alerts = alerts;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PreOrderDetails preOrderDetails = (PreOrderDetails) o;
    return Objects.equals(this.preOrderDetailIdentifier, preOrderDetails.preOrderDetailIdentifier)
        && Objects.equals(this.preOrderHeaderIdentifier, preOrderDetails.preOrderHeaderIdentifier)
        && Objects.equals(this.targetDate, preOrderDetails.targetDate)
        && Objects.equals(this.workFlowLocation, preOrderDetails.workFlowLocation)
        && Objects.equals(this.quantityOnHand, preOrderDetails.quantityOnHand)
        && Objects.equals(this.activeIndicator, preOrderDetails.activeIndicator)
        && Objects.equals(this.drug, preOrderDetails.drug)
        && Objects.equals(this.prescription, preOrderDetails.prescription)
        && Objects.equals(this.prescriptionDispense, preOrderDetails.prescriptionDispense)
        && Objects.equals(this.prescriptionRequest, preOrderDetails.prescriptionRequest)
        && Objects.equals(this.prescriber, preOrderDetails.prescriber)
        && Objects.equals(this.alerts, preOrderDetails.alerts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      preOrderDetailIdentifier,
      preOrderHeaderIdentifier,
      targetDate,
      workFlowLocation,
      quantityOnHand,
      activeIndicator,
      drug,
      prescription,
      prescriptionDispense,
      prescriptionRequest,
      prescriber,
      alerts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PreOrderDetails {\n");

    sb
      .append("    preOrderDetailIdentifier: ")
      .append(toIndentedString(preOrderDetailIdentifier))
      .append("\n");
    sb
      .append("    preOrderHeaderIdentifier: ")
      .append(toIndentedString(preOrderHeaderIdentifier))
      .append("\n");
    sb.append("    targetDate: ").append(toIndentedString(targetDate)).append("\n");
    sb.append("    workFlowLocation: ").append(toIndentedString(workFlowLocation)).append("\n");
    sb.append("    quantityOnHand: ").append(toIndentedString(quantityOnHand)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    drug: ").append(toIndentedString(drug)).append("\n");
    sb.append("    prescription: ").append(toIndentedString(prescription)).append("\n");
    sb.append("    prescriptionDispense: ").append(toIndentedString(prescriptionDispense)).append(
      "\n");
    sb.append("    prescriptionRequest: ").append(toIndentedString(prescriptionRequest)).append(
      "\n");
    sb.append("    prescriber: ").append(toIndentedString(prescriber)).append("\n");
    sb.append("    alerts: ").append(toIndentedString(alerts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
