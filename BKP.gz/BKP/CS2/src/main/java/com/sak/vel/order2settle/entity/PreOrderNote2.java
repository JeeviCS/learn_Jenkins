package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * The persistent class for the PRE_ORDER_NOTE database table.
 * 
 */
@Entity
@Table(name = "PRE_ORDER_NOTE")
@NamedQuery(name = "PreOrderNote2.findAll", query = "SELECT p FROM PreOrderNote p")
public class PreOrderNote2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRE_ORDER_NOTE_ID_GENERATOR")
	@Column(name = "PRE_ORDR_NOTE_ID")
	@SequenceGenerator(sequenceName = "pre_ordr_note_id_seq", initialValue = 1, allocationSize = 1, name = "PRE_ORDER_NOTE_ID_GENERATOR")
	private long preOrdrNoteId;

	@Column(name = "CRTE_TS")
	private Timestamp crteTs;

	@Column(name = "CRTE_USR_NM")
	private String crteUsrNm;

	@Column(name = "NOTE_TYP")
	private String noteTyp;

	@Column(name = "PRE_ORDR_NOTE_TX")
	private String preOrdrNoteTx;

	@Column(name = "PTNT_ID")
	private BigDecimal ptntId;

	@Column(name = "SRC_SYSTM_NM")
	private String srcSystmNm;

	@Column(name = "SRC_SYSTM_NOTE_ID")
	private BigDecimal srcSystmNoteId;

	@Column(name = "UPD_TS")
	private Timestamp updTs;

	@Column(name = "UPD_USR_NM")
	private String updUsrNm;

	// bi-directional many-to-one association to PreOrderHeader
	@ManyToOne
	@JoinColumn(name = "PRE_ORDR_HDR_ID")
	private PreOrderHeader2 preOrderHeader2;

	public PreOrderNote2() {
	}

	public long getPreOrdrNoteId() {
		return this.preOrdrNoteId;
	}

	void setPreOrdrNoteId(long preOrdrNoteId) {
		this.preOrdrNoteId = preOrdrNoteId;
	}

	public Timestamp getCrteTs() {
		return this.crteTs;
	}

	public void setCrteTs(Timestamp crteTs) {
		this.crteTs = crteTs;
	}

	public String getCrteUsrNm() {
		return this.crteUsrNm;
	}

	public void setCrteUsrNm(String crteUsrNm) {
		this.crteUsrNm = crteUsrNm;
	}

	public String getNoteTyp() {
		return this.noteTyp;
	}

	public void setNoteTyp(String noteTyp) {
		this.noteTyp = noteTyp;
	}

	public String getPreOrdrNoteTx() {
		return this.preOrdrNoteTx;
	}

	public void setPreOrdrNoteTx(String preOrdrNoteTx) {
		this.preOrdrNoteTx = preOrdrNoteTx;
	}

	public BigDecimal getPtntId() {
		return this.ptntId;
	}

	public void setPtntId(BigDecimal ptntId) {
		this.ptntId = ptntId;
	}

	public String getSrcSystmNm() {
		return this.srcSystmNm;
	}

	public void setSrcSystmNm(String srcSystmNm) {
		this.srcSystmNm = srcSystmNm;
	}

	public BigDecimal getSrcSystmNoteId() {
		return this.srcSystmNoteId;
	}

	public void setSrcSystmNoteId(BigDecimal srcSystmNoteId) {
		this.srcSystmNoteId = srcSystmNoteId;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrNm() {
		return this.updUsrNm;
	}

	public void setUpdUsrNm(String updUsrNm) {
		this.updUsrNm = updUsrNm;
	}

	public PreOrderHeader2 getPreOrderHeader() {
		return this.preOrderHeader2;
	}

	public void setPreOrderHeader(PreOrderHeader2 preOrderHeader) {
		this.preOrderHeader2 = preOrderHeader;
	}

}