
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

@Controller
public class OrderDownloadFailureApiController implements OrderDownloadFailureApi {

  @Autowired
  SpecialtyLogger LOGGER;

  public ResponseEntity<Void> orderDownloadFailureGet(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "order scheduling Id", required = true) @RequestParam(value = "orderSchedulingId", required = true) Integer orderSchedulingId,
      @NotNull @ApiParam(value = "status", required = true) @RequestParam(value = "status", required = true) String status,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    // do some magic!
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return new ResponseEntity<Void>(HttpStatus.OK);
  }

}
