
package com.cvs.specialty.ordermaintenance.api;

import io.swagger.annotations.ApiParam;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.service.CancelDownloadService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-01T16:17:14.841Z")

@RestController
@RequestMapping("/")
public class CancelDownloadApiController implements CancelDownloadApi {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  CancelDownloadService cancelDownloadService;

  // @RequestMapping(value = "/cancelDownload")
  public ResponseEntity<List<CanceDownloadReasonCodes>> cancelDownloadGet(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "access token to validate this request", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "order Id") @RequestParam(value = "orderId", required = false) Integer orderId,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {
    // do some magic!
    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<List<CanceDownloadReasonCodes>> result = cancelDownloadService.cancelDownloadGet(orderId);
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return result;
  }

  public ResponseEntity<Void> cancelDownloadPost(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "access token to validate this request", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "hbs Number", required = true) @RequestParam(value = "hbsNumber", required = true) Long hbsNumber,
      @NotNull @ApiParam(value = "shipment Number", required = true) @RequestParam(value = "shipmentNumber", required = true) Long shipmentNumber,
      @NotNull @ApiParam(value = "cancel reason", required = true) @RequestParam(value = "cancelReason", required = true) String cancelReason,
      @NotNull @ApiParam(value = "comment", required = true) @RequestParam(value = "comment", required = true) String comment,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");
    LOGGER.info(
      "cancelDownloadPost  - " + userId + "-" + messageId + "-" + hbsNumber + "-"
          + shipmentNumber);
    
    cancelDownloadService.cancelDownloadPost(hbsNumber, shipmentNumber, cancelReason, comment, userId, messageId);
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return new ResponseEntity<Void>(HttpStatus.OK);
  }

}
