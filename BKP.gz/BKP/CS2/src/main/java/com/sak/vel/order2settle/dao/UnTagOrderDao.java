package com.cvs.specialty.ordermaintenance.dao;

import java.math.BigDecimal;
import java.util.List;

import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.model.UntagReasonCodes;

public interface UnTagOrderDao {


	List<RxDetailsList> unTagRxorder(List<RxDetailsList> unTagRx, long orderId, BigDecimal reasonCode);
	
	List<UntagReasonCodes> getUntagReasonCodes(long orderId, String reasonCode);

	

}

