package com.cvs.specialty.ordermaintenance.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;

@Repository
@Transactional
public interface SbpEntityBpmProcessMapRepo extends JpaRepository<SbpEntityBpmProcessMap, Long> {
	SbpEntityBpmProcessMap findBySbpEntyId(Long entityId);
}
