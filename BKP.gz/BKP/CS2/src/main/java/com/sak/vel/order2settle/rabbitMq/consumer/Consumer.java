/*package com.cvs.specialty.ordermaintenance.rabbitMq.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cvs.specialty.ordermaintenance.dao.CancelDownloadDao;
import com.cvs.specialty.ordermaintenance.model.CancelOrderDownloadSuccess;

@Component
public class Consumer {
  
  @Autowired
  CancelDownloadDao cancelDownloadDao;
  
  CancelOrderDownloadSuccess cancelOrderDownloadSuccess;

  @RabbitListener(queues = "${jsa.rabbitmq.queue1}", containerFactory = "jsaFactory")
  public void recievedMessage(CancelOrderDownloadSuccess ordDwnld) {
    try {
      System.out.println("recievedMessage: " + ordDwnld);
      cancelOrderDownloadSuccess = ordDwnld;
      JSONObject jsonInfo = new JSONObject();
      try {
        if ("SUCCESS".equals(cancelOrderDownloadSuccess.getStatus())) {
          // Order download details
          jsonInfo.put("orderGuideId", cancelOrderDownloadSuccess.getOrderGuideId());
          jsonInfo.put("status", cancelOrderDownloadSuccess.getStatus());
          jsonInfo.put("HBSOrderNumber", cancelOrderDownloadSuccess.getHbsOrderNumber());
          jsonInfo.put("HBSShipmentNo", cancelOrderDownloadSuccess.getHbsShipmentNumber());
          jsonInfo.put("HBSStatus", cancelOrderDownloadSuccess.getHbsStatus());
          
          cancelDownloadDao.updateOrderStatus(cancelOrderDownloadSuccess.getOrderGuideId(), "OPEN");
          
        } else {
          jsonInfo.put("orderGuideId", cancelOrderDownloadSuccess.getOrderGuideId());
          jsonInfo.put("status", cancelOrderDownloadSuccess.getStatus());
        }
      } catch (JSONException e1) {
        
      }

      RestTemplate restTemplate = new RestTemplate();
      String walletBalanceUrl = "http://localhost:8080/diversion-tasks/v1/orderDownload";
      HttpHeaders httpHeaders = new HttpHeaders();
      httpHeaders.set("Content-Type", "application/json");

      HttpEntity<String> httpEntity = new HttpEntity<String>(jsonInfo.toString(), httpHeaders);

      restTemplate.exchange(walletBalanceUrl, HttpMethod.PUT, httpEntity, Object.class);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
*/