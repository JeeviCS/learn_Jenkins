package com.cvs.specialty.ordermaintenance.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PreOrderHeaderTasks;


@Repository
@Transactional
public interface ListOfTasksRepo extends JpaRepository<PreOrderHeaderTasks, Long> {
	@Modifying(clearAutomatically = true)	
    @Query("select  bpm.sbpWrkQueTaskId as sbpWrkQueTaskId, bpm.sbpEntyBpmPrcMapId as sbpEntyBpmPrcMapId, bpm.bpmTaskInstanceId as bpmTaskInstanceId, bpm.bpmTaskNm as bpmTaskNm, bpm.sbpQueTaskStusCd as sbpQueTaskStusCd, map.bpmPrcsInstanceId as bpmPrcsInstanceId  \r\n" +
    		"    		from  SbpEntityBpmProcessMap map,SbpWorkQueueTaskBpmTask bpm where \r\n" + 
    		"    		 bpm.actvIn='Y' and bpm.sbpQueTaskStusCd NOT IN ('COMPLETED','CANCELLED') and map.sbpEntyBpmPrcMapId=bpm.sbpEntyBpmPrcMapId and map.sbpEntyTyp='ORDER' and map.sbpEntyId= :orderId ")
	List<Object[]> findBypreOrdrHdrId( @Param("orderId") Long orderId);	
	
	@Modifying(clearAutomatically = true)	
    @Query("select  bpm.sbpWrkQueTaskId as sbpWrkQueTaskId, bpm.sbpEntyBpmPrcMapId as sbpEntyBpmPrcMapId, bpm.bpmTaskInstanceId as bpmTaskInstanceId, bpm.bpmTaskNm as bpmTaskNm, bpm.sbpQueTaskStusCd as sbpQueTaskStusCd, map.bpmPrcsInstanceId as bpmPrcsInstanceId  \r\n" +
    		"    		from  SbpEntityBpmProcessMap map,SbpWorkQueueTaskBpmTask bpm where \r\n" + 
    		"    		 bpm.actvIn='Y' and bpm.sbpQueTaskStusCd IN ('UNASSIGNED') and map.sbpEntyBpmPrcMapId=bpm.sbpEntyBpmPrcMapId and map.sbpEntyTyp='ORDER' and map.sbpEntyId= :orderId ")
	List<Object[]> findUnassignedTask( @Param("orderId") Long orderId);	
	
}