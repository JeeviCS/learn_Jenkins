package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.PreOrderHeader;

public interface ShippingInformationDao {

	List<PreOrderHeader> getShippingDetails(long preOrderId, String status);

	PreOrderHeader getShippingInfo(Long preOrderHeaderId, Long patientId);

	Void updateShippingDetails(long orderId, PreOrderHeader shippingDetails);
}

