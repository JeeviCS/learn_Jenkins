package com.cvs.specialty.ordermaintenance.dao;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;

public interface AutoDownloadEligibilityRulesDao {
	
	ResponseEntity<AutoDownloadError> validateAutoDownloadRules(Long preOrderHeaderId, Long patientId);

}
