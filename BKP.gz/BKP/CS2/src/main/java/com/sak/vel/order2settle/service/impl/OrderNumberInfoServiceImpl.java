
package com.cvs.specialty.ordermaintenance.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderNumberInfoDao;
import com.cvs.specialty.ordermaintenance.model.OrderSatCode;
import com.cvs.specialty.ordermaintenance.service.OrderNumberInfoService;
import com.cvs.specialty.ordermaintenance.util.ValidationError;

@Repository
public class OrderNumberInfoServiceImpl implements OrderNumberInfoService {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	OrderNumberInfoDao orderInfoDao;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResponseEntity<OrderSatCode> getOrderInfo(long preOrderId) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		ResponseEntity<OrderSatCode> response1 = null;

		try {

			ValidationError error = validateInput(preOrderId);
			if (error != null)
				return new ResponseEntity(error, HttpStatus.NOT_ACCEPTABLE);

			OrderSatCode response = orderInfoDao.getOrderInfo(preOrderId);

			if (response == null) {
				response1 = new ResponseEntity(response, HttpStatus.NOT_FOUND);
			} else {
				response1 = new ResponseEntity(response, HttpStatus.OK);
			}
			LOGGER.info(LogMsgConstants.METHOD_EXIT);
			return response1;
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			return new ResponseEntity<OrderSatCode>(HttpStatus.BAD_REQUEST);
		}

	}

	private ValidationError validateInput(long preOrderId) {
		boolean validPreorderId = validatePreOrderId(preOrderId);

		ValidationError error = null;

		if (!validPreorderId) {
			error = new ValidationError("Invalid Pre Order Id", "preOrderId");
			return error;
		}

		return error;
	}

	private boolean validatePreOrderId(long preOrderId) {
		if (0L == preOrderId || preOrderId < 0)
			return false;
		else
			return true;
	}

	private boolean validateOrderGuideNumber(long orderGuideNumber) {
		if (0L == orderGuideNumber || orderGuideNumber < 0)
			return false;
		else
			return true;
	}

}
