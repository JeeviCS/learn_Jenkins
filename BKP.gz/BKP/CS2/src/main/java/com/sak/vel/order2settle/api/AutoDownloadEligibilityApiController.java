
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;
import com.cvs.specialty.ordermaintenance.service.AutoDownloadEligibilityService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@Controller
public class AutoDownloadEligibilityApiController implements AutoDownloadEligibilityApi {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  AutoDownloadEligibilityService autoDownloadEligibilityService;

  @Override
  public ResponseEntity<AutoDownloadError> autoDownloadEligibilityGet(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "access token to validate this request", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "preOrderHeaderId", required = true) @RequestParam(value = "preOrderHeaderId", required = true) Long preOrderHeaderId,
      @NotNull @ApiParam(value = "patientId", required = true) @RequestParam(value = "patientId", required = true) Long patientId,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {
   
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");

    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    LOGGER.info(
      "AutoDownloadEligibilityGet  - " + userId + "-" + messageId + "-" + patientId + "-"
          + preOrderHeaderId);
    ResponseEntity<AutoDownloadError> autoDownloadError = null;
    try {
      autoDownloadError = autoDownloadEligibilityService
        .validateAutoDownloadEligibilityRules(preOrderHeaderId, patientId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return autoDownloadError;

    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<AutoDownloadError>(HttpStatus.BAD_REQUEST);
    }
  }
}
