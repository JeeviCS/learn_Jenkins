
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PrescriptionRequest
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class PrescriptionRequest {
  @JsonProperty("prescriptionRequestIdentifier")
  private String prescriptionRequestIdentifier = null;

  @JsonProperty("patientIdentifier")
  private String patientIdentifier = null;

  @JsonProperty("drugIdentifier")
  private String drugIdentifier = null;

  @JsonProperty("prescriberIndetifier")
  private String prescriberIndetifier = null;

  @JsonProperty("receivingPharmacyIndicator")
  private String receivingPharmacyIndicator = null;

  @JsonProperty("sendingPharmacyIndicator")
  private String sendingPharmacyIndicator = null;

  @JsonProperty("partyAddressIdentifier")
  private String partyAddressIdentifier = null;

  @JsonProperty("partyContactPreferenceIdentifier")
  private String partyContactPreferenceIdentifier = null;

  @JsonProperty("prescriptionIdentifier")
  private String prescriptionIdentifier = null;

  @JsonProperty("prescriptionOriginCode")
  private String prescriptionOriginCode = null;

  @JsonProperty("brandDrugName")
  private String brandDrugName = null;

  @JsonProperty("prescriptionWrittenQuantity")
  private String prescriptionWrittenQuantity = null;

  @JsonProperty("drugCautionCode")
  private String drugCautionCode = null;

  @JsonProperty("daysSupplyNumber")
  private String daysSupplyNumber = null;

  @JsonProperty("refillsAuthorizedNumber")
  private String refillsAuthorizedNumber = null;
  /*
   * @JsonProperty("prescriptionWrittenDate") private LocalDate prescriptionWrittenDate = null;
   */

  @JsonProperty("anticipatedNeedsByDate")
  private String anticipatedNeedsByDate = null;

  @JsonProperty("arriveOnByCode")
  private String arriveOnByCode = null;

  public PrescriptionRequest prescriptionRequestIdentifier(String prescriptionRequestIdentifier) {
    this.prescriptionRequestIdentifier = prescriptionRequestIdentifier;
    return this;
  }

  /**
   * Get prescriptionRequestIdentifier
   * 
   * @return prescriptionRequestIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionRequestIdentifier() {
    return prescriptionRequestIdentifier;
  }

  public void setPrescriptionRequestIdentifier(String prescriptionRequestIdentifier) {
    this.prescriptionRequestIdentifier = prescriptionRequestIdentifier;
  }

  public PrescriptionRequest patientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public PrescriptionRequest drugIdentifier(String drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
    return this;
  }

  /**
   * Get drugIdentifier
   * 
   * @return drugIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getDrugIdentifier() {
    return drugIdentifier;
  }

  public void setDrugIdentifier(String drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
  }

  public PrescriptionRequest prescriberIndetifier(String prescriberIndetifier) {
    this.prescriberIndetifier = prescriberIndetifier;
    return this;
  }

  /**
   * Get prescriberIndetifier
   * 
   * @return prescriberIndetifier
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberIndetifier() {
    return prescriberIndetifier;
  }

  public void setPrescriberIndetifier(String prescriberIndetifier) {
    this.prescriberIndetifier = prescriberIndetifier;
  }

  public PrescriptionRequest receivingPharmacyIndicator(String receivingPharmacyIndicator) {
    this.receivingPharmacyIndicator = receivingPharmacyIndicator;
    return this;
  }

  /**
   * Get receivingPharmacyIndicator
   * 
   * @return receivingPharmacyIndicator
   **/
  @ApiModelProperty(value = "")

  public String getReceivingPharmacyIndicator() {
    return receivingPharmacyIndicator;
  }

  public void setReceivingPharmacyIndicator(String receivingPharmacyIndicator) {
    this.receivingPharmacyIndicator = receivingPharmacyIndicator;
  }

  public PrescriptionRequest sendingPharmacyIndicator(String sendingPharmacyIndicator) {
    this.sendingPharmacyIndicator = sendingPharmacyIndicator;
    return this;
  }

  /**
   * Get sendingPharmacyIndicator
   * 
   * @return sendingPharmacyIndicator
   **/
  @ApiModelProperty(value = "")

  public String getSendingPharmacyIndicator() {
    return sendingPharmacyIndicator;
  }

  public void setSendingPharmacyIndicator(String sendingPharmacyIndicator) {
    this.sendingPharmacyIndicator = sendingPharmacyIndicator;
  }

  public PrescriptionRequest partyAddressIdentifier(String partyAddressIdentifier) {
    this.partyAddressIdentifier = partyAddressIdentifier;
    return this;
  }

  /**
   * Get partyAddressIdentifier
   * 
   * @return partyAddressIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPartyAddressIdentifier() {
    return partyAddressIdentifier;
  }

  public void setPartyAddressIdentifier(String partyAddressIdentifier) {
    this.partyAddressIdentifier = partyAddressIdentifier;
  }

  public PrescriptionRequest partyContactPreferenceIdentifier(
      String partyContactPreferenceIdentifier) {
    this.partyContactPreferenceIdentifier = partyContactPreferenceIdentifier;
    return this;
  }

  /**
   * Get partyContactPreferenceIdentifier
   * 
   * @return partyContactPreferenceIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPartyContactPreferenceIdentifier() {
    return partyContactPreferenceIdentifier;
  }

  public void setPartyContactPreferenceIdentifier(String partyContactPreferenceIdentifier) {
    this.partyContactPreferenceIdentifier = partyContactPreferenceIdentifier;
  }

  public PrescriptionRequest prescriptionIdentifier(String prescriptionIdentifier) {
    this.prescriptionIdentifier = prescriptionIdentifier;
    return this;
  }

  /**
   * Get prescriptionIdentifier
   * 
   * @return prescriptionIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionIdentifier() {
    return prescriptionIdentifier;
  }

  public void setPrescriptionIdentifier(String prescriptionIdentifier) {
    this.prescriptionIdentifier = prescriptionIdentifier;
  }

  public PrescriptionRequest prescriptionOriginCode(String prescriptionOriginCode) {
    this.prescriptionOriginCode = prescriptionOriginCode;
    return this;
  }

  /**
   * Get prescriptionOriginCode
   * 
   * @return prescriptionOriginCode
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionOriginCode() {
    return prescriptionOriginCode;
  }

  public void setPrescriptionOriginCode(String prescriptionOriginCode) {
    this.prescriptionOriginCode = prescriptionOriginCode;
  }

  public PrescriptionRequest brandDrugName(String brandDrugName) {
    this.brandDrugName = brandDrugName;
    return this;
  }

  /**
   * Get brandDrugName
   * 
   * @return brandDrugName
   **/
  @ApiModelProperty(value = "")

  public String getBrandDrugName() {
    return brandDrugName;
  }

  public void setBrandDrugName(String brandDrugName) {
    this.brandDrugName = brandDrugName;
  }

  public PrescriptionRequest prescriptionWrittenQuantity(String prescriptionWrittenQuantity) {
    this.prescriptionWrittenQuantity = prescriptionWrittenQuantity;
    return this;
  }

  /**
   * Get prescriptionWrittenQuantity
   * 
   * @return prescriptionWrittenQuantity
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionWrittenQuantity() {
    return prescriptionWrittenQuantity;
  }

  public void setPrescriptionWrittenQuantity(String prescriptionWrittenQuantity) {
    this.prescriptionWrittenQuantity = prescriptionWrittenQuantity;
  }

  public PrescriptionRequest drugCautionCode(String drugCautionCode) {
    this.drugCautionCode = drugCautionCode;
    return this;
  }

  /**
   * Get drugCautionCode
   * 
   * @return drugCautionCode
   **/
  @ApiModelProperty(value = "")

  public String getDrugCautionCode() {
    return drugCautionCode;
  }

  public void setDrugCautionCode(String drugCautionCode) {
    this.drugCautionCode = drugCautionCode;
  }

  public PrescriptionRequest daysSupplyNumber(String daysSupplyNumber) {
    this.daysSupplyNumber = daysSupplyNumber;
    return this;
  }

  /**
   * Get daysSupplyNumber
   * 
   * @return daysSupplyNumber
   **/
  @ApiModelProperty(value = "")

  public String getDaysSupplyNumber() {
    return daysSupplyNumber;
  }

  public void setDaysSupplyNumber(String daysSupplyNumber) {
    this.daysSupplyNumber = daysSupplyNumber;
  }

  public PrescriptionRequest refillsAuthorizedNumber(String refillsAuthorizedNumber) {
    this.refillsAuthorizedNumber = refillsAuthorizedNumber;
    return this;
  }

  /**
   * Get refillsAuthorizedNumber
   * 
   * @return refillsAuthorizedNumber
   **/
  @ApiModelProperty(value = "")

  public String getRefillsAuthorizedNumber() {
    return refillsAuthorizedNumber;
  }

  public void setRefillsAuthorizedNumber(String refillsAuthorizedNumber) {
    this.refillsAuthorizedNumber = refillsAuthorizedNumber;
  }

  /*
   * public PrescriptionRequest prescriptionWrittenDate(LocalDate prescriptionWrittenDate) {
   * this.prescriptionWrittenDate = prescriptionWrittenDate; return this; }
   */

  /**
   * Get prescriptionWrittenDate
   * 
   * @return prescriptionWrittenDate
   **/
  @ApiModelProperty(value = "")

  @Valid
  /*
   * public LocalDate getPrescriptionWrittenDate() { return prescriptionWrittenDate; }
   * 
   * public void setPrescriptionWrittenDate(LocalDate prescriptionWrittenDate) {
   * this.prescriptionWrittenDate = prescriptionWrittenDate; }
   */
  public PrescriptionRequest anticipatedNeedsByDate(String anticipatedNeedsByDate) {
    this.anticipatedNeedsByDate = anticipatedNeedsByDate;
    return this;
  }

  /**
   * Get anticipatedNeedsByDate
   * 
   * @return anticipatedNeedsByDate
   **/
  @ApiModelProperty(value = "")

  public String getAnticipatedNeedsByDate() {
    return anticipatedNeedsByDate;
  }

  public void setAnticipatedNeedsByDate(String anticipatedNeedsByDate) {
    this.anticipatedNeedsByDate = anticipatedNeedsByDate;
  }

  public PrescriptionRequest arriveOnByCode(String arriveOnByCode) {
    this.arriveOnByCode = arriveOnByCode;
    return this;
  }

  /**
   * Get arriveOnByCode
   * 
   * @return arriveOnByCode
   **/
  @ApiModelProperty(value = "")

  public String getArriveOnByCode() {
    return arriveOnByCode;
  }

  public void setArriveOnByCode(String arriveOnByCode) {
    this.arriveOnByCode = arriveOnByCode;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PrescriptionRequest prescriptionRequest = (PrescriptionRequest) o;
    return Objects
      .equals(this.prescriptionRequestIdentifier, prescriptionRequest.prescriptionRequestIdentifier)
        && Objects.equals(this.patientIdentifier, prescriptionRequest.patientIdentifier)
        && Objects.equals(this.drugIdentifier, prescriptionRequest.drugIdentifier)
        && Objects.equals(this.prescriberIndetifier, prescriptionRequest.prescriberIndetifier)
        && Objects
          .equals(this.receivingPharmacyIndicator, prescriptionRequest.receivingPharmacyIndicator)
        && Objects
          .equals(this.sendingPharmacyIndicator, prescriptionRequest.sendingPharmacyIndicator)
        && Objects.equals(this.partyAddressIdentifier, prescriptionRequest.partyAddressIdentifier)
        && Objects.equals(
          this.partyContactPreferenceIdentifier,
          prescriptionRequest.partyContactPreferenceIdentifier)
        && Objects.equals(this.prescriptionIdentifier, prescriptionRequest.prescriptionIdentifier)
        && Objects.equals(this.prescriptionOriginCode, prescriptionRequest.prescriptionOriginCode)
        && Objects.equals(this.brandDrugName, prescriptionRequest.brandDrugName)
        && Objects
          .equals(this.prescriptionWrittenQuantity, prescriptionRequest.prescriptionWrittenQuantity)
        && Objects.equals(this.drugCautionCode, prescriptionRequest.drugCautionCode)
        && Objects.equals(this.daysSupplyNumber, prescriptionRequest.daysSupplyNumber)
        && Objects.equals(this.refillsAuthorizedNumber, prescriptionRequest.refillsAuthorizedNumber)
        &&
        /*
         * Objects.equals(this.prescriptionWrittenDate, prescriptionRequest.prescriptionWrittenDate)
         * &&
         */
        Objects.equals(this.anticipatedNeedsByDate, prescriptionRequest.anticipatedNeedsByDate)
        && Objects.equals(this.arriveOnByCode, prescriptionRequest.arriveOnByCode);
  }

  /*
   * @Override public int hashCode() { return Objects.hash(prescriptionRequestIdentifier,
   * patientIdentifier, drugIdentifier, prescriberIndetifier, receivingPharmacyIndicator,
   * sendingPharmacyIndicator, partyAddressIdentifier, partyContactPreferenceIdentifier,
   * prescriptionIdentifier, prescriptionOriginCode, brandDrugName, prescriptionWrittenQuantity,
   * drugCautionCode, daysSupplyNumber, refillsAuthorizedNumber, prescriptionWrittenDate,
   * anticipatedNeedsByDate, arriveOnByCode); }
   */
  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PrescriptionRequest {\n");

    sb
      .append("    prescriptionRequestIdentifier: ")
      .append(toIndentedString(prescriptionRequestIdentifier))
      .append("\n");
    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb.append("    drugIdentifier: ").append(toIndentedString(drugIdentifier)).append("\n");
    sb.append("    prescriberIndetifier: ").append(toIndentedString(prescriberIndetifier)).append(
      "\n");
    sb
      .append("    receivingPharmacyIndicator: ")
      .append(toIndentedString(receivingPharmacyIndicator))
      .append("\n");
    sb
      .append("    sendingPharmacyIndicator: ")
      .append(toIndentedString(sendingPharmacyIndicator))
      .append("\n");
    sb
      .append("    partyAddressIdentifier: ")
      .append(toIndentedString(partyAddressIdentifier))
      .append("\n");
    sb
      .append("    partyContactPreferenceIdentifier: ")
      .append(toIndentedString(partyContactPreferenceIdentifier))
      .append("\n");
    sb
      .append("    prescriptionIdentifier: ")
      .append(toIndentedString(prescriptionIdentifier))
      .append("\n");
    sb
      .append("    prescriptionOriginCode: ")
      .append(toIndentedString(prescriptionOriginCode))
      .append("\n");
    sb.append("    brandDrugName: ").append(toIndentedString(brandDrugName)).append("\n");
    sb
      .append("    prescriptionWrittenQuantity: ")
      .append(toIndentedString(prescriptionWrittenQuantity))
      .append("\n");
    sb.append("    drugCautionCode: ").append(toIndentedString(drugCautionCode)).append("\n");
    sb.append("    daysSupplyNumber: ").append(toIndentedString(daysSupplyNumber)).append("\n");
    sb
      .append("    refillsAuthorizedNumber: ")
      .append(toIndentedString(refillsAuthorizedNumber))
      .append("\n");
    /*
     * sb.append("    prescriptionWrittenDate: ").append(toIndentedString(prescriptionWrittenDate)).
     * append("\n");
     */ sb
      .append("    anticipatedNeedsByDate: ")
      .append(toIndentedString(anticipatedNeedsByDate))
      .append("\n");
    sb.append("    arriveOnByCode: ").append(toIndentedString(arriveOnByCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
