package  com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import  com.cvs.specialty.ordermaintenance.model.RxDiversionDetails;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RxTransactionDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-19T16:52:21.883Z")

public class RxTransactionDetails   {
  @JsonProperty("ALNotes")
  private String alNotes = null;

  @JsonProperty("activeIndiactor")
  private String activeIndiactor = null;

  @JsonProperty("prescriptionDispensesId")
  private Long prescriptionDispensesId = null;

  @JsonProperty("prescriptionsId")
  private Long prescriptionsId = null;

  @JsonProperty("shippingSite")
  private String shippingSite = null;

  @JsonProperty("quantityDispensed")
  private Long quantityDispensed = null;

  @JsonProperty("rxDiversionDetails")
  @Valid
  private List<RxDiversionDetails> rxDiversionDetails = null;

  public RxTransactionDetails alNotes(String alNotes) {
    this.alNotes = alNotes;
    return this;
  }

  /**
   * Get alNotes
   * @return alNotes
  **/
  @ApiModelProperty(value = "")


  public String getAlNotes() {
    return alNotes;
  }

  public void setAlNotes(String alNotes) {
    this.alNotes = alNotes;
  }

  public RxTransactionDetails activeIndiactor(String activeIndiactor) {
    this.activeIndiactor = activeIndiactor;
    return this;
  }

  /**
   * Get activeIndiactor
   * @return activeIndiactor
  **/
  @ApiModelProperty(value = "")


  public String getActiveIndiactor() {
    return activeIndiactor;
  }

  public void setActiveIndiactor(String activeIndiactor) {
    this.activeIndiactor = activeIndiactor;
  }

  public RxTransactionDetails prescriptionDispensesId(Long prescriptionDispensesId) {
    this.prescriptionDispensesId = prescriptionDispensesId;
    return this;
  }

  /**
   * Get prescriptionDispensesId
   * @return prescriptionDispensesId
  **/
  @ApiModelProperty(value = "")


  public Long getPrescriptionDispensesId() {
    return prescriptionDispensesId;
  }

  public void setPrescriptionDispensesId(Long prescriptionDispensesId) {
    this.prescriptionDispensesId = prescriptionDispensesId;
  }

  public RxTransactionDetails prescriptionsId(Long prescriptionsId) {
    this.prescriptionsId = prescriptionsId;
    return this;
  }

  /**
   * Get prescriptionsId
   * @return prescriptionsId
  **/
  @ApiModelProperty(value = "")


  public Long getPrescriptionsId() {
    return prescriptionsId;
  }

  public void setPrescriptionsId(Long prescriptionsId) {
    this.prescriptionsId = prescriptionsId;
  }

  public RxTransactionDetails shippingSite(String shippingSite) {
    this.shippingSite = shippingSite;
    return this;
  }

  /**
   * Get shippingSite
   * @return shippingSite
  **/
  @ApiModelProperty(value = "")


  public String getShippingSite() {
    return shippingSite;
  }

  public void setShippingSite(String shippingSite) {
    this.shippingSite = shippingSite;
  }

  public RxTransactionDetails quantityDispensed(Long quantityDispensed) {
    this.quantityDispensed = quantityDispensed;
    return this;
  }

  /**
   * Get quantityDispensed
   * @return quantityDispensed
  **/
  @ApiModelProperty(value = "")


  public Long getQuantityDispensed() {
    return quantityDispensed;
  }

  public void setQuantityDispensed(Long quantityDispensed) {
    this.quantityDispensed = quantityDispensed;
  }

  public RxTransactionDetails rxDiversionDetails(List<RxDiversionDetails> rxDiversionDetails) {
    this.rxDiversionDetails = rxDiversionDetails;
    return this;
  }

  public RxTransactionDetails addRxDiversionDetailsItem(RxDiversionDetails rxDiversionDetailsItem) {
    if (this.rxDiversionDetails == null) {
      this.rxDiversionDetails = new ArrayList<RxDiversionDetails>();
    }
    this.rxDiversionDetails.add(rxDiversionDetailsItem);
    return this;
  }

  /**
   * Get rxDiversionDetails
   * @return rxDiversionDetails
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<RxDiversionDetails> getRxDiversionDetails() {
    return rxDiversionDetails;
  }

  public void setRxDiversionDetails(List<RxDiversionDetails> rxDiversionDetails) {
    this.rxDiversionDetails = rxDiversionDetails;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RxTransactionDetails rxTransactionDetails = (RxTransactionDetails) o;
    return Objects.equals(this.alNotes, rxTransactionDetails.alNotes) &&
        Objects.equals(this.activeIndiactor, rxTransactionDetails.activeIndiactor) &&
        Objects.equals(this.prescriptionDispensesId, rxTransactionDetails.prescriptionDispensesId) &&
        Objects.equals(this.prescriptionsId, rxTransactionDetails.prescriptionsId) &&
        Objects.equals(this.shippingSite, rxTransactionDetails.shippingSite) &&
        Objects.equals(this.quantityDispensed, rxTransactionDetails.quantityDispensed) &&
        Objects.equals(this.rxDiversionDetails, rxTransactionDetails.rxDiversionDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(alNotes, activeIndiactor, prescriptionDispensesId, prescriptionsId, shippingSite, quantityDispensed, rxDiversionDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RxTransactionDetails {\n");
    
    sb.append("    alNotes: ").append(toIndentedString(alNotes)).append("\n");
    sb.append("    activeIndiactor: ").append(toIndentedString(activeIndiactor)).append("\n");
    sb.append("    prescriptionDispensesId: ").append(toIndentedString(prescriptionDispensesId)).append("\n");
    sb.append("    prescriptionsId: ").append(toIndentedString(prescriptionsId)).append("\n");
    sb.append("    shippingSite: ").append(toIndentedString(shippingSite)).append("\n");
    sb.append("    quantityDispensed: ").append(toIndentedString(quantityDispensed)).append("\n");
    sb.append("    rxDiversionDetails: ").append(toIndentedString(rxDiversionDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

