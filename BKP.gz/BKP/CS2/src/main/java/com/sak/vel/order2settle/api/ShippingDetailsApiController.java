
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.ResourceAccessException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;
import com.cvs.specialty.ordermaintenance.service.ShippingDetailsService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

@RestController
@RequestMapping("/")
public class ShippingDetailsApiController implements ShippingDetailsApi {
  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  ShippingDetailsService shippingDetailsService;

  /*
   * @Override public ResponseEntity<List<ShipmentDetails>> shippingDetailsGet(String serviceId,
   * String userId, String messageId, Long orderId, String status, String shipmentNumber) { // do
   * some magic!
   * 
   * ResponseEntity<List<ShipmentDetails>> response = null;
   * 
   * try { System.out.println("response from ShippingDetailsController" +shipmentNumber); response =
   * shippingDetailsService.getShippingDetails(orderId, status, shipmentNumber);
   * 
   * } catch (ResourceAccessException rae) { // LOG.error("Failed to Retrieve DocumentType Record",
   * rae);
   * 
   * } return response;
   * 
   * }
   */
  public ResponseEntity<ShipmentDetails> shippingDetailsGet(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "order Id", required = true) @RequestParam(value = "orderId", required = true) Long orderId,
      @NotNull @ApiParam(value = "status", required = true) @RequestParam(value = "status", required = true) String status,
      @NotNull @ApiParam(value = "shipping number", required = true) @RequestParam(value = "shipmentNumber", required = true) String shipmentNumber,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    ResponseEntity<ShipmentDetails> result = null;

    try {
      LOGGER.info("response from ShippingDetailsController" + shipmentNumber);
      result = shippingDetailsService.getShippingDetails(orderId, status, shipmentNumber);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return result;
    } catch (ResourceAccessException rae) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, rae);
      // LOG.error("Failed to Retrieve DocumentType Record", rae);
      return new ResponseEntity<ShipmentDetails>(HttpStatus.BAD_REQUEST);
    }

  }
}
