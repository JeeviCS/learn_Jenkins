package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the PATIENT_SPCL_ACCTS database table.
 * 
 */
@Embeddable
public class PatientSpclAcctPKEO implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PATIENT_ID", insertable=false, updatable=false)
	private long patientId;

	@Column(name="SPCL_ACCT_ID", insertable=false, updatable=false)
	private long spclAcctId;

	public PatientSpclAcctPKEO() {
	}
	public long getPatientId() {
		return this.patientId;
	}
	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}
	public long getSpclAcctId() {
		return this.spclAcctId;
	}
	public void setSpclAcctId(long spclAcctId) {
		this.spclAcctId = spclAcctId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PatientSpclAcctPKEO)) {
			return false;
		}
		PatientSpclAcctPKEO castOther = (PatientSpclAcctPKEO)other;
		return 
			(this.patientId == castOther.patientId)
			&& (this.spclAcctId == castOther.spclAcctId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.patientId ^ (this.patientId >>> 32)));
		hash = hash * prime + ((int) (this.spclAcctId ^ (this.spclAcctId >>> 32)));
		
		return hash;
	}
}
