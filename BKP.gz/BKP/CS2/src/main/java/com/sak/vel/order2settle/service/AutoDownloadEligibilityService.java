package com.cvs.specialty.ordermaintenance.service;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;
import com.cvs.specialty.ordermaintenance.model.Diversion;


public interface AutoDownloadEligibilityService {
	
  ResponseEntity<Diversion> autoDownloadPost(Integer patientId, Integer preOrderHeaderId, String userId, String messageId);
  
  ResponseEntity<AutoDownloadError> validateAutoDownloadEligibilityRules(Long preOrderHeaderId, Long patientId);
	
}
