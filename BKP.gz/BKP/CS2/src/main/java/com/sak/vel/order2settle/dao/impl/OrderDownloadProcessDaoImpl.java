
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderDownloadProcessDao;
import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;
import com.cvs.specialty.ordermaintenance.repository.OrderDownloadBPMProcessRepo;
import com.cvs.specialty.ordermaintenance.repository.SbpEntityBpmProcessMapRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class OrderDownloadProcessDaoImpl implements OrderDownloadProcessDao {

  @Autowired
  SbpEntityBpmProcessMapRepo sbpEntityBpmProcessMapRepo;

  @Autowired
  SpecialtyLogger LOGGER;

  @Override
  public
      ResponseEntity<SbpEntityBpmProcessMap>
      createProcessInstanceId(BigDecimal preorderId, BigDecimal instanceId) {
    SbpEntityBpmProcessMap spbEntityProcessMap = new SbpEntityBpmProcessMap();

    try {

      LOGGER.info(LogMsgConstants.METHOD_ENTRY);
      spbEntityProcessMap.setBpmPrcsInstanceId(instanceId);
      spbEntityProcessMap.setSbpEntyId(preorderId.longValue());
      spbEntityProcessMap.setBpmPrcsNm("DownloadWF");
      spbEntityProcessMap.setSbpEntyTyp("ORDER");
      spbEntityProcessMap.setCrteTs(new Timestamp(1000));
      spbEntityProcessMap.setCrteUsrNm("Build3.2");
      sbpEntityBpmProcessMapRepo.saveAndFlush(spbEntityProcessMap);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
    }

    catch (DataAccessException e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "DataAccessException");

    } catch (Exception e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "Exception");

    }

    return new ResponseEntity<SbpEntityBpmProcessMap>(spbEntityProcessMap, HttpStatus.ACCEPTED);
  }

}
