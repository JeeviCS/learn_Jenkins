package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.cvs.specialty.ordermaintenance.model.RxTransactionDetails;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * OrderDownloadEngine
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-19T16:52:21.883Z")

public class OrderDownloadEngine   {
  @JsonProperty("orderGuideID")
  private Long orderGuideID = null;

  @JsonProperty("patientId")
  private Long patientId = null;

  @JsonProperty("PLNotes")
  private String plNotes = null;

  @JsonProperty("createUser")
  private String createUser = null;

  @JsonProperty("modeInd")
  private String modeInd = null;

  @JsonProperty("needsDate")
  private String needsDate = null;

  @JsonProperty("needsOnByInit")
  private String needsOnByInit = null;

  @JsonProperty("reprocessCount")
  private Long reprocessCount = null;

  @JsonProperty("processingSite")
  private String processingSite = null;

  @JsonProperty("shipToAddress1")
  private String shipToAddress1 = null;

  @JsonProperty("shipToAddress2")
  private String shipToAddress2 = null;

  @JsonProperty("shipToCity")
  private String shipToCity = null;

  @JsonProperty("shipToDirection")
  private String shipToDirection = null;

  @JsonProperty("shipToPhoneNo")
  private Long shipToPhoneNo = null;

  @JsonProperty("shipToPostalCode")
  private String shipToPostalCode = null;

  @JsonProperty("shipToState")
  private String shipToState = null;

  @JsonProperty("shipmentMethod")
  private String shipmentMethod = null;

  @JsonProperty("shipmentcarrier")
  private String shipmentcarrier = null;

  @JsonProperty("shippingSite")
  private String shippingSite = null;

  @JsonProperty("signatureRequired")
  private String signatureRequired = null;

  @JsonProperty("updateUser")
  private String updateUser = null;



  @JsonProperty("rxTransactionDetails")
  @Valid
  private List<RxTransactionDetails> rxTransactionDetails = null;

  public OrderDownloadEngine orderGuideID(Long orderGuideID) {
    this.orderGuideID = orderGuideID;
    return this;
  }

  /**
   * Get orderGuideID
   * @return orderGuideID
  **/
  @ApiModelProperty(value = "")


  public Long getOrderGuideID() {
    return orderGuideID;
  }

  public void setOrderGuideID(Long orderGuideID) {
    this.orderGuideID = orderGuideID;
  }

  public OrderDownloadEngine patientId(Long patientId) {
    this.patientId = patientId;
    return this;
  }

  /**
   * Get patientId
   * @return patientId
  **/
  @ApiModelProperty(value = "")


  public Long getPatientId() {
    return patientId;
  }

  public void setPatientId(Long patientId) {
    this.patientId = patientId;
  }

  public OrderDownloadEngine plNotes(String plNotes) {
    this.plNotes = plNotes;
    return this;
  }

  /**
   * Get plNotes
   * @return plNotes
  **/
  @ApiModelProperty(value = "")


  public String getPlNotes() {
    return plNotes;
  }

  public void setPlNotes(String plNotes) {
    this.plNotes = plNotes;
  }

  public OrderDownloadEngine createUser(String createUser) {
    this.createUser = createUser;
    return this;
  }

  /**
   * Get createUser
   * @return createUser
  **/
  @ApiModelProperty(value = "")


  public String getCreateUser() {
    return createUser;
  }

  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  public OrderDownloadEngine modeInd(String modeInd) {
    this.modeInd = modeInd;
    return this;
  }

  /**
   * Get modeInd
   * @return modeInd
  **/
  @ApiModelProperty(value = "")


  public String getModeInd() {
    return modeInd;
  }

  public void setModeInd(String modeInd) {
    this.modeInd = modeInd;
  }

  public OrderDownloadEngine needsDate(String needsDate) {
    this.needsDate = needsDate;
    return this;
  }

  /**
   * Get needsDate
   * @return needsDate
  **/
  @ApiModelProperty(value = "")


  public String getNeedsDate() {
    return needsDate;
  }

  public void setNeedsDate(String needsDate) {
    this.needsDate = needsDate;
  }

  public OrderDownloadEngine needsOnByInit(String needsOnByInit) {
    this.needsOnByInit = needsOnByInit;
    return this;
  }

  /**
   * Get needsOnByInit
   * @return needsOnByInit
  **/
  @ApiModelProperty(value = "")


  public String getNeedsOnByInit() {
    return needsOnByInit;
  }

  public void setNeedsOnByInit(String needsOnByInit) {
    this.needsOnByInit = needsOnByInit;
  }

  public OrderDownloadEngine reprocessCount(Long reprocessCount) {
    this.reprocessCount = reprocessCount;
    return this;
  }

  /**
   * Get reprocessCount
   * @return reprocessCount
  **/
  @ApiModelProperty(value = "")


  public Long getReprocessCount() {
    return reprocessCount;
  }

  public void setReprocessCount(Long reprocessCount) {
    this.reprocessCount = reprocessCount;
  }

  public OrderDownloadEngine processingSite(String processingSite) {
    this.processingSite = processingSite;
    return this;
  }

  /**
   * Get processingSite
   * @return processingSite
  **/
  @ApiModelProperty(value = "")


  public String getProcessingSite() {
    return processingSite;
  }

  public void setProcessingSite(String processingSite) {
    this.processingSite = processingSite;
  }

  public OrderDownloadEngine shipToAddress1(String shipToAddress1) {
    this.shipToAddress1 = shipToAddress1;
    return this;
  }

  /**
   * Get shipToAddress1
   * @return shipToAddress1
  **/
  @ApiModelProperty(value = "")


  public String getShipToAddress1() {
    return shipToAddress1;
  }

  public void setShipToAddress1(String shipToAddress1) {
    this.shipToAddress1 = shipToAddress1;
  }

  public OrderDownloadEngine shipToAddress2(String shipToAddress2) {
    this.shipToAddress2 = shipToAddress2;
    return this;
  }

  /**
   * Get shipToAddress2
   * @return shipToAddress2
  **/
  @ApiModelProperty(value = "")


  public String getShipToAddress2() {
    return shipToAddress2;
  }

  public void setShipToAddress2(String shipToAddress2) {
    this.shipToAddress2 = shipToAddress2;
  }

  public OrderDownloadEngine shipToCity(String shipToCity) {
    this.shipToCity = shipToCity;
    return this;
  }

  /**
   * Get shipToCity
   * @return shipToCity
  **/
  @ApiModelProperty(value = "")


  public String getShipToCity() {
    return shipToCity;
  }

  public void setShipToCity(String shipToCity) {
    this.shipToCity = shipToCity;
  }

  public OrderDownloadEngine shipToDirection(String shipToDirection) {
    this.shipToDirection = shipToDirection;
    return this;
  }

  /**
   * Get shipToDirection
   * @return shipToDirection
  **/
  @ApiModelProperty(value = "")


  public String getShipToDirection() {
    return shipToDirection;
  }

  public void setShipToDirection(String shipToDirection) {
    this.shipToDirection = shipToDirection;
  }

  public OrderDownloadEngine shipToPhoneNo(Long shipToPhoneNo) {
    this.shipToPhoneNo = shipToPhoneNo;
    return this;
  }

  /**
   * Get shipToPhoneNo
   * @return shipToPhoneNo
  **/
  @ApiModelProperty(value = "")


  public Long getShipToPhoneNo() {
    return shipToPhoneNo;
  }

  public void setShipToPhoneNo(Long shipToPhoneNo) {
    this.shipToPhoneNo = shipToPhoneNo;
  }

  public OrderDownloadEngine shipToPostalCode(String shipToPostalCode) {
    this.shipToPostalCode = shipToPostalCode;
    return this;
  }

  /**
   * Get shipToPostalCode
   * @return shipToPostalCode
  **/
  @ApiModelProperty(value = "")


  public String getShipToPostalCode() {
    return shipToPostalCode;
  }

  public void setShipToPostalCode(String shipToPostalCode) {
    this.shipToPostalCode = shipToPostalCode;
  }

  public OrderDownloadEngine shipToState(String shipToState) {
    this.shipToState = shipToState;
    return this;
  }

  /**
   * Get shipToState
   * @return shipToState
  **/
  @ApiModelProperty(value = "")


  public String getShipToState() {
    return shipToState;
  }

  public void setShipToState(String shipToState) {
    this.shipToState = shipToState;
  }

  public OrderDownloadEngine shipmentMethod(String shipmentMethod) {
    this.shipmentMethod = shipmentMethod;
    return this;
  }

  /**
   * Get shipmentMethod
   * @return shipmentMethod
  **/
  @ApiModelProperty(value = "")


  public String getShipmentMethod() {
    return shipmentMethod;
  }

  public void setShipmentMethod(String shipmentMethod) {
    this.shipmentMethod = shipmentMethod;
  }

  public OrderDownloadEngine shipmentcarrier(String shipmentcarrier) {
    this.shipmentcarrier = shipmentcarrier;
    return this;
  }

  /**
   * Get shipmentcarrier
   * @return shipmentcarrier
  **/
  @ApiModelProperty(value = "")


  public String getShipmentcarrier() {
    return shipmentcarrier;
  }

  public void setShipmentcarrier(String shipmentcarrier) {
    this.shipmentcarrier = shipmentcarrier;
  }

  public OrderDownloadEngine shippingSite(String shippingSite) {
    this.shippingSite = shippingSite;
    return this;
  }

  /**
   * Get shippingSite
   * @return shippingSite
  **/
  @ApiModelProperty(value = "")


  public String getShippingSite() {
    return shippingSite;
  }

  public void setShippingSite(String shippingSite) {
    this.shippingSite = shippingSite;
  }

  public OrderDownloadEngine signatureRequired(String signatureRequired) {
    this.signatureRequired = signatureRequired;
    return this;
  }

  /**
   * Get signatureRequired
   * @return signatureRequired
  **/
  @ApiModelProperty(value = "")


  public String getSignatureRequired() {
    return signatureRequired;
  }

  public void setSignatureRequired(String signatureRequired) {
    this.signatureRequired = signatureRequired;
  }

  public OrderDownloadEngine updateUser(String updateUser) {
    this.updateUser = updateUser;
    return this;
  }

  /**
   * Get updateUser
   * @return updateUser
  **/
  @ApiModelProperty(value = "")


  public String getUpdateUser() {
    return updateUser;
  }

  public void setUpdateUser(String updateUser) {
    this.updateUser = updateUser;
  }




  public OrderDownloadEngine rxTransactionDetails(List<RxTransactionDetails> rxTransactionDetails) {
    this.rxTransactionDetails = rxTransactionDetails;
    return this;
  }

  public OrderDownloadEngine addRxTransactionDetailsItem(RxTransactionDetails rxTransactionDetailsItem) {
    if (this.rxTransactionDetails == null) {
      this.rxTransactionDetails = new ArrayList<RxTransactionDetails>();
    }
    this.rxTransactionDetails.add(rxTransactionDetailsItem);
    return this;
  }

  /**
   * Get rxTransactionDetails
   * @return rxTransactionDetails
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<RxTransactionDetails> getRxTransactionDetails() {
    return rxTransactionDetails;
  }

  public void setRxTransactionDetails(List<RxTransactionDetails> rxTransactionDetails) {
    this.rxTransactionDetails = rxTransactionDetails;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderDownloadEngine orderDownloadEngine = (OrderDownloadEngine) o;
    return Objects.equals(this.orderGuideID, orderDownloadEngine.orderGuideID) &&
        Objects.equals(this.patientId, orderDownloadEngine.patientId) &&
        Objects.equals(this.plNotes, orderDownloadEngine.plNotes) &&
        Objects.equals(this.createUser, orderDownloadEngine.createUser) &&
        Objects.equals(this.modeInd, orderDownloadEngine.modeInd) &&
        Objects.equals(this.needsDate, orderDownloadEngine.needsDate) &&
        Objects.equals(this.needsOnByInit, orderDownloadEngine.needsOnByInit) &&
        Objects.equals(this.reprocessCount, orderDownloadEngine.reprocessCount) &&
        Objects.equals(this.processingSite, orderDownloadEngine.processingSite) &&
        Objects.equals(this.shipToAddress1, orderDownloadEngine.shipToAddress1) &&
        Objects.equals(this.shipToAddress2, orderDownloadEngine.shipToAddress2) &&
        Objects.equals(this.shipToCity, orderDownloadEngine.shipToCity) &&
        Objects.equals(this.shipToDirection, orderDownloadEngine.shipToDirection) &&
        Objects.equals(this.shipToPhoneNo, orderDownloadEngine.shipToPhoneNo) &&
        Objects.equals(this.shipToPostalCode, orderDownloadEngine.shipToPostalCode) &&
        Objects.equals(this.shipToState, orderDownloadEngine.shipToState) &&
        Objects.equals(this.shipmentMethod, orderDownloadEngine.shipmentMethod) &&
        Objects.equals(this.shipmentcarrier, orderDownloadEngine.shipmentcarrier) &&
        Objects.equals(this.shippingSite, orderDownloadEngine.shippingSite) &&
        Objects.equals(this.signatureRequired, orderDownloadEngine.signatureRequired) &&
        Objects.equals(this.updateUser, orderDownloadEngine.updateUser)  &&
        Objects.equals(this.rxTransactionDetails, orderDownloadEngine.rxTransactionDetails);
  }

  

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderDownloadEngine {\n");
    
    sb.append("    orderGuideID: ").append(toIndentedString(orderGuideID)).append("\n");
    sb.append("    patientId: ").append(toIndentedString(patientId)).append("\n");
    sb.append("    plNotes: ").append(toIndentedString(plNotes)).append("\n");
    sb.append("    createUser: ").append(toIndentedString(createUser)).append("\n");
    sb.append("    modeInd: ").append(toIndentedString(modeInd)).append("\n");
    sb.append("    needsDate: ").append(toIndentedString(needsDate)).append("\n");
    sb.append("    needsOnByInit: ").append(toIndentedString(needsOnByInit)).append("\n");
    sb.append("    reprocessCount: ").append(toIndentedString(reprocessCount)).append("\n");
    sb.append("    processingSite: ").append(toIndentedString(processingSite)).append("\n");
    sb.append("    shipToAddress1: ").append(toIndentedString(shipToAddress1)).append("\n");
    sb.append("    shipToAddress2: ").append(toIndentedString(shipToAddress2)).append("\n");
    sb.append("    shipToCity: ").append(toIndentedString(shipToCity)).append("\n");
    sb.append("    shipToDirection: ").append(toIndentedString(shipToDirection)).append("\n");
    sb.append("    shipToPhoneNo: ").append(toIndentedString(shipToPhoneNo)).append("\n");
    sb.append("    shipToPostalCode: ").append(toIndentedString(shipToPostalCode)).append("\n");
    sb.append("    shipToState: ").append(toIndentedString(shipToState)).append("\n");
    sb.append("    shipmentMethod: ").append(toIndentedString(shipmentMethod)).append("\n");
    sb.append("    shipmentcarrier: ").append(toIndentedString(shipmentcarrier)).append("\n");
    sb.append("    shippingSite: ").append(toIndentedString(shippingSite)).append("\n");
    sb.append("    signatureRequired: ").append(toIndentedString(signatureRequired)).append("\n");
    sb.append("    updateUser: ").append(toIndentedString(updateUser)).append("\n");
    sb.append("    rxTransactionDetails: ").append(toIndentedString(rxTransactionDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

