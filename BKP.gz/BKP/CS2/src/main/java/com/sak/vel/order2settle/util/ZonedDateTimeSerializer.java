
package com.cvs.specialty.ordermaintenance.util;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

@SuppressWarnings("serial")
public class ZonedDateTimeSerializer extends StdSerializer<ZonedDateTime> {
  private static final DateTimeFormatter formatter = DateTimeFormatter
    .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

  public ZonedDateTimeSerializer() {
    this(null);
  }

  public ZonedDateTimeSerializer(Class<ZonedDateTime> t) {
    super(t);
  }

  @Override
  public void serialize(ZonedDateTime value, JsonGenerator gen, SerializerProvider arg2)
      throws IOException {
    gen.writeString(formatter.format(value));
  }
}
