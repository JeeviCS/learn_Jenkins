package com.cvs.specialty.ordermaintenance.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Diversion {

  @JsonProperty("diversionId")
  private Long diversionId;
  
  @JsonProperty("diversionType")
  private String diversionType;
  
  @JsonProperty("reasonCode")
  private String reasonCode;
  
  public Long getDiversionId() {
    return diversionId;
  }
  public void setDiversionId(Long diversionId) {
    this.diversionId = diversionId;
  }
  public String getDiversionType() {
    return diversionType;
  }
  public void setDiversionType(String diversionType) {
    this.diversionType = diversionType;
  }
  public String getReasonCode() {
    return reasonCode;
  }
  public void setReasonCode(String reasonCode) {
    this.reasonCode = reasonCode;
  }
  
  
}
