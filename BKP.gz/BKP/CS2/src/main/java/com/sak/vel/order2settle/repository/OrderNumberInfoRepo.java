
package com.cvs.specialty.ordermaintenance.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PrescriptionDispOrderEO;

@Repository
@Transactional
public interface OrderNumberInfoRepo extends JpaRepository<PrescriptionDispOrderEO, Long> {

  // PreOrderHeader findByPreOrdrHdrId(long preOrderHeaderID);

  /*
   * @Query("select s.sbpWorkQueueTaskId from SbpWorkQueueTaskBpmTask s " +
   * "where s.bpmTaskInstanceId in (:bpmTaskInstanceId) ")
   */

  @Query("SELECT o.orderNumber, o.shipmentNumber, o.orderStatus "
      + "FROM PrescriptionDispOrderEO o " + "WHERE o.orderGuideNumber = :orderGuideNumber "
      + "ORDER BY o.shipmentNumber DESC")
  List<Object>
      findByOrderGudieNumber2(@Param("orderGuideNumber") BigDecimal orderGuideNumber);
}
