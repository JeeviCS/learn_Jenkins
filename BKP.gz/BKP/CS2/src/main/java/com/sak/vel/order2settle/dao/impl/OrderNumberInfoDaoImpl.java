
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderNumberInfoDao;
import com.cvs.specialty.ordermaintenance.model.OrderSatCode;
import com.cvs.specialty.ordermaintenance.model.PrescriptionDispOrders;
import com.cvs.specialty.ordermaintenance.repository.OrderNumberInfoRepo;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class OrderNumberInfoDaoImpl implements OrderNumberInfoDao {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	OrderNumberInfoRepo orderInfoRepo;

	@SuppressWarnings("rawtypes")
	@Autowired
	PreOrderHeaderRepo preOrderHeaderRepo;

	@SuppressWarnings("rawtypes")
	@Override
	public OrderSatCode getOrderInfo(long preOrderId) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		Object preOrderHeader = null;
		List<PrescriptionDispOrders> prescriptionDispOrderModels = null;
		try {
			List<Object> prescriptionDispOrders = orderInfoRepo.findByOrderGudieNumber2(new BigDecimal(preOrderId));

			preOrderHeader = preOrderHeaderRepo.findordersatcode(preOrderId);
			Iterator itr = prescriptionDispOrders.iterator();

			prescriptionDispOrderModels = new ArrayList<PrescriptionDispOrders>();

			while (itr.hasNext()) {
				Object[] obj = (Object[]) itr.next();

				PrescriptionDispOrders prescriptionDispOrdersModel = new PrescriptionDispOrders();

				prescriptionDispOrdersModel.setOrderNumber(String.valueOf(obj[0]));
				prescriptionDispOrdersModel.setShipmentNumber(String.valueOf(obj[1]));
				prescriptionDispOrdersModel.setOrderStatus(String.valueOf(obj[2]));
				prescriptionDispOrderModels.add(prescriptionDispOrdersModel);
			}

		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			throw new OrderMaintenanceException(e, "Exception");

		}

		Object[] obj = (Object[]) preOrderHeader;

		OrderSatCode orderSatCodes = new OrderSatCode();
		orderSatCodes.setOrderStatusCode(String.valueOf(obj[1]));
		orderSatCodes.setOrderStatusReasonCode(String.valueOf(obj[2]));
		orderSatCodes.setPatientIdentifier(String.valueOf(obj[0]));
		orderSatCodes.setHbsNumber(prescriptionDispOrderModels);

		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return orderSatCodes;
	}

}
