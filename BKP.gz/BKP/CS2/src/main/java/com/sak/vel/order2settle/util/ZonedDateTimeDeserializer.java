
package com.cvs.specialty.ordermaintenance.util;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class ZonedDateTimeDeserializer extends StdDeserializer<ZonedDateTime> {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  private static final DateTimeFormatter formatter = DateTimeFormatter
    .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

  public ZonedDateTimeDeserializer() {
    this(null);
  }

  public ZonedDateTimeDeserializer(Class<ZonedDateTime> t) {
    super(t);
  }

  @Override
  public ZonedDateTime deserialize(JsonParser jsonparser, DeserializationContext context)
      throws IOException, JsonProcessingException {
    String date = jsonparser.getText();
    try {
      return ZonedDateTime.parse(date, formatter);
    } catch (DateTimeParseException e) {
      throw new RuntimeException(e);
    }
  }
}
