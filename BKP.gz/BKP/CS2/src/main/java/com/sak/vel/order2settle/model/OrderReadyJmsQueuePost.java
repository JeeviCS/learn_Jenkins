package com.cvs.specialty.ordermaintenance.model;


import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderReadyJmsQueuePost {
	
	@JsonProperty("payload")
	private String payload;
	
	
	
	@JsonProperty("headers")
	private String headers;
	
	
	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getHeaders() {
		return headers;
	}

	public void setHeaders(String headers) {
		this.headers = headers;
	}

	@JsonProperty("preOrderHeaderId")
	private Long preOrderHeaderId;
	
	@JsonProperty("patientId")
	private Long patientId;
	
	@JsonProperty("status")
	private String status;
	
	@JsonProperty("userId")
	private String userId;

	public Long getPreOrderHeaderId() {
		return preOrderHeaderId;
	}

	public void setPreOrderHeaderId(Long preOrderHeaderId) {
		this.preOrderHeaderId = preOrderHeaderId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	

}
