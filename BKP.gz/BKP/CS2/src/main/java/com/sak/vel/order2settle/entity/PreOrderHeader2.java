package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

/**
 * The persistent class for the PRE_ORDER_HEADER database table.
 * 
 */
@Entity
@Table(name = "PRE_ORDER_HEADER")
@NamedQuery(name = "PreOrderHeader2.findAll", query = "SELECT p FROM PreOrderHeader p")
public class PreOrderHeader2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRE_ORDER_HEADER_ID_GENERATOR")
	@Column(name = "PRE_ORDR_HDR_ID")
	@SequenceGenerator(sequenceName = "pre_ordr_hdr_id_seq", initialValue = 1, allocationSize = 1, name = "PRE_ORDER_HEADER_ID_GENERATOR")

	private long preOrdrHdrId;

	@Column(name = "PATIENT_ADDRESS_ID")
	private BigDecimal patAddrId;

	public String getShipmentNumber() {
		return shipmentNumber;
	}

	public void setShipmentNumber(String shipmentNumber) {
		this.shipmentNumber = shipmentNumber;
	}

	@Column(name = "ARV_ON_BY_CD")
	private String arvOnByCd;

	@Column(name = "CMPNY_ID")
	private BigDecimal cmpnyId;

	@Column(name = "CNFRM_DLVRY_TO_ADDR_IN")
	private String cnfrmDlvryToAddrIn;

	@Column(name = "CRTE_TS")
	private Timestamp crteTs;

	@Column(name = "CRTE_USR_NM")
	private String crteUsrNm;

	@Temporal(TemporalType.DATE)
	@Column(name = "EXHST_DT")
	private Date exhstDt;

	@Temporal(TemporalType.DATE)
	@Column(name = "FLUP_DT")
	private Date flupDt;

	@Column(name = "INQ_RSLT_ID")
	private BigDecimal inqRsltId;

	@Temporal(TemporalType.DATE)
	@Column(name = "ORDR_RQST_CMPLTN_DT")
	private Date ordrRqstCmpltnDt;

	@Column(name = "ORDR_SCHD_ID")
	private String ordrSchdId;

	@Column(name = "ORDR_SCHD_PRCS_STUS_ID")
	private BigDecimal ordrSchdPrcsStusId;

	@Column(name = "ORDR_STUS_CD")
	private String ordrStusCd;

	@Column(name = "ORDR_STUS_RSN_CD")
	private String ordrStusRsnCd;

	@Column(name = "PHMCY_ID")
	private BigDecimal phmcyId;

	@Column(name = "PTNT_ID")
	private BigDecimal ptntId;

	@Column(name = "PTNT_SGNTR_RQRD_IN")
	private String ptntSgntrRqrdIn;

	@Column(name = "SHPMT_MTHD_CD")
	private String shpmtMthdCd;

	@Column(name = "SRC_ORDR_NB_TX")
	private String srcOrdrNbTx;

	@Column(name = "SRC_SYSTM_ID")
	private BigDecimal srcSystmId;

	@Column(name = "SRC_SYSTM_NM")
	private String srcSystmNm;

	@Column(name = "UPD_TS")
	private Timestamp updTs;

	@Column(name = "UPD_USR_NM")
	private String updUsrNm;

	@Column(name = "SHPMT_NB")
	private String shipmentNumber;

	// bi-directional many-to-one association to PreOrderNote
	@OneToMany(mappedBy = "preOrderHeader2")
	private List<PreOrderNote2> preOrderNotes;

	public PreOrderHeader2() {
	}

	public long getPreOrdrHdrId() {
		return this.preOrdrHdrId;
	}

	public void setPreOrdrHdrId(long preOrdrHdrId) {
		this.preOrdrHdrId = preOrdrHdrId;
	}

	public BigDecimal getPatAddrId() {
		return this.patAddrId;
	}

	public void setPatAddrId(BigDecimal patAddrId) {
		this.patAddrId = patAddrId;
	}

	public String getArvOnByCd() {
		return this.arvOnByCd;
	}

	public void setArvOnByCd(String arvOnByCd) {
		this.arvOnByCd = arvOnByCd;
	}

	public BigDecimal getCmpnyId() {
		return this.cmpnyId;
	}

	public void setCmpnyId(BigDecimal cmpnyId) {
		this.cmpnyId = cmpnyId;
	}

	public String getCnfrmDlvryToAddrIn() {
		return this.cnfrmDlvryToAddrIn;
	}

	public void setCnfrmDlvryToAddrIn(String cnfrmDlvryToAddrIn) {
		this.cnfrmDlvryToAddrIn = cnfrmDlvryToAddrIn;
	}

	public Timestamp getCrteTs() {
		return this.crteTs;
	}

	public void setCrteTs(Timestamp crteTs) {
		this.crteTs = crteTs;
	}

	public String getCrteUsrNm() {
		return this.crteUsrNm;
	}

	public void setCrteUsrNm(String crteUsrNm) {
		this.crteUsrNm = crteUsrNm;
	}

	public Date getExhstDt() {
		return this.exhstDt;
	}

	public void setExhstDt(Date exhstDt) {
		this.exhstDt = exhstDt;
	}

	public Date getFlupDt() {
		return this.flupDt;
	}

	public void setFlupDt(Date flupDt) {
		this.flupDt = flupDt;
	}

	public BigDecimal getInqRsltId() {
		return this.inqRsltId;
	}

	public void setInqRsltId(BigDecimal inqRsltId) {
		this.inqRsltId = inqRsltId;
	}

	public Date getOrdrRqstCmpltnDt() {
		return this.ordrRqstCmpltnDt;
	}

	public void setOrdrRqstCmpltnDt(Date ordrRqstCmpltnDt) {
		this.ordrRqstCmpltnDt = ordrRqstCmpltnDt;
	}

	public String getOrdrSchdId() {
		return this.ordrSchdId;
	}

	public void setOrdrSchdId(String ordrSchdId) {
		this.ordrSchdId = ordrSchdId;
	}

	public BigDecimal getOrdrSchdPrcsStusId() {
		return this.ordrSchdPrcsStusId;
	}

	public void setOrdrSchdPrcsStusId(BigDecimal ordrSchdPrcsStusId) {
		this.ordrSchdPrcsStusId = ordrSchdPrcsStusId;
	}

	public String getOrdrStusCd() {
		return this.ordrStusCd;
	}

	public void setOrdrStusCd(String ordrStusCd) {
		this.ordrStusCd = ordrStusCd;
	}

	public String getOrdrStusRsnCd() {
		return this.ordrStusRsnCd;
	}

	public void setOrdrStusRsnCd(String ordrStusRsnCd) {
		this.ordrStusRsnCd = ordrStusRsnCd;
	}

	public BigDecimal getPhmcyId() {
		return this.phmcyId;
	}

	public void setPhmcyId(BigDecimal phmcyId) {
		this.phmcyId = phmcyId;
	}

	public BigDecimal getPtntId() {
		return this.ptntId;
	}

	public void setPtntId(BigDecimal ptntId) {
		this.ptntId = ptntId;
	}

	public String getPtntSgntrRqrdIn() {
		return this.ptntSgntrRqrdIn;
	}

	public void setPtntSgntrRqrdIn(String ptntSgntrRqrdIn) {
		this.ptntSgntrRqrdIn = ptntSgntrRqrdIn;
	}

	public String getShpmtMthdCd() {
		return this.shpmtMthdCd;
	}

	public void setShpmtMthdCd(String shpmtMthdCd) {
		this.shpmtMthdCd = shpmtMthdCd;
	}

	public String getSrcOrdrNbTx() {
		return this.srcOrdrNbTx;
	}

	public void setSrcOrdrNbTx(String srcOrdrNbTx) {
		this.srcOrdrNbTx = srcOrdrNbTx;
	}

	public BigDecimal getSrcSystmId() {
		return this.srcSystmId;
	}

	public void setSrcSystmId(BigDecimal srcSystmId) {
		this.srcSystmId = srcSystmId;
	}

	public String getSrcSystmNm() {
		return this.srcSystmNm;
	}

	public void setSrcSystmNm(String srcSystmNm) {
		this.srcSystmNm = srcSystmNm;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrNm() {
		return this.updUsrNm;
	}

	public void setUpdUsrNm(String updUsrNm) {
		this.updUsrNm = updUsrNm;
	}

	public List<PreOrderNote2> getPreOrderNotes() {
		return this.preOrderNotes;
	}

	public void setPreOrderNotes(List<PreOrderNote2> preOrderNotes) {
		this.preOrderNotes = preOrderNotes;
	}

	public PreOrderNote2 addPreOrderNote(PreOrderNote2 preOrderNote) {
		getPreOrderNotes().add(preOrderNote);
		preOrderNote.setPreOrderHeader(this);

		return preOrderNote;
	}

	public PreOrderNote2 removePreOrderNote(PreOrderNote2 preOrderNote) {
		getPreOrderNotes().remove(preOrderNote);
		preOrderNote.setPreOrderHeader(null);

		return preOrderNote;
	}

}