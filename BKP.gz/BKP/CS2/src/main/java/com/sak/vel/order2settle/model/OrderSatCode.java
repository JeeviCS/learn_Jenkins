
package com.cvs.specialty.ordermaintenance.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderSatCode {

  @JsonProperty("patientIdentifier")
  private String patientIdentifier = null;

  @JsonProperty("orderStatusCode")
  private String orderStatusCode = null;

  @JsonProperty("orderStatusReasonCode")
  private String orderStatusReasonCode = null;

  @JsonProperty("hbsNumber")
  List<PrescriptionDispOrders> hbsNumber;

  public String getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public String getOrderStatusCode() {
    return orderStatusCode;
  }

  public void setOrderStatusCode(String orderStatusCode) {
    this.orderStatusCode = orderStatusCode;
  }

  public String getOrderStatusReasonCode() {
    return orderStatusReasonCode;
  }

  public void setOrderStatusReasonCode(String orderStatusReasonCode) {
    this.orderStatusReasonCode = orderStatusReasonCode;
  }

  public List<PrescriptionDispOrders> getHbsNumber() {
    return hbsNumber;
  }

  public void setHbsNumber(List<PrescriptionDispOrders> hbsNumber) {
    this.hbsNumber = hbsNumber;
  }

}
