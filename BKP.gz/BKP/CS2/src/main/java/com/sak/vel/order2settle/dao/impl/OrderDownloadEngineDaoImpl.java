
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderDownloadEngineDao;
import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;
import com.cvs.specialty.ordermaintenance.model.RxTransactionDetails;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class OrderDownloadEngineDaoImpl implements OrderDownloadEngineDao {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	DataSource dataSource;

	private Connection getConnection() {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return conn;
	}

	@Override
	public OrderDownloadEngine getPatientShippingInfo(long preOrderId, long patientID) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		Connection con = null;
		PreparedStatement pStatement = null;
		PreparedStatement pStatement2 = null;

		OrderDownloadEngine orderDownload = new OrderDownloadEngine();
		List<RxTransactionDetails> rxTransactionDetailsList = new ArrayList<RxTransactionDetails>();

		orderDownload.setOrderGuideID(preOrderId);
		orderDownload.setPatientId(patientID);

		try {

			con = getConnection();
			String patientShipmentQuery = "select \r\n"
					+ "PRE_ORDER_HEADER.ARV_ON_BY_CD , PRE_ORDER_HEADER.ORDR_RQST_CMPLTN_DT,\r\n"
					+ "PATIENT_ADDRESS.ADDRESS_1,PATIENT_ADDRESS.ADDRESS_2,PATIENT_ADDRESS.CITY,PATIENT_ADDRESS.DIRECTIONS,PATIENT_ADDRESS.ZIP_1 , PATIENT_ADDRESS.ZIP_2,\r\n"
					+ "PATIENT_ADDRESS.STATE,NVL(PATIENT_ADDRESS.DAY_PHONE_NUMBER, PATIENT_ADDRESS.EVE_PHONE_NUMBER),\r\n"
					+ "PRE_ORDER_HEADER.SHPMT_MTHD_CD,PRE_ORDER_HEADER.PTNT_SGNTR_RQRD_IN\r\n" + "\r\n"
					+ "from PRE_ORDER_HEADER,PATIENT_ADDRESS\r\n" + "\r\n"
					+ "where PRE_ORDER_HEADER.PATIENT_ADDRESS_ID = PATIENT_ADDRESS.PATIENT_ADDRESS_ID\r\n"
					+ "and PRE_ORDER_HEADER.PRE_ORDR_HDR_ID = ?" + "and PRE_ORDER_HEADER.PTNT_ID = ?";

			pStatement = con.prepareStatement(patientShipmentQuery);
			pStatement.setLong(1, preOrderId);
			pStatement.setLong(2, patientID);

			String rxTransactionDetailsQuery = "select PRE_ORDER_DETAIL.ACTV_IN,PRE_ORDER_DETAIL.RX_DSPNS_ID,PRE_ORDER_DETAIL.RX_ID, PRE_ORDER_DETAIL.RMNG_QY from PRE_ORDER_DETAIL, pre_order_header"
					+ " where  pre_order_header.PRE_ORDR_HDR_ID = PRE_ORDER_DETAIL.PRE_ORDR_HDR_ID "
					+ "and  pre_order_header.PTNT_ID =?";

			pStatement2 = con.prepareStatement(rxTransactionDetailsQuery);
			pStatement2.setLong(1, patientID);

			ResultSet rs = pStatement.executeQuery();

			// Expected only One Row in the response

			while (rs.next()) {

				if (rs.getString(1) != null) {
					orderDownload.setNeedsOnByInit(rs.getString(1));
				}

				if (rs.getString(2) != null) {
					orderDownload.setNeedsDate(rs.getDate(2).toString());
				}
				if (rs.getString(3) != null) {
					orderDownload.setShipToAddress1(rs.getString(3));
				}
				if (rs.getString(4) != null) {
					orderDownload.setShipToAddress2(rs.getString(4));
				}
				if (rs.getString(5) != null) {
					orderDownload.setShipToCity(rs.getString(5));
				}
				if (rs.getString(6) != null) {
					orderDownload.setShipToDirection(rs.getString(6));
				}
				if (rs.getString(7) != null && rs.getString(8) != null) {
					orderDownload.setShipToPostalCode(rs.getString(7) + rs.getString(8)); //
				}

				if (rs.getString(9) != null) {
					orderDownload.setShipToState(rs.getString(9));
				}

				if (rs.getString(10) != null) {
					orderDownload.setShipToPhoneNo(rs.getLong(10));
				}
				if (rs.getString(11) != null) {
					orderDownload.setShipmentMethod(rs.getString(11));
				}

				if (rs.getString(12) != null) {
					orderDownload.setSignatureRequired(rs.getString(12));
				}

				orderDownload.setCreateUser("Build 3.2");
				orderDownload.setUpdateUser("Build 3.2");

				orderDownload.setPlNotes("PLNotes");
				orderDownload.setModeInd("B");
				orderDownload.setReprocessCount(0L);
				orderDownload.setProcessingSite("LNA");
				orderDownload.setShipmentcarrier("BMNEAM");
				orderDownload.setShippingSite("PGH");

			}

			ResultSet rs2 = pStatement2.executeQuery();

			while (rs2.next()) {

				RxTransactionDetails rxTransactionDetails = new RxTransactionDetails();
				if (rs2.getString(1) != null) {
					rxTransactionDetails.setActiveIndiactor(rs2.getString(1));
				}
				if (rs2.getString(2) != null) {
					rxTransactionDetails.setPrescriptionDispensesId(rs2.getLong(2));
				}

				if (rs2.getString(3) != null) {
					rxTransactionDetails.setPrescriptionsId(rs2.getLong(3));
				}
				if (rs2.getString(4) != null) {
					rxTransactionDetails.setQuantityDispensed(rs2.getLong(4));
				}

				// rxTransactionDetails.setRxDiversionDetails(diversionDetailsList);
				rxTransactionDetails.setShippingSite("PGH");
				// rxTransactionDetailsList.add(rxTransactionDetails);
				rxTransactionDetails.setAlNotes("aln");

				rxTransactionDetailsList.add(rxTransactionDetails);
				orderDownload.setRxTransactionDetails(rxTransactionDetailsList);
			}

			rs.close();
			rs2.close();
			con.close();
		} catch (SQLException e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			throw new OrderMaintenanceException(e, "SQLException");

		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			throw new OrderMaintenanceException(e, "Exception");

		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return orderDownload;

	}

}
