
package com.cvs.specialty.ordermaintenance.model;

import java.math.BigDecimal;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OrderNotes
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class OrderNotes {
  @JsonProperty("preOrderNoteIdentifier")
  private Long preOrderNoteIdentifier = null;

  @JsonProperty("patientIndetifier")
  private BigDecimal patientIndetifier = null;

  @JsonProperty("preOrderHeaderIdentifier")
  private Long preOrderHeaderIdentifier = null;

  @JsonProperty("sourceSystemNoteIdentifier")
  private BigDecimal sourceSystemNoteIdentifier = null;

  @JsonProperty("sourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("noteType")
  private String noteType = null;

  @JsonProperty("preOrderNoteText")
  private String preOrderNoteText = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public OrderNotes preOrderNoteIdentifier(long preOrderNoteIdentifier) {
    this.preOrderNoteIdentifier = preOrderNoteIdentifier;
    return this;
  }

  /**
   * Get preOrderNoteIdentifier
   * 
   * @return preOrderNoteIdentifier
   **/
  @ApiModelProperty(value = "")

  public long getPreOrderNoteIdentifier() {
    return preOrderNoteIdentifier;
  }

  public void setPreOrderNoteIdentifier(long preOrderNoteIdentifier) {
    this.preOrderNoteIdentifier = preOrderNoteIdentifier;
  }

  public OrderNotes patientIndetifier(BigDecimal patientIndetifier) {
    this.patientIndetifier = patientIndetifier;
    return this;
  }

  /**
   * Get patientIndetifier
   * 
   * @return patientIndetifier
   **/
  @ApiModelProperty(value = "")

  public BigDecimal getPatientIndetifier() {
    return patientIndetifier;
  }

  public void setPatientIndetifier(BigDecimal patientIndetifier) {
    this.patientIndetifier = patientIndetifier;
  }

  public OrderNotes preOrderHeaderIdentifier(long preOrderHeaderIdentifier) {
    this.preOrderHeaderIdentifier = preOrderHeaderIdentifier;
    return this;
  }

  /**
   * Get preOrderHeaderIdentifier
   * 
   * @return preOrderHeaderIdentifier
   **/
  @ApiModelProperty(value = "")

  public long getPreOrderHeaderIdentifier() {
    return preOrderHeaderIdentifier;
  }

  public void setPreOrderHeaderIdentifier(long preOrderHeaderIdentifier) {
    this.preOrderHeaderIdentifier = preOrderHeaderIdentifier;
  }

  public OrderNotes sourceSystemNoteIdentifier(BigDecimal sourceSystemNoteIdentifier) {
    this.sourceSystemNoteIdentifier = sourceSystemNoteIdentifier;
    return this;
  }

  /**
   * Get sourceSystemNoteIdentifier
   * 
   * @return sourceSystemNoteIdentifier
   **/
  @ApiModelProperty(value = "")

  public BigDecimal getSourceSystemNoteIdentifier() {
    return sourceSystemNoteIdentifier;
  }

  public void setSourceSystemNoteIdentifier(BigDecimal sourceSystemNoteIdentifier) {
    this.sourceSystemNoteIdentifier = sourceSystemNoteIdentifier;
  }

  public OrderNotes sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * 
   * @return sourceSystemName
   **/
  @ApiModelProperty(value = "")

  public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public OrderNotes noteType(String noteType) {
    this.noteType = noteType;
    return this;
  }

  /**
   * Get noteType
   * 
   * @return noteType
   **/
  @ApiModelProperty(value = "")

  public String getNoteType() {
    return noteType;
  }

  public void setNoteType(String noteType) {
    this.noteType = noteType;
  }

  public OrderNotes preOrderNoteText(String preOrderNoteText) {
    this.preOrderNoteText = preOrderNoteText;
    return this;
  }

  /**
   * Get preOrderNoteText
   * 
   * @return preOrderNoteText
   **/
  @ApiModelProperty(value = "")

  public String getPreOrderNoteText() {
    return preOrderNoteText;
  }

  public void setPreOrderNoteText(String preOrderNoteText) {
    this.preOrderNoteText = preOrderNoteText;
  }

  public OrderNotes audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderNotes orderNotes = (OrderNotes) o;
    return Objects.equals(this.preOrderNoteIdentifier, orderNotes.preOrderNoteIdentifier)
        && Objects.equals(this.patientIndetifier, orderNotes.patientIndetifier)
        && Objects.equals(this.preOrderHeaderIdentifier, orderNotes.preOrderHeaderIdentifier)
        && Objects.equals(this.sourceSystemNoteIdentifier, orderNotes.sourceSystemNoteIdentifier)
        && Objects.equals(this.sourceSystemName, orderNotes.sourceSystemName)
        && Objects.equals(this.noteType, orderNotes.noteType)
        && Objects.equals(this.preOrderNoteText, orderNotes.preOrderNoteText)
        && Objects.equals(this.audit, orderNotes.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      preOrderNoteIdentifier,
      patientIndetifier,
      preOrderHeaderIdentifier,
      sourceSystemNoteIdentifier,
      sourceSystemName,
      noteType,
      preOrderNoteText,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderNotes {\n");

    sb
      .append("    preOrderNoteIdentifier: ")
      .append(toIndentedString(preOrderNoteIdentifier))
      .append("\n");
    sb.append("    patientIndetifier: ").append(toIndentedString(patientIndetifier)).append("\n");
    sb
      .append("    preOrderHeaderIdentifier: ")
      .append(toIndentedString(preOrderHeaderIdentifier))
      .append("\n");
    sb
      .append("    sourceSystemNoteIdentifier: ")
      .append(toIndentedString(sourceSystemNoteIdentifier))
      .append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    noteType: ").append(toIndentedString(noteType)).append("\n");
    sb.append("    preOrderNoteText: ").append(toIndentedString(preOrderNoteText)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
