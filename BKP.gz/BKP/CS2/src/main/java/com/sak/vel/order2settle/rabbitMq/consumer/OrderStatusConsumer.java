
package com.cvs.specialty.ordermaintenance.rabbitMq.consumer;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;
import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;
import com.cvs.specialty.ordermaintenance.model.Diversion;
import com.cvs.specialty.ordermaintenance.model.OrderStatus;
import com.cvs.specialty.ordermaintenance.rabbitMq.producer.RabbitMQSender;
import com.cvs.specialty.ordermaintenance.repository.SbpEntityBpmProcessMapRepo;

@Component
public class OrderStatusConsumer {

	/*@Autowired
	RabbitMQSender rabbitMQSender;

	@Value("${specialty.bpm.url}")
	private String bmpUrl;

	@Value("${specialty.bpm.download.container.id}")
	private String bmpContainerId;

	@Value("${specialty.bpm.download.process.id}")
	private String bmpProcessId;

	@Value("${specialty.bpm.username}")
	private String bmpUsername;

	@Value("${specialty.bpm.password}")
	private String bmpPassword;

	@Value("${specialty.bpm.signal.ref.name}")
	private String bpmSignalRefName;

	@Autowired
	SbpEntityBpmProcessMapRepo sbpEntityBpmProcessMapRepo;

	@Autowired
	SpecialtyLogger LOGGER;

	OrderStatus orderStatus;

	@RabbitListener(queues = "${orderStatus.rabbitmq.queue}", containerFactory = "jsaFactory")
	public void recievedMessage(OrderStatus orderStatus) throws JSONException {

		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		LOGGER.info("order ID :::" + orderStatus.getOrderGuideNumber());

		RestTemplate restTemplate = new RestTemplate();

		String orderStatusURL = "http://localhost:8070/OrderStatus";
		HttpHeaders httpHeaders = new HttpHeaders();

		httpHeaders.set("Content-Type", "application/json");
		httpHeaders.set("Accept", "application/json");

		try {
			LOGGER.info("Calling order status service to change pre_order_header status");

			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(orderStatusURL);

			UriComponents components = builder.build();
			String fullyQualifiedURL = components.toString();

			MultiValueMap<String, String> headerParams = new LinkedMultiValueMap<String, String>();

			headerParams.add("Content-Type", "application/json");
			headerParams.add("Accept", "*");
			headerParams.add("access-token", "1");
			headerParams.add("message-id", "1");

			HttpEntity<?> entity = new HttpEntity<Object>(headerParams);
			// Add Path Params to URL
			fullyQualifiedURL += "?preOrderHeaderId=" + orderStatus.getOrderGuideNumber();

			// restTemplate.exchange(fullyQualifiedURL, HttpMethod.PUT, entity,
			// String.class);

			// TODO:query SBP_ENTITY_PROCESS_MAP table if process instance id found call BPM
			// else called UI.

			AutoDownloadError autoDownloadError = new AutoDownloadError();
			autoDownloadError.setActionId("1"); // dont pass
			autoDownloadError.setOutcomeId("1"); // dont pass
			autoDownloadError.setDivertRequired("Y");
			autoDownloadError.setTaskType("Process");
			autoDownloadError.setEntityId(123L);
			autoDownloadError.setEntityType("Order");
			autoDownloadError.setPatientId(1243332L);
			autoDownloadError.setFollowUpDate(new Date());
			List<Diversion> diversionList = new ArrayList<Diversion>();
			Diversion diversion = new Diversion();
			diversion.setDiversionId(123L);
			diversionList.add(diversion);
			autoDownloadError.setDiversions(diversionList);
			autoDownloadError.setTaskId(25L);
			autoDownloadError.setCallingService("DownloadFailureService");
			

			SbpEntityBpmProcessMap sbpEntityBpmProcessMap = null;

			LOGGER.info("Fetching Bpm Process Instance Id");
			sbpEntityBpmProcessMap = sbpEntityBpmProcessMapRepo.findBySbpEntyId(orderStatus.getOrderGuideNumber());

			LOGGER.info("Sending response to BPM >>>>>");
			// Map<String, Object> params = new HashMap<String, Object>();
			// params.put("downloadFailureError",autoDownloadError);
			// KieServicesClient client = KieServiceUtil.configure(bmpUrl, bmpUsername,
			// bmpPassword, false);
			// ProcessServicesClient ptClient =
			// client.getServicesClient(ProcessServicesClient.class);
			//
			// // Calling BPM resume process
			// ptClient.signalProcessInstance(bmpContainerId,
			// 580L, bpmSignalRefName,
			// params);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/
}
