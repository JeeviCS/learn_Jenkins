package com.cvs.specialty.ordermaintenance.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class,property="@id", scope = CancelOrderDownloadSuccess.class)
public class CancelOrderDownloadSuccess {

    private Long orderGuideId = null;

    private String status = null;

    private Long hbsOrderNumber = null;

    private Long hbsShipmentNumber = null;

    private String hbsStatus = null;

    private List<OrderDiversionDetails> orderDiversionDetailsList = null;

    private RxDetails rxDetails = null;

    public CancelOrderDownloadSuccess() {
    }

    public CancelOrderDownloadSuccess(Long orderGuideId, String status, Long hbsOrderNumber, Long hbsShipmentNumber,
        String hbsStatus, List<OrderDiversionDetails> orderDiversionDetailsList,
        RxDetails rxDetails) {
      this.orderGuideId = orderGuideId;
      this.status = status;
      this.hbsOrderNumber = hbsOrderNumber;
      this.hbsShipmentNumber = hbsShipmentNumber;
      this.hbsStatus = hbsStatus;
      this.orderDiversionDetailsList = orderDiversionDetailsList;
      this.rxDetails = rxDetails;
    }

    public Long getOrderGuideId() {
      return orderGuideId;
    }

    public void setOrderGuideId(Long orderGuideId) {
      this.orderGuideId = orderGuideId;
    }

    public String getStatus() {
      return status;
    }

    public void setStatus(String status) {
      this.status = status;
    }

    public Long getHbsOrderNumber() {
      return hbsOrderNumber;
    }

    public void setHbsOrderNumber(Long hbsOrderNumber) {
      this.hbsOrderNumber = hbsOrderNumber;
    }

    public Long getHbsShipmentNumber() {
      return hbsShipmentNumber;
    }

    public void setHbsShipmentNumber(Long hbsShipmentNumber) {
      this.hbsShipmentNumber = hbsShipmentNumber;
    }

    public String getHbsStatus() {
      return hbsStatus;
    }

    public void setHbsStatus(String hbsStatus) {
      this.hbsStatus = hbsStatus;
    }

    public List<OrderDiversionDetails> getOrderDiversionDetailsList() {
      return orderDiversionDetailsList;
    }

    public void setOrderDiversionDetailsList(List<OrderDiversionDetails> orderDiversionDetailsList) {
      this.orderDiversionDetailsList = orderDiversionDetailsList;
    }

    public RxDetails getRxDetails() {
      return rxDetails;
    }

    public void setRxDetails(RxDetails rxDetails) {
      this.rxDetails = rxDetails;
    }

    @Override
    public String toString() {
      return "CancelOrderDownloadSuccess [orderGuideId=" + orderGuideId + ", status=" + status
          + ", hbsOrderNumber=" + hbsOrderNumber + ", hbsShipmentNumber=" + hbsShipmentNumber
          + ", hbsStatus=" + hbsStatus + ", orderDiversionDetailsList=" + orderDiversionDetailsList
          + ", rxDetails=" + rxDetails + "]";
    }
    
    
}
