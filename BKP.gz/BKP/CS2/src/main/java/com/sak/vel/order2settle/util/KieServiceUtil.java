/**
 * 
 */
package com.cvs.specialty.ordermaintenance.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.kie.server.api.KieServerConstants;
import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.credentials.EnteredTokenCredentialsProvider;

/**
 * @author Z230337
 *
 */
public class KieServiceUtil {

	private KieServiceUtil() {
		super();
	}

	public static KieServicesClient configure(String url, String token) {
		System.setProperty(KieServerConstants.CFG_BYPASS_AUTH_USER, "true");
		EnteredTokenCredentialsProvider credentialProvider = new EnteredTokenCredentialsProvider(token);

		List<String> capabilities = new ArrayList<String>();
		capabilities.add(KieServerConstants.CAPABILITY_BPM);

		KieServicesConfiguration config = KieServicesFactory.newRestConfiguration(url, credentialProvider);
		config.setCapabilities(capabilities);

		// Set<Class<?>> extra = new HashSet<Class<?>>();

		// Name of the external class/object loaded into JBPM while creating process
		// instance
		// extra.add(ExternalClass.class);
		// config.addExtraClasses(extra);

		config.setMarshallingFormat(MarshallingFormat.JSON);

		return KieServicesFactory.newKieServicesClient(config);

	}

	public static KieServicesClient configure(String url, String username, String password,boolean flagExtraClass) {
		System.setProperty(KieServerConstants.CFG_BYPASS_AUTH_USER, "true");
		KieServicesConfiguration config = KieServicesFactory.newRestConfiguration(url, username, password);
		config.setMarshallingFormat(MarshallingFormat.JSON);
		if(flagExtraClass) {
			Set<Class<?>> extra = new HashSet<Class<?>>();
			extra.add(ProcessSignal.class);
			config.addExtraClasses(extra);
			
		}
		return KieServicesFactory.newKieServicesClient(config);
	}

}
