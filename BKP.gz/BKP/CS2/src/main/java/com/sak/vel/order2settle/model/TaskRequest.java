package com.cvs.specialty.ordermaintenance.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Class Description: Mapper class to Task request for creating task
 * 
 * @author Z243590
 *
 */
	@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-09T21:58:09.088Z")

@JsonInclude(Include.NON_NULL)
public class TaskRequest {

	@JsonProperty("taskSource")
	private String taskSource = null;

	@JsonProperty("taskReason")
	private String taskReason = null;
	
	@JsonProperty("priorityFlag")
	private Boolean priorityFlag = null;
	
	/**
	 * @return the followUpDate
	 */
	
	@JsonProperty("followUpDate")
	private String followUpDate = null;
	
	
	@JsonProperty("commentTxt")
	private String commentTxt = null;
	
	@JsonProperty("rxOrderNumber")
	private String rxOrderNumber = null;

	/**
	 * @return the taskSource
	 */
	public String getTaskSource() {
		return taskSource;
	}

	/**
	 * @param taskSource the taskSource to set
	 */
	public void setTaskSource(String taskSource) {
		this.taskSource = taskSource;
	}

	/**
	 * @return the taskReason
	 */
	public String getTaskReason() {
		return taskReason;
	}

	
	/**
	 * @return the followUpDate
	 */
	public String getFollowUpDate() {
		return followUpDate;
	}

	/**
	 * @param followUpDate the followUpDate to set
	 */
	public void setFollowUpDate(String followUpDate) {
		this.followUpDate = followUpDate;
	}

	/**
	 * @param taskReason the taskReason to set
	 */
	public void setTaskReason(String taskReason) {
		this.taskReason = taskReason;
	}

	/**
	 * @return the priorityFlag
	 */
	public Boolean getPriorityFlag() {
		return priorityFlag;
	}

	/**
	 * @param priorityFlag the priorityFlag to set
	 */
	public void setPriorityFlag(Boolean priorityFlag) {
		this.priorityFlag = priorityFlag;
	}


	/**
	 * @return the commentTxt
	 */
	public String getCommentTxt() {
		return commentTxt;
	}

	/**
	 * @param commentTxt the commentTxt to set
	 */
	public void setCommentTxt(String commentTxt) {
		this.commentTxt = commentTxt;
	}

	/**
	 * @return the rxOrderNumber
	 */
	public String getRxOrderNumber() {
		return rxOrderNumber;
	}

	/**
	 * @param rxOrderNumber the rxOrderNumber to set
	 */
	public void setRxOrderNumber(String rxOrderNumber) {
		this.rxOrderNumber = rxOrderNumber;
	}

}
