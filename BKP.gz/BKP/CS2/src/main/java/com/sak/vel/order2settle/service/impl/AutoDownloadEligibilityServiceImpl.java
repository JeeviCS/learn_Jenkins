
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.AutoDownloadEligibilityRulesDao;
import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;
import com.cvs.specialty.ordermaintenance.model.Diversion;
import com.cvs.specialty.ordermaintenance.service.AutoDownloadEligibilityService;

@Repository
public class AutoDownloadEligibilityServiceImpl implements AutoDownloadEligibilityService {

  @Autowired
  AutoDownloadEligibilityRulesDao autoDownloadEligibilityRulesDao;

  @Autowired
  SpecialtyLogger LOGGER;

  @Override
  public ResponseEntity<Diversion> autoDownloadPost(
      Integer patientId,
      Integer preOrderHeaderId,
      String userId,
      String messageId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    HttpHeaders headers = new HttpHeaders();
    Diversion d = new Diversion();
    try {
      d.setDiversionId(123L);
      d.setDiversionType("RDSM");
      d.setReasonCode("Continue to rule 7");

      headers.setContentType(MediaType.APPLICATION_JSON);
      List<MediaType> acceptHeaders = new ArrayList<MediaType>();
      acceptHeaders.add(MediaType.APPLICATION_JSON);
      headers.set("Content-Type", "application/json");
      headers.setAccept(acceptHeaders);
      headers.add("message-id", messageId);
      headers.add("service-id", messageId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<Diversion>(d, HttpStatus.OK);
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Diversion>(HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public
      ResponseEntity<AutoDownloadError>
      validateAutoDownloadEligibilityRules(Long preOrderHeaderId, Long patientId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<AutoDownloadError> response = autoDownloadEligibilityRulesDao
      .validateAutoDownloadRules(preOrderHeaderId, patientId);
    LOGGER.info("list " + response);
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return response;
  }

}
