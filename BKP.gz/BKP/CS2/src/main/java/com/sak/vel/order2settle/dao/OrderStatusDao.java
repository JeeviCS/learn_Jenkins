
package com.cvs.specialty.ordermaintenance.dao;

public interface OrderStatusDao {

  Void updateOrderStatus(Long preOrdrHdrId);

}
