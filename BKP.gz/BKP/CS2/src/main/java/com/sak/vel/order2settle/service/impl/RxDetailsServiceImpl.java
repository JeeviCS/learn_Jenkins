
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.RxDetailsDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.RxDetailsService;

@Repository
public class RxDetailsServiceImpl implements RxDetailsService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  RxDetailsDao rxDetailsDao;

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Override
  public ResponseEntity<List<RxDetailsList>> rxDetailsListGet(long orderId, long patientID) {

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    List<RxDetailsList> response = null;
    try {
      response = rxDetailsDao.rxDetailsGet(orderId, patientID);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity(response, HttpStatus.OK);
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<List<RxDetailsList>>(HttpStatus.BAD_REQUEST);
    }

    // return (ResponseEntity<List<RxDetailsList>>) response;
  }

}
