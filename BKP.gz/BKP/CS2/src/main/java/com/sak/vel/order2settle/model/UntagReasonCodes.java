package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * UntagReasonCodes
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-21T20:06:05.432Z")

public class UntagReasonCodes   {
  @JsonProperty("untagReasonDesc")
  private String untagReasonDesc = null;

  @JsonProperty("untagReasonCode")
  private String untagReasonCode = null;

  public UntagReasonCodes untagReasonDesc(String untagReasonDesc) {
    this.untagReasonDesc = untagReasonDesc;
    return this;
  }

  /**
   * Get untagReasonDesc
   * @return untagReasonDesc
  **/
  @ApiModelProperty(value = "")


  public String getUntagReasonDesc() {
    return untagReasonDesc;
  }

  public void setUntagReasonDesc(String untagReasonDesc) {
    this.untagReasonDesc = untagReasonDesc;
  }

  public UntagReasonCodes untagReasonCode(String untagReasonCode) {
    this.untagReasonCode = untagReasonCode;
    return this;
  }

  /**
   * Get untagReasonCode
   * @return untagReasonCode
  **/
  @ApiModelProperty(value = "")


  public String getUntagReasonCode() {
    return untagReasonCode;
  }

  public void setUntagReasonCode(String untagReasonCode) {
    this.untagReasonCode = untagReasonCode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UntagReasonCodes untagReasonCodes = (UntagReasonCodes) o;
    return Objects.equals(this.untagReasonDesc, untagReasonCodes.untagReasonDesc) &&
        Objects.equals(this.untagReasonCode, untagReasonCodes.untagReasonCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(untagReasonDesc, untagReasonCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UntagReasonCodes {\n");
    
    sb.append("    untagReasonDesc: ").append(toIndentedString(untagReasonDesc)).append("\n");
    sb.append("    untagReasonCode: ").append(toIndentedString(untagReasonCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

