
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.AddRxOrderDao;
import com.cvs.specialty.ordermaintenance.entity.ItemEO;
import com.cvs.specialty.ordermaintenance.entity.PreOrderDetailEO;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionDispensesEO;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.repository.*;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class AddRxOrderDaoImpl implements AddRxOrderDao {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	PreOrderDetailRepo preOrderDetailRepo;

	@SuppressWarnings("rawtypes")
	@Autowired
	PreOrderHeaderRepo preOrderHeaderRepo;
	@Autowired
	PrescriptionRepo prescriptionRepo;
	@Autowired
	ItemsRepo itemsRepo;
	@Autowired
	PrescriptionDispensesRepo prescriptionDispensesRepo;

	@Override
	public List<RxDetailsList> addRxorder(List<RxDetailsList> rxList, long preOrderId) {
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);

		for (int i = 0; i < rxList.size(); i++) {

			PreOrderDetailEO preOrderDetailEO = new PreOrderDetailEO();

			PrescriptionDispensesEO prescriptionDispensesEO = new PrescriptionDispensesEO();
			ItemEO itemEO = new ItemEO();

			try {
				LOGGER.info("Drug Name: " + rxList.get(i).getDrug().getDrugName() + "\nDrug Strength"
						+ rxList.get(i).getDrug().getDrugStrengthText());
				LOGGER.info("Prescription Dispense ID: "
						+ rxList.get(i).getPrescriptionDispense().getPrescriptionDispenseIdentifier());

				LOGGER.info("Prescription ID: " + rxList.get(i).getPrescription().getPrescriptionIdentifier());
				LOGGER.info("PreHeader order ID: " + preOrderId);

				itemEO = itemsRepo.findByItemId(rxList.get(i).getDrug().getDrugIdentifier());

				prescriptionDispensesEO = prescriptionDispensesRepo
						.findById(rxList.get(i).getPrescriptionDispense().getPrescriptionDispenseIdentifier());

				preOrderDetailEO.setRxId(new BigDecimal(rxList.get(i).getPrescription().getPrescriptionIdentifier()));
				preOrderDetailEO.setPrescriptionDispens(prescriptionDispensesEO);

				preOrderDetailEO.setPreOrdrHdrId(new BigDecimal(preOrderId));

				preOrderDetailEO.setItem(itemEO);
				
				
				System.out.println("------->"+rxList.get(i).getRx_onHand());
				preOrderDetailEO.setRmngQy(new BigDecimal(rxList.get(i).getRx_onHand()));
				

				if (itemEO != null && prescriptionDispensesEO != null) {
					LOGGER.info("Item and Prescription dispenses are not null");
					preOrderDetailRepo.save(preOrderDetailEO);
				} else {
					if (itemEO == null) {
						LOGGER.info("itemEO is null");
						LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED);
						throw new OrderMaintenanceException( "Items are null");

					} else {
						LOGGER.info("Prescription dispense is null");
						LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED);
						throw new OrderMaintenanceException( "Prescription is null");
					}
				}

			}

			catch (DataAccessException e) {

				LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
				throw new OrderMaintenanceException(e, "DataAccessException");

			} catch (Exception e) {

				LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
				throw new OrderMaintenanceException(e, "Exception");
			}

			LOGGER.info(LogMsgConstants.METHOD_EXIT);

		}
		return null;

	}
}
