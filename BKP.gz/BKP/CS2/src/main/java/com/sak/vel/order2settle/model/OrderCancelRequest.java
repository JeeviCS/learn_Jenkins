package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OrderCancelRequest
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-23T04:18:50.004Z")

public class OrderCancelRequest   {
	@JsonProperty("orderId")
	private Long orderId = null;

	@JsonProperty("patientId")
	private Long patientId = null;

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	@JsonProperty("orderCancelReason")
	private String orderCancelReason = null;

	@JsonProperty("patientNotifiedFlag")
	private Boolean patientNotifiedFlag = null;

	@JsonProperty("mdNotifiedFlag")
	private Boolean mdNotifiedFlag = null;

	public OrderCancelRequest orderId(Long orderId) {
		this.orderId = orderId;
		return this;
	}

	/**
	 * Get orderId
	 * @return orderId
	 **/
	@ApiModelProperty(value = "")


	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public OrderCancelRequest orderCancelReason(String orderCancelReason) {
		this.orderCancelReason = orderCancelReason;
		return this;
	}

	/**
	 * Get orderCancelReason
	 * @return orderCancelReason
	 **/
	@ApiModelProperty(value = "")


	public String getOrderCancelReason() {
		return orderCancelReason;
	}

	public void setOrderCancelReason(String orderCancelReason) {
		this.orderCancelReason = orderCancelReason;
	}

	public OrderCancelRequest patientNotifiedFlag(Boolean patientNotifiedFlag) {
		this.patientNotifiedFlag = patientNotifiedFlag;
		return this;
	}

	/**
	 * Get patientNotifiedFlag
	 * @return patientNotifiedFlag
	 **/
	@ApiModelProperty(value = "")


	public Boolean getPatientNotifiedFlag() {
		return patientNotifiedFlag;
	}

	public void setPatientNotifiedFlag(Boolean patientNotifiedFlag) {
		this.patientNotifiedFlag = patientNotifiedFlag;
	}

	public OrderCancelRequest mdNotifiedFlag(Boolean mdNotifiedFlag) {
		this.mdNotifiedFlag = mdNotifiedFlag;
		return this;
	}

	/**
	 * Get mdNotifiedFlag
	 * @return mdNotifiedFlag
	 **/
	@ApiModelProperty(value = "")


	public Boolean getMdNotifiedFlag() {
		return mdNotifiedFlag;
	}

	public void setMdNotifiedFlag(Boolean mdNotifiedFlag) {
		this.mdNotifiedFlag = mdNotifiedFlag;
	}


	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		OrderCancelRequest orderCancelRequest = (OrderCancelRequest) o;
		return Objects.equals(this.orderId, orderCancelRequest.orderId) &&
				Objects.equals(this.patientId, orderCancelRequest.patientId) &&
				Objects.equals(this.orderCancelReason, orderCancelRequest.orderCancelReason) &&
				Objects.equals(this.patientNotifiedFlag, orderCancelRequest.patientNotifiedFlag) &&
				Objects.equals(this.mdNotifiedFlag, orderCancelRequest.mdNotifiedFlag);
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderId, patientId,orderCancelReason, patientNotifiedFlag, mdNotifiedFlag);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class OrderCancelRequest {\n");

		sb.append("    orderId: ").append(toIndentedString(orderId)).append("\n");
		sb.append("    patientId: ").append(toIndentedString(patientId)).append("\n");
		sb.append("    orderCancelReason: ").append(toIndentedString(orderCancelReason)).append("\n");
		sb.append("    patientNotifiedFlag: ").append(toIndentedString(patientNotifiedFlag)).append("\n");
		sb.append("    mdNotifiedFlag: ").append(toIndentedString(mdNotifiedFlag)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}

