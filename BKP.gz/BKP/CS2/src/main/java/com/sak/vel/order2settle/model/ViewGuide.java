
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ViewGuide
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class ViewGuide {
  @JsonProperty("quantityOnHand")
  private Integer quantityOnHand = null;

  @JsonProperty("diversion")
  private String diversion = null;

  @JsonProperty("prescription")
  private Prescription prescription = null;

  @JsonProperty("drug")
  private Drug drug = null;

  @JsonProperty("prescriptionDispense")
  private PrescriptionDispense prescriptionDispense = null;

  @JsonProperty("prescriptionRequest")
  private PrescriptionRequest prescriptionRequest = null;

  @JsonProperty("prescriber")
  private Prescriber prescriber = null;

  public ViewGuide quantityOnHand(Integer quantityOnHand) {
    this.quantityOnHand = quantityOnHand;
    return this;
  }

  /**
   * Get quantityOnHand
   * 
   * @return quantityOnHand
   **/
  @ApiModelProperty(value = "")

  public Integer getQuantityOnHand() {
    return quantityOnHand;
  }

  public void setQuantityOnHand(Integer quantityOnHand) {
    this.quantityOnHand = quantityOnHand;
  }

  public ViewGuide diversion(String diversion) {
    this.diversion = diversion;
    return this;
  }

  /**
   * Get diversion
   * 
   * @return diversion
   **/
  @ApiModelProperty(value = "")

  public String getDiversion() {
    return diversion;
  }

  public void setDiversion(String diversion) {
    this.diversion = diversion;
  }

  public ViewGuide prescription(Prescription prescription) {
    this.prescription = prescription;
    return this;
  }

  /**
   * Get prescription
   * 
   * @return prescription
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Prescription getPrescription() {
    return prescription;
  }

  public void setPrescription(Prescription prescription) {
    this.prescription = prescription;
  }

  public ViewGuide drug(Drug drug) {
    this.drug = drug;
    return this;
  }

  /**
   * Get drug
   * 
   * @return drug
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Drug getDrug() {
    return drug;
  }

  public void setDrug(Drug drug) {
    this.drug = drug;
  }

  public ViewGuide prescriptionDispense(PrescriptionDispense prescriptionDispense) {
    this.prescriptionDispense = prescriptionDispense;
    return this;
  }

  /**
   * Get prescriptionDispense
   * 
   * @return prescriptionDispense
   **/
  @ApiModelProperty(value = "")

  @Valid

  public PrescriptionDispense getPrescriptionDispense() {
    return prescriptionDispense;
  }

  public void setPrescriptionDispense(PrescriptionDispense prescriptionDispense) {
    this.prescriptionDispense = prescriptionDispense;
  }

  public ViewGuide prescriptionRequest(PrescriptionRequest prescriptionRequest) {
    this.prescriptionRequest = prescriptionRequest;
    return this;
  }

  /**
   * Get prescriptionRequest
   * 
   * @return prescriptionRequest
   **/
  @ApiModelProperty(value = "")

  @Valid

  public PrescriptionRequest getPrescriptionRequest() {
    return prescriptionRequest;
  }

  public void setPrescriptionRequest(PrescriptionRequest prescriptionRequest) {
    this.prescriptionRequest = prescriptionRequest;
  }

  public ViewGuide prescriber(Prescriber prescriber) {
    this.prescriber = prescriber;
    return this;
  }

  /**
   * Get prescriber
   * 
   * @return prescriber
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Prescriber getPrescriber() {
    return prescriber;
  }

  public void setPrescriber(Prescriber prescriber) {
    this.prescriber = prescriber;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ViewGuide viewGuide = (ViewGuide) o;
    return Objects.equals(this.quantityOnHand, viewGuide.quantityOnHand)
        && Objects.equals(this.diversion, viewGuide.diversion)
        && Objects.equals(this.prescription, viewGuide.prescription)
        && Objects.equals(this.drug, viewGuide.drug)
        && Objects.equals(this.prescriptionDispense, viewGuide.prescriptionDispense)
        && Objects.equals(this.prescriptionRequest, viewGuide.prescriptionRequest)
        && Objects.equals(this.prescriber, viewGuide.prescriber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      quantityOnHand,
      diversion,
      prescription,
      drug,
      prescriptionDispense,
      prescriptionRequest,
      prescriber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ViewGuide {\n");

    sb.append("    quantityOnHand: ").append(toIndentedString(quantityOnHand)).append("\n");
    sb.append("    diversion: ").append(toIndentedString(diversion)).append("\n");
    sb.append("    prescription: ").append(toIndentedString(prescription)).append("\n");
    sb.append("    drug: ").append(toIndentedString(drug)).append("\n");
    sb.append("    prescriptionDispense: ").append(toIndentedString(prescriptionDispense)).append(
      "\n");
    sb.append("    prescriptionRequest: ").append(toIndentedString(prescriptionRequest)).append(
      "\n");
    sb.append("    prescriber: ").append(toIndentedString(prescriber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
