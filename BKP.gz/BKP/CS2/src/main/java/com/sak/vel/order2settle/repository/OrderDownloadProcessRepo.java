package com.cvs.specialty.ordermaintenance.repository;


import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PatientAddress;

@Repository
@Transactional
public interface OrderDownloadProcessRepo extends JpaRepository<PatientAddress, Long> {
	
	/*@Query("select * from PatientAddress where patientId = ?1")*/
	List<PatientAddress> findByPatientId(BigDecimal patientId);
	
	@Modifying
	@Query("update PatientAddress ptntAddr set "
			+ "ptntAddr.id = :id,ptntAddr.address1 = :address1, ptntAddr.address2 = :address2, "
			+ "ptntAddr.city = :city, ptntAddr.addressCategory = :addressCategory, ptntAddr.addressSeqNo = :addressSeqNo, ptntAddr.addressTypeCd = :addressTypeCd,"
			+ "ptntAddr.addressRank = :addressRank, ptntAddr.monInd = :monInd, ptntAddr.tueInd = :tueInd, ptntAddr.wedInd = :wedInd, ptntAddr.thuInd = :thuInd, ptntAddr.friInd = :friInd,"
			+ "ptntAddr.satInd = :satInd,ptntAddr.sunInd = :sunInd,ptntAddr.createDt = :createDt, ptntAddr.createBy = :createBy"
			+ " where ptntAddr.id = :id")
	Integer updateShippingDetailforPtnt(@Param("id") BigDecimal id, @Param("address1") String address1,
											@Param("address2") String address2, @Param("city") String city, 
											@Param("addressCategory") String addressCategory, @Param("addressSeqNo") long addressSeqNo, @Param("addressTypeCd") String addressTypeCd,
											@Param("addressRank") long addressRank, @Param("monInd") String monInd, @Param("tueInd") String tueInd, @Param("wedInd") String wedInd, @Param("thuInd") String thuInd,
											@Param("friInd") String friInd, @Param("satInd") String satInd, @Param("sunInd") String sunInd, @Param("createDt") Date createDt, @Param("createBy") String createBy); 
	
	
	//PreOrderNote findByCrteUsrNm(String name);
	
	//PreOrderNote findByIntakeRfrlIdAndDocNm(BigDecimal intakeId, String docNm);
	
/*	
	patientAddr.setPatientId(preOrderHeader.getPtntId());
	patientAddr.setAddress1(shippingDetails.getShippingDetails().getAddressLine1Text());
	patientAddr.setAddress2(shippingDetails.getShippingDetails().getAddressLine2Text());
	patientAddr.setCity(shippingDetails.getShippingDetails().getCityText());
	patientAddr.setCountryCd(shippingDetails.getShippingDetails().getCountryText());
	patientAddr.setAddressCategory(shippingDetails.getShippingDetails().getAddressCategoryCode());
	shippingDetails.getShippingDetails().getAddressSeqNo();
			shippingDetails.getShippingDetails().getAddressTypeCd();
				shippingDetails.getShippingDetails().getAddressRank();
				shippingDetails.getShippingDetails().getMonInd();
				shippingDetails.getShippingDetails().getTueInd();
				shippingDetails.getShippingDetails().getWedInd();
				shippingDetails.getShippingDetails().getThuInd();
				shippingDetails.getShippingDetails().getFriInd();
				shippingDetails.getShippingDetails().getSatInd();
				shippingDetails.getShippingDetails().getSunInd();
				shippingDetails.getShippingDetails().getCreateDt();
				shippingDetails.getShippingDetails().getCreateBy();
	*/
}





