package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PATIENT_ADDRESSES database table.
 * 
 */
@Entity
@Table(name="PATIENT_ADDRESSES")
@NamedQuery(name="PatientAddress.findAll", query="SELECT p FROM PatientAddress p")
public class PatientAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	/*@EmbeddedId
	private PatientAddressPK id;*/
	@Id
	@Column(name="PATIENT_ID")
	private BigDecimal patientId;

	@Column(name="ADDRESS_SEQ_NO")
	private Long addressSeqNo;
	
	public BigDecimal getPatientId() {
		return patientId;
	}

	public void setPatientId(BigDecimal patientId) {
		this.patientId = patientId;
	}

	public Long getAddressSeqNo() {
		return addressSeqNo;
	}

	public void setAddressSeqNo(Long addressSeqNo) {
		this.addressSeqNo = addressSeqNo;
	}

	@Column(name="ADDRESS_1")
	private String address1;

	@Column(name="ADDRESS_2")
	private String address2;

	@Column(name="ADDRESS_3")
	private String address3;

	@Column(name="ADDRESS_CATEGORY")
	private String addressCategory;

	@Temporal(TemporalType.DATE)
	@Column(name="ADDRESS_END_DT")
	private Date addressEndDt;

	@Column(name="ADDRESS_RANK")
	private Long addressRank;

	@Temporal(TemporalType.DATE)
	@Column(name="ADDRESS_START_DT")
	private Date addressStartDt;

	@Column(name="ADDRESS_TYPE_CD")
	private String addressTypeCd;

	@Column(name="CELL_PHONE")
	private BigDecimal cellPhone;

	private String city;

	@Column(name="CONTACT_FIRST_NAME")
	private String contactFirstName;

	@Column(name="CONTACT_LAST_NAME")
	private String contactLastName;

	@Column(name="CONTACT_REL_TO_PT_CD")
	private BigDecimal contactRelToPtCd;

	@Column(name="CREATE_BY")
	private String createBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_DT")
	private Date createDt;

	private String directions;

	@Column(name="FRI_IND")
	private String friInd;

	@Column(name="MASTER_ADDRESS_TYPE")
	private String masterAddressType;

	@Column(name="MON_IND")
	private String monInd;

	@Column(name="SAT_IND")
	private String satInd;

	@Column(name="SHIP_WITH_ADDRESS_ID")
	private BigDecimal shipWithAddressId;

	@Column(name="STATE_CD")
	private String stateCd;

	@Column(name="STORE_ID")
	private BigDecimal storeId;

	@Column(name="SUN_IND")
	private String sunInd;

	@Column(name="TELEPHONE_DAY")
	private BigDecimal telephoneDay;

	@Column(name="TELEPHONE_EVE")
	private BigDecimal telephoneEve;

	@Column(name="THU_IND")
	private String thuInd;

	@Column(name="TUE_IND")
	private String tueInd;

	@Column(name="UPDATE_BY")
	private String updateBy;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATE_DT")
	private Date updateDt;

	@Column(name="WED_IND")
	private String wedInd;

	@Column(name="ZIP_1")
	private String zip1;

	@Column(name="ZIP_2")
	private String zip2;

	public PatientAddress() {
	}

/*	public PatientAddressPK getId() {
		return this.id;
	}

	public void setId(PatientAddressPK id) {
		this.id = id;
	}*/

	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return this.address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddressCategory() {
		return this.addressCategory;
	}

	public void setAddressCategory(String addressCategory) {
		this.addressCategory = addressCategory;
	}

	public Date getAddressEndDt() {
		return this.addressEndDt;
	}

	public void setAddressEndDt(Date addressEndDt) {
		this.addressEndDt = addressEndDt;
	}

	public Long getAddressRank() {
		return this.addressRank;
	}

	public void setAddressRank(Long addressRank) {
		this.addressRank = addressRank;
	}

	public Date getAddressStartDt() {
		return this.addressStartDt;
	}

	public void setAddressStartDt(Date addressStartDt) {
		this.addressStartDt = addressStartDt;
	}

	public String getAddressTypeCd() {
		return this.addressTypeCd;
	}

	public void setAddressTypeCd(String addressTypeCd) {
		this.addressTypeCd = addressTypeCd;
	}

	public BigDecimal getCellPhone() {
		return this.cellPhone;
	}

	public void setCellPhone(BigDecimal cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getContactFirstName() {
		return this.contactFirstName;
	}

	public void setContactFirstName(String contactFirstName) {
		this.contactFirstName = contactFirstName;
	}

	public String getContactLastName() {
		return this.contactLastName;
	}

	public void setContactLastName(String contactLastName) {
		this.contactLastName = contactLastName;
	}

	public BigDecimal getContactRelToPtCd() {
		return this.contactRelToPtCd;
	}

	public void setContactRelToPtCd(BigDecimal contactRelToPtCd) {
		this.contactRelToPtCd = contactRelToPtCd;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDt() {
		return this.createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getDirections() {
		return this.directions;
	}

	public void setDirections(String directions) {
		this.directions = directions;
	}

	public String getFriInd() {
		return this.friInd;
	}

	public void setFriInd(String friInd) {
		this.friInd = friInd;
	}

	public String getMasterAddressType() {
		return this.masterAddressType;
	}

	public void setMasterAddressType(String masterAddressType) {
		this.masterAddressType = masterAddressType;
	}

	public String getMonInd() {
		return this.monInd;
	}

	public void setMonInd(String monInd) {
		this.monInd = monInd;
	}

	public String getSatInd() {
		return this.satInd;
	}

	public void setSatInd(String satInd) {
		this.satInd = satInd;
	}

	public BigDecimal getShipWithAddressId() {
		return this.shipWithAddressId;
	}

	public void setShipWithAddressId(BigDecimal shipWithAddressId) {
		this.shipWithAddressId = shipWithAddressId;
	}

	public String getStateCd() {
		return this.stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public BigDecimal getStoreId() {
		return this.storeId;
	}

	public void setStoreId(BigDecimal storeId) {
		this.storeId = storeId;
	}

	public String getSunInd() {
		return this.sunInd;
	}

	public void setSunInd(String sunInd) {
		this.sunInd = sunInd;
	}

	public BigDecimal getTelephoneDay() {
		return this.telephoneDay;
	}

	public void setTelephoneDay(BigDecimal telephoneDay) {
		this.telephoneDay = telephoneDay;
	}

	public BigDecimal getTelephoneEve() {
		return this.telephoneEve;
	}

	public void setTelephoneEve(BigDecimal telephoneEve) {
		this.telephoneEve = telephoneEve;
	}

	public String getThuInd() {
		return this.thuInd;
	}

	public void setThuInd(String thuInd) {
		this.thuInd = thuInd;
	}

	public String getTueInd() {
		return this.tueInd;
	}

	public void setTueInd(String tueInd) {
		this.tueInd = tueInd;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public String getWedInd() {
		return this.wedInd;
	}

	public void setWedInd(String wedInd) {
		this.wedInd = wedInd;
	}

	public String getZip1() {
		return this.zip1;
	}

	public void setZip1(String zip1) {
		this.zip1 = zip1;
	}

	public String getZip2() {
		return this.zip2;
	}

	public void setZip2(String zip2) {
		this.zip2 = zip2;
	}

}