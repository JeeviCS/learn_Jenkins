
package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.RxDetailsList;

public interface SplitRxOrderDao {

  List<RxDetailsList> splitRxorder(List<RxDetailsList> rxList, long preOrderId);

}
