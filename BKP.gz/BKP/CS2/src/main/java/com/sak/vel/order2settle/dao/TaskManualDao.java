package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.TaskLists;

public interface TaskManualDao {
	public List<TaskLists> getListofTasks(String orderId);
	public List<TaskLists> getListofUnassignedTasks(String orderId);
}
