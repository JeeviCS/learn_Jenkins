/**
 * 
 */
package com.cvs.specialty.ordermaintenance.util;

/**
 * This class is to handle the exceptions returned by RestTemplate
 * @author Z231675
 *
 */
public class RestInvocationException extends OrderMaintenanceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9201907998552089284L;
	
	private String responseBody;
	

	/**
	 * @param httpStatusCode
	 * @param responseBody
	 * @param errorCode
	 * @param paramName
	 */
	public RestInvocationException(int httpStatusCode, String responseBody, String errorCode) {
		this.httpStatusCode = httpStatusCode;
		this.responseBody = responseBody;
		this.errorCode = errorCode;
	}

	/**
	 * @return the responseBody
	 */
	public String getResponseBody() {
		return responseBody;
	}

	/**
	 * @param responseBody the responseBody to set
	 */
	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}

}
