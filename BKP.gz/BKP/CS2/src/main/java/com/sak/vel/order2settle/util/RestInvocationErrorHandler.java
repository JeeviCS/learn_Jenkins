/**
 * 
 */
package com.cvs.specialty.ordermaintenance.util;

import static com.cvs.specialty.ordermaintenance.util.Constants.REST_INVOCATION_ERROR;

import java.io.IOException;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

/**
 * This class is to handle the exceptions returned by RestTemplate
 * @author Z231675
 *
 */
public class RestInvocationErrorHandler extends DefaultResponseErrorHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(RestInvocationErrorHandler.class);

	/* (non-Javadoc)
	 * @see org.springframework.web.client.DefaultResponseErrorHandler#handleError(org.springframework.http.client.ClientHttpResponse)
	 */
	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		logger.error("Error occurred while REST API Invocation: Http Status Code: {}, Response Body: {}", response.getStatusText(), getResponseBody(response));
		throw new RestInvocationException(500, Arrays.toString(getResponseBody(response)), REST_INVOCATION_ERROR);
	}

}
