package com.cvs.specialty.ordermaintenance.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.model.OrderDownloadFailure;
import com.cvs.specialty.ordermaintenance.service.DownloadFailureService;

@Repository
public class DownloadFailureServiceImpl implements DownloadFailureService {


	@Autowired
	SpecialtyLogger LOGGER;

	@Override
	public ResponseEntity<String> downloadFailure(OrderDownloadFailure orderDownloadFailure) {
		RestTemplate restTemplate = new RestTemplate();
		
		String downloadFailureBPMUrl = "http://10.228.132.81:8080/rule/swagger-ui.html#!/Download_Failure_Rule/executeDownloadFailureRuleUsingPOST";
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");

		System.out.println("into service impl:::");
		HttpEntity<OrderDownloadFailure> httpEntity = new HttpEntity<OrderDownloadFailure>(orderDownloadFailure, httpHeaders);

		ResponseEntity<OrderDownloadFailure> response= restTemplate.exchange(downloadFailureBPMUrl, HttpMethod.GET, httpEntity, OrderDownloadFailure.class);
	
		System.out.println("in the service impl"+response);
		return null ;	
	}


}
