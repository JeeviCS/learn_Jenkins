
package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the PRESCRIPTION_DISP_ORDERS database table.
 * 
 */
@Entity
@Table(name = "PRESCRIPTION_DISP_ORDERS")
@NamedQuery(name = "PrescriptionDispOrderEO.findAll", query = "SELECT p FROM PrescriptionDispOrderEO p")
public class PrescriptionDispOrderEO implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  private long id;

  @Column(name = "ACTUAL_DISPENSED")
  private BigDecimal actualDispensed;

  @Column(name = "CANCEL_DATE")
  private Date cancelDate;

  @Column(name = "CANCEL_REASON")
  private String cancelReason;

  @Column(name = "CANCEL_SITE_ID")
  private BigDecimal cancelSiteId;

  @Column(name = "COMPANY_ID")
  private BigDecimal companyId;

  @Column(name = "CREATE_BY")
  private String createBy;

  @Column(name = "CREATE_DATE")
  private Date createDate;

  @Column(name = "CREATE_PHARMACARE_SYSTEM_ID")
  private BigDecimal createPharmacareSystemId;

  @Column(name = "CREATE_PROCESS")
  private String createProcess;

  @Column(name = "DOWNLOAD_DATE")
  private Date downloadDate;

  @Column(name = "DOWNLOAD_DATE_TIME")
  private Date downloadDateTime;

  @Column(name = "IOR_ORDER_ID")
  private BigDecimal iorOrderId;

  @Column(name = "NEEDS_DT")
  private Date needsDt;

  @Column(name = "NEEDS_ON_BY_INIT")
  private String needsOnByInit;

  @Column(name = "NON_RX_ITEM")
  private String nonRxItem;

  @Column(name = "ORDER_GUIDE_NUMBER")
  private BigDecimal orderGuideNumber;

  @Column(name = "ORDER_NUMBER")
  private String orderNumber;

  @Column(name = "ORDER_QUANTITY")
  private BigDecimal orderQuantity;

  @Column(name = "ORDER_STATUS")
  private String orderStatus;

  @Column(name = "PRESCRIPTIONS_DISPENSES_ID")
  private BigDecimal prescriptionsDispensesId;

  @Column(name = "PROCESSING_COMPANY_ID")
  private BigDecimal processingCompanyId;

  @Column(name = "PROCESSING_SITE_ID")
  private BigDecimal processingSiteId;

  @Column(name = "RETAIL_ITEM_COUNTER")
  private String retailItemCounter;

  @Column(name = "RETAIL_ITEM_PATIENT_PAY")
  private BigDecimal retailItemPatientPay;

  @Column(name = "SERVICE_FEE_ATTACH_IND")
  private String serviceFeeAttachInd;

  @Column(name = "SHIPMENT_NUMBER")
  private String shipmentNumber;

  @Column(name = "SHIPPED_DATE")
  private Date shippedDate;

  @Column(name = "SHIPPED_DATE_TIME")
  private Date shippedDateTime;

  @Column(name = "SITE_ID")
  private BigDecimal siteId;

  @Column(name = "SKU_NUMBER")
  private String skuNumber;

  @Column(name = "SPARCS_INTERFACE_DATE")
  private Date sparcsInterfaceDate;

  @Column(name = "UPDATE_BY")
  private String updateBy;

  @Column(name = "UPDATE_DATE")
  private Date updateDate;

  @Column(name = "UPDATE_PHARMACARE_SYSTEM_ID")
  private BigDecimal updatePharmacareSystemId;

  @Column(name = "UPDATE_PROCESS")
  private String updateProcess;

  public PrescriptionDispOrderEO() {}

  public long getId() {
    return this.id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public BigDecimal getActualDispensed() {
    return this.actualDispensed;
  }

  public void setActualDispensed(BigDecimal actualDispensed) {
    this.actualDispensed = actualDispensed;
  }

  public Date getCancelDate() {
    return this.cancelDate;
  }

  public void setCancelDate(Date cancelDate) {
    this.cancelDate = cancelDate;
  }

  public String getCancelReason() {
    return this.cancelReason;
  }

  public void setCancelReason(String cancelReason) {
    this.cancelReason = cancelReason;
  }

  public BigDecimal getCancelSiteId() {
    return this.cancelSiteId;
  }

  public void setCancelSiteId(BigDecimal cancelSiteId) {
    this.cancelSiteId = cancelSiteId;
  }

  public BigDecimal getCompanyId() {
    return this.companyId;
  }

  public void setCompanyId(BigDecimal companyId) {
    this.companyId = companyId;
  }

  public String getCreateBy() {
    return this.createBy;
  }

  public void setCreateBy(String createBy) {
    this.createBy = createBy;
  }

  public Date getCreateDate() {
    return this.createDate;
  }

  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }

  public BigDecimal getCreatePharmacareSystemId() {
    return this.createPharmacareSystemId;
  }

  public void setCreatePharmacareSystemId(BigDecimal createPharmacareSystemId) {
    this.createPharmacareSystemId = createPharmacareSystemId;
  }

  public String getCreateProcess() {
    return this.createProcess;
  }

  public void setCreateProcess(String createProcess) {
    this.createProcess = createProcess;
  }

  public Date getDownloadDate() {
    return this.downloadDate;
  }

  public void setDownloadDate(Date downloadDate) {
    this.downloadDate = downloadDate;
  }

  public Date getDownloadDateTime() {
    return this.downloadDateTime;
  }

  public void setDownloadDateTime(Date downloadDateTime) {
    this.downloadDateTime = downloadDateTime;
  }

  public BigDecimal getIorOrderId() {
    return this.iorOrderId;
  }

  public void setIorOrderId(BigDecimal iorOrderId) {
    this.iorOrderId = iorOrderId;
  }

  public Date getNeedsDt() {
    return this.needsDt;
  }

  public void setNeedsDt(Date needsDt) {
    this.needsDt = needsDt;
  }

  public String getNeedsOnByInit() {
    return this.needsOnByInit;
  }

  public void setNeedsOnByInit(String needsOnByInit) {
    this.needsOnByInit = needsOnByInit;
  }

  public String getNonRxItem() {
    return this.nonRxItem;
  }

  public void setNonRxItem(String nonRxItem) {
    this.nonRxItem = nonRxItem;
  }

  public BigDecimal getOrderGuideNumber() {
    return this.orderGuideNumber;
  }

  public void setOrderGuideNumber(BigDecimal orderGuideNumber) {
    this.orderGuideNumber = orderGuideNumber;
  }

  public String getOrderNumber() {
    return this.orderNumber;
  }

  public void setOrderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
  }

  public BigDecimal getOrderQuantity() {
    return this.orderQuantity;
  }

  public void setOrderQuantity(BigDecimal orderQuantity) {
    this.orderQuantity = orderQuantity;
  }

  public String getOrderStatus() {
    return this.orderStatus;
  }

  public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
  }

  public BigDecimal getPrescriptionsDispensesId() {
    return this.prescriptionsDispensesId;
  }

  public void setPrescriptionsDispensesId(BigDecimal prescriptionsDispensesId) {
    this.prescriptionsDispensesId = prescriptionsDispensesId;
  }

  public BigDecimal getProcessingCompanyId() {
    return this.processingCompanyId;
  }

  public void setProcessingCompanyId(BigDecimal processingCompanyId) {
    this.processingCompanyId = processingCompanyId;
  }

  public BigDecimal getProcessingSiteId() {
    return this.processingSiteId;
  }

  public void setProcessingSiteId(BigDecimal processingSiteId) {
    this.processingSiteId = processingSiteId;
  }

  public String getRetailItemCounter() {
    return this.retailItemCounter;
  }

  public void setRetailItemCounter(String retailItemCounter) {
    this.retailItemCounter = retailItemCounter;
  }

  public BigDecimal getRetailItemPatientPay() {
    return this.retailItemPatientPay;
  }

  public void setRetailItemPatientPay(BigDecimal retailItemPatientPay) {
    this.retailItemPatientPay = retailItemPatientPay;
  }

  public String getServiceFeeAttachInd() {
    return this.serviceFeeAttachInd;
  }

  public void setServiceFeeAttachInd(String serviceFeeAttachInd) {
    this.serviceFeeAttachInd = serviceFeeAttachInd;
  }

  public String getShipmentNumber() {
    return this.shipmentNumber;
  }

  public void setShipmentNumber(String shipmentNumber) {
    this.shipmentNumber = shipmentNumber;
  }

  public Date getShippedDate() {
    return this.shippedDate;
  }

  public void setShippedDate(Date shippedDate) {
    this.shippedDate = shippedDate;
  }

  public Date getShippedDateTime() {
    return this.shippedDateTime;
  }

  public void setShippedDateTime(Date shippedDateTime) {
    this.shippedDateTime = shippedDateTime;
  }

  public BigDecimal getSiteId() {
    return this.siteId;
  }

  public void setSiteId(BigDecimal siteId) {
    this.siteId = siteId;
  }

  public String getSkuNumber() {
    return this.skuNumber;
  }

  public void setSkuNumber(String skuNumber) {
    this.skuNumber = skuNumber;
  }

  public Date getSparcsInterfaceDate() {
    return this.sparcsInterfaceDate;
  }

  public void setSparcsInterfaceDate(Date sparcsInterfaceDate) {
    this.sparcsInterfaceDate = sparcsInterfaceDate;
  }

  public String getUpdateBy() {
    return this.updateBy;
  }

  public void setUpdateBy(String updateBy) {
    this.updateBy = updateBy;
  }

  public Date getUpdateDate() {
    return this.updateDate;
  }

  public void setUpdateDate(Date updateDate) {
    this.updateDate = updateDate;
  }

  public BigDecimal getUpdatePharmacareSystemId() {
    return this.updatePharmacareSystemId;
  }

  public void setUpdatePharmacareSystemId(BigDecimal updatePharmacareSystemId) {
    this.updatePharmacareSystemId = updatePharmacareSystemId;
  }

  public String getUpdateProcess() {
    return this.updateProcess;
  }

  public void setUpdateProcess(String updateProcess) {
    this.updateProcess = updateProcess;
  }

  /*
   * public List<PrescriptionDispOrder> getPdisorder() { return pdisorder; }
   * 
   * public void setPdisorder(List<PrescriptionDispOrder> pdisorder) { this.pdisorder = pdisorder; }
   * 
   * 
   * public List<PrescriptionDispOrder> pdisorder;
   */
}
