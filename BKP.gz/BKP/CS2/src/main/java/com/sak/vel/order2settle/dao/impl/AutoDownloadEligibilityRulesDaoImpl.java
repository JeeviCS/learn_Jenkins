
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.AutoDownloadEligibilityRulesDao;
import com.cvs.specialty.ordermaintenance.model.AutoDownloadEligibility;
import com.cvs.specialty.ordermaintenance.model.AutoDownloadError;
import com.cvs.specialty.ordermaintenance.model.Diversion;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;

@Repository
public class AutoDownloadEligibilityRulesDaoImpl implements AutoDownloadEligibilityRulesDao {
	public static final String DATE_FORMAT_YYYY_MM_DD_T_Z = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
	public static final String DATE_FORMAT_MM_DD_YY = "MM/dd/yyyy";

	@SuppressWarnings("rawtypes")
	@Autowired
	PreOrderHeaderRepo preOrderHeaderRepo;

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	DataSource dataSource;

	List<Diversion> diversionList = new ArrayList<Diversion>();

	PreparedStatement pStatement = null;
	

	private Connection getConnection() {
		//LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		Connection conn = null;
		try {
			System.out.println("before data source");
			conn = dataSource.getConnection();
			System.out.println("after data source");
		} catch (Exception e) {
			//LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
		}
		//LOGGER.info(LogMsgConstants.METHOD_EXIT);
		return conn;
	}
	
	Connection con = getConnection();

	@Override
	public ResponseEntity<AutoDownloadError> validateAutoDownloadRules(Long preOrderHeaderId, Long patientId) {

		//LOGGER.info(LogMsgConstants.METHOD_ENTRY);

		List<Diversion> diversionList = new ArrayList<Diversion>();
		Diversion diversion = new Diversion();

		AutoDownloadEligibility autoDownloadEligibility = new AutoDownloadEligibility();
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();

		AutoDownloadError autoDownloadError = new AutoDownloadError();
		autoDownloadError.setCallingService("autoDownloadEligibilityRulesService");
		autoDownloadError.setEntityId(preOrderHeaderId);
		autoDownloadError.setEntityType("ORDER");
		autoDownloadError.setPatientId(patientId);
		autoDownloadError.setTaskType("Process");
		autoDownloadError.setNbdTooFarIndicator("N");
		autoDownloadError.setFollowUpDate(date);

		try {
			// Rule 1 Query
			if (executeRule1Query(con, pStatement, preOrderHeaderId)) {
				return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
			} else {
				// Multiple Rules Query
				AutoDownloadEligibility autoDownloadEligibility1 = executeRules(con, autoDownloadEligibility,
						preOrderHeaderId);

				if (autoDownloadEligibility1.getRdsmIndicator().equals("Y")) {
					// create Diversion to RDSM Queue
					diversion.setDiversionId(1L);
					diversionList.add(diversion);
					autoDownloadError.setDiversions(diversionList);
					return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
				} else if (autoDownloadEligibility1.getIsNeedsDateValid() != null) {
					// if No Create alert divert to Scheduling exceptions for re-scheduling
					diversion.setDiversionId(1L);
					diversionList.add(diversion);
					autoDownloadError.setDiversions(diversionList);
					return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
				} else {
					if (autoDownloadEligibility1.getIsMAJ().equals("MAJ")) {
						if (autoDownloadEligibility1.getBenefitCheckComplnIn().equals("Y")
								&& autoDownloadEligibility1.getEligCheckIn().equals("Y")
								&& autoDownloadEligibility1.getRxInfoCheckComplnIn().equals("Y")
								&& autoDownloadEligibility1.getReadyToFill().equals("Y")) {
							if (executePayorQuery(patientId)) {
								// create diversion download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (executePatientQuery(patientId)) {
								// create diversion download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (executeDrugQuery()) {
								// create diversion download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (executeSACQuery()) {
								// create diversion download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (executeMDOQuery()) {
								// create diversion download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (!autoDownloadEligibility1.getAddressCategory().equals("PO")) {
								// if Yes continue to next rule else divert to Download DIversion Queues
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (!(autoDownloadEligibility1.getQuantityDispensed() > 0)) {
								// create download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (autoDownloadEligibility1.getMedispanStatusIndicator().equals("H")
									|| autoDownloadEligibility1.getMedispanStatusIndicator().equals("R")
									|| autoDownloadEligibility1.getMedispanStatusIndicator().equals("U")
									|| autoDownloadEligibility1.getMedispanStatusIndicator().equals("E")) {
								// create download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} 
							else if(autoDownloadEligibility1.getNdcNumber() == null) {
								//TODO: if same create divert to download diversion queue
							}
							else if (autoDownloadEligibility1.getDxStatus().equals("I")) {
								// create download diversion queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (!autoDownloadEligibility1.getrxVerifyFlag().equals("V")) {
								// create rx Verification Main Queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (autoDownloadEligibility1.getDirections() == null
									|| autoDownloadEligibility1.getDirections() == "") {
								// create Rph Verification Queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							} else if (autoDownloadEligibility1.getNdcNumber() == null) {
								// divert to Tech Clarification Diversion Queue
								diversion.setDiversionId(1L);
								diversionList.add(diversion);
								autoDownloadError.setDiversions(diversionList);
								return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
							}
							else if(!autoDownloadEligibility1.getRefrigInd().equals("Y") ) { // Rule 29

								// Update Arv_on_by_cd in pre_order_header to ON

								if ((autoDownloadEligibility1.getAddress1() == null
										|| autoDownloadEligibility1.getAddress1() == "")
										&& (autoDownloadEligibility1.getCity() == null
										|| autoDownloadEligibility1.getCity() == "")
										&& (autoDownloadEligibility1.getState() == null
										|| autoDownloadEligibility1.getState() == ""
										&& autoDownloadEligibility1.getZip() == null
										|| autoDownloadEligibility1.getZip().equals(""))) {
									// divert to download diversion queue
									diversion.setDiversionId(1L);
									diversionList.add(diversion);
									autoDownloadError.setDiversions(diversionList);
									return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
								}
								//								 else if() {
								//									 
								//									 
								//									 
								//								 }
								else if (!(autoDownloadEligibility1.getPatientSiteId()
										.equals(autoDownloadEligibility1.getPrescriptionSiteId()))) {
									// divert to download diversion queue
									diversion.setDiversionId(1L);
									diversionList.add(diversion);
									autoDownloadError.setDiversions(diversionList);
									return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
								}
								else if(autoDownloadEligibility1.getIsDrugValid() == null) {
									
									// divert to Tech Clarification diversion queue
									diversion.setDiversionId(1L);
									diversionList.add(diversion);
									autoDownloadError.setDiversions(diversionList);
									return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
								}
								else if (autoDownloadEligibility1.getIsNeedsDateValid().compareTo(date) > 0) {
									// divert to download diversion queue
									diversion.setDiversionId(1L);
									diversionList.add(diversion);
									autoDownloadError.setDiversions(diversionList);
									return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
								}

							}
							else {

								if (numberOfPrescriptions() > 15) {
									// divert to download diversion queue
									diversion.setDiversionId(1L);
									diversionList.add(diversion);
									autoDownloadError.setDiversions(diversionList);
									return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
								}

								if ((autoDownloadEligibility1.getIsNeedsDateValid().getTime() - date.getTime())
										/ (1000 * 60 * 60 * 24) < timer()) {
									autoDownloadError.setNbdWaitPeriod(timer());
									autoDownloadError.setNbdTooFarIndicator("Y");
									if (!(masterSwitch().equals("ON")) && !(siteSwitch().equals("PGH"))) {
										// divert to download diversion queue
										diversion.setDiversionId(1L);
										diversionList.add(diversion);
										autoDownloadError.setDiversions(diversionList);
										return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
									}
								}

							}
						} else {
							// create diversion to MAJ Diversion Queue
							diversion.setDiversionId(1L);
							diversionList.add(diversion);
							autoDownloadError.setDiversions(diversionList);
							return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
						}
					} else {
						if (!autoDownloadEligibility1.getBillingStatusCode().equals("C")
								|| !autoDownloadEligibility1.getBillingStatusCode().equals("D")
								|| !autoDownloadEligibility1.getBillingStatusCode().equals("P")) {
							// create diversion to ECS Rejection Diversion Queue
							diversion.setDiversionId(1L);
							diversionList.add(diversion);
							autoDownloadError.setDiversions(diversionList);
							return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);
						}
					}

				}

			}

		} catch (SQLException sqlException) {

		} catch (ParseException parseException) {

		}
		return new ResponseEntity<AutoDownloadError>(autoDownloadError, HttpStatus.OK);

	}

	public AutoDownloadEligibility executeRules(Connection con, AutoDownloadEligibility autoDownloadEligbility,
			Long preOrderHeaderId) {

	//	LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		String query = "select pat.RETAIL_DISPENSE_SPEC_MGMT_IND, " + "       poh.ORDR_RQST_CMPLTN_DT          , "
				+ "       poh.ARV_ON_BY_CD                    , " + "       ite.REFRIG_IND                   , "
				+ "       prd.billing_status               , " + "       case prd.billing_status\r\n"
				+ "       when 'C' then 'CAPTURED'\r\n" + "       when 'D' then 'DUPLICATE'\r\n"
				+ "       when 'P' then 'PAID'\r\n" + "       else  'UNPAID'\r\n" + "       end,\r\n"
				+ "       prd.QUANTITY_DISPENSED           , " + "       pre.MEDISPAN_IND                 , "
				+ "       pad.address_category             , " + "       ite.NDC_NUMBER                   , "
				+ "       hcp.DXSTATUS                     , " + "       ite.narc_cd                      , "
				+ "       hcp.DEA_NO                       , " + "       pre.rx_verify_ind                , "
				+ "       pre.DIRECTIONS                    , " + "       pad.patient_address_id           , "
				+ "       pad.ADDRESS_1                    , " + "       pad.ADDRESS_2                    , "
				+ "       pad.state                        ," + "       pad.ZIP_1                        ,"
				+ "       pre.DISCONTINUE_DATE             ," + "       pre.SITE_ID                      , "
				+ "       pat.site_id                     , " + "       sit.NATIONAL_PROVIDER_ID         , "
				+ "       pat.DISEASE_ST_CD                ," + "       prd.BNFT_CHK_CMPLT_IN            "
				+ "       prd.elig_chk_in,\r\n" + "       prd.RX_INFO_CHK_CMPLT_IN\r\n"
				+ "CASE WHEN SYSDATE > prd.FILL_ON_OR_AFTR_DT THEN 'Y' ELSE 'N' END\r\n"
				+ "           ready_to_Fill,\r\n" + "       CASE NVL (bg.prm_ins_form_type_cd, 'XXX')\r\n"
				+ "           WHEN 'ECS' THEN 'N'\r\n" + "           ELSE 'Y'\r\n" + "       END\r\n"
				+ "           maj_ind\r\n, pad.city, ite.active_ind" + "" + "from pre_order_header poh, patients pat,\r\n"
				+ "       pre_order_detail pod,\r\n" + "       items ite,\r\n"
				+ "       prescription_dispenses prd,\r\n" + "       prescriptions pre,\r\n"
				+ "       patient_address pad,\r\n" + "       health_care_profs hcp,\r\n" + "       Sites sit\r\n"
				+ "where  poh.PRE_ORDR_HDR_ID = '" + preOrderHeaderId + "'\r\n"
				+ "       and poh.ptnt_id = pat.patient_id\r\n"
				+ "       and pod.PRE_ORDR_HDR_ID = poh.PRE_ORDR_HDR_ID\r\n" + "       and pod.itm_id = ite.item_id\r\n"
				+ "       and pod.RX_DSPNS_ID = prd.id \r\n" + "       and pre.id = pod.rx_id\r\n"
				+ "       and poh.patient_address_id = pad.patient_address_id \r\n"
				+ "       and pre.hcp_id = hcp.hcp_id \r\n" + "       and sit.site_id = pre.site_id\r\n"
				+ "       and sit.company_id = pre.company_id \r\n" + "\r\n" + "\r\n" + "";

		try {
			pStatement = con.prepareStatement(query);
			ResultSet rs = pStatement.executeQuery();
			while (rs.next()) {

				autoDownloadEligbility.setRdsmIndicator(rs.getString(1));
				autoDownloadEligbility.setIsNeedsDateValid(rs.getDate(2));
				autoDownloadEligbility.setArvOnByCd(rs.getString(3));
				autoDownloadEligbility.setRefrigInd(rs.getString(4));
				autoDownloadEligbility.setBillingStatusCode(rs.getString(5));
				autoDownloadEligbility.setQuantityDispensed(rs.getInt(6));
				autoDownloadEligbility.setMedispanStatusIndicator(rs.getString(7));
				autoDownloadEligbility.setAddressCategory(rs.getString(8));
				autoDownloadEligbility.setNdcNumber(rs.getInt(9));
				autoDownloadEligbility.setDxStatus(rs.getString(10));
				autoDownloadEligbility.setrxVerifyFlag(rs.getString(13));
				autoDownloadEligbility.setDirections(rs.getString(14));
				autoDownloadEligbility.setPatientAddressId(rs.getInt(15));
				autoDownloadEligbility.setAddress1(rs.getString(16));
				autoDownloadEligbility.setAddress2(rs.getString(17));
				autoDownloadEligbility.setState(rs.getString(18));
				autoDownloadEligbility.setZip(rs.getInt(19));
				autoDownloadEligbility.setDiscontinueDate(rs.getDate(20));
				autoDownloadEligbility.setPrescriptionSiteId(rs.getInt(21));
				autoDownloadEligbility.setpatientSiteId(rs.getInt(22));
				autoDownloadEligbility.setBenefitCheckComplnIn(rs.getString(25));
				autoDownloadEligbility.setEligCheckIn(rs.getString(26));
				autoDownloadEligbility.setRxInfoCheckComplnIn(rs.getString(27));
				autoDownloadEligbility.setReadyToFill(rs.getString(28));
				autoDownloadEligbility.setisMAJ(rs.getString(29));
				autoDownloadEligbility.setCity(rs.getString(30));
				autoDownloadEligbility.setIsDrugValid(rs.getString(31));
			}

		} catch (SQLException e) {

		}
		return autoDownloadEligbility;
	}

	public Integer numberOfPrescriptions() {
		String query = "SELECT rv_high_value FROM cg_ref_codes\r\n"
				+ "WHERE rv_domain = 'AUTO_DOWNLOAD' and rv_low_value = 'DOWNLOAD RX COUNT';\r\n" + "";
		Integer numberOfPrescriptions = null;
		try {
			pStatement = con.prepareStatement(query);
			ResultSet rs = pStatement.executeQuery();
			while (rs.next()) {
				numberOfPrescriptions = rs.getInt(1);
			}
		} catch (SQLException e) {

		}
		return numberOfPrescriptions;
	}

	public Integer timer() {
		String query = "SELECT rv_high_value FROM cg_ref_codes\r\n"
				+ "WHERE rv_domain = 'AUTO_DOWNLOAD' and rv_low_value = 'NEEDS DATE LIMIT';\r\n" + "";
		Integer needsDateLimit = null;
		try {
			pStatement = con.prepareStatement(query);
			ResultSet rs = pStatement.executeQuery();
			while (rs.next()) {
				needsDateLimit = rs.getInt(1);
			}
		} catch (SQLException e) {

		}
		return needsDateLimit;
	}

	public String masterSwitch() {
		String query = "SELECT rv_high_value FROM cg_ref_codes\r\n"
				+ "WHERE rv_domain = 'AUTO_DOWNLOAD' and rv_low_value = 'MASTER SWITCH';\r\n" + "";
		String isMasterSwitchOn = null;
		try {
			pStatement = con.prepareStatement(query);
			ResultSet rs = pStatement.executeQuery();
			while (rs.next()) {
				isMasterSwitchOn = rs.getString(1);
			}
		} catch (SQLException e) {

		}
		return isMasterSwitchOn;
	}

	public String siteSwitch() {
		String query = "SELECT rv_high_value FROM cg_ref_codes\r\n"
				+ "WHERE rv_domain = 'AUTO_DOWNLOAD' and rv_low_value = 'SITE SWITCH';\r\n" + "";
		String isSiteSwitchOn = null;
		try {
			pStatement = con.prepareStatement(query);
			ResultSet rs = pStatement.executeQuery();
			while (rs.next()) {
				isSiteSwitchOn = rs.getString(1);
			}
		} catch (SQLException e) {

		}
		return isSiteSwitchOn;
	}

	private boolean executeRule1Query(Connection con, PreparedStatement pStatement, Long preOrderHeaderId)
			throws SQLException, ParseException {

		String rule1Query = "SELECT swq.sbp_que_nm \r\n" + "  FROM sbp_work_queue swq, sbp_work_queue_task swqt,\r\n"
				+ "       SBP_ENTITY_BPM_PROCESS_MAP sebpm,\r\n" + "       SBP_WORK_QUEUE_TASK_BPM_TASK swqtbt\r\n"
				+ "WHERE  UPPER (sbp_que_nm) = 'ESCALATION_DIVERSION'\r\n"
				+ "        swq.sbp_wrk_que_id = swqt.sbp_wrk_que_id \r\n"
				+ "       AND swqtbt.SBP_WRK_QUE_TASK_ID = swqt.SBP_WRK_QUE_TASK_ID\r\n"
				+ "       AND swqtbt.SBP_ENTY_BPM_PRC_MAP_ID = sebpm.SBP_ENTY_BPM_PRC_MAP_ID\r\n"
				+ "       AND sebpm.RX_ID = (select pd.rx_id from pre_Order_header po, pre_order_detail pd where po.pre_ordr_hdr_id = pd.pre_ordr_hdr_id and po.pre_ordr_hdr_id = :preOrderHeaderId)";
		pStatement = con.prepareStatement(rule1Query);
		ResultSet rs = pStatement.executeQuery();
		pStatement.setLong(1, preOrderHeaderId);
		if (rs == null) {
			return false;
		} else {
			while (rs.next()) {
				if (rs.getString(1) != null) {
					return true;
				}
			}
		}
		return false;
	}

	// check with Hari
	private boolean executePayorQuery(Long patientId) throws SQLException, ParseException {

		String payorQuery = "SELECT crc.text_1 effective_date, crc.TEXT_2 as expiration_date\r\n"
				+ "  FROM common_reference_codes crc, patient_bill_grps pbg, bill_grps bg\r\n"
				+ "WHERE     pbg.bill_grp_id = bg.bill_grp_id\r\n" + "       AND pbg.patient_id = " + patientId + "\r\n"
				+ "       AND crc.rv_domain = 'WFO_DOWNLOAD_RULES'\r\n" +
				// " AND crc.rv_abbreviation = bg.TYPE_SRC_CD||'-'||bg.PLAN_SRC_CD\r\n" +
				"       AND crc.rv_meaning = 'PAYOR_RULE'";

		pStatement = con.prepareStatement(payorQuery);
		ResultSet rs = pStatement.executeQuery();
		boolean downloadExceptionPayorIndicator = false;
		if (rs == null) {
			return downloadExceptionPayorIndicator;
		} else {
			while (rs.next()) {
				Date effectiveDate = convertStringToDate(rs.getString(1));
				Date expiryDate = convertStringToDate(rs.getString(2));
				// expiryDate < effectiveDate
				if (expiryDate != null && effectiveDate != null && expiryDate.before(effectiveDate)) {
					downloadExceptionPayorIndicator = true;
				} else {
					downloadExceptionPayorIndicator = false;

				}
			}
		}
		return downloadExceptionPayorIndicator;
	}

	private boolean executePatientQuery(Long patientId) throws SQLException, ParseException {
		String patientQuery = "SELECT crc.text_1 effective_date, crc.TEXT_2 as expiration_date\r\n"
				+ " FROM patients pat, common_reference_codes crc\r\n" + " WHERE     pat.patient_id = " + patientId
				+ "\r\n" + "     AND crc.rv_domain = 'WFO_DOWNLOAD_RULES'\r\n"
				+ "     AND crc.rv_abbreviation = pat.DISEASE_ST_CD\r\n" + "     AND crc.rv_meaning = 'THERAPY_RULE'";
		pStatement = con.prepareStatement(patientQuery);
		ResultSet rs = pStatement.executeQuery();
		boolean downloadExceptionPayorIndicator = false;
		if (rs == null) {
			downloadExceptionPayorIndicator = true;
		} else {
			while (rs.next()) {
				Date effectiveDate = convertStringToDate(rs.getString(1));
				Date expiryDate = convertStringToDate(rs.getString(2));
				// expiryDate < effectiveDate
				if (expiryDate != null && effectiveDate != null && expiryDate.before(effectiveDate)) {
					downloadExceptionPayorIndicator = true;
				} else {
					downloadExceptionPayorIndicator = false;
				}
			}
		}
		return downloadExceptionPayorIndicator;
	}

	private boolean executeDrugQuery() throws SQLException, ParseException {
		String drugQuery = "SELECT crc.text_1 effective_date, crc.TEXT_2 as expiration_date\r\n"
				+ " FROM common_reference_codes crc, prescription_dispenses pd, items ite\r\n"
				+ " WHERE     pd.item_id = ite.item_id\r\n" + "       AND crc.rv_domain = 'WFO_DOWNLOAD_RULES'\r\n"
				+ "       AND crc.rv_abbreviation = ite.item_src_cd\r\n" + "       AND crc.rv_meaning = 'DRUG_RULE'";

		boolean downloadExceptionDrugIndicator = false;
		pStatement = con.prepareStatement(drugQuery);
		ResultSet rs = pStatement.executeQuery();
		if (rs == null) {
			downloadExceptionDrugIndicator = true;
		} else {
			while (rs.next()) {
				Date effectiveDate = convertStringToDate(rs.getString(1));
				Date expiryDate = convertStringToDate(rs.getString(2));
				// expiryDate < effectiveDate
				if (expiryDate != null && effectiveDate != null && expiryDate.before(effectiveDate)) {
					downloadExceptionDrugIndicator = true;
				} else {
					downloadExceptionDrugIndicator = false;
				}
			}
		}
		return downloadExceptionDrugIndicator;
	}

	private boolean executeSACQuery() throws SQLException, ParseException {

		String sacQuery = "SELECT crc.text_1 effective_date, crc.TEXT_2 as expiration_date\r\n"
				+ "  FROM patient_spcl_Accts psa, spcl_accts sa, common_reference_codes crc\r\n"
				+ " WHERE     psa.SPCL_ACCT_ID = sa.SPCL_ACCT_ID\r\n"
				+ "       AND psa.patient_id = :input_patient_id\r\n"
				+ "       AND crc.rv_domain = 'WFO_DOWNLOAD_RULES'\r\n"
				+ "       AND crc.rv_abbreviation = sa.spcl_src_cd\r\n" + " AND crc.rv_meaning = 'SAC_RULE'";
		pStatement = con.prepareStatement(sacQuery);
		ResultSet rs = pStatement.executeQuery();
		boolean exceptionSACIndicator = false;
		if (rs == null) {
			exceptionSACIndicator = true;
		} else {
			while (rs.next()) {
				Date effectiveDate = convertStringToDate(rs.getString(1));
				Date expiryDate = convertStringToDate(rs.getString(2));
				// expiryDate < effectiveDate
				if (expiryDate != null && effectiveDate != null && expiryDate.before(effectiveDate)) {
					exceptionSACIndicator = true;
				} else {
					exceptionSACIndicator = false;
				}
			}
		}
		return exceptionSACIndicator;
	}

	private boolean executeMDOQuery() throws SQLException, ParseException {

		String mdoQuery = "SELECT crc.text_1 effective_date, crc.TEXT_2 as expiration_date\r\n"
				+ " FROM common_reference_codes crc, prescription_dispenses pd, items ite\r\n"
				+ " WHERE     pd.item_id = ite.item_id\r\n" + "     AND crc.rv_domain = 'WFO_DOWNLOAD_RULES'\r\n"
				+ "     AND crc.rv_abbreviation = ite.item_src_cd\r\n"
				+ "     AND crc.rv_meaning = 'MDO_ADDRESS_REQUIRED'";

		pStatement = con.prepareStatement(mdoQuery);
		ResultSet rs = pStatement.executeQuery();

		boolean mdoShipIndicator = false;
		if (rs == null) {
			mdoShipIndicator = true;
		} else {
			while (rs.next()) {
				Date effectiveDate = convertStringToDate(rs.getString(1));
				Date expiryDate = convertStringToDate(rs.getString(2));
				// expiryDate < effectiveDate
				if (expiryDate != null && effectiveDate != null && expiryDate.before(effectiveDate)) {
					mdoShipIndicator = true;
				} else {
					mdoShipIndicator = false;
				}
			}
		}
		return mdoShipIndicator;
	}

	public static Date convertStringToDate(String strDate) throws ParseException {
		return convertStringToDate(strDate, DATE_FORMAT_YYYY_MM_DD_T_Z);
	}

	public static Date convertStringToDate(String strDate, String dateFormat) throws ParseException {
		Date date = null;
		if (strDate != null && !strDate.isEmpty()) {
			SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
			date = formatter.parse(strDate);
		}
		return date;
	}
}
