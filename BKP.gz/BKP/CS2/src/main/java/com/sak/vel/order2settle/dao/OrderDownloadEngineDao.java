package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;
import com.cvs.specialty.ordermaintenance.model.OrderNotes;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;

public interface OrderDownloadEngineDao {



	OrderDownloadEngine getPatientShippingInfo(long preOrderId, long patientID);

	

}
