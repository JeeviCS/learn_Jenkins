package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;

public interface CancelDownloadService {
	
	ResponseEntity<List<CanceDownloadReasonCodes>> cancelDownloadGet(long preOrderId);
	
	ResponseEntity<Void> cancelDownloadPost(Long hbsNumber, Long shipmentNumber, String cancelReason, String comment, String userId, String messageId);
}
