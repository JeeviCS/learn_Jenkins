
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.*;

import com.cvs.specialty.ordermaintenance.model.ErrorResponse;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.*;

@Api(value = "OrderStatus", description = "Order Status UPDATE API")
public interface OrderStatusApi {

  @ApiOperation(value = "Updates Order Status", notes = "This end point updates order status", response = Void.class, tags = {
      "Order Status"
  })
  @ApiResponses(value = {
      @ApiResponse(code = 204, message = "Order status updated successfully.", response = Void.class),
      @ApiResponse(code = 400, message = "Bad Request. Please see response body for more details.", response = ErrorResponse.class),
      @ApiResponse(code = 401, message = "Unauthorized", response = Void.class),
      @ApiResponse(code = 500, message = "Internal Server Error. Please see response body for more details.", response = ErrorResponse.class)
  })

  @RequestMapping(value = "/v1/OrderStatus", method = RequestMethod.PUT)

  ResponseEntity<Void> updateOrderStatus(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @ApiParam(value = "preOrderHeaderId") @RequestParam Long preOrderHeaderId,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception;

}
