package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-219T10:23:06.615Z")
public class CancelOrderResponse {
	   @JsonProperty("orderId")
	   private Long orderId = null;
	   @JsonProperty("message")
	   private String message=null;

	   public CancelOrderResponse orderId(Long orderId) {
	     this.orderId = orderId;
	     return this;
	   }
	   public CancelOrderResponse message(String message) {
		     this.message = message;
		     return this;
		   }

	    /**
	    * Get orderId
	    * @return orderId
	   **/
	   @ApiModelProperty(value = "")


	   public Long getOrderId() {
	     return orderId;
	   }

	   public void setOrderId(Long orderId) {
	     this.orderId = orderId;
	   }
	   @ApiModelProperty(value = "")


	   public String getMessage() {
		   return message;
	   }
	   public void setMessage(String message) {
		   this.message = message;
	   }


	


	   @Override
	   public boolean equals(java.lang.Object o) {
	     if (this == o) {
	       return true;
	     }
	     if (o == null || getClass() != o.getClass()) {
	       return false;
	     }
	     CancelOrderResponse cancelOrderResponse = (CancelOrderResponse) o;
	     return Objects.equals(this.orderId, cancelOrderResponse.orderId);
	
	     
	   }

	@Override
	   public int hashCode() {
	     return Objects.hash(orderId);
	   }

	   @Override
	   public String toString() {
	     StringBuilder sb = new StringBuilder();
	     sb.append("class CancelOrderResponse {\n");
	     
	     sb.append("    OrderId: ").append(toIndentedString(orderId)).append("\n");
	     sb.append("    Message: ").append(toIndentedString(message)).append("\n");
	     sb.append("}");
	     return sb.toString();
	   }

	   /**
	    * Convert the given object to string with each line indented by 4 spaces
	    * (except the first line).
	    */
	   private String toIndentedString(java.lang.Object o) {
	     if (o == null) {
	       return "null";
	     }
	     return o.toString().replace("\n", "\n    ");
	   }

}
