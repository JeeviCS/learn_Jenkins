/*package com.cvs.specialty.ordermaintenance.rabbitMq.producer;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface RabbitMqChannel {
	@Output("producer")
	MessageChannel producer();
}*/