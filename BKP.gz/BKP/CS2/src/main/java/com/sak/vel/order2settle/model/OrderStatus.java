package com.cvs.specialty.ordermaintenance.model;

import java.util.List;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;


public class OrderStatus {

	private Long orderGuideNumber;
	
	private String transStatus;
	
	private String hbsOrderNumber;
	
	private String hbsShipmentNumber;
	
	private String orderStatus;
	
	private List<DiversionDetails> orderDiversionDetails;
	
	private List<RxDetails> rxDetails;

	public Long getOrderGuideNumber() {
		return orderGuideNumber;
	}

	public void setOrderGuideNumber(Long orderGuideNumber) {
		this.orderGuideNumber = orderGuideNumber;
	}

	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	public String getHbsOrderNumber() {
		return hbsOrderNumber;
	}

	public void setHbsOrderNumber(String hbsOrderNumber) {
		this.hbsOrderNumber = hbsOrderNumber;
	}

	public String getHbsShipmentNumber() {
		return hbsShipmentNumber;
	}

	public void setHbsShipmentNumber(String hbsShipmentNumber) {
		this.hbsShipmentNumber = hbsShipmentNumber;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public List<DiversionDetails> getOrderDiversionDetails() {
		return orderDiversionDetails;
	}

	public void setOrderDiversionDetails(
			List<DiversionDetails> orderDiversionDetails) {
		this.orderDiversionDetails = orderDiversionDetails;
	}

	public List<RxDetails> getRxDetails() {
		return rxDetails;
	}

	public void setRxDetails(List<RxDetails> rxDetails) {
		this.rxDetails = rxDetails;
	}
	
	
}




