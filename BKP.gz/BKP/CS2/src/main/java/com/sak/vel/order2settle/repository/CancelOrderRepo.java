package com.cvs.specialty.ordermaintenance.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PreOrderHeaderCancel;

@Repository
@Transactional
public interface CancelOrderRepo extends JpaRepository<PreOrderHeaderCancel, Long> {
	@Modifying(clearAutomatically = true)	
    @Query("UPDATE PreOrderHeaderCancel poh SET poh.ptntNtfidIn = :patFlag, poh.hltcrPrfsnNtfidIn= :MDFlag, poh.ordrStusCd= :order_status, poh.ordrStusRsnCd= :cancel_reason,poh.crteUsrNm= :userId WHERE poh.preOrdrHdrId = :order_id")
    int updateCancelOrder(@Param("patFlag") String patFlag, @Param("MDFlag") String MDFlag, @Param("order_status") String order_status, @Param("order_id") long order_id,
    		@Param("cancel_reason") String cancel_reason,@Param("userId") String userId);	
}
