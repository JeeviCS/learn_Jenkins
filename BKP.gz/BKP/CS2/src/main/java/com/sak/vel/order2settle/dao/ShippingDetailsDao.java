
package com.cvs.specialty.ordermaintenance.dao;

import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;

public interface ShippingDetailsDao {

  ShipmentDetails getShippingDetails(long preOrderId, String status, String shipmentNumber);

}
