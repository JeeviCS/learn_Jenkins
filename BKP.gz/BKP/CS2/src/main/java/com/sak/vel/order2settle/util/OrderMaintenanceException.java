
package com.cvs.specialty.ordermaintenance.util;

/**
 * This class is to handle any exceptions at the controller level globally.
 * 
 * @author Z231675
 *
 */
public class OrderMaintenanceException extends RuntimeException {

  /**
   * 
   */
  private static final long serialVersionUID = -8653007067540841196L;

  int httpStatusCode;

  /**
   * @return the httpStatusCode
   */
  public int getHttpStatusCode() {
    return httpStatusCode;
  }

  /**
   * @param httpStatusCode
   *          the httpStatusCode to set
   */
  public void setHttpStatusCode(int httpStatusCode) {
    this.httpStatusCode = httpStatusCode;
  }

  String errorCode;
  String paramName;

  /**
   * 
   */
  public OrderMaintenanceException() {
    super();
  }

  /**
   * @return the errorCode
   */
  public String getErrorCode() {
    return errorCode;
  }

  /**
   * @param errorCode
   *          the errorCode to set
   */
  public void setErrorCode(String errorCode) {
    this.errorCode = errorCode;
  }

  /**
   * @return the paramName
   */
  public String getParamName() {
    return paramName;
  }

  /**
   * @param paramName
   *          the paramName to set
   */
  public void setParamName(String paramName) {
    this.paramName = paramName;
  }

  public OrderMaintenanceException(final Throwable cause, final String errorCode) {
    super(cause);
    this.errorCode = errorCode;
  }
  
  public OrderMaintenanceException( final String errorCode) {
	    
	    this.errorCode = errorCode;
	  }
}
