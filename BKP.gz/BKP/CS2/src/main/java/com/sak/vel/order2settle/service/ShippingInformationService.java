package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.PreOrderHeader;

public interface ShippingInformationService {

	ResponseEntity<List<PreOrderHeader>> getShippingDetails(long preOrderId, String status);

	ResponseEntity<PreOrderHeader> getShippingInfo(Long preOrderHeaderId, Long patientId);

	ResponseEntity<Void> updateShippingDetails(Long orderId, Long patientId, PreOrderHeader shippingDetails);

}
