
package com.cvs.specialty.ordermaintenance.model;

import java.math.BigDecimal;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Prescription
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class Prescription {
  @JsonProperty("prescriptionIdentifier")
  private long prescriptionIdentifier;

  @JsonProperty("patientIdentifier")
  private String patientIdentifier = null;

  @JsonProperty("prescriberIdentifier")
  private long prescriberIdentifier;

  @JsonProperty("drugIdentifier")
  private String drugIdentifier = null;

  @JsonProperty("prescriptionReceivedDate")
  private String prescriptionReceivedDate = null;

  @JsonProperty("prescriptionWrittenDate")
  private String prescriptionWrittenDate = null;

  @JsonProperty("prescriptionWrittenQuantity")
  private String prescriptionWrittenQuantity = null;

  @JsonProperty("remainingPrescriptionQuantity")
  private String remainingPrescriptionQuantity = null;

  @JsonProperty("remianingRefillsQuantity")
  private String remianingRefillsQuantity = null;

  @JsonProperty("nationalDrugCodeIdentifier")
  private String nationalDrugCodeIdentifier = null;

  @JsonProperty("prescriptionNumber")
  private BigDecimal prescriptionNumber = null;

  @JsonProperty("prescriptiontypeIndicator")
  private String prescriptiontypeIndicator = null;

  @JsonProperty("autoAdjudicationIndicator")
  private String autoAdjudicationIndicator = null;

  @JsonProperty("medispanIndicator")
  private String medispanIndicator = null;

  public Prescription prescriptionIdentifier(long prescriptionIdentifier) {
    this.prescriptionIdentifier = prescriptionIdentifier;
    return this;
  }

  /**
   * Get prescriptionIdentifier
   * 
   * @return prescriptionIdentifier
   **/
  @ApiModelProperty(value = "")

  public long getPrescriptionIdentifier() {
    return prescriptionIdentifier;
  }

  public void setPrescriptionIdentifier(long prescriptionIdentifier) {
    this.prescriptionIdentifier = prescriptionIdentifier;
  }

  public Prescription patientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public Prescription prescriberIdentifier(long prescriberIdentifier) {
    this.prescriberIdentifier = prescriberIdentifier;
    return this;
  }

  /**
   * Get prescriberIdentifier
   * 
   * @return prescriberIdentifier
   **/
  @ApiModelProperty(value = "")

  public long getPrescriberIdentifier() {
    return prescriberIdentifier;
  }

  public void setPrescriberIdentifier(long prescriberIdentifier) {
    this.prescriberIdentifier = prescriberIdentifier;
  }

  public Prescription drugIdentifier(String drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
    return this;
  }

  /**
   * Get drugIdentifier
   * 
   * @return drugIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getDrugIdentifier() {
    return drugIdentifier;
  }

  public void setDrugIdentifier(String drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
  }

  public Prescription prescriptionReceivedDate(String prescriptionReceivedDate) {
    this.prescriptionReceivedDate = prescriptionReceivedDate;
    return this;
  }

  /**
   * Get prescriptionReceivedDate
   * 
   * @return prescriptionReceivedDate
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionReceivedDate() {
    return prescriptionReceivedDate;
  }

  public void setPrescriptionReceivedDate(String prescriptionReceivedDate) {
    this.prescriptionReceivedDate = prescriptionReceivedDate;
  }

  public Prescription prescriptionWrittenDate(String prescriptionWrittenDate) {
    this.prescriptionWrittenDate = prescriptionWrittenDate;
    return this;
  }

  /**
   * Get prescriptionWrittenDate
   * 
   * @return prescriptionWrittenDate
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionWrittenDate() {
    return prescriptionWrittenDate;
  }

  public void setPrescriptionWrittenDate(String prescriptionWrittenDate) {
    this.prescriptionWrittenDate = prescriptionWrittenDate;
  }

  public Prescription prescriptionWrittenQuantity(String prescriptionWrittenQuantity) {
    this.prescriptionWrittenQuantity = prescriptionWrittenQuantity;
    return this;
  }

  /**
   * Get prescriptionWrittenQuantity
   * 
   * @return prescriptionWrittenQuantity
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptionWrittenQuantity() {
    return prescriptionWrittenQuantity;
  }

  public void setPrescriptionWrittenQuantity(String prescriptionWrittenQuantity) {
    this.prescriptionWrittenQuantity = prescriptionWrittenQuantity;
  }

  public Prescription remainingPrescriptionQuantity(String remainingPrescriptionQuantity) {
    this.remainingPrescriptionQuantity = remainingPrescriptionQuantity;
    return this;
  }

  /**
   * Get remainingPrescriptionQuantity
   * 
   * @return remainingPrescriptionQuantity
   **/
  @ApiModelProperty(value = "")

  public String getRemainingPrescriptionQuantity() {
    return remainingPrescriptionQuantity;
  }

  public void setRemainingPrescriptionQuantity(String remainingPrescriptionQuantity) {
    this.remainingPrescriptionQuantity = remainingPrescriptionQuantity;
  }

  public Prescription remianingRefillsQuantity(String remianingRefillsQuantity) {
    this.remianingRefillsQuantity = remianingRefillsQuantity;
    return this;
  }

  /**
   * Get remianingRefillsQuantity
   * 
   * @return remianingRefillsQuantity
   **/
  @ApiModelProperty(value = "")

  public String getRemianingRefillsQuantity() {
    return remianingRefillsQuantity;
  }

  public void setRemianingRefillsQuantity(String remianingRefillsQuantity) {
    this.remianingRefillsQuantity = remianingRefillsQuantity;
  }

  public Prescription nationalDrugCodeIdentifier(String nationalDrugCodeIdentifier) {
    this.nationalDrugCodeIdentifier = nationalDrugCodeIdentifier;
    return this;
  }

  /**
   * Get nationalDrugCodeIdentifier
   * 
   * @return nationalDrugCodeIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getNationalDrugCodeIdentifier() {
    return nationalDrugCodeIdentifier;
  }

  public void setNationalDrugCodeIdentifier(String nationalDrugCodeIdentifier) {
    this.nationalDrugCodeIdentifier = nationalDrugCodeIdentifier;
  }

  public Prescription prescriptionNumber(BigDecimal prescriptionNumber) {
    this.prescriptionNumber = prescriptionNumber;
    return this;
  }

  /**
   * Get prescriptionNumber
   * 
   * @return prescriptionNumber
   **/
  @ApiModelProperty(value = "")

  public BigDecimal getPrescriptionNumber() {
    return prescriptionNumber;
  }

  public void setPrescriptionNumber(BigDecimal prescriptionNumber) {
    this.prescriptionNumber = prescriptionNumber;
  }

  public Prescription prescriptiontypeIndicator(String prescriptiontypeIndicator) {
    this.prescriptiontypeIndicator = prescriptiontypeIndicator;
    return this;
  }

  /**
   * Get prescriptiontypeIndicator
   * 
   * @return prescriptiontypeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getPrescriptiontypeIndicator() {
    return prescriptiontypeIndicator;
  }

  public void setPrescriptiontypeIndicator(String prescriptiontypeIndicator) {
    this.prescriptiontypeIndicator = prescriptiontypeIndicator;
  }

  public Prescription autoAdjudicationIndicator(String autoAdjudicationIndicator) {
    this.autoAdjudicationIndicator = autoAdjudicationIndicator;
    return this;
  }

  /**
   * Get autoAdjudicationIndicator
   * 
   * @return autoAdjudicationIndicator
   **/
  @ApiModelProperty(value = "")

  public String getAutoAdjudicationIndicator() {
    return autoAdjudicationIndicator;
  }

  public void setAutoAdjudicationIndicator(String autoAdjudicationIndicator) {
    this.autoAdjudicationIndicator = autoAdjudicationIndicator;
  }

  public Prescription medispanIndicator(String medispanIndicator) {
    this.medispanIndicator = medispanIndicator;
    return this;
  }

  /**
   * Get medispanIndicator
   * 
   * @return medispanIndicator
   **/
  @ApiModelProperty(value = "")

  public String getMedispanIndicator() {
    return medispanIndicator;
  }

  public void setMedispanIndicator(String medispanIndicator) {
    this.medispanIndicator = medispanIndicator;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Prescription prescription = (Prescription) o;
    return Objects.equals(this.prescriptionIdentifier, prescription.prescriptionIdentifier)
        && Objects.equals(this.patientIdentifier, prescription.patientIdentifier)
        && Objects.equals(this.prescriberIdentifier, prescription.prescriberIdentifier)
        && Objects.equals(this.drugIdentifier, prescription.drugIdentifier)
        && Objects.equals(this.prescriptionReceivedDate, prescription.prescriptionReceivedDate)
        && Objects.equals(this.prescriptionWrittenDate, prescription.prescriptionWrittenDate)
        && Objects
          .equals(this.prescriptionWrittenQuantity, prescription.prescriptionWrittenQuantity)
        && Objects
          .equals(this.remainingPrescriptionQuantity, prescription.remainingPrescriptionQuantity)
        && Objects.equals(this.remianingRefillsQuantity, prescription.remianingRefillsQuantity)
        && Objects.equals(this.nationalDrugCodeIdentifier, prescription.nationalDrugCodeIdentifier)
        && Objects.equals(this.prescriptionNumber, prescription.prescriptionNumber)
        && Objects.equals(this.prescriptiontypeIndicator, prescription.prescriptiontypeIndicator)
        && Objects.equals(this.autoAdjudicationIndicator, prescription.autoAdjudicationIndicator)
        && Objects.equals(this.medispanIndicator, prescription.medispanIndicator);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      prescriptionIdentifier,
      patientIdentifier,
      prescriberIdentifier,
      drugIdentifier,
      prescriptionReceivedDate,
      prescriptionWrittenDate,
      prescriptionWrittenQuantity,
      remainingPrescriptionQuantity,
      remianingRefillsQuantity,
      nationalDrugCodeIdentifier,
      prescriptionNumber,
      prescriptiontypeIndicator,
      autoAdjudicationIndicator,
      medispanIndicator);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Prescription {\n");

    sb
      .append("    prescriptionIdentifier: ")
      .append(toIndentedString(prescriptionIdentifier))
      .append("\n");
    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb.append("    prescriberIdentifier: ").append(toIndentedString(prescriberIdentifier)).append(
      "\n");
    sb.append("    drugIdentifier: ").append(toIndentedString(drugIdentifier)).append("\n");
    sb
      .append("    prescriptionReceivedDate: ")
      .append(toIndentedString(prescriptionReceivedDate))
      .append("\n");
    sb
      .append("    prescriptionWrittenDate: ")
      .append(toIndentedString(prescriptionWrittenDate))
      .append("\n");
    sb
      .append("    prescriptionWrittenQuantity: ")
      .append(toIndentedString(prescriptionWrittenQuantity))
      .append("\n");
    sb
      .append("    remainingPrescriptionQuantity: ")
      .append(toIndentedString(remainingPrescriptionQuantity))
      .append("\n");
    sb
      .append("    remianingRefillsQuantity: ")
      .append(toIndentedString(remianingRefillsQuantity))
      .append("\n");
    sb
      .append("    nationalDrugCodeIdentifier: ")
      .append(toIndentedString(nationalDrugCodeIdentifier))
      .append("\n");
    sb.append("    prescriptionNumber: ").append(toIndentedString(prescriptionNumber)).append("\n");
    sb
      .append("    prescriptiontypeIndicator: ")
      .append(toIndentedString(prescriptiontypeIndicator))
      .append("\n");
    sb
      .append("    autoAdjudicationIndicator: ")
      .append(toIndentedString(autoAdjudicationIndicator))
      .append("\n");
    sb.append("    medispanIndicator: ").append(toIndentedString(medispanIndicator)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
