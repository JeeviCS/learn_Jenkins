package com.cvs.specialty.ordermaintenance.model;
import java.sql.Timestamp;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-22T12:32:09.067Z")

public class TaskLists {

	@JsonProperty("actionId")
	private Long actionId;

	@JsonProperty("bpmTaskInstanceId")
	private Long bpmTaskInstanceId;

	@JsonProperty("comments")
	private String comments = null;

	@JsonProperty("outcomeId")
	private Long outcomeId;

	@JsonProperty("patientId")
	private Long patientId;

	@JsonProperty("prescriberId")
	private Long prescriberId;

	@JsonProperty("processInstanceMapId")
	private Long processInstanceMapId;

	@JsonProperty("queueTaskId")
	private Long queueTaskId;

	@JsonProperty("queueTaskStatusCode")
	private String queueTaskStatusCode = null;

	@JsonProperty("siteId")
	private Long siteId;

	@JsonProperty("taskInstanceMapId")
	private Long taskInstanceMapId;

	@JsonProperty("updatedUserName")
	private String updatedUserName = null;

	@JsonProperty("bpmTaskName")
	private String bpmTaskName = null;

	public String getBpmTaskName() {
		return bpmTaskName;
	}

	public void setBpmTaskName(String bpmTaskName) {
		this.bpmTaskName = bpmTaskName;
	}

	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public Long getBpmTaskInstanceId() {
		return bpmTaskInstanceId;
	}

	public void setBpmTaskInstanceId(Long bpmTaskInstanceId) {
		this.bpmTaskInstanceId = bpmTaskInstanceId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getPrescriberId() {
		return prescriberId;
	}

	public void setPrescriberId(Long prescriberId) {
		this.prescriberId = prescriberId;
	}

	public Long getProcessInstanceMapId() {
		return processInstanceMapId;
	}

	public void setProcessInstanceMapId(Long processInstanceMapId) {
		this.processInstanceMapId = processInstanceMapId;
	}

	public Long getQueueTaskId() {
		return queueTaskId;
	}

	public void setQueueTaskId(Long queueTaskId) {
		this.queueTaskId = queueTaskId;
	}

	public String getQueueTaskStatusCode() {
		return queueTaskStatusCode;
	}

	public void setQueueTaskStatusCode(String queueTaskStatusCode) {
		this.queueTaskStatusCode = queueTaskStatusCode;
	}

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Long getTaskInstanceMapId() {
		return taskInstanceMapId;
	}

	public void setTaskInstanceMapId(Long taskInstanceMapId) {
		this.taskInstanceMapId = taskInstanceMapId;
	}

	public String getUpdatedUserName() {
		return updatedUserName;
	}

	public void setUpdatedUserName(String updatedUserName) {
		this.updatedUserName = updatedUserName;
	}




		@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		TaskLists taskLists = (TaskLists) o;
		return Objects.equals(this.actionId, taskLists.actionId) &&
				Objects.equals(this.bpmTaskInstanceId, taskLists.bpmTaskInstanceId) &&
				Objects.equals(this.comments, taskLists.comments) &&
				Objects.equals(this.outcomeId, taskLists.outcomeId) &&
				Objects.equals(this.patientId, taskLists.patientId) &&
				Objects.equals(this.prescriberId, taskLists.prescriberId) &&
				Objects.equals(this.processInstanceMapId, taskLists.processInstanceMapId) &&
				Objects.equals(this.queueTaskId, taskLists.queueTaskId) &&
				Objects.equals(this.queueTaskStatusCode, taskLists.queueTaskStatusCode) &&
				Objects.equals(this.siteId, taskLists.siteId) &&
				Objects.equals(this.taskInstanceMapId, taskLists.taskInstanceMapId) &&
				Objects.equals(this.taskInstanceMapId, taskLists.taskInstanceMapId) ;
	}

	@Override
	public int hashCode() {
		return Objects.hash(actionId, bpmTaskInstanceId,comments, outcomeId, patientId, prescriberId, processInstanceMapId, queueTaskId,
				queueTaskStatusCode, siteId, taskInstanceMapId, updatedUserName);
	}

	/*@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Task {\n");

		sb.append("    actionId: ").append(toIndentedString(actionId)).append("\n");
		sb.append("    bpmTaskInstanceId: ").append(toIndentedString(bpmTaskInstanceId)).append("\n");
		sb.append("    comments: ").append(toIndentedString(comments)).append("\n");
		sb.append("    outcomeId: ").append(toIndentedString(outcomeId)).append("\n");
		sb.append("    patientId: ").append(toIndentedString(patientId)).append("\n");
		sb.append("}");
		return sb.toString();
	}*/

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}
