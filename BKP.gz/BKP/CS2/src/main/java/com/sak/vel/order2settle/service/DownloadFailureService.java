package com.cvs.specialty.ordermaintenance.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cvs.specialty.ordermaintenance.model.OrderDownloadFailure;

public interface DownloadFailureService {
	ResponseEntity<String> downloadFailure(OrderDownloadFailure orderDownloadFailure);
}
