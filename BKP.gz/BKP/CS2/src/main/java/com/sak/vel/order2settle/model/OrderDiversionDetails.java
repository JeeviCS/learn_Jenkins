package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * OrderDiversionDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-19T16:52:21.883Z")

public class OrderDiversionDetails   {
  
  @JsonProperty("failureCode")
  private Integer failureCode;
  
  @JsonProperty("failureMessage")
  private String failureMessage;
  
  public Integer getFailureCode() {
    return failureCode;
  }
  public void setFailureCode(Integer failureCode) {
    this.failureCode = failureCode;
  }
  public String getFailureMessage() {
    return failureMessage;
  }
  public void setFailureMessage(String failureMessage) {
    this.failureMessage = failureMessage;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderDiversionDetails orderDiversionDetails = (OrderDiversionDetails) o;
    return Objects.equals(this.failureCode, orderDiversionDetails.failureCode) &&
        Objects.equals(this.failureMessage, orderDiversionDetails.failureMessage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(failureCode, failureMessage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderDiversionDetails {\n");
    
    sb.append("    failureCode: ").append(toIndentedString(failureCode)).append("\n");
    sb.append("    failureMessage: ").append(toIndentedString(failureMessage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

