
package com.cvs.specialty.ordermaintenance.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.joda.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Patient
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class Patient {
  @JsonProperty("patientIdentifier")
  private Long patientIdentifier = null;

  @JsonProperty("pharmacyIdentifier")
  private Long pharmacyIdentifier = null;

  @JsonProperty("sourceSystemIdentifier")
  private Long sourceSystemIdentifier = null;

  @JsonProperty("sourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("patientPresentInEnterpriseSystems")
  private String patientPresentInEnterpriseSystems = null;

  @JsonProperty("patientFirstName")
  private String patientFirstName = null;

  @JsonProperty("patientLastName")
  private String patientLastName = null;

  @JsonProperty("patientMiddleInitialText")
  private String patientMiddleInitialText = null;

  @JsonProperty("birthdate")
  private LocalDate birthdate = null;

  @JsonProperty("patientSpecialAccount")
  private List<PatientSpecialAccount> patientSpecialAccount = null;

  @JsonProperty("patientStore")
  private Pharmacy patientStore = null;

  @JsonProperty("genderText")
  private String genderText = null;

  @JsonProperty("patientSocialSecurityNumber")
  private String patientSocialSecurityNumber = null;

  @JsonProperty("diseaseStateCode")
  private String diseaseStateCode = null;

  @JsonProperty("patientHipaaAuthPersonName")
  private String patientHipaaAuthPersonName = null;

  @JsonProperty("digitalProfileIndicator")
  private String digitalProfileIndicator = null;

  @JsonProperty("cellPhoneNumber")
  private String cellPhoneNumber = null;

  @JsonProperty("offerPatientQuickRegistrationText")
  private String offerPatientQuickRegistrationText = null;

  @JsonProperty("languageCode")
  private String languageCode = null;

  @JsonProperty("anonymousPassPhraseText")
  private String anonymousPassPhraseText = null;

  @JsonProperty("vipGroupCode")
  private String vipGroupCode = null;

  @JsonProperty("retailDispensedSpecialtyManagedIndicator")
  private String retailDispensedSpecialtyManagedIndicator = null;

  @JsonProperty("preOrderHeader")
  private PreOrderHeader preOrderHeader = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public Patient patientIdentifier(Long patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(Long patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public Patient pharmacyIdentifier(Long pharmacyIdentifier) {
    this.pharmacyIdentifier = pharmacyIdentifier;
    return this;
  }

  /**
   * Get pharmacyIdentifier
   * 
   * @return pharmacyIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getPharmacyIdentifier() {
    return pharmacyIdentifier;
  }

  public void setPharmacyIdentifier(Long pharmacyIdentifier) {
    this.pharmacyIdentifier = pharmacyIdentifier;
  }

  public Patient sourceSystemIdentifier(Long sourceSystemIdentifier) {
    this.sourceSystemIdentifier = sourceSystemIdentifier;
    return this;
  }

  /**
   * Get sourceSystemIdentifier
   * 
   * @return sourceSystemIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getSourceSystemIdentifier() {
    return sourceSystemIdentifier;
  }

  public void setSourceSystemIdentifier(Long sourceSystemIdentifier) {
    this.sourceSystemIdentifier = sourceSystemIdentifier;
  }

  public Patient sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * 
   * @return sourceSystemName
   **/
  @ApiModelProperty(value = "")

  public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public Patient patientPresentInEnterpriseSystems(String patientPresentInEnterpriseSystems) {
    this.patientPresentInEnterpriseSystems = patientPresentInEnterpriseSystems;
    return this;
  }

  /**
   * Get patientPresentInEnterpriseSystems
   * 
   * @return patientPresentInEnterpriseSystems
   **/
  @ApiModelProperty(value = "")

  public String getPatientPresentInEnterpriseSystems() {
    return patientPresentInEnterpriseSystems;
  }

  public void setPatientPresentInEnterpriseSystems(String patientPresentInEnterpriseSystems) {
    this.patientPresentInEnterpriseSystems = patientPresentInEnterpriseSystems;
  }

  public Patient patientFirstName(String patientFirstName) {
    this.patientFirstName = patientFirstName;
    return this;
  }

  /**
   * Get patientFirstName
   * 
   * @return patientFirstName
   **/
  @ApiModelProperty(value = "")

  public String getPatientFirstName() {
    return patientFirstName;
  }

  public void setPatientFirstName(String patientFirstName) {
    this.patientFirstName = patientFirstName;
  }

  public Patient patientLastName(String patientLastName) {
    this.patientLastName = patientLastName;
    return this;
  }

  /**
   * Get patientLastName
   * 
   * @return patientLastName
   **/
  @ApiModelProperty(value = "")

  public String getPatientLastName() {
    return patientLastName;
  }

  public void setPatientLastName(String patientLastName) {
    this.patientLastName = patientLastName;
  }

  public Patient patientMiddleInitialText(String patientMiddleInitialText) {
    this.patientMiddleInitialText = patientMiddleInitialText;
    return this;
  }

  /**
   * Get patientMiddleInitialText
   * 
   * @return patientMiddleInitialText
   **/
  @ApiModelProperty(value = "")

  public String getPatientMiddleInitialText() {
    return patientMiddleInitialText;
  }

  public void setPatientMiddleInitialText(String patientMiddleInitialText) {
    this.patientMiddleInitialText = patientMiddleInitialText;
  }

  public Patient birthdate(LocalDate birthdate) {
    this.birthdate = birthdate;
    return this;
  }

  /**
   * Get birthdate
   * 
   * @return birthdate
   **/
  @ApiModelProperty(value = "")

  @Valid

  public LocalDate getBirthdate() {
    return birthdate;
  }

  public void setBirthdate(LocalDate birthdate) {
    this.birthdate = birthdate;
  }

  public Patient patientSpecialAccount(List<PatientSpecialAccount> patientSpecialAccount) {
    this.patientSpecialAccount = patientSpecialAccount;
    return this;
  }

  public Patient addPatientSpecialAccountItem(PatientSpecialAccount patientSpecialAccountItem) {
    if (this.patientSpecialAccount == null) {
      this.patientSpecialAccount = new ArrayList<PatientSpecialAccount>();
    }
    this.patientSpecialAccount.add(patientSpecialAccountItem);
    return this;
  }

  /**
   * Get patientSpecialAccount
   * 
   * @return patientSpecialAccount
   **/
  @ApiModelProperty(value = "")

  @Valid

  public List<PatientSpecialAccount> getPatientSpecialAccount() {
    return patientSpecialAccount;
  }

  public void setPatientSpecialAccount(List<PatientSpecialAccount> patientSpecialAccount) {
    this.patientSpecialAccount = patientSpecialAccount;
  }

  public Patient patientStore(Pharmacy patientStore) {
    this.patientStore = patientStore;
    return this;
  }

  /**
   * Get patientStore
   * 
   * @return patientStore
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Pharmacy getPatientStore() {
    return patientStore;
  }

  public void setPatientStore(Pharmacy patientStore) {
    this.patientStore = patientStore;
  }

  public Patient genderText(String genderText) {
    this.genderText = genderText;
    return this;
  }

  /**
   * Get genderText
   * 
   * @return genderText
   **/
  @ApiModelProperty(value = "")

  public String getGenderText() {
    return genderText;
  }

  public void setGenderText(String genderText) {
    this.genderText = genderText;
  }

  public Patient patientSocialSecurityNumber(String patientSocialSecurityNumber) {
    this.patientSocialSecurityNumber = patientSocialSecurityNumber;
    return this;
  }

  /**
   * Get patientSocialSecurityNumber
   * 
   * @return patientSocialSecurityNumber
   **/
  @ApiModelProperty(value = "")

  public String getPatientSocialSecurityNumber() {
    return patientSocialSecurityNumber;
  }

  public void setPatientSocialSecurityNumber(String patientSocialSecurityNumber) {
    this.patientSocialSecurityNumber = patientSocialSecurityNumber;
  }

  public Patient diseaseStateCode(String diseaseStateCode) {
    this.diseaseStateCode = diseaseStateCode;
    return this;
  }

  /**
   * Get diseaseStateCode
   * 
   * @return diseaseStateCode
   **/
  @ApiModelProperty(value = "")

  public String getDiseaseStateCode() {
    return diseaseStateCode;
  }

  public void setDiseaseStateCode(String diseaseStateCode) {
    this.diseaseStateCode = diseaseStateCode;
  }

  public Patient patientHipaaAuthPersonName(String patientHipaaAuthPersonName) {
    this.patientHipaaAuthPersonName = patientHipaaAuthPersonName;
    return this;
  }

  /**
   * Get patientHipaaAuthPersonName
   * 
   * @return patientHipaaAuthPersonName
   **/
  @ApiModelProperty(value = "")

  public String getPatientHipaaAuthPersonName() {
    return patientHipaaAuthPersonName;
  }

  public void setPatientHipaaAuthPersonName(String patientHipaaAuthPersonName) {
    this.patientHipaaAuthPersonName = patientHipaaAuthPersonName;
  }

  public Patient digitalProfileIndicator(String digitalProfileIndicator) {
    this.digitalProfileIndicator = digitalProfileIndicator;
    return this;
  }

  /**
   * Get digitalProfileIndicator
   * 
   * @return digitalProfileIndicator
   **/
  @ApiModelProperty(value = "")

  public String getDigitalProfileIndicator() {
    return digitalProfileIndicator;
  }

  public void setDigitalProfileIndicator(String digitalProfileIndicator) {
    this.digitalProfileIndicator = digitalProfileIndicator;
  }

  public Patient cellPhoneNumber(String cellPhoneNumber) {
    this.cellPhoneNumber = cellPhoneNumber;
    return this;
  }

  /**
   * Get cellPhoneNumber
   * 
   * @return cellPhoneNumber
   **/
  @ApiModelProperty(value = "")

  public String getCellPhoneNumber() {
    return cellPhoneNumber;
  }

  public void setCellPhoneNumber(String cellPhoneNumber) {
    this.cellPhoneNumber = cellPhoneNumber;
  }

  public Patient offerPatientQuickRegistrationText(String offerPatientQuickRegistrationText) {
    this.offerPatientQuickRegistrationText = offerPatientQuickRegistrationText;
    return this;
  }

  /**
   * Get offerPatientQuickRegistrationText
   * 
   * @return offerPatientQuickRegistrationText
   **/
  @ApiModelProperty(value = "")

  public String getOfferPatientQuickRegistrationText() {
    return offerPatientQuickRegistrationText;
  }

  public void setOfferPatientQuickRegistrationText(String offerPatientQuickRegistrationText) {
    this.offerPatientQuickRegistrationText = offerPatientQuickRegistrationText;
  }

  public Patient languageCode(String languageCode) {
    this.languageCode = languageCode;
    return this;
  }

  /**
   * Get languageCode
   * 
   * @return languageCode
   **/
  @ApiModelProperty(value = "")

  public String getLanguageCode() {
    return languageCode;
  }

  public void setLanguageCode(String languageCode) {
    this.languageCode = languageCode;
  }

  public Patient anonymousPassPhraseText(String anonymousPassPhraseText) {
    this.anonymousPassPhraseText = anonymousPassPhraseText;
    return this;
  }

  /**
   * Get anonymousPassPhraseText
   * 
   * @return anonymousPassPhraseText
   **/
  @ApiModelProperty(value = "")

  public String getAnonymousPassPhraseText() {
    return anonymousPassPhraseText;
  }

  public void setAnonymousPassPhraseText(String anonymousPassPhraseText) {
    this.anonymousPassPhraseText = anonymousPassPhraseText;
  }

  public Patient vipGroupCode(String vipGroupCode) {
    this.vipGroupCode = vipGroupCode;
    return this;
  }

  /**
   * Get vipGroupCode
   * 
   * @return vipGroupCode
   **/
  @ApiModelProperty(value = "")

  public String getVipGroupCode() {
    return vipGroupCode;
  }

  public void setVipGroupCode(String vipGroupCode) {
    this.vipGroupCode = vipGroupCode;
  }

  public Patient retailDispensedSpecialtyManagedIndicator(
      String retailDispensedSpecialtyManagedIndicator) {
    this.retailDispensedSpecialtyManagedIndicator = retailDispensedSpecialtyManagedIndicator;
    return this;
  }

  /**
   * Get retailDispensedSpecialtyManagedIndicator
   * 
   * @return retailDispensedSpecialtyManagedIndicator
   **/
  @ApiModelProperty(value = "")

  public String getRetailDispensedSpecialtyManagedIndicator() {
    return retailDispensedSpecialtyManagedIndicator;
  }

  public void setRetailDispensedSpecialtyManagedIndicator(
      String retailDispensedSpecialtyManagedIndicator) {
    this.retailDispensedSpecialtyManagedIndicator = retailDispensedSpecialtyManagedIndicator;
  }

  public Patient preOrderHeader(PreOrderHeader preOrderHeader) {
    this.preOrderHeader = preOrderHeader;
    return this;
  }

  /**
   * Get preOrderHeader
   * 
   * @return preOrderHeader
   **/
  @ApiModelProperty(value = "")

  @Valid

  public PreOrderHeader getPreOrderHeader() {
    return preOrderHeader;
  }

  public void setPreOrderHeader(PreOrderHeader preOrderHeader) {
    this.preOrderHeader = preOrderHeader;
  }

  public Patient audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Patient patient = (Patient) o;
    return Objects.equals(this.patientIdentifier, patient.patientIdentifier)
        && Objects.equals(this.pharmacyIdentifier, patient.pharmacyIdentifier)
        && Objects.equals(this.sourceSystemIdentifier, patient.sourceSystemIdentifier)
        && Objects.equals(this.sourceSystemName, patient.sourceSystemName)
        && Objects
          .equals(this.patientPresentInEnterpriseSystems, patient.patientPresentInEnterpriseSystems)
        && Objects.equals(this.patientFirstName, patient.patientFirstName)
        && Objects.equals(this.patientLastName, patient.patientLastName)
        && Objects.equals(this.patientMiddleInitialText, patient.patientMiddleInitialText)
        && Objects.equals(this.birthdate, patient.birthdate)
        && Objects.equals(this.patientSpecialAccount, patient.patientSpecialAccount)
        && Objects.equals(this.patientStore, patient.patientStore)
        && Objects.equals(this.genderText, patient.genderText)
        && Objects.equals(this.patientSocialSecurityNumber, patient.patientSocialSecurityNumber)
        && Objects.equals(this.diseaseStateCode, patient.diseaseStateCode)
        && Objects.equals(this.patientHipaaAuthPersonName, patient.patientHipaaAuthPersonName)
        && Objects.equals(this.digitalProfileIndicator, patient.digitalProfileIndicator)
        && Objects.equals(this.cellPhoneNumber, patient.cellPhoneNumber)
        && Objects
          .equals(this.offerPatientQuickRegistrationText, patient.offerPatientQuickRegistrationText)
        && Objects.equals(this.languageCode, patient.languageCode)
        && Objects.equals(this.anonymousPassPhraseText, patient.anonymousPassPhraseText)
        && Objects.equals(this.vipGroupCode, patient.vipGroupCode)
        && Objects.equals(
          this.retailDispensedSpecialtyManagedIndicator,
          patient.retailDispensedSpecialtyManagedIndicator)
        && Objects.equals(this.preOrderHeader, patient.preOrderHeader)
        && Objects.equals(this.audit, patient.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      patientIdentifier,
      pharmacyIdentifier,
      sourceSystemIdentifier,
      sourceSystemName,
      patientPresentInEnterpriseSystems,
      patientFirstName,
      patientLastName,
      patientMiddleInitialText,
      birthdate,
      patientSpecialAccount,
      patientStore,
      genderText,
      patientSocialSecurityNumber,
      diseaseStateCode,
      patientHipaaAuthPersonName,
      digitalProfileIndicator,
      cellPhoneNumber,
      offerPatientQuickRegistrationText,
      languageCode,
      anonymousPassPhraseText,
      vipGroupCode,
      retailDispensedSpecialtyManagedIndicator,
      preOrderHeader,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Patient {\n");

    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb.append("    pharmacyIdentifier: ").append(toIndentedString(pharmacyIdentifier)).append("\n");
    sb
      .append("    sourceSystemIdentifier: ")
      .append(toIndentedString(sourceSystemIdentifier))
      .append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb
      .append("    patientPresentInEnterpriseSystems: ")
      .append(toIndentedString(patientPresentInEnterpriseSystems))
      .append("\n");
    sb.append("    patientFirstName: ").append(toIndentedString(patientFirstName)).append("\n");
    sb.append("    patientLastName: ").append(toIndentedString(patientLastName)).append("\n");
    sb
      .append("    patientMiddleInitialText: ")
      .append(toIndentedString(patientMiddleInitialText))
      .append("\n");
    sb.append("    birthdate: ").append(toIndentedString(birthdate)).append("\n");
    sb.append("    patientSpecialAccount: ").append(toIndentedString(patientSpecialAccount)).append(
      "\n");
    sb.append("    patientStore: ").append(toIndentedString(patientStore)).append("\n");
    sb.append("    genderText: ").append(toIndentedString(genderText)).append("\n");
    sb
      .append("    patientSocialSecurityNumber: ")
      .append(toIndentedString(patientSocialSecurityNumber))
      .append("\n");
    sb.append("    diseaseStateCode: ").append(toIndentedString(diseaseStateCode)).append("\n");
    sb
      .append("    patientHipaaAuthPersonName: ")
      .append(toIndentedString(patientHipaaAuthPersonName))
      .append("\n");
    sb
      .append("    digitalProfileIndicator: ")
      .append(toIndentedString(digitalProfileIndicator))
      .append("\n");
    sb.append("    cellPhoneNumber: ").append(toIndentedString(cellPhoneNumber)).append("\n");
    sb
      .append("    offerPatientQuickRegistrationText: ")
      .append(toIndentedString(offerPatientQuickRegistrationText))
      .append("\n");
    sb.append("    languageCode: ").append(toIndentedString(languageCode)).append("\n");
    sb
      .append("    anonymousPassPhraseText: ")
      .append(toIndentedString(anonymousPassPhraseText))
      .append("\n");
    sb.append("    vipGroupCode: ").append(toIndentedString(vipGroupCode)).append("\n");
    sb
      .append("    retailDispensedSpecialtyManagedIndicator: ")
      .append(toIndentedString(retailDispensedSpecialtyManagedIndicator))
      .append("\n");
    sb.append("    preOrderHeader: ").append(toIndentedString(preOrderHeader)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
