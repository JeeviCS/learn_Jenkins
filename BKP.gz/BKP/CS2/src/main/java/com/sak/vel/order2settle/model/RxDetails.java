package com.cvs.specialty.ordermaintenance.model;

import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RxDetails {
	
  @JsonProperty("prescriptionDispensesId")
	private Long prescriptionDispensesId;
	
  @JsonProperty("rxDiversionDetails")
	private List<OrderDiversionDetails> rxDiversionDetails;

	public Long getPrescriptionDispensesId() {
		return prescriptionDispensesId;
	}

	public void setPrescriptionDispensesId(Long prescriptionDispensesId) {
		this.prescriptionDispensesId = prescriptionDispensesId;
	}

	public List<OrderDiversionDetails> getRxDiversionDetails() {
		return rxDiversionDetails;
	}

	public void setRxDiversionDetails(List<OrderDiversionDetails> rxDiversionDetails) {
		this.rxDiversionDetails = rxDiversionDetails;
	}

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RxDetails rxDetails = (RxDetails) o;
    return Objects.equals(this.prescriptionDispensesId, rxDetails.prescriptionDispensesId) &&
        Objects.equals(this.rxDiversionDetails, rxDetails.rxDiversionDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(prescriptionDispensesId, rxDiversionDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RxDetails {\n");
    
    sb.append("    prescriptionDispensesId: ").append(toIndentedString(prescriptionDispensesId)).append("\n");
    sb.append("    rxDiversionDetails: ").append(toIndentedString(rxDiversionDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
