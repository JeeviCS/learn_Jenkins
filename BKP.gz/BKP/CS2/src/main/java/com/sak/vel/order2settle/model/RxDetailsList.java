
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * RxDetailsList
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class RxDetailsList {
	@JsonProperty("quantityOnHand")
	private Integer quantityOnHand = null;

	@JsonProperty("diversion")
	private String diversion = null;

	@JsonProperty("prescription")
	private Prescription prescription = null;

	@JsonProperty("drug")
	private Drug drug = null;

	@JsonProperty("prescriptionDispense")
	private PrescriptionDispense prescriptionDispense = null;

	@JsonProperty("prescriptionRequest")
	private PrescriptionRequest prescriptionRequest = null;

	@JsonProperty("prescriber")
	private Prescriber prescriber = null;

	private long rx_rxNumber;

	private String rx_medication;

	private String rx_strength;

	private int rx_quantity;

	private int rx_daySupply;
	private int rx_onHand;
	private int rx_copay;
	private long rx_PrescriptionIdentifier;
	private long rx_drugIdentifier;
	private long rx_PrescriptionDispenseIdentifier;

	public long getRx_PrescriptionIdentifier() {
		return rx_PrescriptionIdentifier;
	}

	public void setRx_PrescriptionIdentifier(long rx_PrescriptionIdentifier) {
		this.rx_PrescriptionIdentifier = rx_PrescriptionIdentifier;
	}

	public long getRx_drugIdentifier() {
		return rx_drugIdentifier;
	}

	public void setRx_drugIdentifier(long rx_drugIdentifier) {
		this.rx_drugIdentifier = rx_drugIdentifier;
	}

	public long getRx_PrescriptionDispenseIdentifier() {
		return rx_PrescriptionDispenseIdentifier;
	}

	public void setRx_PrescriptionDispenseIdentifier(long rx_PrescriptionDispenseIdentifier) {
		this.rx_PrescriptionDispenseIdentifier = rx_PrescriptionDispenseIdentifier;
	}

	public long getRx_rxNumber() {
		return rx_rxNumber;
	}

	public void setRx_rxNumber(long rx_rxNumber) {
		this.rx_rxNumber = rx_rxNumber;
	}

	public String getRx_medication() {
		return rx_medication;
	}

	public void setRx_medication(String rx_medication) {
		this.rx_medication = rx_medication;
	}

	public String getRx_strength() {
		return rx_strength;
	}

	public void setRx_strength(String rx_strength) {
		this.rx_strength = rx_strength;
	}

	public int getRx_quantity() {
		return rx_quantity;
	}

	public void setRx_quantity(int rx_quantity) {
		this.rx_quantity = rx_quantity;
	}

	public int getRx_daySupply() {
		return rx_daySupply;
	}

	public void setRx_daySupply(int rx_daySupply) {
		this.rx_daySupply = rx_daySupply;
	}

	public int getRx_onHand() {
		return rx_onHand;
	}

	public void setRx_onHand(int rx_onHand) {
		this.rx_onHand = rx_onHand;
	}

	public int getRx_copay() {
		return rx_copay;
	}

	public void setRx_copay(int rx_copay) {
		this.rx_copay = rx_copay;
	}

	public RxDetailsList quantityOnHand(Integer quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
		return this;
	}

	/**
	 * Get quantityOnHand
	 * 
	 * @return quantityOnHand
	 **/
	@ApiModelProperty(value = "")

	public Integer getQuantityOnHand() {
		return quantityOnHand;
	}

	public void setQuantityOnHand(Integer quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}

	public RxDetailsList diversion(String diversion) {
		this.diversion = diversion;
		return this;
	}

	/**
	 * Get diversion
	 * 
	 * @return diversion
	 **/
	@ApiModelProperty(value = "")

	public String getDiversion() {
		return diversion;
	}

	public void setDiversion(String diversion) {
		this.diversion = diversion;
	}

	public RxDetailsList prescription(Prescription prescription) {
		this.prescription = prescription;
		return this;
	}

	/**
	 * Get prescription
	 * 
	 * @return prescription
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public Prescription getPrescription() {
		return prescription;
	}

	public void setPrescription(Prescription prescription) {
		this.prescription = prescription;
	}

	public RxDetailsList drug(Drug drug) {
		this.drug = drug;
		return this;
	}

	/**
	 * Get drug
	 * 
	 * @return drug
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public Drug getDrug() {
		return drug;
	}

	public void setDrug(Drug drug) {
		this.drug = drug;
	}

	public RxDetailsList prescriptionDispense(PrescriptionDispense prescriptionDispense) {
		this.prescriptionDispense = prescriptionDispense;
		return this;
	}

	/**
	 * Get prescriptionDispense
	 * 
	 * @return prescriptionDispense
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public PrescriptionDispense getPrescriptionDispense() {
		return prescriptionDispense;
	}

	public void setPrescriptionDispense(PrescriptionDispense prescriptionDispense) {
		this.prescriptionDispense = prescriptionDispense;
	}

	public RxDetailsList prescriptionRequest(PrescriptionRequest prescriptionRequest) {
		this.prescriptionRequest = prescriptionRequest;
		return this;
	}

	/**
	 * Get prescriptionRequest
	 * 
	 * @return prescriptionRequest
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public PrescriptionRequest getPrescriptionRequest() {
		return prescriptionRequest;
	}

	public void setPrescriptionRequest(PrescriptionRequest prescriptionRequest) {
		this.prescriptionRequest = prescriptionRequest;
	}

	public RxDetailsList prescriber(Prescriber prescriber) {
		this.prescriber = prescriber;
		return this;
	}

	/**
	 * Get prescriber
	 * 
	 * @return prescriber
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public Prescriber getPrescriber() {
		return prescriber;
	}

	public void setPrescriber(Prescriber prescriber) {
		this.prescriber = prescriber;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		RxDetailsList rxDetailsList = (RxDetailsList) o;
		return Objects.equals(this.quantityOnHand, rxDetailsList.quantityOnHand)
				&& Objects.equals(this.diversion, rxDetailsList.diversion)
				&& Objects.equals(this.prescription, rxDetailsList.prescription)
				&& Objects.equals(this.drug, rxDetailsList.drug)
				&& Objects.equals(this.prescriptionDispense, rxDetailsList.prescriptionDispense)
				&& Objects.equals(this.prescriptionRequest, rxDetailsList.prescriptionRequest)
				&& Objects.equals(this.prescriber, rxDetailsList.prescriber);
	}

	@Override
	public int hashCode() {
		return Objects.hash(quantityOnHand, diversion, prescription, drug, prescriptionDispense, prescriptionRequest,
				prescriber);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class RxDetailsList {\n");

		sb.append("    quantityOnHand: ").append(toIndentedString(quantityOnHand)).append("\n");
		sb.append("    diversion: ").append(toIndentedString(diversion)).append("\n");
		sb.append("    prescription: ").append(toIndentedString(prescription)).append("\n");
		sb.append("    drug: ").append(toIndentedString(drug)).append("\n");
		sb.append("    prescriptionDispense: ").append(toIndentedString(prescriptionDispense)).append("\n");
		sb.append("    prescriptionRequest: ").append(toIndentedString(prescriptionRequest)).append("\n");
		sb.append("    prescriber: ").append(toIndentedString(prescriber)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}
