
package com.cvs.specialty.ordermaintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.client.RestTemplate;

import com.cvs.specialty.ordermaintenance.util.RestInvocationErrorHandler;

@ComponentScan("com.cvs.specialty")
@SpringBootApplication
@EnableDiscoveryClient
public class OrderMaintenanceApiApplication {
  public static void main(String[] args) {
    SpringApplication.run(OrderMaintenanceApiApplication.class, args);
  }

  /**
   * Rest Template to be used in outbound method invocations Also holds the reference to the
   * {@code RestInvocationErrorHandler} for handling errors during outbound method invocations.
   * 
   * @return RestTemplate
   */
  @Bean
  public RestTemplate workflowRestTemplate() {
    RestTemplate template = new RestTemplate();
    template.setErrorHandler(new RestInvocationErrorHandler());
    return template;

  }

  /**
   * Spring Bean for holding the message sources, in order to resolve the error-code lookups.
   * 
   * @return MessageSource
   */
  @Bean
  public MessageSource messageSource() {
    ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
    messageSource.addBasenames("ordermaintenance-messages");
    return messageSource;
  }
}
