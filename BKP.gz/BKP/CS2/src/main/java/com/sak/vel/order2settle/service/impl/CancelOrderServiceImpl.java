
package com.cvs.specialty.ordermaintenance.service.impl;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.common.OrderCancelConstant;
import com.cvs.specialty.ordermaintenance.dao.CancelOrderDao;
import com.cvs.specialty.ordermaintenance.dao.impl.TaskManualDaoImpl;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.mapper.OrderCancelMapper;
import com.cvs.specialty.ordermaintenance.model.AssignTask;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.CancelReason;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
import com.cvs.specialty.ordermaintenance.model.RouteToQueueRequest;
import com.cvs.specialty.ordermaintenance.model.RouteToQueueResponse;
import com.cvs.specialty.ordermaintenance.model.Task;
import com.cvs.specialty.ordermaintenance.model.TaskLists;
import com.cvs.specialty.ordermaintenance.model.TaskMessageResponse;
import com.cvs.specialty.ordermaintenance.repository.ListOfTasksRepo;
import com.cvs.specialty.ordermaintenance.service.CancelOrderService;

@Service
public class CancelOrderServiceImpl implements CancelOrderService {
	@Autowired
	SpecialtyLogger serviceLogger;

	@Autowired
	CancelOrderDao cancelOrderdao;
	@Autowired
	OrderCancelMapper orderCancelMapper;

	@Autowired
	TaskManualDaoImpl taskManualDaoImpl;

	@Autowired
	ListOfTasksRepo listOfTasksRepo;


	@Autowired
	RestTemplate restTemplate;

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}


	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@Value("${createtask.wrapper.service.url}")
	private String createTaskUrl;
	
	
	@Value("${canceltask.wrapper.service.url}")
	private String cancelTaskUrl;

	@Value("${assigntask.wrapper.service.url}")
	private String assignTaskUrl;

	public OrderCancelMapper getOrderCancelMapper() {
		return orderCancelMapper;
	}


	public void setOrderCancelMapper(OrderCancelMapper orderCancelMapper) {
		this.orderCancelMapper = orderCancelMapper;
	}


	public List<CancelReason> getCancelReason(){

		serviceLogger.info("Service to get cancel Reason Info ");
		List<CancelReason> map=new ArrayList<CancelReason>();
		String domain=OrderCancelConstant.PreferenceTextCgLowValues.DOMAIN;	
		String rvHighValue=OrderCancelConstant.PreferenceTextCgLowValues.CANCELREASON_HIGH_VALUE;
		List<CgRefCode> liCgRefCode = cancelOrderdao.getCancelReason(domain, rvHighValue);
		if (!liCgRefCode.isEmpty()) {
			map=orderCancelMapper.getCancelReason(liCgRefCode);
		}
	return map;
	}



	@Override
	public CancelOrderResponse submitCancelOrder(OrderCancelRequest cancelOrder, String userId, String accessToken, String messageId){

		CancelOrderResponse cancelOrderResponse=null;
		List<TaskLists> tasklist = null;
		List<TaskLists> tasklistUnassigned = null;
		List<Long> TaskId_List;
		Long orderId;
		try {
			serviceLogger.info("Invoking Domain Model to Update order cancel in SPARCS");
			orderId=cancelOrder.getOrderId();
			if(orderId != null) {
				tasklistUnassigned = taskManualDaoImpl.getListofUnassignedTasks(orderId.toString());
				if(tasklistUnassigned!=null && tasklistUnassigned.size()>0) {
					serviceLogger.error("No. of Unassigned Tasks to be assigned: "+tasklistUnassigned.size());
					
					for (int i = 0; i < tasklistUnassigned.size(); i++) {
						TaskLists taskList= tasklistUnassigned.get(i) ;
						AssignTask assignTask = getAssignTaskRequest(cancelOrder, taskList);
						callAssignTask(messageId, accessToken, assignTask);
						}
					}
				tasklist =  taskManualDaoImpl.getListofTasks(orderId.toString());
				if(tasklist!=null && tasklist.size()>0) {
					serviceLogger.error("No. of Tasks to be cancelled: "+tasklist.size());
					
					for (int i = 0; i < tasklist.size(); i++) {
						TaskLists taskList= tasklist.get(i) ;
						Task cancelTask = getCancelTaskRrequest(cancelOrder, taskList);
						callCancelTask(messageId, accessToken, cancelTask);
						}
					}
			}

			cancelOrderResponse=cancelOrderdao.submitCancelOrder(cancelOrder, userId);

		} catch (Exception ex) {
			serviceLogger.error("Failed to Update order cancel "+ ex.getMessage());
		}

		return cancelOrderResponse;
	}
	
	/*public ResponseEntity<TaskMessageResponse> callCreateServicerForPatientNotified(String userId,String accessToken,String messageId, OrderCancelRequest cancelOrder)
	{
		ResponseEntity<TaskMessageResponse> result=null;
		HttpHeaders headers = new HttpHeaders();

		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("service-id", "1");
		headers.add("user-id", userId);
		headers.add("access-token", accessToken);
		headers.add("message-id", messageId);
		TaskRequest task=new TaskRequest();
		UserRequest user=new UserRequest();
		TaskManualApiCreateTaskRequest taskManualApiCreateTaskRequest = new TaskManualApiCreateTaskRequest();
		ZonedDateTime followUpDate= ZonedDateTime.now(ZoneId.systemDefault());
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");  
		String followupDate = followUpDate.format(dateFormat);
		try {

			task.setTaskReason(OrderCancelConstant.PreferenceTextCgLowValues.TASKREASON_PATIENT_NOTIFIED);
			task.setTaskSource(OrderCancelConstant.PreferenceTextCgLowValues.TASKSOURCE);
			task.setFollowUpDate(followupDate);
			task.setRxOrderNumber(cancelOrder.getOrderId().toString());
			task.setPriorityFlag(true);
			task.setCommentTxt(OrderCancelConstant.PreferenceTextCgLowValues.COMMENT_PATIENT_NOTIFIED);
			user.setUserId(userId);
			user.setUserName(OrderCancelConstant.PreferenceTextCgLowValues.USERNAME);
			user.setUserRole(OrderCancelConstant.PreferenceTextCgLowValues.USERROLE);
			taskManualApiCreateTaskRequest.setTask(task);
			taskManualApiCreateTaskRequest.setUser(user);
			HttpEntity<TaskManualApiCreateTaskRequest> entity = new HttpEntity<TaskManualApiCreateTaskRequest>(taskManualApiCreateTaskRequest,headers);
			createTaskUrl = createTaskUrl.concat(cancelOrder.getPatientId().toString());
			result = restTemplate.postForEntity(createTaskUrl, entity, TaskMessageResponse.class);

			if(result.getStatusCode().equals(HttpStatus.OK))
			{
				//	serviceLogger.info("Task Created Successfully: "+result.getBody().getTaskId());
				return  new ResponseEntity<TaskMessageResponse>(HttpStatus.OK);
			}

		}catch(HttpClientErrorException e) {
			//			serviceLogger.error("Result" + e.getRawStatusCode());
			//			serviceLogger.error(e.getMessage());

		}
		return result;

	}
	public ResponseEntity<TaskMessageResponse> callCreateServicerForMD_Notified(String userId,String accessToken,String messageId, OrderCancelRequest cancelOrder)
	{
		ResponseEntity<TaskMessageResponse> result=null;
		HttpHeaders headers = new HttpHeaders();
		TaskManualApiCreateTaskRequest taskManualApiCreateTaskRequest = new TaskManualApiCreateTaskRequest();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.add("service-id", "1");
		headers.add("user-id", userId);
		headers.add("access-token", accessToken);
		headers.add("message-id", messageId);
		TaskRequest task=new TaskRequest();
		UserRequest user=new UserRequest();
		ZonedDateTime followUpDate= ZonedDateTime.now(ZoneId.systemDefault());
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss");  
		String followupDate = followUpDate.format(dateFormat); 

		try {

			task.setTaskReason(OrderCancelConstant.PreferenceTextCgLowValues.TASKREASON_MD_NOTIFIED);
			task.setTaskSource(OrderCancelConstant.PreferenceTextCgLowValues.TASKSOURCE);
			task.setFollowUpDate(followupDate);
			task.setRxOrderNumber(cancelOrder.getOrderId().toString());
			task.setPriorityFlag(true);
			task.setCommentTxt(OrderCancelConstant.PreferenceTextCgLowValues.COMMENT_MD_NOTIFIED);
			user.setUserId(userId);
			user.setUserName(OrderCancelConstant.PreferenceTextCgLowValues.USERNAME);
			user.setUserRole(OrderCancelConstant.PreferenceTextCgLowValues.USERROLE);
			taskManualApiCreateTaskRequest.setTask(task);
			taskManualApiCreateTaskRequest.setUser(user);
			HttpEntity<TaskManualApiCreateTaskRequest> entity = new HttpEntity<TaskManualApiCreateTaskRequest>(taskManualApiCreateTaskRequest,headers);
			createTaskUrl = createTaskUrl.concat(cancelOrder.getPatientId().toString());
			result = restTemplate.postForEntity(createTaskUrl, entity, TaskMessageResponse.class);
			if(result.getStatusCode().equals(HttpStatus.OK))
			{

				//				serviceLogger.info("Task Created Successfully: "+result.getBody().getTaskId());
				return  new ResponseEntity<TaskMessageResponse>(HttpStatus.OK);

			}

		}catch(HttpClientErrorException e) {
			//			serviceLogger.error("Result" + e.getRawStatusCode());
			//			serviceLogger.error(e.getMessage());

		}
		return result;
	}
*/
	
	public ResponseEntity<RouteToQueueResponse> callCreateService(String userId,String accessToken,String messageId, OrderCancelRequest cancelOrder)
	{
		ResponseEntity<RouteToQueueResponse> result=null;
		HttpHeaders headers = new HttpHeaders();
		RouteToQueueRequest routeToQueueRequest = getRouteToQueueRequest(cancelOrder);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		//headers.add("service-id", "1");
		//headers.add("user-id", userId);
		headers.add("access-token", accessToken);
		headers.add("message-id", messageId);
		
		try {
			//createTaskUrl = createTaskUrl.concat(cancelOrder.getPatientId().toString());
			serviceLogger.info("Task Creation URL: "+createTaskUrl);
			HttpEntity<RouteToQueueRequest> entity = new HttpEntity<RouteToQueueRequest>(routeToQueueRequest,headers);
			result = restTemplate.exchange(createTaskUrl, HttpMethod.PUT, entity, RouteToQueueResponse.class);
			if(result.getStatusCode().equals(HttpStatus.OK))
			{
				serviceLogger.info("Task Created Successfully with TaskInstanceId: "+result.getBody().getTargetBpmTaskInstanceId());
				return  new ResponseEntity<RouteToQueueResponse>(HttpStatus.OK);
			}

		}catch(HttpClientErrorException e) {
			serviceLogger.error("Result" + e.getRawStatusCode());
			serviceLogger.error(e.getMessage());

		}
		return result;
	}
	
	public String callCancelTask(String messageId,String accessToken,Task cancelTask) {
		ResponseEntity<String> responseEntity=null;
		String  response=null;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		//headers.add("user-id", userId);
		headers.add("access-token", accessToken);
		headers.add("message-id", messageId);
		//Task cancelTaskRequest= getCancelTaskRrequest(cancelOrder);	
		try{
			HttpEntity<Task> entity = new HttpEntity<Task>(cancelTask,headers);
			responseEntity = restTemplate.exchange(cancelTaskUrl, HttpMethod.PUT, entity, String.class);
			if(responseEntity.getStatusCode().equals(HttpStatus.NO_CONTENT))
			{
				serviceLogger.info("Task cancel success for TaskInstanceID: "+cancelTask.getBpmTaskInstanceId());
				response = "SUCCESS";
			}
			//response= responseEntity.getBody();
		}catch(HttpClientErrorException e) {
			serviceLogger.error("Result" + e.getRawStatusCode());
			serviceLogger.error(e.getMessage());
			response = "Task Cancel Failed";
		}
		return response;
	}
	
	public String callAssignTask(String messageId,String accessToken,AssignTask assignTask) {
		ResponseEntity<String> responseEntity=null;
		String  response=null;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		//headers.add("user-id", userId);
		headers.add("access-token", accessToken);
		headers.add("message-id", messageId);
		//Task cancelTaskRequest= getCancelTaskRrequest(cancelOrder);	
		try{
			HttpEntity<AssignTask> entity = new HttpEntity<AssignTask>(assignTask,headers);
			responseEntity = restTemplate.exchange(assignTaskUrl, HttpMethod.PUT, entity, String.class);
			if(responseEntity.getStatusCode().equals(HttpStatus.CREATED))
			{
				serviceLogger.info("Task Assign success for TaskInstanceID: "+assignTask.getBpmTaskInstanceId());
				response = "SUCCESS";
			}
			//response= responseEntity.getBody();
		}catch(HttpClientErrorException e) {
			serviceLogger.error("Result" + e.getRawStatusCode());
			serviceLogger.error(e.getMessage());
			response = "Task Assign Failed";
		}
		return response;
	}
	
	
	public RouteToQueueRequest getRouteToQueueRequest(OrderCancelRequest cancelOrder) {
		ZonedDateTime followUpDate= ZonedDateTime.now(ZoneId.systemDefault());
		RouteToQueueRequest routeToQueueRequest = new RouteToQueueRequest();
		routeToQueueRequest.setActionId(null);
		routeToQueueRequest.setCallingService(OrderCancelConstant.PreferenceTextCgLowValues.CALLING_SERVICE);
		if(cancelOrder.getPatientNotifiedFlag() != null && !cancelOrder.getPatientNotifiedFlag()) {
			routeToQueueRequest.setComments("Order "+cancelOrder.getOrderId().toString()+OrderCancelConstant.PreferenceTextCgLowValues.COMMENT_PATIENT_NOTIFIED);
			routeToQueueRequest.setTargetTaskName(OrderCancelConstant.PreferenceTextCgLowValues.TARGET_PT_TASK_NAME);
			routeToQueueRequest.setTaskId(null);
		}
		if(cancelOrder.getMdNotifiedFlag() != null && !cancelOrder.getMdNotifiedFlag()) {
			routeToQueueRequest.setComments("Order "+cancelOrder.getOrderId().toString()+OrderCancelConstant.PreferenceTextCgLowValues.COMMENT_MD_NOTIFIED);
			routeToQueueRequest.setTargetTaskName(OrderCancelConstant.PreferenceTextCgLowValues.TARGET_MD_TASK_NAME);
			routeToQueueRequest.setTaskId(null);
		}
		routeToQueueRequest.setDiversionId(null);
		routeToQueueRequest.setEntityId(cancelOrder.getOrderId());
		routeToQueueRequest.setEntityType(OrderCancelConstant.PreferenceTextCgLowValues.ENTITY_TYPE);
		routeToQueueRequest.setFollowUpDate(followUpDate);
		routeToQueueRequest.setOutcomeId(null);
		routeToQueueRequest.setPatientId(cancelOrder.getPatientId());
		routeToQueueRequest.setPrescriberId(null);
		routeToQueueRequest.setPrimaryBillGroupId(null);
		routeToQueueRequest.setProcessInstanceId(null);
		routeToQueueRequest.setTaskType(OrderCancelConstant.PreferenceTextCgLowValues.TASK_TYPE);
		return routeToQueueRequest;
	}
	
	public Task getCancelTaskRrequest( OrderCancelRequest cancelOrder, TaskLists taskList)
	{
		Task cancelTaskRequest= new Task();
		ZonedDateTime followUpDate= ZonedDateTime.now(ZoneId.systemDefault());
		cancelTaskRequest.setActionId(105L);
		cancelTaskRequest.setActionType("");
		cancelTaskRequest.setActiveIndicator("N");
		cancelTaskRequest.setBpmProcessInstanceId(null);
		cancelTaskRequest.setBpmProcessName("");
		cancelTaskRequest.setBpmTaskInstanceId(taskList.getBpmTaskInstanceId());
		cancelTaskRequest.setBpmTaskName("");
		cancelTaskRequest.setBpmTaskStatusCode("");
		cancelTaskRequest.setComments(cancelOrder.getOrderCancelReason());
		cancelTaskRequest.setCompleteTaskUserId("");
		cancelTaskRequest.setCompletionTimestamp(null);
		cancelTaskRequest.setCreatedTimeStamp(null);
		cancelTaskRequest.setEntityBpmProcessMapId(null);
		cancelTaskRequest.setEntityId(cancelOrder.getOrderId());
		cancelTaskRequest.setFollowUpDate(followUpDate);
		cancelTaskRequest.setFollowUpTimestamp(null);
		cancelTaskRequest.setIntakeReferralId(null);
		cancelTaskRequest.setNdc("");
		cancelTaskRequest.setOutcomeId(150L);
		cancelTaskRequest.setPatientId(cancelOrder.getPatientId());
		cancelTaskRequest.setPrescriberId(null);
		cancelTaskRequest.setProcessInstanceMapId(taskList.getProcessInstanceMapId());
		cancelTaskRequest.setQueueTaskId(null);
		cancelTaskRequest.setQueueTaskStatusCode("");
		cancelTaskRequest.setSiteId(null);
		cancelTaskRequest.setTaskInstanceMapId(null);
		cancelTaskRequest.setUpdatedTimeStamp(null);
		cancelTaskRequest.setUpdatedUserName("");
		return cancelTaskRequest;
	}
	
	public AssignTask getAssignTaskRequest( OrderCancelRequest cancelOrder, TaskLists taskList)
	{
		AssignTask assignTaskRequest= new AssignTask();
		ZonedDateTime followUpDate= ZonedDateTime.now(ZoneId.systemDefault());
		/*assignTaskRequest.setActionId(null);
		assignTaskRequest.setActionType("");
		assignTaskRequest.setActiveIndicator("N");
		assignTaskRequest.setBpmProcessInstanceId(null);
		assignTaskRequest.setBpmProcessName("");*/
		assignTaskRequest.setBpmTaskInstanceId(taskList.getBpmTaskInstanceId());
		assignTaskRequest.setBpmTaskName(taskList.getBpmTaskName());
		/*assignTaskRequest.setBpmTaskStatusCode("");
		assignTaskRequest.setComments(cancelOrder.getOrderCancelReason());
		assignTaskRequest.setCompleteTaskUserId("");
		assignTaskRequest.setCompletionTimestamp(null);
		assignTaskRequest.setCreatedTimeStamp(null);
		assignTaskRequest.setEntityBpmProcessMapId(null);
		assignTaskRequest.setEntityId(cancelOrder.getOrderId());
		assignTaskRequest.setFollowUpDate(followUpDate);
		assignTaskRequest.setFollowUpTimestamp(null);
		assignTaskRequest.setIntakeReferralId(null);
		assignTaskRequest.setNdc("");
		assignTaskRequest.setOutcomeId(null);
		assignTaskRequest.setPatientId(cancelOrder.getPatientId());
		assignTaskRequest.setPrescriberId(null);
		assignTaskRequest.setProcessInstanceMapId(taskList.getProcessInstanceMapId());
		assignTaskRequest.setQueueTaskId(null);
		assignTaskRequest.setQueueTaskStatusCode("");
		assignTaskRequest.setSiteId(null);
		assignTaskRequest.setTaskInstanceMapId(null);
		assignTaskRequest.setUpdatedTimeStamp(null);
		assignTaskRequest.setUpdatedUserName("");*/
		return assignTaskRequest;
	}
}
