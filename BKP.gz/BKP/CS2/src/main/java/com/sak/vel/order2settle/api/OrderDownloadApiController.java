
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

@Controller
public class OrderDownloadApiController implements OrderDownloadApi {

  @Autowired
  SpecialtyLogger LOGGER;

  public ResponseEntity<Void> orderDownloadPost(

      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "access token to validate this request", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "order Id", required = true) @RequestParam(value = "orderId", required = true) Integer orderId,
      @NotNull @ApiParam(value = "status", required = true) @RequestParam(value = "status", required = true) String status,
      @ApiParam(value = "Request Body", required = true) @Valid @RequestBody RxDetailsList rxDetailsList,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {

    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    // do some magic!
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return new ResponseEntity<Void>(HttpStatus.OK);
  }

}
