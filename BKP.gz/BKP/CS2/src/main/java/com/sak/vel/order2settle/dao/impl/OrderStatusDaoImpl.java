
package com.cvs.specialty.ordermaintenance.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderStatusDao;
import com.cvs.specialty.ordermaintenance.repository.PreOrderHeaderRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class OrderStatusDaoImpl implements OrderStatusDao {

  @Autowired
  SpecialtyLogger LOGGER;

  @SuppressWarnings("rawtypes")
  @Autowired
  PreOrderHeaderRepo pOrderHeaderRepo;

  @Override
  public Void updateOrderStatus(Long preOrdrHdrId) {

    try {
      LOGGER.info(LogMsgConstants.METHOD_ENTRY);
      pOrderHeaderRepo.updateOrderStatus(preOrdrHdrId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
    } catch (DataAccessException e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "DataAccessException");

    } catch (Exception e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);

      throw new OrderMaintenanceException(e, "Exception");
    }
    return null;

  }
}
