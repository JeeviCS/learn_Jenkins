package com.cvs.specialty.ordermaintenance.repository;


import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PatientAddress;
import com.cvs.specialty.ordermaintenance.entity.PatientAddressEO;

@Repository
@Transactional
public interface PatientAddressRepo extends JpaRepository<PatientAddressEO, Long> {
	
	List<PatientAddress> findByPatientId(BigDecimal patientId);
	
	@Modifying
	@Query("update PatientAddressEO ptntAddr set "
			+ "ptntAddr.address1 = :address1, ptntAddr.address2 = :address2, "
			+ "ptntAddr.city = :city, ptntAddr.addressCategory = :addressCategory,"
			+ "ptntAddr.monInd = :monInd, ptntAddr.tueInd = :tueInd, ptntAddr.wedInd = :wedInd, ptntAddr.thuInd = :thuInd, ptntAddr.friInd = :friInd,"
			+ "ptntAddr.satInd = :satInd,ptntAddr.sunInd = :sunInd, ptntAddr.createBy = :createBy"
			+ " where ptntAddr.patientAddressId = :id")
	Integer updateShippingDetailforPtnt(@Param("id") Long id, @Param("address1") String address1,
											@Param("address2") String address2, @Param("city") String city, 
											@Param("addressCategory") String addressCategory,
											@Param("monInd") String monInd, @Param("tueInd") String tueInd, @Param("wedInd") String wedInd, @Param("thuInd") String thuInd,
											@Param("friInd") String friInd, @Param("satInd") String satInd, @Param("sunInd") String sunInd, @Param("createBy") String createBy); 
}





