package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;

/**
 * The persistent class for the PRE_ORDER_DETAIL database table.
 * 
 */
@Entity
@Table(name = "PRE_ORDER_DETAIL")
@NamedQuery(name = "PreOrderDetailEO.findAll", query = "SELECT p FROM PreOrderDetailEO p")
public class PreOrderDetailEO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRE_ORDER_DETAIL_ID_GENERATOR")
	@Column(name = "PRE_ORDR_DTL_ID")
	@SequenceGenerator(sequenceName = "pre_ordr_dtl_id_id_seq", initialValue=1,allocationSize = 1, name = "PRE_ORDER_DETAIL_ID_GENERATOR")
	private long preOrdrDtlId;

	@Column(name = "ACTV_IN")
	private String actvIn;

	@Column(name = "CRTE_TS")
	private Timestamp crteTs;

	@Column(name = "CRTE_USR_NM")
	private String crteUsrNm;

	@Column(name = "HLTCR_PRFSN_ID")
	private BigDecimal hltcrPrfsnId;

	@Column(name = "PRE_ORDR_HDR_ID")
	private BigDecimal preOrdrHdrId;

	@Column(name = "RMNG_QY")
	private BigDecimal rmngQy;

	@Column(name = "RX_ID")
	private BigDecimal rxId;

	@Column(name = "RX_RQST_ID")
	private BigDecimal rxRqstId;

	@Column(name = "SRC_SYSTM_ID")
	private BigDecimal srcSystmId;

	@Column(name = "SRC_SYSTM_NM")
	private String srcSystmNm;

	@Column(name = "UPD_TS")
	private Timestamp updTs;

	@Column(name = "UPD_USR_NM")
	private String updUsrNm;

	// bi-directional many-to-one association to Item
	@ManyToOne
	@JoinColumn(name = "ITM_ID")
	private ItemEO item;

	// bi-directional many-to-one association to PrescriptionDispens
	@ManyToOne
	@JoinColumn(name = "RX_DSPNS_ID")
	private PrescriptionDispensesEO prescriptionDispens;

	public PreOrderDetailEO() {
	}

	public long getPreOrdrDtlId() {
		return this.preOrdrDtlId;
	}

	public void setPreOrdrDtlId(long preOrdrDtlId) {
		this.preOrdrDtlId = preOrdrDtlId;
	}

	public String getActvIn() {
		return this.actvIn;
	}

	public void setActvIn(String actvIn) {
		this.actvIn = actvIn;
	}

	public Timestamp getCrteTs() {
		return this.crteTs;
	}

	public void setCrteTs(Timestamp crteTs) {
		this.crteTs = crteTs;
	}

	public String getCrteUsrNm() {
		return this.crteUsrNm;
	}

	public void setCrteUsrNm(String crteUsrNm) {
		this.crteUsrNm = crteUsrNm;
	}

	public BigDecimal getHltcrPrfsnId() {
		return this.hltcrPrfsnId;
	}

	public void setHltcrPrfsnId(BigDecimal hltcrPrfsnId) {
		this.hltcrPrfsnId = hltcrPrfsnId;
	}

	public BigDecimal getPreOrdrHdrId() {
		return this.preOrdrHdrId;
	}

	public void setPreOrdrHdrId(BigDecimal preOrdrHdrId) {
		this.preOrdrHdrId = preOrdrHdrId;
	}

	public BigDecimal getRmngQy() {
		return this.rmngQy;
	}

	public void setRmngQy(BigDecimal rmngQy) {
		this.rmngQy = rmngQy;
	}

	public BigDecimal getRxId() {
		return this.rxId;
	}

	public void setRxId(BigDecimal rxId) {
		this.rxId = rxId;
	}

	public BigDecimal getRxRqstId() {
		return this.rxRqstId;
	}

	public void setRxRqstId(BigDecimal rxRqstId) {
		this.rxRqstId = rxRqstId;
	}

	public BigDecimal getSrcSystmId() {
		return this.srcSystmId;
	}

	public void setSrcSystmId(BigDecimal srcSystmId) {
		this.srcSystmId = srcSystmId;
	}

	public String getSrcSystmNm() {
		return this.srcSystmNm;
	}

	public void setSrcSystmNm(String srcSystmNm) {
		this.srcSystmNm = srcSystmNm;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrNm() {
		return this.updUsrNm;
	}

	public void setUpdUsrNm(String updUsrNm) {
		this.updUsrNm = updUsrNm;
	}

	public ItemEO getItem() {
		return this.item;
	}

	public void setItem(ItemEO item) {
		this.item = item;
	}

	public PrescriptionDispensesEO getPrescriptionDispens() {
		return this.prescriptionDispens;
	}

	public void setPrescriptionDispens(PrescriptionDispensesEO prescriptionDispens) {
		this.prescriptionDispens = prescriptionDispens;
	}

}