
package com.cvs.specialty.ordermaintenance.dao;

import com.cvs.specialty.ordermaintenance.model.OrderSatCode;

public interface OrderNumberInfoDao {

  OrderSatCode getOrderInfo(long preOrderId);
}
