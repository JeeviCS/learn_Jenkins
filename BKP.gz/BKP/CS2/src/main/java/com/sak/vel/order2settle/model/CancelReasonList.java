package com.cvs.specialty.ordermaintenance.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CancelReasonList
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-22T12:32:09.067Z")

public class CancelReasonList   {
	@JsonProperty("CancelReasons")
	private Map<String,String> cancelReasons = null;

	public CancelReasonList cancelReasons(Map<String,String> cancelReasons) {
		this.cancelReasons = cancelReasons;
		return this;
	}

	public CancelReasonList addCancelReasonsItem(Map<String,String> cancelReasonsItem) {
		if (this.cancelReasons == null) {
			this.cancelReasons = new HashMap<>();
		}
		this.cancelReasons.putAll(cancelReasonsItem);
		return this;
	}

	/**
	 * Get cancelReasons
	 * @return cancelReasons
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public Map<String,String>  getCancelReasons() {
		return cancelReasons;
	}

	public void setCancelReasons(Map<String,String> cancelReasons) {
		this.cancelReasons = cancelReasons;
	}


	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		CancelReasonList cancelReasonList = (CancelReasonList) o;
		return Objects.equals(this.cancelReasons, cancelReasonList.cancelReasons);
	}

	@Override
	public int hashCode() {
		return Objects.hash(cancelReasons);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class CancelReasonList {\n");

		sb.append("    cancelReasons: ").append(toIndentedString(cancelReasons)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

}

