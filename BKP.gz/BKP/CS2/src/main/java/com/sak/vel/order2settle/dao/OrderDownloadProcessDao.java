package com.cvs.specialty.ordermaintenance.dao;

import java.math.BigDecimal;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;

public interface OrderDownloadProcessDao {

	ResponseEntity<SbpEntityBpmProcessMap> createProcessInstanceId(BigDecimal preorderId, BigDecimal instanceId);
}
