package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.cvs.specialty.ordermaintenance.model.CurrentOrders;

/**
 * @author Z226695
 *
 */
public interface PatientIdCurrentOrdersService {

	List<CurrentOrders> getCurrentOrders(String patientId) throws DataAccessException;

}
