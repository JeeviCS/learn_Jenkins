package com.cvs.specialty.ordermaintenance.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RouteToQueueResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("targetProcessInstanceId")
	private Long targetProcessInstanceId;

	@JsonProperty("targetTaskType")
	private String targetTaskType;

	@JsonProperty("targetEntityId")
	private Long targetEntityId;

	@JsonProperty("targetEntityType")
	private String targetEntityType;

	@JsonProperty("createBy")
	private String createBy;
	
	@JsonProperty("createDate")
	private String createDate;

	@JsonProperty("updateBy")
	private String updateBy;

	@JsonProperty("updateDate")
	private String updateDate;

	@JsonProperty("serviceName")
	private String serviceName;

	@JsonProperty("targetBpmTaskInstanceId")
	private String targetBpmTaskInstanceId;

	public Long getTargetProcessInstanceId() {
		return targetProcessInstanceId;
	}

	public void setTargetProcessInstanceId(Long targetProcessInstanceId) {
		this.targetProcessInstanceId = targetProcessInstanceId;
	}

	public String getTargetTaskType() {
		return targetTaskType;
	}

	public void setTargetTaskType(String targetTaskType) {
		this.targetTaskType = targetTaskType;
	}

	public Long getTargetEntityId() {
		return targetEntityId;
	}

	public void setTargetEntityId(Long targetEntityId) {
		this.targetEntityId = targetEntityId;
	}

	public String getTargetEntityType() {
		return targetEntityType;
	}

	public void setTargetEntityType(String targetEntityType) {
		this.targetEntityType = targetEntityType;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	public String getTargetBpmTaskInstanceId() {
		return targetBpmTaskInstanceId;
	}

	public void setTargetBpmTaskInstanceId(String targetBpmTaskInstanceId) {
		this.targetBpmTaskInstanceId = targetBpmTaskInstanceId;
	}


}
