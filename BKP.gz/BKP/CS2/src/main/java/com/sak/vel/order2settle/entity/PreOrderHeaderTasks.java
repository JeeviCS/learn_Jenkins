package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the PRE_ORDER_HEADER database table.
 * 
 */
@Entity
@Table(name="PRE_ORDER_HEADER")
@NamedQuery(name="PreOrderHeaderTasks.findAll", query="SELECT p FROM PreOrderHeaderTasks p")
public class PreOrderHeaderTasks implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRE_ORDR_HDR_ID")
	private long preOrdrHdrId;

	@Column(name="ADDR_SEQ_NB")
	private BigDecimal addrSeqNb;

	@Column(name="ARV_ON_BY_CD")
	private String arvOnByCd;

	@Column(name="CMPNY_ID")
	private BigDecimal cmpnyId;

	@Column(name="CNFRM_DLVRY_TO_ADDR_IN")
	private String cnfrmDlvryToAddrIn;

	@Column(name="CRTE_TS")
	private Timestamp crteTs;

	@Column(name="CRTE_USR_NM")
	private String crteUsrNm;

	@Temporal(TemporalType.DATE)
	@Column(name="EXHST_DT")
	private Date exhstDt;

	@Temporal(TemporalType.DATE)
	@Column(name="FLUP_DT")
	private Date flupDt;

	@Column(name="HLTCR_PRFSN_NTFID_IN")
	private String hltcrPrfsnNtfidIn;

	@Column(name="INQ_RSLT_ID")
	private BigDecimal inqRsltId;

	@Temporal(TemporalType.DATE)
	@Column(name="ORDR_RQST_CMPLTN_DT")
	private Date ordrRqstCmpltnDt;

	@Column(name="ORDR_SCHD_ID")
	private String ordrSchdId;

	@Column(name="ORDR_SCHD_PRCS_STUS_ID")
	private BigDecimal ordrSchdPrcsStusId;

	@Column(name="ORDR_STUS_CD")
	private String ordrStusCd;

	@Column(name="ORDR_STUS_RSN_CD")
	private String ordrStusRsnCd;

	@Column(name="PHMCY_ID")
	private BigDecimal phmcyId;

	@Column(name="PTNT_ID")
	private BigDecimal ptntId;

	@Column(name="PTNT_NTFID_IN")
	private String ptntNtfidIn;

	@Column(name="PTNT_SGNTR_RQRD_IN")
	private String ptntSgntrRqrdIn;

	@Column(name="SHPMT_MTHD_CD")
	private String shpmtMthdCd;

	@Column(name="SHPMT_NB")
	private String shpmtNb;

	@Column(name="SRC_ORDR_NB_TX")
	private String srcOrdrNbTx;

	@Column(name="SRC_SYSTM_ID")
	private BigDecimal srcSystmId;

	@Column(name="SRC_SYSTM_NM")
	private String srcSystmNm;

	@Column(name="UPD_TS")
	private Timestamp updTs;

	@Column(name="UPD_USR_NM")
	private String updUsrNm;

	//bi-directional many-to-one association to SbpEntityBpmProcessMap
	@OneToMany(mappedBy="preOrderHeader")
	private List<SbpEntityBpmProcessMap> sbpEntityBpmProcessMaps;


	public PreOrderHeaderTasks() {
	}

	public long getPreOrdrHdrId() {
		return this.preOrdrHdrId;
	}

	public void setPreOrdrHdrId(long preOrdrHdrId) {
		this.preOrdrHdrId = preOrdrHdrId;
	}

	public BigDecimal getAddrSeqNb() {
		return this.addrSeqNb;
	}

	public void setAddrSeqNb(BigDecimal addrSeqNb) {
		this.addrSeqNb = addrSeqNb;
	}

	public String getArvOnByCd() {
		return this.arvOnByCd;
	}

	public void setArvOnByCd(String arvOnByCd) {
		this.arvOnByCd = arvOnByCd;
	}

	public BigDecimal getCmpnyId() {
		return this.cmpnyId;
	}

	public void setCmpnyId(BigDecimal cmpnyId) {
		this.cmpnyId = cmpnyId;
	}

	public String getCnfrmDlvryToAddrIn() {
		return this.cnfrmDlvryToAddrIn;
	}

	public void setCnfrmDlvryToAddrIn(String cnfrmDlvryToAddrIn) {
		this.cnfrmDlvryToAddrIn = cnfrmDlvryToAddrIn;
	}

	public Timestamp getCrteTs() {
		return this.crteTs;
	}

	public void setCrteTs(Timestamp crteTs) {
		this.crteTs = crteTs;
	}

	public String getCrteUsrNm() {
		return this.crteUsrNm;
	}

	public void setCrteUsrNm(String crteUsrNm) {
		this.crteUsrNm = crteUsrNm;
	}

	public Date getExhstDt() {
		return this.exhstDt;
	}

	public void setExhstDt(Date exhstDt) {
		this.exhstDt = exhstDt;
	}

	public Date getFlupDt() {
		return this.flupDt;
	}

	public void setFlupDt(Date flupDt) {
		this.flupDt = flupDt;
	}

	public String getHltcrPrfsnNtfidIn() {
		return this.hltcrPrfsnNtfidIn;
	}

	public void setHltcrPrfsnNtfidIn(String hltcrPrfsnNtfidIn) {
		this.hltcrPrfsnNtfidIn = hltcrPrfsnNtfidIn;
	}

	public BigDecimal getInqRsltId() {
		return this.inqRsltId;
	}

	public void setInqRsltId(BigDecimal inqRsltId) {
		this.inqRsltId = inqRsltId;
	}

	public Date getOrdrRqstCmpltnDt() {
		return this.ordrRqstCmpltnDt;
	}

	public void setOrdrRqstCmpltnDt(Date ordrRqstCmpltnDt) {
		this.ordrRqstCmpltnDt = ordrRqstCmpltnDt;
	}

	public String getOrdrSchdId() {
		return this.ordrSchdId;
	}

	public void setOrdrSchdId(String ordrSchdId) {
		this.ordrSchdId = ordrSchdId;
	}

	public BigDecimal getOrdrSchdPrcsStusId() {
		return this.ordrSchdPrcsStusId;
	}

	public void setOrdrSchdPrcsStusId(BigDecimal ordrSchdPrcsStusId) {
		this.ordrSchdPrcsStusId = ordrSchdPrcsStusId;
	}

	public String getOrdrStusCd() {
		return this.ordrStusCd;
	}

	public void setOrdrStusCd(String ordrStusCd) {
		this.ordrStusCd = ordrStusCd;
	}

	public String getOrdrStusRsnCd() {
		return this.ordrStusRsnCd;
	}

	public void setOrdrStusRsnCd(String ordrStusRsnCd) {
		this.ordrStusRsnCd = ordrStusRsnCd;
	}

	public BigDecimal getPhmcyId() {
		return this.phmcyId;
	}

	public void setPhmcyId(BigDecimal phmcyId) {
		this.phmcyId = phmcyId;
	}

	public BigDecimal getPtntId() {
		return this.ptntId;
	}

	public void setPtntId(BigDecimal ptntId) {
		this.ptntId = ptntId;
	}

	public String getPtntNtfidIn() {
		return this.ptntNtfidIn;
	}

	public void setPtntNtfidIn(String ptntNtfidIn) {
		this.ptntNtfidIn = ptntNtfidIn;
	}

	public String getPtntSgntrRqrdIn() {
		return this.ptntSgntrRqrdIn;
	}

	public void setPtntSgntrRqrdIn(String ptntSgntrRqrdIn) {
		this.ptntSgntrRqrdIn = ptntSgntrRqrdIn;
	}

	public String getShpmtMthdCd() {
		return this.shpmtMthdCd;
	}

	public void setShpmtMthdCd(String shpmtMthdCd) {
		this.shpmtMthdCd = shpmtMthdCd;
	}

	public String getShpmtNb() {
		return this.shpmtNb;
	}

	public void setShpmtNb(String shpmtNb) {
		this.shpmtNb = shpmtNb;
	}

	public String getSrcOrdrNbTx() {
		return this.srcOrdrNbTx;
	}

	public void setSrcOrdrNbTx(String srcOrdrNbTx) {
		this.srcOrdrNbTx = srcOrdrNbTx;
	}

	public BigDecimal getSrcSystmId() {
		return this.srcSystmId;
	}

	public void setSrcSystmId(BigDecimal srcSystmId) {
		this.srcSystmId = srcSystmId;
	}

	public String getSrcSystmNm() {
		return this.srcSystmNm;
	}

	public void setSrcSystmNm(String srcSystmNm) {
		this.srcSystmNm = srcSystmNm;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrNm() {
		return this.updUsrNm;
	}

	public void setUpdUsrNm(String updUsrNm) {
		this.updUsrNm = updUsrNm;
	}

	public List<SbpEntityBpmProcessMap> getSbpEntityBpmProcessMaps() {
		return this.sbpEntityBpmProcessMaps;
	}

	public void setSbpEntityBpmProcessMaps(List<SbpEntityBpmProcessMap> sbpEntityBpmProcessMaps) {
		this.sbpEntityBpmProcessMaps = sbpEntityBpmProcessMaps;
	}

	public SbpEntityBpmProcessMap addSbpEntityBpmProcessMap(SbpEntityBpmProcessMap sbpEntityBpmProcessMap) {
		getSbpEntityBpmProcessMaps().add(sbpEntityBpmProcessMap);
		sbpEntityBpmProcessMap.setPreOrderHeader(this);

		return sbpEntityBpmProcessMap;
	}

	public SbpEntityBpmProcessMap removeSbpEntityBpmProcessMap(SbpEntityBpmProcessMap sbpEntityBpmProcessMap) {
		getSbpEntityBpmProcessMaps().remove(sbpEntityBpmProcessMap);
		sbpEntityBpmProcessMap.setPreOrderHeader(null);

		return sbpEntityBpmProcessMap;
	}

}