
package com.cvs.specialty.ordermaintenance.model;

import java.util.Date;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ShipmentDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-15T16:49:06.821Z")

public class ShipmentDetails {
  @JsonProperty("shipmentNumber")
  private String shipmentNumber = null;

  @JsonProperty("orderDownloadDate")
  private Date orderDownloadDate = null;

  @JsonProperty("orderShippedDate")
  private Date orderShippedDate = null;

  @JsonProperty("orderDownloadUserInitials")
  private String orderDownloadUserInitials = null;

  @JsonProperty("shippedLocation")
  private String shippedLocation = null;

  @JsonProperty("ppsStatus")
  private String ppsStatus = null;

  @JsonProperty("shippingMethodService")
  private String shippingMethodService = null;

  @JsonProperty("orderTrackingNum1")
  private String orderTrackingNum1 = null;

  @JsonProperty("orderTrackingNum2")
  private String orderTrackingNum2 = null;

  @JsonProperty("orderTrackingNum3")
  private String orderTrackingNum3 = null;

  @JsonProperty("packOperator")
  private String packOperator = null;

  @JsonProperty("welcomePackIndicator")
  private String welcomePackIndicator = null;

  @JsonProperty("expansionPackIndicator")
  private String expansionPackIndicator = null;

  @JsonProperty("zipExtensionCode")
  private String zipExtensionCode = null;

  @JsonProperty("cancelReason")
  private String cancelReason = null;

  @JsonProperty("address1")
  private String address1 = null;

  @JsonProperty("address2")
  private String address2 = null;

  @JsonProperty("city")
  private String city = null;

  @JsonProperty("state")
  private String state = null;

  @JsonProperty("zip")
  private String zip = null;

  @JsonProperty("country")
  private String country = null;

  @JsonProperty("storeNum")
  private Long storeNum = null;

  @JsonProperty("phoneNum")
  private String phoneNum = null;

  @JsonProperty("barcodeNum")
  private String barcodeNum = null;

  @JsonProperty("checkInDate")
  private Date checkInDate = null;

  @JsonProperty("pickUpDate")
  private Date pickUpDate = null;

  @JsonProperty("anticipatedDate")
  private Date anticipatedDate = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public ShipmentDetails shipmentNumber(String shipmentNumber) {
    this.shipmentNumber = shipmentNumber;
    return this;
  }

  /**
   * Get shipmentNumber
   * 
   * @return shipmentNumber
   **/
  @ApiModelProperty(value = "")

  public String getShipmentNumber() {
    return shipmentNumber;
  }

  public void setShipmentNumber(String shipmentNumber) {
    this.shipmentNumber = shipmentNumber;
  }

  public ShipmentDetails orderDownloadDate(Date orderDownloadDate) {
    this.orderDownloadDate = orderDownloadDate;
    return this;
  }

  /**
   * Get orderDownloadDate
   * 
   * @return orderDownloadDate
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Date getOrderDownloadDate() {
    return orderDownloadDate;
  }

  public void setOrderDownloadDate(Date orderDownloadDate) {
    this.orderDownloadDate = orderDownloadDate;
  }

  public ShipmentDetails orderShippedDate(Date orderShippedDate) {
    this.orderShippedDate = orderShippedDate;
    return this;
  }

  /**
   * Get orderShippedDate
   * 
   * @return orderShippedDate
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Date getOrderShippedDate() {
    return orderShippedDate;
  }

  public void setOrderShippedDate(Date orderShippedDate) {
    this.orderShippedDate = orderShippedDate;
  }

  public ShipmentDetails orderDownloadUserInitials(String orderDownloadUserInitials) {
    this.orderDownloadUserInitials = orderDownloadUserInitials;
    return this;
  }

  /**
   * Get orderDownloadUserInitials
   * 
   * @return orderDownloadUserInitials
   **/
  @ApiModelProperty(value = "")

  public String getOrderDownloadUserInitials() {
    return orderDownloadUserInitials;
  }

  public void setOrderDownloadUserInitials(String orderDownloadUserInitials) {
    this.orderDownloadUserInitials = orderDownloadUserInitials;
  }

  public ShipmentDetails shippedLocation(String shippedLocation) {
    this.shippedLocation = shippedLocation;
    return this;
  }

  /**
   * Get shippedLocation
   * 
   * @return shippedLocation
   **/
  @ApiModelProperty(value = "")

  public String getShippedLocation() {
    return shippedLocation;
  }

  public void setShippedLocation(String shippedLocation) {
    this.shippedLocation = shippedLocation;
  }

  public ShipmentDetails ppsStatus(String ppsStatus) {
    this.ppsStatus = ppsStatus;
    return this;
  }

  /**
   * Get ppsStatus
   * 
   * @return ppsStatus
   **/
  @ApiModelProperty(value = "")

  public String getPpsStatus() {
    return ppsStatus;
  }

  public void setPpsStatus(String ppsStatus) {
    this.ppsStatus = ppsStatus;
  }

  public ShipmentDetails shippingMethodService(String shippingMethodService) {
    this.shippingMethodService = shippingMethodService;
    return this;
  }

  /**
   * Get shippingMethodService
   * 
   * @return shippingMethodService
   **/
  @ApiModelProperty(value = "")

  public String getShippingMethodService() {
    return shippingMethodService;
  }

  public void setShippingMethodService(String shippingMethodService) {
    this.shippingMethodService = shippingMethodService;
  }

  public ShipmentDetails orderTrackingNum1(String orderTrackingNum1) {
    this.orderTrackingNum1 = orderTrackingNum1;
    return this;
  }

  /**
   * Get orderTrackingNum1
   * 
   * @return orderTrackingNum1
   **/
  @ApiModelProperty(value = "")

  public String getOrderTrackingNum1() {
    return orderTrackingNum1;
  }

  public void setOrderTrackingNum1(String orderTrackingNum1) {
    this.orderTrackingNum1 = orderTrackingNum1;
  }

  public ShipmentDetails orderTrackingNum2(String orderTrackingNum2) {
    this.orderTrackingNum2 = orderTrackingNum2;
    return this;
  }

  /**
   * Get orderTrackingNum2
   * 
   * @return orderTrackingNum2
   **/
  @ApiModelProperty(value = "")

  public String getOrderTrackingNum2() {
    return orderTrackingNum2;
  }

  public void setOrderTrackingNum2(String orderTrackingNum2) {
    this.orderTrackingNum2 = orderTrackingNum2;
  }

  public ShipmentDetails orderTrackingNum3(String orderTrackingNum3) {
    this.orderTrackingNum3 = orderTrackingNum3;
    return this;
  }

  /**
   * Get orderTrackingNum3
   * 
   * @return orderTrackingNum3
   **/
  @ApiModelProperty(value = "")

  public String getOrderTrackingNum3() {
    return orderTrackingNum3;
  }

  public void setOrderTrackingNum3(String orderTrackingNum3) {
    this.orderTrackingNum3 = orderTrackingNum3;
  }

  public ShipmentDetails packOperator(String packOperator) {
    this.packOperator = packOperator;
    return this;
  }

  /**
   * Get packOperator
   * 
   * @return packOperator
   **/
  @ApiModelProperty(value = "")

  public String getPackOperator() {
    return packOperator;
  }

  public void setPackOperator(String packOperator) {
    this.packOperator = packOperator;
  }

  public ShipmentDetails welcomePackIndicator(String welcomePackIndicator) {
    this.welcomePackIndicator = welcomePackIndicator;
    return this;
  }

  /**
   * Get welcomePackIndicator
   * 
   * @return welcomePackIndicator
   **/
  @ApiModelProperty(value = "")

  public String getWelcomePackIndicator() {
    return welcomePackIndicator;
  }

  public void setWelcomePackIndicator(String welcomePackIndicator) {
    this.welcomePackIndicator = welcomePackIndicator;
  }

  public ShipmentDetails expansionPackIndicator(String expansionPackIndicator) {
    this.expansionPackIndicator = expansionPackIndicator;
    return this;
  }

  /**
   * Get expansionPackIndicator
   * 
   * @return expansionPackIndicator
   **/
  @ApiModelProperty(value = "")

  public String getExpansionPackIndicator() {
    return expansionPackIndicator;
  }

  public void setExpansionPackIndicator(String expansionPackIndicator) {
    this.expansionPackIndicator = expansionPackIndicator;
  }

  public ShipmentDetails zipExtensionCode(String zipExtensionCode) {
    this.zipExtensionCode = zipExtensionCode;
    return this;
  }

  /**
   * Get zipExtensionCode
   * 
   * @return zipExtensionCode
   **/
  @ApiModelProperty(value = "")

  public String getZipExtensionCode() {
    return zipExtensionCode;
  }

  public void setZipExtensionCode(String zipExtensionCode) {
    this.zipExtensionCode = zipExtensionCode;
  }

  public ShipmentDetails cancelReason(String cancelReason) {
    this.cancelReason = cancelReason;
    return this;
  }

  /**
   * Get cancelReason
   * 
   * @return cancelReason
   **/
  @ApiModelProperty(value = "")

  public String getCancelReason() {
    return cancelReason;
  }

  public void setCancelReason(String cancelReason) {
    this.cancelReason = cancelReason;
  }

  public ShipmentDetails address1(String address1) {
    this.address1 = address1;
    return this;
  }

  /**
   * Get address1
   * 
   * @return address1
   **/
  @ApiModelProperty(value = "")

  public String getAddress1() {
    return address1;
  }

  public void setAddress1(String address1) {
    this.address1 = address1;
  }

  public ShipmentDetails address2(String address2) {
    this.address2 = address2;
    return this;
  }

  /**
   * Get address2
   * 
   * @return address2
   **/
  @ApiModelProperty(value = "")

  public String getAddress2() {
    return address2;
  }

  public void setAddress2(String address2) {
    this.address2 = address2;
  }

  public ShipmentDetails city(String city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * 
   * @return city
   **/
  @ApiModelProperty(value = "")

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public ShipmentDetails state(String state) {
    this.state = state;
    return this;
  }

  /**
   * Get state
   * 
   * @return state
   **/
  @ApiModelProperty(value = "")

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public ShipmentDetails zip(String zip) {
    this.zip = zip;
    return this;
  }

  /**
   * Get zip
   * 
   * @return zip
   **/
  @ApiModelProperty(value = "")

  public String getZip() {
    return zip;
  }

  public void setZip(String zip) {
    this.zip = zip;
  }

  public ShipmentDetails country(String country) {
    this.country = country;
    return this;
  }

  /**
   * Get country
   * 
   * @return country
   **/
  @ApiModelProperty(value = "")

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public ShipmentDetails storeNum(Long storeNum) {
    this.storeNum = storeNum;
    return this;
  }

  /**
   * Get storeNum
   * 
   * @return storeNum
   **/
  @ApiModelProperty(value = "")

  public Long getStoreNum() {
    return storeNum;
  }

  public void setStoreNum(Long storeNum) {
    this.storeNum = storeNum;
  }

  public ShipmentDetails phoneNum(String phoneNum) {
    this.phoneNum = phoneNum;
    return this;
  }

  /**
   * Get phoneNum
   * 
   * @return phoneNum
   **/
  @ApiModelProperty(value = "")

  public String getPhoneNum() {
    return phoneNum;
  }

  public void setPhoneNum(String phoneNum) {
    this.phoneNum = phoneNum;
  }

  public ShipmentDetails barcodeNum(String barcodeNum) {
    this.barcodeNum = barcodeNum;
    return this;
  }

  /**
   * Get barcodeNum
   * 
   * @return barcodeNum
   **/
  @ApiModelProperty(value = "")

  public String getBarcodeNum() {
    return barcodeNum;
  }

  public void setBarcodeNum(String barcodeNum) {
    this.barcodeNum = barcodeNum;
  }

  public ShipmentDetails checkInDate(Date checkInDate) {
    this.checkInDate = checkInDate;
    return this;
  }

  /**
   * Get checkInDate
   * 
   * @return checkInDate
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Date getCheckInDate() {
    return checkInDate;
  }

  public void setCheckInDate(Date checkInDate) {
    this.checkInDate = checkInDate;
  }

  public ShipmentDetails pickUpDate(Date pickUpDate) {
    this.pickUpDate = pickUpDate;
    return this;
  }

  /**
   * Get pickUpDate
   * 
   * @return pickUpDate
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Date getPickUpDate() {
    return pickUpDate;
  }

  public void setPickUpDate(Date pickUpDate) {
    this.pickUpDate = pickUpDate;
  }

  public ShipmentDetails anticipatedDate(Date anticipatedDate) {
    this.anticipatedDate = anticipatedDate;
    return this;
  }

  /**
   * Get anticipatedDate
   * 
   * @return anticipatedDate
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Date getAnticipatedDate() {
    return anticipatedDate;
  }

  public void setAnticipatedDate(Date anticipatedDate) {
    this.anticipatedDate = anticipatedDate;
  }

  public ShipmentDetails audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShipmentDetails shipmentDetails = (ShipmentDetails) o;
    return Objects.equals(this.shipmentNumber, shipmentDetails.shipmentNumber)
        && Objects.equals(this.orderDownloadDate, shipmentDetails.orderDownloadDate)
        && Objects.equals(this.orderShippedDate, shipmentDetails.orderShippedDate)
        && Objects.equals(this.orderDownloadUserInitials, shipmentDetails.orderDownloadUserInitials)
        && Objects.equals(this.shippedLocation, shipmentDetails.shippedLocation)
        && Objects.equals(this.ppsStatus, shipmentDetails.ppsStatus)
        && Objects.equals(this.shippingMethodService, shipmentDetails.shippingMethodService)
        && Objects.equals(this.orderTrackingNum1, shipmentDetails.orderTrackingNum1)
        && Objects.equals(this.orderTrackingNum2, shipmentDetails.orderTrackingNum2)
        && Objects.equals(this.orderTrackingNum3, shipmentDetails.orderTrackingNum3)
        && Objects.equals(this.packOperator, shipmentDetails.packOperator)
        && Objects.equals(this.welcomePackIndicator, shipmentDetails.welcomePackIndicator)
        && Objects.equals(this.expansionPackIndicator, shipmentDetails.expansionPackIndicator)
        && Objects.equals(this.zipExtensionCode, shipmentDetails.zipExtensionCode)
        && Objects.equals(this.cancelReason, shipmentDetails.cancelReason)
        && Objects.equals(this.address1, shipmentDetails.address1)
        && Objects.equals(this.address2, shipmentDetails.address2)
        && Objects.equals(this.city, shipmentDetails.city)
        && Objects.equals(this.state, shipmentDetails.state)
        && Objects.equals(this.zip, shipmentDetails.zip)
        && Objects.equals(this.country, shipmentDetails.country)
        && Objects.equals(this.storeNum, shipmentDetails.storeNum)
        && Objects.equals(this.phoneNum, shipmentDetails.phoneNum)
        && Objects.equals(this.barcodeNum, shipmentDetails.barcodeNum)
        && Objects.equals(this.checkInDate, shipmentDetails.checkInDate)
        && Objects.equals(this.pickUpDate, shipmentDetails.pickUpDate)
        && Objects.equals(this.anticipatedDate, shipmentDetails.anticipatedDate)
        && Objects.equals(this.audit, shipmentDetails.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      shipmentNumber,
      orderDownloadDate,
      orderShippedDate,
      orderDownloadUserInitials,
      shippedLocation,
      ppsStatus,
      shippingMethodService,
      orderTrackingNum1,
      orderTrackingNum2,
      orderTrackingNum3,
      packOperator,
      welcomePackIndicator,
      expansionPackIndicator,
      zipExtensionCode,
      cancelReason,
      address1,
      address2,
      city,
      state,
      zip,
      country,
      storeNum,
      phoneNum,
      barcodeNum,
      checkInDate,
      pickUpDate,
      anticipatedDate,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShipmentDetails {\n");

    sb.append("    shipmentNumber: ").append(toIndentedString(shipmentNumber)).append("\n");
    sb.append("    orderDownloadDate: ").append(toIndentedString(orderDownloadDate)).append("\n");
    sb.append("    orderShippedDate: ").append(toIndentedString(orderShippedDate)).append("\n");
    sb
      .append("    orderDownloadUserInitials: ")
      .append(toIndentedString(orderDownloadUserInitials))
      .append("\n");
    sb.append("    shippedLocation: ").append(toIndentedString(shippedLocation)).append("\n");
    sb.append("    ppsStatus: ").append(toIndentedString(ppsStatus)).append("\n");
    sb.append("    shippingMethodService: ").append(toIndentedString(shippingMethodService)).append(
      "\n");
    sb.append("    orderTrackingNum1: ").append(toIndentedString(orderTrackingNum1)).append("\n");
    sb.append("    orderTrackingNum2: ").append(toIndentedString(orderTrackingNum2)).append("\n");
    sb.append("    orderTrackingNum3: ").append(toIndentedString(orderTrackingNum3)).append("\n");
    sb.append("    packOperator: ").append(toIndentedString(packOperator)).append("\n");
    sb.append("    welcomePackIndicator: ").append(toIndentedString(welcomePackIndicator)).append(
      "\n");
    sb
      .append("    expansionPackIndicator: ")
      .append(toIndentedString(expansionPackIndicator))
      .append("\n");
    sb.append("    zipExtensionCode: ").append(toIndentedString(zipExtensionCode)).append("\n");
    sb.append("    cancelReason: ").append(toIndentedString(cancelReason)).append("\n");
    sb.append("    address1: ").append(toIndentedString(address1)).append("\n");
    sb.append("    address2: ").append(toIndentedString(address2)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    zip: ").append(toIndentedString(zip)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    storeNum: ").append(toIndentedString(storeNum)).append("\n");
    sb.append("    phoneNum: ").append(toIndentedString(phoneNum)).append("\n");
    sb.append("    barcodeNum: ").append(toIndentedString(barcodeNum)).append("\n");
    sb.append("    checkInDate: ").append(toIndentedString(checkInDate)).append("\n");
    sb.append("    pickUpDate: ").append(toIndentedString(pickUpDate)).append("\n");
    sb.append("    anticipatedDate: ").append(toIndentedString(anticipatedDate)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
