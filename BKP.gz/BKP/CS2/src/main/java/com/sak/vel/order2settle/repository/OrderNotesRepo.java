
package com.cvs.specialty.ordermaintenance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.entity.PreOrderNote;

@Repository
@Transactional
public interface OrderNotesRepo extends JpaRepository<PreOrderNote, Long> {

  List<PreOrderNote> findByPreOrderHeader(PreOrderHeader preOrderHeaderID);

  PreOrderNote findByCrteUsrNm(String name);

  // PreOrderNote findByIntakeRfrlIdAndDocNm(BigDecimal intakeId, String docNm);

}
