package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.CurrentOrders;

/**
 * 
 */

public interface PatientIdCurrentOrdersDAO {

	 List<CurrentOrders> getCurrentOrderDetails(long patientId);
}
