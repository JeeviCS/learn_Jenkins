
package com.cvs.specialty.ordermaintenance.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderDownloadEngineDao;
import com.cvs.specialty.ordermaintenance.model.OrderDownloadEngine;
import com.cvs.specialty.ordermaintenance.rabbitMq.consumer.OrderMaintenanceConsumer;
import com.cvs.specialty.ordermaintenance.rabbitMq.producer.RabbitMQSender;/*
import com.cvs.specialty.ordermaintenance.rabbitMq.producer.RabbitMqChannel;*/
import com.cvs.specialty.ordermaintenance.service.OrderDownloadEngineService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class OrderDownloadEngineServiceImpl implements OrderDownloadEngineService {

	@Autowired
	OrderDownloadEngineDao orderDownloadEngine;
	@Autowired
	RabbitMQSender rabbitMQSender;
	@Autowired
	OrderMaintenanceConsumer orderMaintenanceConsumer;

	@Autowired
	SpecialtyLogger LOGGER;

	/*@Autowired
	RabbitMqChannel mqChannel;*/

	//private static ObjectMapper objectMapper = new ObjectMapper();
	
	@Override
	public ResponseEntity<OrderDownloadEngine> getPatientShippingInfo(long preOrderId, long patientID) {
		// TODO Auto-generated method stub
		LOGGER.info(LogMsgConstants.METHOD_ENTRY);
		ResponseEntity<OrderDownloadEngine> response = null;
		try {
			OrderDownloadEngine orderDownloadEngineModel = orderDownloadEngine.getPatientShippingInfo(preOrderId, patientID);

			rabbitMQSender.sendToOrderDownloadEngine(orderDownloadEngineModel);

			System.out.println("service is hit with \n" + orderDownloadEngineModel);

			if (orderDownloadEngineModel != null) {

				response = new ResponseEntity<>(orderDownloadEngineModel, HttpStatus.OK);
			}
			LOGGER.info(LogMsgConstants.METHOD_EXIT);
			return response;
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			return new ResponseEntity<OrderDownloadEngine>(HttpStatus.BAD_REQUEST);
		}

		/*try {
			mqChannel.producer()
					.send(MessageBuilder.withPayload(objectMapper.writeValueAsString(orderDownloadEngineModel))
							.setHeader("access-token", headers.getAccessToken()).build());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block e.printStackTrace();
		}*/

	}
}
