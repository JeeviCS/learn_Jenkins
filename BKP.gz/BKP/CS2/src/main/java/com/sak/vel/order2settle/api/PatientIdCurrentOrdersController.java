
package com.cvs.specialty.ordermaintenance.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.ResourceAccessException;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.CurrentOrders;
import com.cvs.specialty.ordermaintenance.service.PatientIdCurrentOrdersService;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-05T09:07:57.039Z")

@RestController
@RequestMapping("/")
public class PatientIdCurrentOrdersController implements PatientIdCurrentOrdersApi {

  @Autowired
  PatientIdCurrentOrdersService patientIdCurrentOrdersService;

  @Autowired
  SpecialtyLogger LOGGER;

  public ResponseEntity<List<CurrentOrders>> patientIdCurrentOrdersGet(
      @ApiParam(value = "Logged in user Id", required = true) @RequestHeader(value = "user-id", required = true) String userId,
      @ApiParam(value = "Unique identifier for this request.", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access token for this request", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @ApiParam(value = "patient ID", required = true) @PathVariable("patientId") String patientId,
      @ApiParam(value = "Unique identifier for this request.") @RequestHeader(value = "service-id", required = false) String serviceId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    List<CurrentOrders> currentOrdersList = null;
    try {
      currentOrdersList = patientIdCurrentOrdersService.getCurrentOrders(patientId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<List<CurrentOrders>>(currentOrdersList, HttpStatus.OK);
    } catch (ResourceAccessException rae) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, rae);
      return new ResponseEntity<List<CurrentOrders>>(HttpStatus.BAD_REQUEST);
    }

  }

}
