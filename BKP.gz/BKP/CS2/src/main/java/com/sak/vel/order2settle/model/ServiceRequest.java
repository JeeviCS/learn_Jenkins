package com.cvs.specialty.ordermaintenance.model;

public class ServiceRequest<T> {
	
	String serviceId;
	String messageId;	

	String userId;

	T body;
	/**
	 * @return the serviceId
	 */
	public String getServiceId() {
		return serviceId;
	}
	/**
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	/**
	 * @return the messageId
	 */
	public String getMessageId() {
		return messageId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
	/**
	 * @return the body
	 */
	public T getBody() {
		return body;
	}
	/**
	 * @param body the body to set
	 */
	public void setBody(T body) {
		this.body = body;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

		
		
}
