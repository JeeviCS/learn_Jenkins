
package com.cvs.specialty.ordermaintenance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;

@Repository
@Transactional
public interface PreOrderHeaderRepo<T, ID> extends JpaRepository<PreOrderHeader, Long> {

	PreOrderHeader findByPreOrdrHdrId(long preOrderNoteId);

	// PreOrderNote findByCrteUsrNm(String name);

	// PreOrderNote findByIntakeRfrlIdAndDocNm(BigDecimal intakeId, String docNm);

	// shipping details

	@Modifying
	@Query("update PreOrderHeader preOrdHdr set preOrdHdr.arvOnByCd = :arvOnByCd,preOrdHdr.ptntSgntrRqrdIn = :ptntSgntrRqrdIn,"
			+ " preOrdHdr.cnfrmDlvryToAddrIn = :cnfrmDlvryToAddrIn, preOrdHdr.shpmtMthdCd = :shpmtMthdCd "
			+ " where preOrdHdr.preOrdrHdrId = :preOrdrHdrId")
	Integer updateShippingDetailforPreOrd(@Param("arvOnByCd") String arvOnByCd,
			@Param("ptntSgntrRqrdIn") String ptntSgntrRqrdIn, @Param("cnfrmDlvryToAddrIn") String cnfrmDlvryToAddrIn,
			@Param("shpmtMthdCd") String shpmtMthdCd, @Param("preOrdrHdrId") long preOrdrHdrId);

	@Query("SELECT p.ptntId, p.ordrStusCd, p.ordrStusRsnCd FROM PreOrderHeader p WHERE p.preOrdrHdrId = :preOrdrHdrId ")
	Object findordersatcode(@Param("preOrdrHdrId") long preOrdrHdrId);

	/*@Query("select PreOrderHeader.arvOnByCd , PreOrderHeader.ordrRqstCmpltnDt, PatientAddressEO.ADDRESS_1,PatientAddressEO.ADDRESS_2,PatientAddressEO.CITY,PatientAddressEO.DIRECTIONS,PatientAddressEO.ZIP_1 , PatientAddressEO.ZIP_2, "
			+ "PatientAddressEO.STATE,NVL(PatientAddressEO.DAY_PHONE_NUMBER, PatientAddressEO.EVE_PHONE_NUMBER),PreOrderHeader.SHPMT_MTHD_CD,PreOrderHeader.PTNT_SGNTR_RQRD_IN"
			+ "from PreOrderHeader,PatientAddressEO "
			+ "where PreOrderHeader.PatientAddressEO_ID = PatientAddressEO.PatientAddressEO_ID"
			+ "and PreOrderHeader.PRE_ORDR_HDR_ID = 2")
	Object findPatientShippingInfo(@Param("preOrdrHdrId") long preOrdrHdrId);*/
	
	@Modifying
	@Query("UPDATE PreOrderHeader preOrdHdr SET preOrdHdr.ordrStusCd = 'D' where preOrdHdr.preOrdrHdrId = :preOrdrHdrId")
	void updateOrderStatus(@Param("preOrdrHdrId") long preOrdrHdrId);
	

}
