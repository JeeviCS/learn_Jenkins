
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Prescriber
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class Prescriber {
  @JsonProperty("prescriberIdentifier")
  private String prescriberIdentifier = null;

  @JsonProperty("systemSourceprescriberIdentifier")
  private String systemSourceprescriberIdentifier = null;

  @JsonProperty("prescriberType")
  private String prescriberType = null;

  @JsonProperty("prescriberCategoryCode")
  private String prescriberCategoryCode = null;

  @JsonProperty("prescriberFirstName")
  private String prescriberFirstName = null;

  @JsonProperty("prescriberLastName")
  private String prescriberLastName = null;

  @JsonProperty("prescriberNationalProviderIdentifier")
  private String prescriberNationalProviderIdentifier = null;

  @JsonProperty("prescriberLicenseNumber")
  private String prescriberLicenseNumber = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public Prescriber prescriberIdentifier(String prescriberIdentifier) {
    this.prescriberIdentifier = prescriberIdentifier;
    return this;
  }

  /**
   * Get prescriberIdentifier
   * 
   * @return prescriberIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberIdentifier() {
    return prescriberIdentifier;
  }

  public void setPrescriberIdentifier(String prescriberIdentifier) {
    this.prescriberIdentifier = prescriberIdentifier;
  }

  public Prescriber systemSourceprescriberIdentifier(String systemSourceprescriberIdentifier) {
    this.systemSourceprescriberIdentifier = systemSourceprescriberIdentifier;
    return this;
  }

  /**
   * Get systemSourceprescriberIdentifier
   * 
   * @return systemSourceprescriberIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSystemSourceprescriberIdentifier() {
    return systemSourceprescriberIdentifier;
  }

  public void setSystemSourceprescriberIdentifier(String systemSourceprescriberIdentifier) {
    this.systemSourceprescriberIdentifier = systemSourceprescriberIdentifier;
  }

  public Prescriber prescriberType(String prescriberType) {
    this.prescriberType = prescriberType;
    return this;
  }

  /**
   * Get prescriberType
   * 
   * @return prescriberType
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberType() {
    return prescriberType;
  }

  public void setPrescriberType(String prescriberType) {
    this.prescriberType = prescriberType;
  }

  public Prescriber prescriberCategoryCode(String prescriberCategoryCode) {
    this.prescriberCategoryCode = prescriberCategoryCode;
    return this;
  }

  /**
   * Get prescriberCategoryCode
   * 
   * @return prescriberCategoryCode
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberCategoryCode() {
    return prescriberCategoryCode;
  }

  public void setPrescriberCategoryCode(String prescriberCategoryCode) {
    this.prescriberCategoryCode = prescriberCategoryCode;
  }

  public Prescriber prescriberFirstName(String prescriberFirstName) {
    this.prescriberFirstName = prescriberFirstName;
    return this;
  }

  /**
   * Get prescriberFirstName
   * 
   * @return prescriberFirstName
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberFirstName() {
    return prescriberFirstName;
  }

  public void setPrescriberFirstName(String prescriberFirstName) {
    this.prescriberFirstName = prescriberFirstName;
  }

  public Prescriber prescriberLastName(String prescriberLastName) {
    this.prescriberLastName = prescriberLastName;
    return this;
  }

  /**
   * Get prescriberLastName
   * 
   * @return prescriberLastName
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberLastName() {
    return prescriberLastName;
  }

  public void setPrescriberLastName(String prescriberLastName) {
    this.prescriberLastName = prescriberLastName;
  }

  public Prescriber prescriberNationalProviderIdentifier(
      String prescriberNationalProviderIdentifier) {
    this.prescriberNationalProviderIdentifier = prescriberNationalProviderIdentifier;
    return this;
  }

  /**
   * Get prescriberNationalProviderIdentifier
   * 
   * @return prescriberNationalProviderIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberNationalProviderIdentifier() {
    return prescriberNationalProviderIdentifier;
  }

  public void setPrescriberNationalProviderIdentifier(String prescriberNationalProviderIdentifier) {
    this.prescriberNationalProviderIdentifier = prescriberNationalProviderIdentifier;
  }

  public Prescriber prescriberLicenseNumber(String prescriberLicenseNumber) {
    this.prescriberLicenseNumber = prescriberLicenseNumber;
    return this;
  }

  /**
   * Get prescriberLicenseNumber
   * 
   * @return prescriberLicenseNumber
   **/
  @ApiModelProperty(value = "")

  public String getPrescriberLicenseNumber() {
    return prescriberLicenseNumber;
  }

  public void setPrescriberLicenseNumber(String prescriberLicenseNumber) {
    this.prescriberLicenseNumber = prescriberLicenseNumber;
  }

  public Prescriber activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public Prescriber audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Prescriber prescriber = (Prescriber) o;
    return Objects.equals(this.prescriberIdentifier, prescriber.prescriberIdentifier) && Objects
      .equals(this.systemSourceprescriberIdentifier, prescriber.systemSourceprescriberIdentifier)
        && Objects.equals(this.prescriberType, prescriber.prescriberType)
        && Objects.equals(this.prescriberCategoryCode, prescriber.prescriberCategoryCode)
        && Objects.equals(this.prescriberFirstName, prescriber.prescriberFirstName)
        && Objects.equals(this.prescriberLastName, prescriber.prescriberLastName)
        && Objects.equals(
          this.prescriberNationalProviderIdentifier,
          prescriber.prescriberNationalProviderIdentifier)
        && Objects.equals(this.prescriberLicenseNumber, prescriber.prescriberLicenseNumber)
        && Objects.equals(this.activeIndicator, prescriber.activeIndicator)
        && Objects.equals(this.audit, prescriber.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      prescriberIdentifier,
      systemSourceprescriberIdentifier,
      prescriberType,
      prescriberCategoryCode,
      prescriberFirstName,
      prescriberLastName,
      prescriberNationalProviderIdentifier,
      prescriberLicenseNumber,
      activeIndicator,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Prescriber {\n");

    sb.append("    prescriberIdentifier: ").append(toIndentedString(prescriberIdentifier)).append(
      "\n");
    sb
      .append("    systemSourceprescriberIdentifier: ")
      .append(toIndentedString(systemSourceprescriberIdentifier))
      .append("\n");
    sb.append("    prescriberType: ").append(toIndentedString(prescriberType)).append("\n");
    sb
      .append("    prescriberCategoryCode: ")
      .append(toIndentedString(prescriberCategoryCode))
      .append("\n");
    sb.append("    prescriberFirstName: ").append(toIndentedString(prescriberFirstName)).append(
      "\n");
    sb.append("    prescriberLastName: ").append(toIndentedString(prescriberLastName)).append("\n");
    sb
      .append("    prescriberNationalProviderIdentifier: ")
      .append(toIndentedString(prescriberNationalProviderIdentifier))
      .append("\n");
    sb
      .append("    prescriberLicenseNumber: ")
      .append(toIndentedString(prescriberLicenseNumber))
      .append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
