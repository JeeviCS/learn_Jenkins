
package com.cvs.specialty.ordermaintenance.api;

@SuppressWarnings("serial")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class ApiException extends Exception {
  @SuppressWarnings("unused")
  private int code;

  public ApiException(int code, String msg) {
    super(msg);
    this.code = code;
  }
}
