package com.cvs.specialty.ordermaintenance.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ListofTasks
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-22T12:32:09.067Z")

public class ListofTasks   {
	@JsonProperty("taskList")
	private List<TaskLists> taskList = null;

	public ListofTasks taskList(List<TaskLists> taskList) {
		this.taskList = taskList;
		return this;
	}

	public ListofTasks addTaskListItem(TaskLists taskListItem) {
		if (this.taskList == null) {
			this.taskList = new ArrayList<TaskLists>();
		}
		this.taskList.add(taskListItem);
		return this;
	}

	/**
	 * Get taskList
	 * @return taskList
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<TaskLists> getTaskList() {
		return taskList;
	}

	public void setTaskList(List<TaskLists> taskList) {
		this.taskList = taskList;
	}


	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ListofTasks listofTasks = (ListofTasks) o;
		return Objects.equals(this.taskList, listofTasks.taskList);
	}

	@Override
	public int hashCode() {
		return Objects.hash(taskList);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class ListofTasks {\n");

		sb.append("    taskList: ").append(toIndentedString(taskList)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}

