package com.cvs.specialty.ordermaintenance.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.ordermaintenance.model.RxDetailsList;

public interface RemoveRxService {
	
	

	ResponseEntity<Void> removeRx(Integer preOrderId, List<RxDetailsList> removeRxList);
}
