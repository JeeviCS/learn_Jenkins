package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ITEMS database table.
 * 
 */
@Entity
@Table(name="ITEMS")
@NamedQuery(name="ItemEO.findAll", query="SELECT i FROM ItemEO i")
public class ItemEO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ITEM_ID")
	private long itemId;

	@Column(name="ACQUISITION_AMT")
	private BigDecimal acquisitionAmt;

	@Column(name="ACTIVE_IND")
	private String activeInd;

	@Column(name="ALLOW_FORCE_IN_PREBILL_IND")
	private String allowForceInPrebillInd;

	@Column(name="CATEGORY_CODE")
	private String categoryCode;

	@Column(name="COMPENSIBILITY_GROUP")
	private String compensibilityGroup;

	@Column(name="COMPOUND_DOSAGE_FORM_DESCR_CD")
	private String compoundDosageFormDescrCd;

	@Column(name="COMPOUND_FEE")
	private BigDecimal compoundFee;

	@Column(name="COMPOUND_IND")
	private String compoundInd;

	@Column(name="COMPOUND_PRINT_LABEL_IND")
	private String compoundPrintLabelInd;

	@Column(name="COMPOUND_TXT")
	private String compoundTxt;

	@Column(name="CREATE_BY")
	private String createBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_DT")
	private Date createDt;

	@Column(name="DEFAULT_PLACE_OF_SERVICE_ID")
	private BigDecimal defaultPlaceOfServiceId;

	@Column(name="DIGITAL_DRUG_EXCLUDE_IND")
	private String digitalDrugExcludeInd;

	@Column(name="DISABLE_BYPASS_IND")
	private String disableBypassInd;

	@Column(name="DRUG_CATEGORY")
	private String drugCategory;

	@Column(name="DRUG_MATCH_IND")
	private String drugMatchInd;

	@Column(name="EXPRESS_REFILL_EXCLUDE_IND")
	private String expressRefillExcludeInd;

	@Column(name="FORM_EXCEPTION_IND")
	private String formExceptionInd;

	@Column(name="FORM_TXT")
	private String formTxt;

	@Column(name="FROZEN_MEDISPAN_AWP_AMT")
	private BigDecimal frozenMedispanAwpAmt;

	@Column(name="GENERIC_IND")
	private String genericInd;

	@Column(name="GENERIC_LINK")
	private String genericLink;

	@Column(name="GPI_CODE")
	private String gpiCode;

	@Column(name="GPI_EXT_CD")
	private String gpiExtCd;

	@Column(name="GPI_THERAPY_CD")
	private String gpiTherapyCd;

	@Column(name="ITEM_CATEGORY_ID")
	private BigDecimal itemCategoryId;

	@Column(name="ITEM_NAME")
	private String itemName;

	@Column(name="ITEM_SRC_CD")
	private String itemSrcCd;

	@Column(name="ITEM_TYPE_CD")
	private String itemTypeCd;

	@Column(name="KNOWLEDGE_DRUG_CODE")
	private String knowledgeDrugCode;

	@Column(name="MANUFACTURER_ID")
	private BigDecimal manufacturerId;

	@Column(name="MEDISPAN_MARKUP_FACTOR")
	private BigDecimal medispanMarkupFactor;

	@Column(name="METRIC_QTY")
	private BigDecimal metricQty;

	@Column(name="MULTI_SOURCE_CODE")
	private String multiSourceCode;

	@Column(name="NARC_CD")
	private String narcCd;

	@Column(name="NDC_2_NO")
	private String ndc2No;

	@Column(name="NDC_4_NO")
	private String ndc4No;

	@Column(name="NDC_5_NO")
	private String ndc5No;

	@Column(name="NDC_NUMBER")
	private String ndcNumber;

	@Column(name="PRINT_MG_IND")
	private String printMgInd;

	@Column(name="PROCEDURE_CD")
	private String procedureCd;

	@Column(name="QTY_CONV_IND")
	private String qtyConvInd;

	@Column(name="REASON_CODE")
	private String reasonCode;

	@Column(name="REFRIG_IND")
	private String refrigInd;

	@Column(name="ROUTE_OF_ADMIN")
	private String routeOfAdmin;

	@Column(name="SIG_DEF")
	private String sigDef;

	@Column(name="SIG_IND")
	private String sigInd;

	@Column(name="SIG_PERFECTION_IND")
	private String sigPerfectionInd;

	@Column(name="SIGNATURE_REQUIRED")
	private String signatureRequired;

	@Column(name="SPCL_PRICE_AMT")
	private BigDecimal spclPriceAmt;

	@Temporal(TemporalType.DATE)
	@Column(name="SRC_DELETE_DT")
	private Date srcDeleteDt;

	@Column(name="STRENGTH_TXT")
	private String strengthTxt;

	@Column(name="SYSTEM_SRC_CD")
	private String systemSrcCd;

	@Column(name="UNIT_PKG_CD")
	private String unitPkgCd;

	@Column(name="UNITS_QTY")
	private BigDecimal unitsQty;

	@Column(name="UPC_CD")
	private String upcCd;

	@Column(name="UPDATE_BY")
	private String updateBy;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATE_DT")
	private Date updateDt;

	//bi-directional many-to-one association to PrescriptionDispens
	@OneToMany(mappedBy="item",fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<PrescriptionDispensesEO> prescriptionDispenses;

	//bi-directional many-to-one association to PreOrderDetail
	@OneToMany(mappedBy="item",fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<PreOrderDetailEO> preOrderDetails;

	public ItemEO() {
	}

	public long getItemId() {
		return this.itemId;
	}

	public void setItemId(long itemId) {
		this.itemId = itemId;
	}

	public BigDecimal getAcquisitionAmt() {
		return this.acquisitionAmt;
	}

	public void setAcquisitionAmt(BigDecimal acquisitionAmt) {
		this.acquisitionAmt = acquisitionAmt;
	}

	public String getActiveInd() {
		return this.activeInd;
	}

	public void setActiveInd(String activeInd) {
		this.activeInd = activeInd;
	}

	public String getAllowForceInPrebillInd() {
		return this.allowForceInPrebillInd;
	}

	public void setAllowForceInPrebillInd(String allowForceInPrebillInd) {
		this.allowForceInPrebillInd = allowForceInPrebillInd;
	}

	public String getCategoryCode() {
		return this.categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCompensibilityGroup() {
		return this.compensibilityGroup;
	}

	public void setCompensibilityGroup(String compensibilityGroup) {
		this.compensibilityGroup = compensibilityGroup;
	}

	public String getCompoundDosageFormDescrCd() {
		return this.compoundDosageFormDescrCd;
	}

	public void setCompoundDosageFormDescrCd(String compoundDosageFormDescrCd) {
		this.compoundDosageFormDescrCd = compoundDosageFormDescrCd;
	}

	public BigDecimal getCompoundFee() {
		return this.compoundFee;
	}

	public void setCompoundFee(BigDecimal compoundFee) {
		this.compoundFee = compoundFee;
	}

	public String getCompoundInd() {
		return this.compoundInd;
	}

	public void setCompoundInd(String compoundInd) {
		this.compoundInd = compoundInd;
	}

	public String getCompoundPrintLabelInd() {
		return this.compoundPrintLabelInd;
	}

	public void setCompoundPrintLabelInd(String compoundPrintLabelInd) {
		this.compoundPrintLabelInd = compoundPrintLabelInd;
	}

	public String getCompoundTxt() {
		return this.compoundTxt;
	}

	public void setCompoundTxt(String compoundTxt) {
		this.compoundTxt = compoundTxt;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDt() {
		return this.createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public BigDecimal getDefaultPlaceOfServiceId() {
		return this.defaultPlaceOfServiceId;
	}

	public void setDefaultPlaceOfServiceId(BigDecimal defaultPlaceOfServiceId) {
		this.defaultPlaceOfServiceId = defaultPlaceOfServiceId;
	}

	public String getDigitalDrugExcludeInd() {
		return this.digitalDrugExcludeInd;
	}

	public void setDigitalDrugExcludeInd(String digitalDrugExcludeInd) {
		this.digitalDrugExcludeInd = digitalDrugExcludeInd;
	}

	public String getDisableBypassInd() {
		return this.disableBypassInd;
	}

	public void setDisableBypassInd(String disableBypassInd) {
		this.disableBypassInd = disableBypassInd;
	}

	public String getDrugCategory() {
		return this.drugCategory;
	}

	public void setDrugCategory(String drugCategory) {
		this.drugCategory = drugCategory;
	}

	public String getDrugMatchInd() {
		return this.drugMatchInd;
	}

	public void setDrugMatchInd(String drugMatchInd) {
		this.drugMatchInd = drugMatchInd;
	}

	public String getExpressRefillExcludeInd() {
		return this.expressRefillExcludeInd;
	}

	public void setExpressRefillExcludeInd(String expressRefillExcludeInd) {
		this.expressRefillExcludeInd = expressRefillExcludeInd;
	}

	public String getFormExceptionInd() {
		return this.formExceptionInd;
	}

	public void setFormExceptionInd(String formExceptionInd) {
		this.formExceptionInd = formExceptionInd;
	}

	public String getFormTxt() {
		return this.formTxt;
	}

	public void setFormTxt(String formTxt) {
		this.formTxt = formTxt;
	}

	public BigDecimal getFrozenMedispanAwpAmt() {
		return this.frozenMedispanAwpAmt;
	}

	public void setFrozenMedispanAwpAmt(BigDecimal frozenMedispanAwpAmt) {
		this.frozenMedispanAwpAmt = frozenMedispanAwpAmt;
	}

	public String getGenericInd() {
		return this.genericInd;
	}

	public void setGenericInd(String genericInd) {
		this.genericInd = genericInd;
	}

	public String getGenericLink() {
		return this.genericLink;
	}

	public void setGenericLink(String genericLink) {
		this.genericLink = genericLink;
	}

	public String getGpiCode() {
		return this.gpiCode;
	}

	public void setGpiCode(String gpiCode) {
		this.gpiCode = gpiCode;
	}

	public String getGpiExtCd() {
		return this.gpiExtCd;
	}

	public void setGpiExtCd(String gpiExtCd) {
		this.gpiExtCd = gpiExtCd;
	}

	public String getGpiTherapyCd() {
		return this.gpiTherapyCd;
	}

	public void setGpiTherapyCd(String gpiTherapyCd) {
		this.gpiTherapyCd = gpiTherapyCd;
	}

	public BigDecimal getItemCategoryId() {
		return this.itemCategoryId;
	}

	public void setItemCategoryId(BigDecimal itemCategoryId) {
		this.itemCategoryId = itemCategoryId;
	}

	public String getItemName() {
		return this.itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemSrcCd() {
		return this.itemSrcCd;
	}

	public void setItemSrcCd(String itemSrcCd) {
		this.itemSrcCd = itemSrcCd;
	}

	public String getItemTypeCd() {
		return this.itemTypeCd;
	}

	public void setItemTypeCd(String itemTypeCd) {
		this.itemTypeCd = itemTypeCd;
	}

	public String getKnowledgeDrugCode() {
		return this.knowledgeDrugCode;
	}

	public void setKnowledgeDrugCode(String knowledgeDrugCode) {
		this.knowledgeDrugCode = knowledgeDrugCode;
	}

	public BigDecimal getManufacturerId() {
		return this.manufacturerId;
	}

	public void setManufacturerId(BigDecimal manufacturerId) {
		this.manufacturerId = manufacturerId;
	}

	public BigDecimal getMedispanMarkupFactor() {
		return this.medispanMarkupFactor;
	}

	public void setMedispanMarkupFactor(BigDecimal medispanMarkupFactor) {
		this.medispanMarkupFactor = medispanMarkupFactor;
	}

	public BigDecimal getMetricQty() {
		return this.metricQty;
	}

	public void setMetricQty(BigDecimal metricQty) {
		this.metricQty = metricQty;
	}

	public String getMultiSourceCode() {
		return this.multiSourceCode;
	}

	public void setMultiSourceCode(String multiSourceCode) {
		this.multiSourceCode = multiSourceCode;
	}

	public String getNarcCd() {
		return this.narcCd;
	}

	public void setNarcCd(String narcCd) {
		this.narcCd = narcCd;
	}

	public String getNdc2No() {
		return this.ndc2No;
	}

	public void setNdc2No(String ndc2No) {
		this.ndc2No = ndc2No;
	}

	public String getNdc4No() {
		return this.ndc4No;
	}

	public void setNdc4No(String ndc4No) {
		this.ndc4No = ndc4No;
	}

	public String getNdc5No() {
		return this.ndc5No;
	}

	public void setNdc5No(String ndc5No) {
		this.ndc5No = ndc5No;
	}

	public String getNdcNumber() {
		return this.ndcNumber;
	}

	public void setNdcNumber(String ndcNumber) {
		this.ndcNumber = ndcNumber;
	}

	public String getPrintMgInd() {
		return this.printMgInd;
	}

	public void setPrintMgInd(String printMgInd) {
		this.printMgInd = printMgInd;
	}

	public String getProcedureCd() {
		return this.procedureCd;
	}

	public void setProcedureCd(String procedureCd) {
		this.procedureCd = procedureCd;
	}

	public String getQtyConvInd() {
		return this.qtyConvInd;
	}

	public void setQtyConvInd(String qtyConvInd) {
		this.qtyConvInd = qtyConvInd;
	}

	public String getReasonCode() {
		return this.reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getRefrigInd() {
		return this.refrigInd;
	}

	public void setRefrigInd(String refrigInd) {
		this.refrigInd = refrigInd;
	}

	public String getRouteOfAdmin() {
		return this.routeOfAdmin;
	}

	public void setRouteOfAdmin(String routeOfAdmin) {
		this.routeOfAdmin = routeOfAdmin;
	}

	public String getSigDef() {
		return this.sigDef;
	}

	public void setSigDef(String sigDef) {
		this.sigDef = sigDef;
	}

	public String getSigInd() {
		return this.sigInd;
	}

	public void setSigInd(String sigInd) {
		this.sigInd = sigInd;
	}

	public String getSigPerfectionInd() {
		return this.sigPerfectionInd;
	}

	public void setSigPerfectionInd(String sigPerfectionInd) {
		this.sigPerfectionInd = sigPerfectionInd;
	}

	public String getSignatureRequired() {
		return this.signatureRequired;
	}

	public void setSignatureRequired(String signatureRequired) {
		this.signatureRequired = signatureRequired;
	}

	public BigDecimal getSpclPriceAmt() {
		return this.spclPriceAmt;
	}

	public void setSpclPriceAmt(BigDecimal spclPriceAmt) {
		this.spclPriceAmt = spclPriceAmt;
	}

	public Date getSrcDeleteDt() {
		return this.srcDeleteDt;
	}

	public void setSrcDeleteDt(Date srcDeleteDt) {
		this.srcDeleteDt = srcDeleteDt;
	}

	public String getStrengthTxt() {
		return this.strengthTxt;
	}

	public void setStrengthTxt(String strengthTxt) {
		this.strengthTxt = strengthTxt;
	}

	public String getSystemSrcCd() {
		return this.systemSrcCd;
	}

	public void setSystemSrcCd(String systemSrcCd) {
		this.systemSrcCd = systemSrcCd;
	}

	public String getUnitPkgCd() {
		return this.unitPkgCd;
	}

	public void setUnitPkgCd(String unitPkgCd) {
		this.unitPkgCd = unitPkgCd;
	}

	public BigDecimal getUnitsQty() {
		return this.unitsQty;
	}

	public void setUnitsQty(BigDecimal unitsQty) {
		this.unitsQty = unitsQty;
	}

	public String getUpcCd() {
		return this.upcCd;
	}

	public void setUpcCd(String upcCd) {
		this.upcCd = upcCd;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDt() {
		return this.updateDt;
	}

	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}

	public List<PrescriptionDispensesEO> getPrescriptionDispenses() {
		return this.prescriptionDispenses;
	}

	public void setPrescriptionDispenses(List<PrescriptionDispensesEO> prescriptionDispenses) {
		this.prescriptionDispenses = prescriptionDispenses;
	}

	public PrescriptionDispensesEO addPrescriptionDispens(PrescriptionDispensesEO prescriptionDispens) {
		getPrescriptionDispenses().add(prescriptionDispens);
		prescriptionDispens.setItem(this);

		return prescriptionDispens;
	}

	public PrescriptionDispensesEO removePrescriptionDispens(PrescriptionDispensesEO prescriptionDispens) {
		getPrescriptionDispenses().remove(prescriptionDispens);
		prescriptionDispens.setItem(null);

		return prescriptionDispens;
	}

	public List<PreOrderDetailEO> getPreOrderDetails() {
		return this.preOrderDetails;
	}

	public void setPreOrderDetails(List<PreOrderDetailEO> preOrderDetails) {
		this.preOrderDetails = preOrderDetails;
	}

	public PreOrderDetailEO addPreOrderDetail(PreOrderDetailEO preOrderDetail) {
		getPreOrderDetails().add(preOrderDetail);
		preOrderDetail.setItem(this);

		return preOrderDetail;
	}

	public PreOrderDetailEO removePreOrderDetail(PreOrderDetailEO preOrderDetail) {
		getPreOrderDetails().remove(preOrderDetail);
		preOrderDetail.setItem(null);

		return preOrderDetail;
	}

}