package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.sql.Timestamp;

/**
 * The persistent class for the SBP_ENTITY_BPM_PROCESS_MAP database table.
 * 
 */
@Entity
@Table(name = "SBP_ENTITY_BPM_PROCESS_MAP")
@NamedQuery(name = "SbpEntityBpmProcessMap.findAll", query = "SELECT s FROM SbpEntityBpmProcessMap s")
public class SbpEntityBpmProcessMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SBP_ENTITY_BPM_PROCESS_MAP_ID_GENERATOR")
	@Column(name = "SBP_ENTY_BPM_PRC_MAP_ID")
	@SequenceGenerator(sequenceName = "sbp_enty_bpm_prc_map_id_seq", allocationSize = 1, name = "SBP_ENTITY_BPM_PROCESS_MAP_ID_GENERATOR")
	private Long sbpEntyBpmPrcMapId;

	@Column(name = "ACTV_IN")
	private String actvIn;

	@Column(name = "BPM_PRCS_INSTANCE_ID")
	private BigDecimal bpmPrcsInstanceId;

	@Column(name = "BPM_PRCS_NM")
	private String bpmPrcsNm;

	@Column(name = "BPM_PRCS_STUS_CD")
	private String bpmPrcsStusCd;

	@Column(name = "CNTCT_CMNCT_ID")
	private BigDecimal cntctCmnctId;

	@Column(name = "CRTE_TS")
	private Timestamp crteTs;

	@Column(name = "CRTE_USR_NM")
	private String crteUsrNm;

	@Column(name = "HLTCR_PRFSN_ID")
	private BigDecimal hltcrPrfsnId;

	@Column(name = "INTAKE_RFRL_ID")
	private BigDecimal intakeRfrlId;

	// @Column(name="PRE_ORDR_DTL_ID")
	// private BigDecimal preOrdrDtlId;

	@Column(name = "PRTY_IN")
	private String prtyIn;

	@Column(name = "PTNT_ID")
	private BigDecimal ptntId;

	@Column(name = "RX_DSPNS_ID")
	private BigDecimal rxDspnsId;

	@Column(name = "RX_ID")
	private BigDecimal rxId;

	// @Column(name="RX_RQST_ID")
	// private BigDecimal rxRqstId;

	@Column(name = "SBP_ENTY_ID")
	private Long sbpEntyId;

	@Column(name = "SBP_ENTY_TYP")
	private String sbpEntyTyp;

	@Column(name = "SITE_ID")
	private BigDecimal siteId;

	@Temporal(TemporalType.DATE)
	@Column(name = "TRGT_DT")
	private Date trgtDt;

	@Column(name = "UPD_TS")
	private Timestamp updTs;

	@Column(name = "UPD_USR_NM")
	private String updUsrNm;

	@Column(name = "VIP_IN")
	private String vipIn;

	// bi-directional many-to-one association to PreOrderHeader
	@ManyToOne
	@JoinColumn(name = "PRE_ORDR_HDR_ID")
	private PreOrderHeaderTasks preOrderHeader;

	@OneToMany
	@JoinColumn(name = "SBP_ENTY_BPM_PRC_MAP_ID")
	private List<SbpWorkQueueTaskBpmTask> SbpWorkQueueTaskBpmTasks;

	public SbpEntityBpmProcessMap() {
	}

	public Long getSbpEntyBpmPrcMapId() {
		return this.sbpEntyBpmPrcMapId;
	}

	public void setSbpEntyBpmPrcMapId(Long sbpEntyBpmPrcMapId) {
		this.sbpEntyBpmPrcMapId = sbpEntyBpmPrcMapId;
	}

	public String getActvIn() {
		return this.actvIn;
	}

	public void setActvIn(String actvIn) {
		this.actvIn = actvIn;
	}

	public BigDecimal getBpmPrcsInstanceId() {
		return this.bpmPrcsInstanceId;
	}

	public void setBpmPrcsInstanceId(BigDecimal bpmPrcsInstanceId) {
		this.bpmPrcsInstanceId = bpmPrcsInstanceId;
	}

	public String getBpmPrcsNm() {
		return this.bpmPrcsNm;
	}

	public void setBpmPrcsNm(String bpmPrcsNm) {
		this.bpmPrcsNm = bpmPrcsNm;
	}

	public String getBpmPrcsStusCd() {
		return this.bpmPrcsStusCd;
	}

	public void setBpmPrcsStusCd(String bpmPrcsStusCd) {
		this.bpmPrcsStusCd = bpmPrcsStusCd;
	}

	public BigDecimal getCntctCmnctId() {
		return this.cntctCmnctId;
	}

	public void setCntctCmnctId(BigDecimal cntctCmnctId) {
		this.cntctCmnctId = cntctCmnctId;
	}

	public Timestamp getCrteTs() {
		return this.crteTs;
	}

	public void setCrteTs(Timestamp crteTs) {
		this.crteTs = crteTs;
	}

	public String getCrteUsrNm() {
		return this.crteUsrNm;
	}

	public void setCrteUsrNm(String crteUsrNm) {
		this.crteUsrNm = crteUsrNm;
	}

	public BigDecimal getHltcrPrfsnId() {
		return this.hltcrPrfsnId;
	}

	public void setHltcrPrfsnId(BigDecimal hltcrPrfsnId) {
		this.hltcrPrfsnId = hltcrPrfsnId;
	}

	public BigDecimal getIntakeRfrlId() {
		return this.intakeRfrlId;
	}

	public void setIntakeRfrlId(BigDecimal intakeRfrlId) {
		this.intakeRfrlId = intakeRfrlId;
	}

	// public BigDecimal getPreOrdrDtlId() {
	// return this.preOrdrDtlId;
	// }
	//
	// public void setPreOrdrDtlId(BigDecimal preOrdrDtlId) {
	// this.preOrdrDtlId = preOrdrDtlId;
	// }

	public String getPrtyIn() {
		return this.prtyIn;
	}

	public void setPrtyIn(String prtyIn) {
		this.prtyIn = prtyIn;
	}

	public BigDecimal getPtntId() {
		return this.ptntId;
	}

	public void setPtntId(BigDecimal ptntId) {
		this.ptntId = ptntId;
	}

	public BigDecimal getRxDspnsId() {
		return this.rxDspnsId;
	}

	public void setRxDspnsId(BigDecimal rxDspnsId) {
		this.rxDspnsId = rxDspnsId;
	}

	public BigDecimal getRxId() {
		return this.rxId;
	}

	public void setRxId(BigDecimal rxId) {
		this.rxId = rxId;
	}

	// public BigDecimal getRxRqstId() {
	// return this.rxRqstId;
	// }
	//
	// public void setRxRqstId(BigDecimal rxRqstId) {
	// this.rxRqstId = rxRqstId;
	// }

	public Long getSbpEntyId() {
		return this.sbpEntyId;
	}

	public void setSbpEntyId(Long sbpEntyId) {
		this.sbpEntyId = sbpEntyId;
	}

	public String getSbpEntyTyp() {
		return this.sbpEntyTyp;
	}

	public void setSbpEntyTyp(String sbpEntyTyp) {
		this.sbpEntyTyp = sbpEntyTyp;
	}

	public BigDecimal getSiteId() {
		return this.siteId;
	}

	public void setSiteId(BigDecimal siteId) {
		this.siteId = siteId;
	}

	public Date getTrgtDt() {
		return this.trgtDt;
	}

	public void setTrgtDt(Date trgtDt) {
		this.trgtDt = trgtDt;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrNm() {
		return this.updUsrNm;
	}

	public void setUpdUsrNm(String updUsrNm) {
		this.updUsrNm = updUsrNm;
	}

	public String getVipIn() {
		return this.vipIn;
	}

	public void setVipIn(String vipIn) {
		this.vipIn = vipIn;
	}

	public PreOrderHeaderTasks getPreOrderHeader() {
		return this.preOrderHeader;
	}

	public void setPreOrderHeader(PreOrderHeaderTasks preOrderHeader) {
		this.preOrderHeader = preOrderHeader;
	}

}