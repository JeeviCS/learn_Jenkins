
package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;

public interface CancelDownloadDao {

  List<CanceDownloadReasonCodes> cancelDownloadGet(long orderId);

  Void cancelDownloadPost(long preOrderId, String orderNotes);

}
