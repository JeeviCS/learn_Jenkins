package com.cvs.specialty.ordermaintenance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.ItemEO;

@Repository
@Transactional
public interface ItemsRepo  extends JpaRepository<ItemEO, Long> {
	

	ItemEO findByItemNameAndStrengthTxt(String itemName,String strengthTxt);
	
	
	ItemEO findByItemName(String itemName);
	
	
	

	ItemEO findByItemId(long itemId);

}
