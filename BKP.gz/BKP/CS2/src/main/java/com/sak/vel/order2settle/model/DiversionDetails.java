package com.cvs.specialty.ordermaintenance.model;

public class DiversionDetails {

	private String failureCode;
	
	private String failureDescription;

	public String getFailureCode() {
		return failureCode;
	}

	public void setFailureCode(String failureCode) {
		this.failureCode = failureCode;
	}

	public String getFailureDescription() {
		return failureDescription;
	}

	public void setFailureDescription(String failureDescription) {
		this.failureDescription = failureDescription;
	}
}
