package com.cvs.specialty.ordermaintenance.model;

import java.time.ZonedDateTime;
import java.util.List;

import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeDeserializer;
import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeSerializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class RouteToQueueRequest {
	
	@JsonProperty("actionId")
	private Long actionId;
	
	@JsonProperty("callingService")
	private String callingService;
	
	@JsonProperty("comments")
	private String comments;
	
	@JsonProperty("diversionIds")
	private List<Long> diversionId;
	
	@JsonProperty("entityId")
	private Long entityId;
	
	@JsonProperty("entityType")
	private String entityType;
	
	@JsonProperty("followUpDate")
	@JsonSerialize(using = ZonedDateTimeSerializer.class)
	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
	private ZonedDateTime followUpDate = null;

	@JsonProperty("outcomeId")
	private Long outcomeId;
	
	@JsonProperty("patientId")
	private Long patientId;
	
	@JsonProperty("prescriberId")
	private Long prescriberId;

	@JsonProperty("primaryBillGroupId")
	private Long primaryBillGroupId;

	@JsonProperty("processInstanceId")
	private Long ProcessInstanceId;

	@JsonProperty("targetTaskName")
	private String targetTaskName; 

	@JsonProperty("taskId")
	private Long taskId;

	@JsonProperty("taskType")
	private String taskType;


	public Long getProcessInstanceId() {
		return ProcessInstanceId;
	}

	public void setProcessInstanceId(Long processInstanceId) {
		ProcessInstanceId = processInstanceId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getPrescriberId() {
		return prescriberId;
	}

	public void setPrescriberId(Long prescriberId) {
		this.prescriberId = prescriberId;
	}

	public Long getPrimaryBillGroupId() {
		return primaryBillGroupId;
	}

	public void setPrimaryBillGroupId(Long primaryBillGroupId) {
		this.primaryBillGroupId = primaryBillGroupId;
	}

	

	public ZonedDateTime getFollowUpDate() {
		return followUpDate;
	}

	public void setFollowUpDate(ZonedDateTime followUpDate) {
		this.followUpDate = followUpDate;
	}

	public List<Long> getDiversionId() {
		return diversionId;
	}

	public void setDiversionId(List<Long> diversionId) {
		this.diversionId = diversionId;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCallingService() {
		return callingService;
	}

	public void setCallingService(String callingService) {
		this.callingService = callingService;
	}

	public Long getActionId() {
		return actionId;
	}

	public void setActionId(Long actionId) {
		this.actionId = actionId;
	}

	public Long getOutcomeId() {
		return outcomeId;
	}

	public void setOutcomeId(Long outcomeId) {
		this.outcomeId = outcomeId;
	}

	public String getTargetTaskName() {
		return targetTaskName;
	}

	public void setTargetTaskName(String targetTaskName) {
		this.targetTaskName = targetTaskName;
	}
	
}
