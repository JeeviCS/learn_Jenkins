
package com.cvs.specialty.ordermaintenance.service;

import org.springframework.http.ResponseEntity;

public interface OrderStatusService {

  ResponseEntity<Void> updateOrderStatus(Long preOrdrHdrId);
}
