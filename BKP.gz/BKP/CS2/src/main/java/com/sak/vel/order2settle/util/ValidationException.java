/**
 * 
 */
package com.cvs.specialty.ordermaintenance.util;
/**
 * @author Z231675
 *
 */
public class ValidationException extends OrderMaintenanceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValidationException(String errorCode, String paramName){
		this.errorCode = errorCode;
		this.paramName = paramName;
		this.httpStatusCode = 400;
	}

}
