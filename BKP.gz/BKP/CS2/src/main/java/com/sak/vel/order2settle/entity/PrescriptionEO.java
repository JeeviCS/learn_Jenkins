package com.cvs.specialty.ordermaintenance.entity;


import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PRESCRIPTIONS database table.
 * 
 */
@Entity
@Table(name="PRESCRIPTIONS")
@NamedQuery(name="PrescriptionEO.findAll", query="SELECT p FROM PrescriptionEO p")
public class PrescriptionEO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;

	@Column(name="ACUTE_IND")
	private String acuteInd;

	@Temporal(TemporalType.DATE)
	@Column(name="ANTICIPATED_PICKUP_DATE")
	private Date anticipatedPickupDate;

	@Column(name="AUTO_ADJN_IN")
	private String autoAdjnIn;

	@Column(name="CAUTION_MESSAGE_1")
	private String cautionMessage1;

	@Column(name="CAUTION_MESSAGE_2")
	private String cautionMessage2;

	@Column(name="CAUTION_MESSAGE_3")
	private String cautionMessage3;

	@Column(name="COMPANY_ID")
	private BigDecimal companyId;

	@Column(name="CREATE_BY")
	private String createBy;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_DATE")
	private Date createDate;

	@Column(name="CREATE_PHARMACARE_SYSTEM_ID")
	private BigDecimal createPharmacareSystemId;

	@Column(name="CREATE_PROCESS")
	private String createProcess;

	@Column(name="DAW_CODE")
	private String dawCode;

	private String directions;

	@Column(name="DISCONTINUE_CODE")
	private String discontinueCode;

	@Temporal(TemporalType.DATE)
	@Column(name="DISCONTINUE_DATE")
	private Date discontinueDate;

	@Column(name="DISCONTINUE_REASON_CODE")
	private String discontinueReasonCode;

	@Column(name="DISCONTINUE_USER")
	private String discontinueUser;

	@Column(name="DSG_CHG_IN")
	private String dsgChgIn;

	@Column(name="EPCS_IND")
	private String epcsInd;

	@Column(name="EPIC_TYPE")
	private String epicType;

	@Column(name="EXTERNAL_RX_NUMBER")
	private String externalRxNumber;

	@Temporal(TemporalType.DATE)
	@Column(name="FOLLOW_UP_DATE")
	private Date followUpDate;

	@Column(name="HBS_RX_RELATIONSHIP_CODE")
	private String hbsRxRelationshipCode;

	@Column(name="HCP_ID")
	private BigDecimal hcpId;

	@Temporal(TemporalType.DATE)
	@Column(name="HOLD_END_DATE")
	private Date holdEndDate;

	@Column(name="HOLD_REASON_CODE")
	private String holdReasonCode;

	@Temporal(TemporalType.DATE)
	@Column(name="HOLD_START_DATE")
	private Date holdStartDate;

	@Column(name="ISP_RX_IND")
	private String ispRxInd;

	@Column(name="ISP_RX_STATUS")
	private String ispRxStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="ISP_RX_STATUS_DATE")
	private Date ispRxStatusDate;

	@Column(name="ITEM_ID")
	private BigDecimal itemId;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_DC_RSN_CD_DATE")
	private Date lastUpdDcRsnCdDate;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPD_ON_HLD_RSN_CD_DATE")
	private Date lastUpdOnHldRsnCdDate;

	@Column(name="MANUF_COPAY_DOWNLOAD_OVERRIDE")
	private String manufCopayDownloadOverride;

	@Column(name="MAR_PROJECT_IND")
	private String marProjectInd;

	@Column(name="MCR_HARDCOPY_ON_FILE")
	private String mcrHardcopyOnFile;

	@Column(name="MEDISPAN_IND")
	private String medispanInd;

	@Column(name="NDC_WRITTEN")
	private String ndcWritten;

	@Column(name="NYM_HARDCOPY_ON_FILE")
	private String nymHardcopyOnFile;

	@Column(name="ORIGIN_CODE")
	private BigDecimal originCode;

	@Column(name="PATIENT_ENROLLMENT_ID")
	private BigDecimal patientEnrollmentId;

	@Column(name="PATIENT_ID")
	private BigDecimal patientId;

	@Column(name="QUANTITY_REMAINING")
	private BigDecimal quantityRemaining;

	@Column(name="QUANTITY_WRITTEN")
	private BigDecimal quantityWritten;

	@Column(name="REFILLS_ALLOWED")
	private BigDecimal refillsAllowed;

	@Column(name="REFILLS_LFT")
	private BigDecimal refillsLft;

	@Column(name="RETAIL_DISPENSE_SPEC_MGMT_IND")
	private String retailDispenseSpecMgmtInd;

	@Column(name="RX_COMMENTS")
	private String rxComments;

	@Column(name="RX_NUMBER")
	private BigDecimal rxNumber;

	@Column(name="RX_ON_HOLD_REASON_CODE")
	private String rxOnHoldReasonCode;

	@Column(name="RX_RDSM_TRANSACTION_TYPE")
	private String rxRdsmTransactionType;

	@Temporal(TemporalType.DATE)
	@Column(name="RX_RECEIVED_DATE")
	private Date rxReceivedDate;

	@Column(name="RX_REQUESTS_ID")
	private BigDecimal rxRequestsId;

	@Column(name="RX_TRANSFER_IND")
	private String rxTransferInd;

	@Column(name="RX_VERIFY_IND")
	private String rxVerifyInd;

	private String rxtype;

	@Column(name="SENT_TO_PROTOCALLS")
	private String sentToProtocalls;

	@Column(name="SITE_ID")
	private BigDecimal siteId;

	@Temporal(TemporalType.DATE)
	@Column(name="SRC_DELETE_DATE")
	private Date srcDeleteDate;

	@Column(name="STORE_ID")
	private BigDecimal storeId;

	@Column(name="TRIPLICATE_SERIAL_NUMBER")
	private String triplicateSerialNumber;

	@Column(name="UPDATE_BY")
	private String updateBy;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATE_DATE")
	private Date updateDate;

	@Column(name="UPDATE_PHARMACARE_SYSTEM_ID")
	private BigDecimal updatePharmacareSystemId;

	@Column(name="UPDATE_PROCESS")
	private String updateProcess;

	@Temporal(TemporalType.DATE)
	@Column(name="WRITTEN_DATE")
	private Date writtenDate;

	@Column(name="XDR_CODE")
	private String xdrCode;

	public PrescriptionEO() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAcuteInd() {
		return this.acuteInd;
	}

	public void setAcuteInd(String acuteInd) {
		this.acuteInd = acuteInd;
	}

	public Date getAnticipatedPickupDate() {
		return this.anticipatedPickupDate;
	}

	public void setAnticipatedPickupDate(Date anticipatedPickupDate) {
		this.anticipatedPickupDate = anticipatedPickupDate;
	}

	public String getAutoAdjnIn() {
		return this.autoAdjnIn;
	}

	public void setAutoAdjnIn(String autoAdjnIn) {
		this.autoAdjnIn = autoAdjnIn;
	}

	public String getCautionMessage1() {
		return this.cautionMessage1;
	}

	public void setCautionMessage1(String cautionMessage1) {
		this.cautionMessage1 = cautionMessage1;
	}

	public String getCautionMessage2() {
		return this.cautionMessage2;
	}

	public void setCautionMessage2(String cautionMessage2) {
		this.cautionMessage2 = cautionMessage2;
	}

	public String getCautionMessage3() {
		return this.cautionMessage3;
	}

	public void setCautionMessage3(String cautionMessage3) {
		this.cautionMessage3 = cautionMessage3;
	}

	public BigDecimal getCompanyId() {
		return this.companyId;
	}

	public void setCompanyId(BigDecimal companyId) {
		this.companyId = companyId;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public BigDecimal getCreatePharmacareSystemId() {
		return this.createPharmacareSystemId;
	}

	public void setCreatePharmacareSystemId(BigDecimal createPharmacareSystemId) {
		this.createPharmacareSystemId = createPharmacareSystemId;
	}

	public String getCreateProcess() {
		return this.createProcess;
	}

	public void setCreateProcess(String createProcess) {
		this.createProcess = createProcess;
	}

	public String getDawCode() {
		return this.dawCode;
	}

	public void setDawCode(String dawCode) {
		this.dawCode = dawCode;
	}

	public String getDirections() {
		return this.directions;
	}

	public void setDirections(String directions) {
		this.directions = directions;
	}

	public String getDiscontinueCode() {
		return this.discontinueCode;
	}

	public void setDiscontinueCode(String discontinueCode) {
		this.discontinueCode = discontinueCode;
	}

	public Date getDiscontinueDate() {
		return this.discontinueDate;
	}

	public void setDiscontinueDate(Date discontinueDate) {
		this.discontinueDate = discontinueDate;
	}

	public String getDiscontinueReasonCode() {
		return this.discontinueReasonCode;
	}

	public void setDiscontinueReasonCode(String discontinueReasonCode) {
		this.discontinueReasonCode = discontinueReasonCode;
	}

	public String getDiscontinueUser() {
		return this.discontinueUser;
	}

	public void setDiscontinueUser(String discontinueUser) {
		this.discontinueUser = discontinueUser;
	}

	public String getDsgChgIn() {
		return this.dsgChgIn;
	}

	public void setDsgChgIn(String dsgChgIn) {
		this.dsgChgIn = dsgChgIn;
	}

	public String getEpcsInd() {
		return this.epcsInd;
	}

	public void setEpcsInd(String epcsInd) {
		this.epcsInd = epcsInd;
	}

	public String getEpicType() {
		return this.epicType;
	}

	public void setEpicType(String epicType) {
		this.epicType = epicType;
	}

	public String getExternalRxNumber() {
		return this.externalRxNumber;
	}

	public void setExternalRxNumber(String externalRxNumber) {
		this.externalRxNumber = externalRxNumber;
	}

	public Date getFollowUpDate() {
		return this.followUpDate;
	}

	public void setFollowUpDate(Date followUpDate) {
		this.followUpDate = followUpDate;
	}

	public String getHbsRxRelationshipCode() {
		return this.hbsRxRelationshipCode;
	}

	public void setHbsRxRelationshipCode(String hbsRxRelationshipCode) {
		this.hbsRxRelationshipCode = hbsRxRelationshipCode;
	}

	public BigDecimal getHcpId() {
		return this.hcpId;
	}

	public void setHcpId(BigDecimal hcpId) {
		this.hcpId = hcpId;
	}

	public Date getHoldEndDate() {
		return this.holdEndDate;
	}

	public void setHoldEndDate(Date holdEndDate) {
		this.holdEndDate = holdEndDate;
	}

	public String getHoldReasonCode() {
		return this.holdReasonCode;
	}

	public void setHoldReasonCode(String holdReasonCode) {
		this.holdReasonCode = holdReasonCode;
	}

	public Date getHoldStartDate() {
		return this.holdStartDate;
	}

	public void setHoldStartDate(Date holdStartDate) {
		this.holdStartDate = holdStartDate;
	}

	public String getIspRxInd() {
		return this.ispRxInd;
	}

	public void setIspRxInd(String ispRxInd) {
		this.ispRxInd = ispRxInd;
	}

	public String getIspRxStatus() {
		return this.ispRxStatus;
	}

	public void setIspRxStatus(String ispRxStatus) {
		this.ispRxStatus = ispRxStatus;
	}

	public Date getIspRxStatusDate() {
		return this.ispRxStatusDate;
	}

	public void setIspRxStatusDate(Date ispRxStatusDate) {
		this.ispRxStatusDate = ispRxStatusDate;
	}

	public BigDecimal getItemId() {
		return this.itemId;
	}

	public void setItemId(BigDecimal itemId) {
		this.itemId = itemId;
	}

	public Date getLastUpdDcRsnCdDate() {
		return this.lastUpdDcRsnCdDate;
	}

	public void setLastUpdDcRsnCdDate(Date lastUpdDcRsnCdDate) {
		this.lastUpdDcRsnCdDate = lastUpdDcRsnCdDate;
	}

	public Date getLastUpdOnHldRsnCdDate() {
		return this.lastUpdOnHldRsnCdDate;
	}

	public void setLastUpdOnHldRsnCdDate(Date lastUpdOnHldRsnCdDate) {
		this.lastUpdOnHldRsnCdDate = lastUpdOnHldRsnCdDate;
	}

	public String getManufCopayDownloadOverride() {
		return this.manufCopayDownloadOverride;
	}

	public void setManufCopayDownloadOverride(String manufCopayDownloadOverride) {
		this.manufCopayDownloadOverride = manufCopayDownloadOverride;
	}

	public String getMarProjectInd() {
		return this.marProjectInd;
	}

	public void setMarProjectInd(String marProjectInd) {
		this.marProjectInd = marProjectInd;
	}

	public String getMcrHardcopyOnFile() {
		return this.mcrHardcopyOnFile;
	}

	public void setMcrHardcopyOnFile(String mcrHardcopyOnFile) {
		this.mcrHardcopyOnFile = mcrHardcopyOnFile;
	}

	public String getMedispanInd() {
		return this.medispanInd;
	}

	public void setMedispanInd(String medispanInd) {
		this.medispanInd = medispanInd;
	}

	public String getNdcWritten() {
		return this.ndcWritten;
	}

	public void setNdcWritten(String ndcWritten) {
		this.ndcWritten = ndcWritten;
	}

	public String getNymHardcopyOnFile() {
		return this.nymHardcopyOnFile;
	}

	public void setNymHardcopyOnFile(String nymHardcopyOnFile) {
		this.nymHardcopyOnFile = nymHardcopyOnFile;
	}

	public BigDecimal getOriginCode() {
		return this.originCode;
	}

	public void setOriginCode(BigDecimal originCode) {
		this.originCode = originCode;
	}

	public BigDecimal getPatientEnrollmentId() {
		return this.patientEnrollmentId;
	}

	public void setPatientEnrollmentId(BigDecimal patientEnrollmentId) {
		this.patientEnrollmentId = patientEnrollmentId;
	}

	public BigDecimal getPatientId() {
		return this.patientId;
	}

	public void setPatientId(BigDecimal patientId) {
		this.patientId = patientId;
	}

	public BigDecimal getQuantityRemaining() {
		return this.quantityRemaining;
	}

	public void setQuantityRemaining(BigDecimal quantityRemaining) {
		this.quantityRemaining = quantityRemaining;
	}

	public BigDecimal getQuantityWritten() {
		return this.quantityWritten;
	}

	public void setQuantityWritten(BigDecimal quantityWritten) {
		this.quantityWritten = quantityWritten;
	}

	public BigDecimal getRefillsAllowed() {
		return this.refillsAllowed;
	}

	public void setRefillsAllowed(BigDecimal refillsAllowed) {
		this.refillsAllowed = refillsAllowed;
	}

	public BigDecimal getRefillsLft() {
		return this.refillsLft;
	}

	public void setRefillsLft(BigDecimal refillsLft) {
		this.refillsLft = refillsLft;
	}

	public String getRetailDispenseSpecMgmtInd() {
		return this.retailDispenseSpecMgmtInd;
	}

	public void setRetailDispenseSpecMgmtInd(String retailDispenseSpecMgmtInd) {
		this.retailDispenseSpecMgmtInd = retailDispenseSpecMgmtInd;
	}

	public String getRxComments() {
		return this.rxComments;
	}

	public void setRxComments(String rxComments) {
		this.rxComments = rxComments;
	}

	public BigDecimal getRxNumber() {
		return this.rxNumber;
	}

	public void setRxNumber(BigDecimal rxNumber) {
		this.rxNumber = rxNumber;
	}

	public String getRxOnHoldReasonCode() {
		return this.rxOnHoldReasonCode;
	}

	public void setRxOnHoldReasonCode(String rxOnHoldReasonCode) {
		this.rxOnHoldReasonCode = rxOnHoldReasonCode;
	}

	public String getRxRdsmTransactionType() {
		return this.rxRdsmTransactionType;
	}

	public void setRxRdsmTransactionType(String rxRdsmTransactionType) {
		this.rxRdsmTransactionType = rxRdsmTransactionType;
	}

	public Date getRxReceivedDate() {
		return this.rxReceivedDate;
	}

	public void setRxReceivedDate(Date rxReceivedDate) {
		this.rxReceivedDate = rxReceivedDate;
	}

	public BigDecimal getRxRequestsId() {
		return this.rxRequestsId;
	}

	public void setRxRequestsId(BigDecimal rxRequestsId) {
		this.rxRequestsId = rxRequestsId;
	}

	public String getRxTransferInd() {
		return this.rxTransferInd;
	}

	public void setRxTransferInd(String rxTransferInd) {
		this.rxTransferInd = rxTransferInd;
	}

	public String getRxVerifyInd() {
		return this.rxVerifyInd;
	}

	public void setRxVerifyInd(String rxVerifyInd) {
		this.rxVerifyInd = rxVerifyInd;
	}

	public String getRxtype() {
		return this.rxtype;
	}

	public void setRxtype(String rxtype) {
		this.rxtype = rxtype;
	}

	public String getSentToProtocalls() {
		return this.sentToProtocalls;
	}

	public void setSentToProtocalls(String sentToProtocalls) {
		this.sentToProtocalls = sentToProtocalls;
	}

	public BigDecimal getSiteId() {
		return this.siteId;
	}

	public void setSiteId(BigDecimal siteId) {
		this.siteId = siteId;
	}

	public Date getSrcDeleteDate() {
		return this.srcDeleteDate;
	}

	public void setSrcDeleteDate(Date srcDeleteDate) {
		this.srcDeleteDate = srcDeleteDate;
	}

	public BigDecimal getStoreId() {
		return this.storeId;
	}

	public void setStoreId(BigDecimal storeId) {
		this.storeId = storeId;
	}

	public String getTriplicateSerialNumber() {
		return this.triplicateSerialNumber;
	}

	public void setTriplicateSerialNumber(String triplicateSerialNumber) {
		this.triplicateSerialNumber = triplicateSerialNumber;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public BigDecimal getUpdatePharmacareSystemId() {
		return this.updatePharmacareSystemId;
	}

	public void setUpdatePharmacareSystemId(BigDecimal updatePharmacareSystemId) {
		this.updatePharmacareSystemId = updatePharmacareSystemId;
	}

	public String getUpdateProcess() {
		return this.updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public Date getWrittenDate() {
		return this.writtenDate;
	}

	public void setWrittenDate(Date writtenDate) {
		this.writtenDate = writtenDate;
	}

	public String getXdrCode() {
		return this.xdrCode;
	}

	public void setXdrCode(String xdrCode) {
		this.xdrCode = xdrCode;
	}

}