
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * SpecialtyBuisnessProcessRules
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class SpecialtyBuisnessProcessRules {
  @JsonProperty("specialtyBuisnessProcessRuleIdentifier")
  private String specialtyBuisnessProcessRuleIdentifier = null;

  @JsonProperty("specailtyBuisnessProcessEntityIdentifier")
  private String specailtyBuisnessProcessEntityIdentifier = null;

  @JsonProperty("specialtyBusinessprocessEntityType")
  private String specialtyBusinessprocessEntityType = null;

  @JsonProperty("bpmProcessName")
  private String bpmProcessName = null;

  @JsonProperty("bpmProcessInstanceIdentifier")
  private String bpmProcessInstanceIdentifier = null;

  @JsonProperty("userprofileIdentifier")
  private String userprofileIdentifier = null;

  @JsonProperty("ruleIndentifier")
  private String ruleIndentifier = null;

  @JsonProperty("ruleResultText")
  private String ruleResultText = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public SpecialtyBuisnessProcessRules specialtyBuisnessProcessRuleIdentifier(
      String specialtyBuisnessProcessRuleIdentifier) {
    this.specialtyBuisnessProcessRuleIdentifier = specialtyBuisnessProcessRuleIdentifier;
    return this;
  }

  /**
   * Get specialtyBuisnessProcessRuleIdentifier
   * 
   * @return specialtyBuisnessProcessRuleIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSpecialtyBuisnessProcessRuleIdentifier() {
    return specialtyBuisnessProcessRuleIdentifier;
  }

  public void setSpecialtyBuisnessProcessRuleIdentifier(
      String specialtyBuisnessProcessRuleIdentifier) {
    this.specialtyBuisnessProcessRuleIdentifier = specialtyBuisnessProcessRuleIdentifier;
  }

  public SpecialtyBuisnessProcessRules specailtyBuisnessProcessEntityIdentifier(
      String specailtyBuisnessProcessEntityIdentifier) {
    this.specailtyBuisnessProcessEntityIdentifier = specailtyBuisnessProcessEntityIdentifier;
    return this;
  }

  /**
   * Get specailtyBuisnessProcessEntityIdentifier
   * 
   * @return specailtyBuisnessProcessEntityIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSpecailtyBuisnessProcessEntityIdentifier() {
    return specailtyBuisnessProcessEntityIdentifier;
  }

  public void setSpecailtyBuisnessProcessEntityIdentifier(
      String specailtyBuisnessProcessEntityIdentifier) {
    this.specailtyBuisnessProcessEntityIdentifier = specailtyBuisnessProcessEntityIdentifier;
  }

  public SpecialtyBuisnessProcessRules specialtyBusinessprocessEntityType(
      String specialtyBusinessprocessEntityType) {
    this.specialtyBusinessprocessEntityType = specialtyBusinessprocessEntityType;
    return this;
  }

  /**
   * Get specialtyBusinessprocessEntityType
   * 
   * @return specialtyBusinessprocessEntityType
   **/
  @ApiModelProperty(value = "")

  public String getSpecialtyBusinessprocessEntityType() {
    return specialtyBusinessprocessEntityType;
  }

  public void setSpecialtyBusinessprocessEntityType(String specialtyBusinessprocessEntityType) {
    this.specialtyBusinessprocessEntityType = specialtyBusinessprocessEntityType;
  }

  public SpecialtyBuisnessProcessRules bpmProcessName(String bpmProcessName) {
    this.bpmProcessName = bpmProcessName;
    return this;
  }

  /**
   * Get bpmProcessName
   * 
   * @return bpmProcessName
   **/
  @ApiModelProperty(value = "")

  public String getBpmProcessName() {
    return bpmProcessName;
  }

  public void setBpmProcessName(String bpmProcessName) {
    this.bpmProcessName = bpmProcessName;
  }

  public SpecialtyBuisnessProcessRules bpmProcessInstanceIdentifier(
      String bpmProcessInstanceIdentifier) {
    this.bpmProcessInstanceIdentifier = bpmProcessInstanceIdentifier;
    return this;
  }

  /**
   * Get bpmProcessInstanceIdentifier
   * 
   * @return bpmProcessInstanceIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getBpmProcessInstanceIdentifier() {
    return bpmProcessInstanceIdentifier;
  }

  public void setBpmProcessInstanceIdentifier(String bpmProcessInstanceIdentifier) {
    this.bpmProcessInstanceIdentifier = bpmProcessInstanceIdentifier;
  }

  public SpecialtyBuisnessProcessRules userprofileIdentifier(String userprofileIdentifier) {
    this.userprofileIdentifier = userprofileIdentifier;
    return this;
  }

  /**
   * Get userprofileIdentifier
   * 
   * @return userprofileIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getUserprofileIdentifier() {
    return userprofileIdentifier;
  }

  public void setUserprofileIdentifier(String userprofileIdentifier) {
    this.userprofileIdentifier = userprofileIdentifier;
  }

  public SpecialtyBuisnessProcessRules ruleIndentifier(String ruleIndentifier) {
    this.ruleIndentifier = ruleIndentifier;
    return this;
  }

  /**
   * Get ruleIndentifier
   * 
   * @return ruleIndentifier
   **/
  @ApiModelProperty(value = "")

  public String getRuleIndentifier() {
    return ruleIndentifier;
  }

  public void setRuleIndentifier(String ruleIndentifier) {
    this.ruleIndentifier = ruleIndentifier;
  }

  public SpecialtyBuisnessProcessRules ruleResultText(String ruleResultText) {
    this.ruleResultText = ruleResultText;
    return this;
  }

  /**
   * Get ruleResultText
   * 
   * @return ruleResultText
   **/
  @ApiModelProperty(value = "")

  public String getRuleResultText() {
    return ruleResultText;
  }

  public void setRuleResultText(String ruleResultText) {
    this.ruleResultText = ruleResultText;
  }

  public SpecialtyBuisnessProcessRules activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public SpecialtyBuisnessProcessRules audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SpecialtyBuisnessProcessRules specialtyBuisnessProcessRules = (SpecialtyBuisnessProcessRules) o;
    return Objects.equals(
      this.specialtyBuisnessProcessRuleIdentifier,
      specialtyBuisnessProcessRules.specialtyBuisnessProcessRuleIdentifier)
        && Objects.equals(
          this.specailtyBuisnessProcessEntityIdentifier,
          specialtyBuisnessProcessRules.specailtyBuisnessProcessEntityIdentifier)
        && Objects.equals(
          this.specialtyBusinessprocessEntityType,
          specialtyBuisnessProcessRules.specialtyBusinessprocessEntityType)
        && Objects.equals(this.bpmProcessName, specialtyBuisnessProcessRules.bpmProcessName)
        && Objects.equals(
          this.bpmProcessInstanceIdentifier,
          specialtyBuisnessProcessRules.bpmProcessInstanceIdentifier)
        && Objects
          .equals(this.userprofileIdentifier, specialtyBuisnessProcessRules.userprofileIdentifier)
        && Objects.equals(this.ruleIndentifier, specialtyBuisnessProcessRules.ruleIndentifier)
        && Objects.equals(this.ruleResultText, specialtyBuisnessProcessRules.ruleResultText)
        && Objects.equals(this.activeIndicator, specialtyBuisnessProcessRules.activeIndicator)
        && Objects.equals(this.audit, specialtyBuisnessProcessRules.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      specialtyBuisnessProcessRuleIdentifier,
      specailtyBuisnessProcessEntityIdentifier,
      specialtyBusinessprocessEntityType,
      bpmProcessName,
      bpmProcessInstanceIdentifier,
      userprofileIdentifier,
      ruleIndentifier,
      ruleResultText,
      activeIndicator,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecialtyBuisnessProcessRules {\n");

    sb
      .append("    specialtyBuisnessProcessRuleIdentifier: ")
      .append(toIndentedString(specialtyBuisnessProcessRuleIdentifier))
      .append("\n");
    sb
      .append("    specailtyBuisnessProcessEntityIdentifier: ")
      .append(toIndentedString(specailtyBuisnessProcessEntityIdentifier))
      .append("\n");
    sb
      .append("    specialtyBusinessprocessEntityType: ")
      .append(toIndentedString(specialtyBusinessprocessEntityType))
      .append("\n");
    sb.append("    bpmProcessName: ").append(toIndentedString(bpmProcessName)).append("\n");
    sb
      .append("    bpmProcessInstanceIdentifier: ")
      .append(toIndentedString(bpmProcessInstanceIdentifier))
      .append("\n");
    sb.append("    userprofileIdentifier: ").append(toIndentedString(userprofileIdentifier)).append(
      "\n");
    sb.append("    ruleIndentifier: ").append(toIndentedString(ruleIndentifier)).append("\n");
    sb.append("    ruleResultText: ").append(toIndentedString(ruleResultText)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
