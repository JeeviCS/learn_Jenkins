
package com.cvs.specialty.ordermaintenance.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.ShippingDetailsDao;
import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;
import com.cvs.specialty.ordermaintenance.service.ShippingDetailsService;

@Repository
public class ShippingDetailsServiceImpl implements ShippingDetailsService {
  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  ShippingDetailsDao shippingDetailsDao;

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Override
  public
      ResponseEntity<ShipmentDetails>
      getShippingDetails(Long preOrderId, String status, String shipmentNumber) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<ShipmentDetails> response = null;

    try {
      ShipmentDetails response_list = shippingDetailsDao
        .getShippingDetails(preOrderId, status, shipmentNumber);

      if (response_list == null) {
        response = new ResponseEntity(response_list, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response_list, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;
    } catch (Exception e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<ShipmentDetails>(HttpStatus.BAD_REQUEST);
    }

  }
}
