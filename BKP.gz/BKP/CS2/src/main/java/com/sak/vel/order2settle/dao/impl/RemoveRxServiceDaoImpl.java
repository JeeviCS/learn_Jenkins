
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.RemoveRxServiceDao;
import com.cvs.specialty.ordermaintenance.entity.ItemEO;
import com.cvs.specialty.ordermaintenance.entity.PreOrderDetailEO;
import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionDispensesEO;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionEO;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.repository.*;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class RemoveRxServiceDaoImpl implements RemoveRxServiceDao {

	@Autowired
	SpecialtyLogger LOGGER;

	@Autowired
	PreOrderDetailRepo preOrderDetailRepo;

	@Autowired
	PrescriptionRepo prescriptionRepo;

	@Autowired
	ItemsRepo itemsRepo;

	@SuppressWarnings("rawtypes")
	@Autowired
	PreOrderHeaderRepo preOrderHeaderRepo;
	@Autowired
	PrescriptionDispensesRepo prescriptionDispensesRepo;

	@Transactional
	@Override
	public void removeRx(Integer preOrderId, List<RxDetailsList> removeRxList) throws OrderMaintenanceException {

		LOGGER.info(LogMsgConstants.METHOD_ENTRY);

		PrescriptionEO prescriptionEO = new PrescriptionEO();
		try {
			for (int i = 0; i < removeRxList.size(); i++) {
				PrescriptionDispensesEO prescriptionDispensesEO = new PrescriptionDispensesEO();
				PreOrderDetailEO preOrderDetailEO = new PreOrderDetailEO();

				ItemEO itemEO = itemsRepo.findByItemId(removeRxList.get(i).getRx_drugIdentifier());

				prescriptionEO = prescriptionRepo.findById(removeRxList.get(i).getRx_PrescriptionIdentifier());

				if (prescriptionEO != null && itemEO != null) {

					prescriptionDispensesEO = prescriptionDispensesRepo
							.findById(removeRxList.get(i).getRx_PrescriptionDispenseIdentifier());

					preOrderDetailEO = preOrderDetailRepo.findByPreOrdrHdrIdAndRxIdAndItemAndPrescriptionDispens(
							new BigDecimal(preOrderId), new BigDecimal(prescriptionEO.getId()), itemEO,
							prescriptionDispensesEO);

					// deleting the pre-order-detail
					if (preOrderDetailEO != null) {
						preOrderDetailRepo.delete(preOrderDetailEO);
					}
				} else {
					System.out.println("exception thrown");
					throw new OrderMaintenanceException("Exception");
				}
			}
		} catch (Exception e) {
			LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
			throw new OrderMaintenanceException(e, "Exception");
		}
		LOGGER.info(LogMsgConstants.METHOD_EXIT);

	}

}
