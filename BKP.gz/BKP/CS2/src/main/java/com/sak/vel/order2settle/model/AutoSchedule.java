
package com.cvs.specialty.ordermaintenance.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AutoSchedule
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class AutoSchedule {
  @JsonProperty("patientIdentifier")
  private String patientIdentifier = null;

  @JsonProperty("orderHeader")
  private List<PreOrderHeader> orderHeader = null;

  @JsonProperty("addressSameAsPreviousAddressIndicator")
  private String addressSameAsPreviousAddressIndicator = null;

  @JsonProperty("silverLinkDeliveryDate")
  private String silverLinkDeliveryDate = null;

  @JsonProperty("arriveOnBy")
  private String arriveOnBy = null;

  @JsonProperty("shippmentMethod")
  private String shippmentMethod = null;

  @JsonProperty("signatureRequired")
  private String signatureRequired = null;

  public AutoSchedule patientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public AutoSchedule orderHeader(List<PreOrderHeader> orderHeader) {
    this.orderHeader = orderHeader;
    return this;
  }

  public AutoSchedule addOrderHeaderItem(PreOrderHeader orderHeaderItem) {
    if (this.orderHeader == null) {
      this.orderHeader = new ArrayList<PreOrderHeader>();
    }
    this.orderHeader.add(orderHeaderItem);
    return this;
  }

  /**
   * Get orderHeader
   * 
   * @return orderHeader
   **/
  @ApiModelProperty(value = "")

  @Valid

  public List<PreOrderHeader> getOrderHeader() {
    return orderHeader;
  }

  public void setOrderHeader(List<PreOrderHeader> orderHeader) {
    this.orderHeader = orderHeader;
  }

  public AutoSchedule addressSameAsPreviousAddressIndicator(
      String addressSameAsPreviousAddressIndicator) {
    this.addressSameAsPreviousAddressIndicator = addressSameAsPreviousAddressIndicator;
    return this;
  }

  /**
   * Get addressSameAsPreviousAddressIndicator
   * 
   * @return addressSameAsPreviousAddressIndicator
   **/
  @ApiModelProperty(value = "")

  public String getAddressSameAsPreviousAddressIndicator() {
    return addressSameAsPreviousAddressIndicator;
  }

  public void setAddressSameAsPreviousAddressIndicator(
      String addressSameAsPreviousAddressIndicator) {
    this.addressSameAsPreviousAddressIndicator = addressSameAsPreviousAddressIndicator;
  }

  public AutoSchedule silverLinkDeliveryDate(String silverLinkDeliveryDate) {
    this.silverLinkDeliveryDate = silverLinkDeliveryDate;
    return this;
  }

  /**
   * Get silverLinkDeliveryDate
   * 
   * @return silverLinkDeliveryDate
   **/
  @ApiModelProperty(value = "")

  public String getSilverLinkDeliveryDate() {
    return silverLinkDeliveryDate;
  }

  public void setSilverLinkDeliveryDate(String silverLinkDeliveryDate) {
    this.silverLinkDeliveryDate = silverLinkDeliveryDate;
  }

  public AutoSchedule arriveOnBy(String arriveOnBy) {
    this.arriveOnBy = arriveOnBy;
    return this;
  }

  /**
   * Get arriveOnBy
   * 
   * @return arriveOnBy
   **/
  @ApiModelProperty(value = "")

  public String getArriveOnBy() {
    return arriveOnBy;
  }

  public void setArriveOnBy(String arriveOnBy) {
    this.arriveOnBy = arriveOnBy;
  }

  public AutoSchedule shippmentMethod(String shippmentMethod) {
    this.shippmentMethod = shippmentMethod;
    return this;
  }

  /**
   * Get shippmentMethod
   * 
   * @return shippmentMethod
   **/
  @ApiModelProperty(value = "")

  public String getShippmentMethod() {
    return shippmentMethod;
  }

  public void setShippmentMethod(String shippmentMethod) {
    this.shippmentMethod = shippmentMethod;
  }

  public AutoSchedule signatureRequired(String signatureRequired) {
    this.signatureRequired = signatureRequired;
    return this;
  }

  /**
   * Get signatureRequired
   * 
   * @return signatureRequired
   **/
  @ApiModelProperty(value = "")

  public String getSignatureRequired() {
    return signatureRequired;
  }

  public void setSignatureRequired(String signatureRequired) {
    this.signatureRequired = signatureRequired;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AutoSchedule autoSchedule = (AutoSchedule) o;
    return Objects.equals(this.patientIdentifier, autoSchedule.patientIdentifier)
        && Objects.equals(this.orderHeader, autoSchedule.orderHeader)
        && Objects.equals(
          this.addressSameAsPreviousAddressIndicator,
          autoSchedule.addressSameAsPreviousAddressIndicator)
        && Objects.equals(this.silverLinkDeliveryDate, autoSchedule.silverLinkDeliveryDate)
        && Objects.equals(this.arriveOnBy, autoSchedule.arriveOnBy)
        && Objects.equals(this.shippmentMethod, autoSchedule.shippmentMethod)
        && Objects.equals(this.signatureRequired, autoSchedule.signatureRequired);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      patientIdentifier,
      orderHeader,
      addressSameAsPreviousAddressIndicator,
      silverLinkDeliveryDate,
      arriveOnBy,
      shippmentMethod,
      signatureRequired);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AutoSchedule {\n");

    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb.append("    orderHeader: ").append(toIndentedString(orderHeader)).append("\n");
    sb
      .append("    addressSameAsPreviousAddressIndicator: ")
      .append(toIndentedString(addressSameAsPreviousAddressIndicator))
      .append("\n");
    sb
      .append("    silverLinkDeliveryDate: ")
      .append(toIndentedString(silverLinkDeliveryDate))
      .append("\n");
    sb.append("    arriveOnBy: ").append(toIndentedString(arriveOnBy)).append("\n");
    sb.append("    shippmentMethod: ").append(toIndentedString(shippmentMethod)).append("\n");
    sb.append("    signatureRequired: ").append(toIndentedString(signatureRequired)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
