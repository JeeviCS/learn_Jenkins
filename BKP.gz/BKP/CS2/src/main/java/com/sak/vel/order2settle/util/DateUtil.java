package com.cvs.specialty.ordermaintenance.util;

import java.text.ParseException;
/**
 * 
 * 
 * @author Z231164
 *
 */
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

	/**
	 * 
	 */
	private DateUtil() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static final String DATE_FORMAT_DD_MMM_YY = "yyyy-MM-dd'T'HH:mm:ss";

	public static final String DATE_FORMAT_DD_MMM_YY_NEW = "dd-MM-yyyy HH:mm:ss a";
	private static final ZoneId DEFAULT_ZONE_ID = ZoneId.systemDefault();

	public static ZonedDateTime convertToZonedDateTime(Date date) {
		return convertToZonedDateTime(date, DEFAULT_ZONE_ID);
	}
	public static ZonedDateTime convertToZonedDateTime(Date date, ZoneId zoneId) {
		return ((date != null) ? ZonedDateTime.ofInstant(date.toInstant(), zoneId) : null);
	}
	public static String convertDateToString(Date date) {
		String strDate = null;
		if (date == null)
			return strDate;

		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_DD_MMM_YY);
		strDate = dateFormat.format(date);

		return strDate;

	}
	
	public static ZonedDateTime convertStringToZonedDateTime(String DateStr) {
		return ((DateStr != null) ? ZonedDateTime.parse(DateStr) : null); // TODO - Not working as expected
	}

	public static Date convertStringToDate(String date) throws ParseException {
		Date strDate = null;
		if (date == null)
			return strDate;

		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_DD_MMM_YY);
		strDate = dateFormat.parse(date);
		return strDate;

	}

	public static java.sql.Timestamp convertSQLTimestamp(Date date) {
		java.sql.Timestamp strDate = null;
		if (date == null)
			return strDate;

		return new java.sql.Timestamp(date.getTime());

	}

	public static Date removeTime(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	public static Date convertToDate(ZonedDateTime zonedDate) {
		return ((zonedDate != null) ? Date.from(zonedDate.toInstant()) : null);
	}
	public static String convertDateToString(Date date, String format) {
		String strDate = null;
		if (date == null) return strDate;

		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		strDate = dateFormat.format(date);

		return strDate;
	}

}
