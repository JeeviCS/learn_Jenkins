
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.CancelDownloadDao;
import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.model.CancelOrderDownloadSuccess;
import com.cvs.specialty.ordermaintenance.model.OrderDiversionDetails;
import com.cvs.specialty.ordermaintenance.model.RxDetails;
import com.cvs.specialty.ordermaintenance.rabbitMq.producer.Producer;
import com.cvs.specialty.ordermaintenance.service.CancelDownloadService;
import com.cvs.specialty.ordermaintenance.util.ValidationError;

@Repository
public class CancelDownloadServiceImpl implements CancelDownloadService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  CancelDownloadDao cancelDownloadDao;
  
  @Autowired
  Producer producer;

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Override
  public ResponseEntity<List<CanceDownloadReasonCodes>> cancelDownloadGet(long preOrderId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<List<CanceDownloadReasonCodes>> response = null;

    try {

      boolean validPrOrderId = validatePreOrderId(preOrderId);
      if (!validPrOrderId) {
        ValidationError error = new ValidationError("Invalid Pre Order ID", "preODerId");
        return new ResponseEntity(error, HttpStatus.NOT_ACCEPTABLE);
      }

      List<CanceDownloadReasonCodes> response_list = cancelDownloadDao
        .cancelDownloadGet(preOrderId);

      if (response_list == null) {
        response = new ResponseEntity(response_list, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response_list, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<List<CanceDownloadReasonCodes>>(HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public ResponseEntity<Void> cancelDownloadPost(Long hbsNumber, Long shipmentNumber, String cancelReason, String comment, String userId, String messageId) {
    
    //Integer status = cancelDownloadDao.updateOrderStatus(orderGuideNumber, "CANCEL_REQUESTED");
    
    List<OrderDiversionDetails> diversionDetailsList = new ArrayList<OrderDiversionDetails>();
    
    OrderDiversionDetails diversionDetails = new OrderDiversionDetails();
    diversionDetails.setFailureCode(100);
    diversionDetails.setFailureMessage("Order failed");
    diversionDetailsList.add(diversionDetails);
    
    OrderDiversionDetails diversionDetails2 = new OrderDiversionDetails();
    diversionDetails2.setFailureCode(200);
    diversionDetails2.setFailureMessage("Order download failed");
    diversionDetailsList.add(diversionDetails2);
    
    List<RxDetails> rxDetailsList = new ArrayList<RxDetails>();
    
    RxDetails rxDetails = new RxDetails();
    rxDetails.setPrescriptionDispensesId(1234L);
    rxDetails.setRxDiversionDetails(diversionDetailsList);
    rxDetailsList.add(rxDetails);
    
    CancelOrderDownloadSuccess orderDownload = new CancelOrderDownloadSuccess();
    orderDownload.setOrderGuideId(1000001L);
    orderDownload.setStatus("SUCCESS");
    orderDownload.setHbsOrderNumber(1001L);
    orderDownload.setHbsShipmentNumber(666755L);
    orderDownload.setHbsStatus("IP");
    
    orderDownload.setOrderDiversionDetailsList(diversionDetailsList);
    orderDownload.setRxDetails(rxDetails);
    
    JSONObject jsonInfo = new JSONObject();
    
    try {
      
      // Order download details
      jsonInfo.put("orderGuideID", orderDownload.getOrderGuideId());
      jsonInfo.put("status", orderDownload.getStatus());
      jsonInfo.put("HBSOrderNumber", orderDownload.getHbsOrderNumber());
      jsonInfo.put("HBSShipmentNo", orderDownload.getHbsShipmentNumber());
      jsonInfo.put("HBSStatus", orderDownload.getHbsStatus());

      // Order diversion details
      if (orderDownload.getOrderDiversionDetailsList() != null) {
        JSONArray orderDiversionDetailsArray = getDiversionDetailsArray(orderDownload.getOrderDiversionDetailsList());
        jsonInfo.put("OrderDiversionDetails", orderDiversionDetailsArray);
      }
      
      // RxTransaction details
      JSONArray rxDetailsArray = new JSONArray();
      JSONObject rxDetailsSubJson = new JSONObject();
      rxDetailsSubJson.put("prescriptionDispensesId", orderDownload.getRxDetails().getPrescriptionDispensesId());
      if(orderDownload.getOrderDiversionDetailsList() != null){
        JSONArray rxDiversionDetailsArray = getDiversionDetailsArray(orderDownload.getOrderDiversionDetailsList());
        rxDetailsSubJson.put("rxDiversionDetails", rxDiversionDetailsArray);
      }
      rxDetailsArray.put(rxDetailsSubJson);
      jsonInfo.put("rxDetails", rxDetailsArray);
      
      System.out.println("MessageDetailsJsonToString:" + jsonInfo.toString());
      
    } catch (JSONException e1) {}

    
/*    CancelOrderDownload cancelOrderDownload = new CancelOrderDownload();
    cancelOrderDownload.setHbsNumber(1L);
    cancelOrderDownload.setShipmentNumber(1000001L);
    cancelOrderDownload.setCancelReason("Cancel Requested");
    cancelOrderDownload.setComment("Order download cancelled");

    JSONObject jsonInfo = new JSONObject();
    
    try {
      
      // Order download details
      jsonInfo.put("hbsNumber", cancelOrderDownload.getHbsNumber());
      jsonInfo.put("shipmentNumber", cancelOrderDownload.getShipmentNumber());
      jsonInfo.put("cancelReason", cancelOrderDownload.getCancelReason());
      jsonInfo.put("comment", cancelOrderDownload.getComment());

      System.out.println("MessageDetailsJsonToString:" + jsonInfo.toString());
      
    } catch (JSONException e1) {}
 */ 
    producer.produce(orderDownload);
    System.out.println("MessageDetailsJsonToString after producer:" + orderDownload);
    
    
/*    if (status == 0) {
      HttpHeaders headers = new HttpHeaders();
      CancelOrderDownload orderDownload = new CancelOrderDownload();
      orderDownload.setOrderGuideNumber(orderGuideNumber);
      orderDownload.setCancelReason(cancelReason);

      headers.setContentType(MediaType.APPLICATION_JSON);
      List<MediaType> acceptHeaders = new ArrayList<MediaType>();
      acceptHeaders.add(MediaType.APPLICATION_JSON);
      headers.setAccept(acceptHeaders);
      headers.add("service-id", messageId);
      headers.add(MESSAGE_ID, messageId);

      try {
        HttpEntity<CancelOrderDownload> requestEntity = new HttpEntity<>(orderDownload, headers);
        orderDownloadRestTemplate.exchange(
                                            cancelDownloadWrapperURL,
                                            HttpMethod.PUT,
                                            requestEntity,
                                            String.class);
      } catch (Exception e) {
        status = cancelDownloadDao.updateOrderStatus(orderGuideNumber, "OPEN");
        System.out.println(e);
      }
      status = cancelDownloadDao.updateOrderStatus(orderGuideNumber, "OPEN");
    }*/
    return null;
  }
  
  private JSONArray getDiversionDetailsArray(List<OrderDiversionDetails> diversionDetailsList) {
    JSONArray diversionDetailsArray = new JSONArray();
    
    diversionDetailsList.forEach(diversionDetails -> {
      JSONObject diversionDetailsSubJson = new JSONObject();
      try {
        diversionDetailsSubJson.put("FailureCode", diversionDetails.getFailureCode());
        diversionDetailsSubJson.put("FailureMessage", diversionDetails.getFailureMessage());
      } catch (JSONException e) {}
      
      diversionDetailsArray.put(diversionDetailsSubJson);
    });
    
    return diversionDetailsArray;
  }
  
  private boolean validatePreOrderId(long preOrderId) {
    if (0L == preOrderId || preOrderId < 0)
      return false;
    else
      return true;
  }
}
