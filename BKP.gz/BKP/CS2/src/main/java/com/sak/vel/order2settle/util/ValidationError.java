
package com.cvs.specialty.ordermaintenance.util;

public class ValidationError {

  private String errorMessage;
  private String paramName;
  private int httpStatusCode = 400;

  @SuppressWarnings("unused")
  private static final long serialVersionUID = 1L;

  public ValidationError(String errorMessage, String paramName) {
    this.errorMessage = errorMessage;
    this.paramName = paramName;
  }

  public String getErrorMessage() {
    return errorMessage;
  }

  public void setErrorMessage(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  public String getParamName() {
    return paramName;
  }

  public void setParamName(String paramName) {
    this.paramName = paramName;
  }

  public int getHttpStatusCode() {
    return httpStatusCode;
  }

  public void setHttpStatusCode(int httpStatusCode) {
    this.httpStatusCode = httpStatusCode;
  }

}
