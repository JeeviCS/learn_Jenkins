package com.cvs.specialty.ordermaintenance.util;

public enum ProcessSignal {
	RESUME, CANCEL;
}
