package com.cvs.specialty.ordermaintenance.util;

public class Constants {

	
	public static final String REST_INVOCATION_ERROR = "2000099";
	
	
	public static final String MISSING_PRE_ORDER_ID =  "3000080";
	//public static final String REST_INVOCATION_ERROR = "2000099";
	//public static final String REST_INVOCATION_ERROR = "2000099";
	
	
	public static final String PRE_ORDER_ID = "preOrderId";
	//public static final String REST_INVOCATION_ERROR = "2000099";
	

}
