
package com.cvs.specialty.ordermaintenance.api;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.SplitRxOrderService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

@Controller
public class SplitOrderApiController implements SplitOrderApi {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  SplitRxOrderService splitRxOrderService;

  public ResponseEntity<Void> splitOrderPost(
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      @ApiParam(value = "Access Token", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @NotNull @ApiParam(value = "status", required = true) @RequestParam(value = "status", required = true) String status,
      @ApiParam(value = "Rx order to split", required = true) @Valid @RequestBody List<RxDetailsList> splitRx,
      @NotNull @ApiParam(value = "preOrderId", required = true) @RequestParam(value = "preOrderId", required = true) Integer preOrderId,
      HttpServletRequest request,
      HttpServletResponse response) throws OrderMaintenanceException, BindException, Exception {
    // do some magic!

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");
    try {
      splitRxOrderService.splitRxorder(splitRx, preOrderId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<Void>(HttpStatus.OK);
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }
  }

}
