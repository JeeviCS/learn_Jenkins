package com.cvs.specialty.ordermaintenance.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * OrderDownloadFailure
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-22T15:01:11.542Z")

public class OrderDownloadFailure   {
  @JsonProperty("orderGuideID")
  private Long orderGuideID = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("hbsOrderNumber")
  private Long hbsOrderNumber = null;

  @JsonProperty("hbsShipmentNo")
  private Long hbsShipmentNo = null;

  @JsonProperty("hbsStatus")
  private String hbsStatus = null;

  @JsonProperty("orderDiversionDetails")
  @Valid
  private List<OrderDiversionDetails> orderDiversionDetails = null;

  @JsonProperty("rxTransactionDetails")
  @Valid
  private List<RxTransactionDetails> rxTransactionDetails = null;

  public OrderDownloadFailure orderGuideID(Long orderGuideID) {
    this.orderGuideID = orderGuideID;
    return this;
  }

  /**
   * Get orderGuideID
   * @return orderGuideID
  **/
  @ApiModelProperty(value = "")


  public Long getOrderGuideID() {
    return orderGuideID;
  }

  public void setOrderGuideID(Long orderGuideID) {
    this.orderGuideID = orderGuideID;
  }

  public OrderDownloadFailure status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(value = "")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public OrderDownloadFailure hbsOrderNumber(Long hbsOrderNumber) {
    this.hbsOrderNumber = hbsOrderNumber;
    return this;
  }

  /**
   * Get hbsOrderNumber
   * @return hbsOrderNumber
  **/
  @ApiModelProperty(value = "")


  public Long getHbsOrderNumber() {
    return hbsOrderNumber;
  }

  public void setHbsOrderNumber(Long hbsOrderNumber) {
    this.hbsOrderNumber = hbsOrderNumber;
  }

  public OrderDownloadFailure hbsShipmentNo(Long hbsShipmentNo) {
    this.hbsShipmentNo = hbsShipmentNo;
    return this;
  }

  /**
   * Get hbsShipmentNo
   * @return hbsShipmentNo
  **/
  @ApiModelProperty(value = "")


  public Long getHbsShipmentNo() {
    return hbsShipmentNo;
  }

  public void setHbsShipmentNo(Long hbsShipmentNo) {
    this.hbsShipmentNo = hbsShipmentNo;
  }

  public OrderDownloadFailure hbsStatus(String hbsStatus) {
    this.hbsStatus = hbsStatus;
    return this;
  }

  /**
   * Get hbsStatus
   * @return hbsStatus
  **/
  @ApiModelProperty(value = "")


  public String getHbsStatus() {
    return hbsStatus;
  }

  public void setHbsStatus(String hbsStatus) {
    this.hbsStatus = hbsStatus;
  }

  public OrderDownloadFailure orderDiversionDetails(List<OrderDiversionDetails> orderDiversionDetails) {
    this.orderDiversionDetails = orderDiversionDetails;
    return this;
  }

  public OrderDownloadFailure addOrderDiversionDetailsItem(OrderDiversionDetails orderDiversionDetailsItem) {
    if (this.orderDiversionDetails == null) {
      this.orderDiversionDetails = new ArrayList<OrderDiversionDetails>();
    }
    this.orderDiversionDetails.add(orderDiversionDetailsItem);
    return this;
  }

  /**
   * Get orderDiversionDetails
   * @return orderDiversionDetails
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<OrderDiversionDetails> getOrderDiversionDetails() {
    return orderDiversionDetails;
  }

  public void setOrderDiversionDetails(List<OrderDiversionDetails> orderDiversionDetails) {
    this.orderDiversionDetails = orderDiversionDetails;
  }

  public OrderDownloadFailure rxTransactionDetails(List<RxTransactionDetails> rxTransactionDetails) {
    this.rxTransactionDetails = rxTransactionDetails;
    return this;
  }

  public OrderDownloadFailure addRxTransactionDetailsItem(RxTransactionDetails rxTransactionDetailsItem) {
    if (this.rxTransactionDetails == null) {
      this.rxTransactionDetails = new ArrayList<RxTransactionDetails>();
    }
    this.rxTransactionDetails.add(rxTransactionDetailsItem);
    return this;
  }

  /**
   * Get rxTransactionDetails
   * @return rxTransactionDetails
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<RxTransactionDetails> getRxTransactionDetails() {
    return rxTransactionDetails;
  }

  public void setRxTransactionDetails(List<RxTransactionDetails> rxTransactionDetails) {
    this.rxTransactionDetails = rxTransactionDetails;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrderDownloadFailure orderDownloadFailure = (OrderDownloadFailure) o;
    return Objects.equals(this.orderGuideID, orderDownloadFailure.orderGuideID) &&
        Objects.equals(this.status, orderDownloadFailure.status) &&
        Objects.equals(this.hbsOrderNumber, orderDownloadFailure.hbsOrderNumber) &&
        Objects.equals(this.hbsShipmentNo, orderDownloadFailure.hbsShipmentNo) &&
        Objects.equals(this.hbsStatus, orderDownloadFailure.hbsStatus) &&
        Objects.equals(this.orderDiversionDetails, orderDownloadFailure.orderDiversionDetails) &&
        Objects.equals(this.rxTransactionDetails, orderDownloadFailure.rxTransactionDetails);
  }

  @Override
  public int hashCode() {
    return Objects.hash(orderGuideID, status, hbsOrderNumber, hbsShipmentNo, hbsStatus, orderDiversionDetails, rxTransactionDetails);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OrderDownloadFailure {\n");
    
    sb.append("    orderGuideID: ").append(toIndentedString(orderGuideID)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    hbsOrderNumber: ").append(toIndentedString(hbsOrderNumber)).append("\n");
    sb.append("    hbsShipmentNo: ").append(toIndentedString(hbsShipmentNo)).append("\n");
    sb.append("    hbsStatus: ").append(toIndentedString(hbsStatus)).append("\n");
    sb.append("    orderDiversionDetails: ").append(toIndentedString(orderDiversionDetails)).append("\n");
    sb.append("    rxTransactionDetails: ").append(toIndentedString(rxTransactionDetails)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

