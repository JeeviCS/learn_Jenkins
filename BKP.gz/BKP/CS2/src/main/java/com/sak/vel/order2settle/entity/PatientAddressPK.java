package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the PATIENT_ADDRESSES database table.
 * 
 */
@Embeddable
public class PatientAddressPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PATIENT_ID", insertable=false, updatable=false)
	private long patientId;

	@Column(name="ADDRESS_SEQ_NO")
	private long addressSeqNo;

	public PatientAddressPK() {
	}
	public long getPatientId() {
		return this.patientId;
	}
	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}
	public long getAddressSeqNo() {
		return this.addressSeqNo;
	}
	public void setAddressSeqNo(long addressSeqNo) {
		this.addressSeqNo = addressSeqNo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof PatientAddressPK)) {
			return false;
		}
		PatientAddressPK castOther = (PatientAddressPK)other;
		return 
			(this.patientId == castOther.patientId)
			&& (this.addressSeqNo == castOther.addressSeqNo);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.patientId ^ (this.patientId >>> 32)));
		hash = hash * prime + ((int) (this.addressSeqNo ^ (this.addressSeqNo >>> 32)));
		
		return hash;
	}
}