
package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.model.RxDetailsList;

public interface RemoveRxServiceDao {

	void removeRx(Integer preOrderId, List<RxDetailsList> removeRxList);
}
