package com.cvs.specialty.ordermaintenance.model;


import java.time.ZonedDateTime;
import java.util.Objects;

import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeDeserializer;
import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeSerializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModelProperty;

/**
 * Task
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-02T22:17:30.322Z")

public class Task   {
  @JsonProperty("taskInstanceMapId")
  private Long taskInstanceMapId = null;

  @JsonProperty("queueTaskId")
  private Long queueTaskId = null;

  @JsonProperty("processInstanceMapId")
  private Long processInstanceMapId = null;

  @JsonProperty("bpmTaskName")
  private String bpmTaskName = null;

  @JsonProperty("bpmTaskInstanceId")
  private Long bpmTaskInstanceId = null;

  @JsonProperty("bpmTaskStatusCode")
  private String bpmTaskStatusCode = null;

  @JsonProperty("completeTaskUserId")
  private String completeTaskUserId = null;

  @JsonProperty("completionTimestamp")
 	@JsonSerialize(using = ZonedDateTimeSerializer.class)
 	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
  private ZonedDateTime completionTimestamp = null;

  @JsonProperty("followUpTimestamp")
	@JsonSerialize(using = ZonedDateTimeSerializer.class)
	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
  private ZonedDateTime followUpTimestamp = null;

  @JsonProperty("entityId")
  private Long entityId = null;

  @JsonProperty("entityType")
  private String entityType = null;

  @JsonProperty("bpmProcessName")
  private String bpmProcessName = null;

  @JsonProperty("bpmProcessInstanceId")
  private Long bpmProcessInstanceId = null;

  @JsonProperty("intakeReferralId")
  private Long intakeReferralId = null;

  @JsonProperty("patientId")
  private Long patientId = null;

  @JsonProperty("prescriberId")
  private Long prescriberId = null;

  @JsonProperty("siteId")
  private Long siteId = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("createdUserName")
  private String createdUserName = null;

  @JsonProperty("createdTimeStamp")
	@JsonSerialize(using = ZonedDateTimeSerializer.class)
	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
  private ZonedDateTime createdTimeStamp = null;

  @JsonProperty("updatedUserName")
  private String updatedUserName = null;

  @JsonProperty("updatedTimeStamp")
 	@JsonSerialize(using = ZonedDateTimeSerializer.class)
 	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
  private ZonedDateTime updatedTimeStamp = null;

	@JsonProperty("actionId")
	private Long actionId = null;
	
	@JsonProperty("actionType")
	private String actionType = null;
	
	@JsonProperty("outcomeId")
	private Long outcomeId= null;
	
	@JsonProperty("followUpDate")
	@JsonSerialize(using = ZonedDateTimeSerializer.class)
	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
	private ZonedDateTime followUpDate = null;
	
	
	@JsonProperty("comments")
	private String comments= null;

	@JsonProperty("entityBpmProcessMapId")
	private Long entityBpmProcessMapId = null;
	
    @JsonProperty("queueTaskStatusCode")
	private String queueTaskStatusCode = null;
    
    @JsonProperty("ndc")
    private String ndc = null;
	
  public Task taskInstanceMapId(Long taskInstanceMapId) {
    this.taskInstanceMapId = taskInstanceMapId;
    return this;
  }
  
  
  
	
   /**
   * Get taskInstanceMapId
   * @return taskInstanceMapId
  **/
  @ApiModelProperty(value = "")


  public Long getTaskInstanceMapId() {
    return taskInstanceMapId;
  }

  public void setTaskInstanceMapId(Long taskInstanceMapId) {
    this.taskInstanceMapId = taskInstanceMapId;
  }

  public Task queueTaskId(Long queueTaskId) {
    this.queueTaskId = queueTaskId;
    return this;
  }

   /**
   * Get queueTaskId
   * @return queueTaskId
  **/
  @ApiModelProperty(value = "")


  public Long getQueueTaskId() {
    return queueTaskId;
  }

  public void setQueueTaskId(Long queueTaskId) {
    this.queueTaskId = queueTaskId;
  }

  public Task processInstanceMapId(Long processInstanceMapId) {
    this.processInstanceMapId = processInstanceMapId;
    return this;
  }

   /**
   * Get processInstanceMapId
   * @return processInstanceMapId
  **/
  @ApiModelProperty(value = "")


  public Long getProcessInstanceMapId() {
    return processInstanceMapId;
  }

  public void setProcessInstanceMapId(Long processInstanceMapId) {
    this.processInstanceMapId = processInstanceMapId;
  }

  public Task bpmTaskName(String bpmTaskName) {
    this.bpmTaskName = bpmTaskName;
    return this;
  }

   /**
   * Get bpmTaskName
   * @return bpmTaskName
  **/
  @ApiModelProperty(value = "")


  public String getBpmTaskName() {
    return bpmTaskName;
  }

  public void setBpmTaskName(String bpmTaskName) {
    this.bpmTaskName = bpmTaskName;
  }

  public Task bpmTaskInstanceId(Long bpmTaskInstanceId) {
    this.bpmTaskInstanceId = bpmTaskInstanceId;
    return this;
  }

   /**
   * Get bpmTaskInstanceId
   * @return bpmTaskInstanceId
  **/
  @ApiModelProperty(value = "")


  public Long getBpmTaskInstanceId() {
    return bpmTaskInstanceId;
  }

  public void setBpmTaskInstanceId(Long bpmTaskInstanceId) {
    this.bpmTaskInstanceId = bpmTaskInstanceId;
  }

  public Task bpmTaskStatusCode(String bpmTaskStatusCode) {
    this.bpmTaskStatusCode = bpmTaskStatusCode;
    return this;
  }

   /**
   * Get bpmTaskStatusCode
   * @return bpmTaskStatusCode
  **/
  @ApiModelProperty(value = "")


  public String getBpmTaskStatusCode() {
    return bpmTaskStatusCode;
  }

  public void setBpmTaskStatusCode(String bpmTaskStatusCode) {
    this.bpmTaskStatusCode = bpmTaskStatusCode;
  }

  public Task completeTaskUserId(String completeTaskUserId) {
    this.completeTaskUserId = completeTaskUserId;
    return this;
  }

   /**
   * Get completeTaskUserId
   * @return completeTaskUserId
  **/
  @ApiModelProperty(value = "")


  public String getCompleteTaskUserId() {
    return completeTaskUserId;
  }

  public void setCompleteTaskUserId(String completeTaskUserId) {
    this.completeTaskUserId = completeTaskUserId;
  }

  public Task completionTimestamp(ZonedDateTime completionTimestamp) {
    this.completionTimestamp = completionTimestamp;
    return this;
  }

   /**
   * Get completionTimestamp
   * @return completionTimestamp
  **/
  @ApiModelProperty(value = "")


  public ZonedDateTime getCompletionTimestamp() {
    return completionTimestamp;
  }

  public void setCompletionTimestamp(ZonedDateTime completionTimestamp) {
    this.completionTimestamp = completionTimestamp;
  }

  public Task followUpTimestamp(ZonedDateTime followUpTimestamp) {
    this.followUpTimestamp = followUpTimestamp;
    return this;
  }

   /**
   * Get followUpTimestamp
   * @return followUpTimestamp
  **/
  @ApiModelProperty(value = "")


  public ZonedDateTime getFollowUpTimestamp() {
    return followUpTimestamp;
  }

  public void setFollowUpTimestamp(ZonedDateTime followUpTimestamp) {
    this.followUpTimestamp = followUpTimestamp;
  }

  public Task entityId(Long entityId) {
    this.entityId = entityId;
    return this;
  }

   /**
   * Get entityId
   * @return entityId
  **/
  @ApiModelProperty(value = "")


  public Long getEntityId() {
    return entityId;
  }

  public void setEntityId(Long entityId) {
    this.entityId = entityId;
  }

  public Task entityType(String entityType) {
    this.entityType = entityType;
    return this;
  }

   /**
   * Get entityType
   * @return entityType
  **/
  @ApiModelProperty(value = "")


  public String getEntityType() {
    return entityType;
  }

  public void setEntityType(String entityType) {
    this.entityType = entityType;
  }

  public Task bpmProcessName(String bpmProcessName) {
    this.bpmProcessName = bpmProcessName;
    return this;
  }

   /**
   * Get bpmProcessName
   * @return bpmProcessName
  **/
  @ApiModelProperty(value = "")


  public String getBpmProcessName() {
    return bpmProcessName;
  }

  public void setBpmProcessName(String bpmProcessName) {
    this.bpmProcessName = bpmProcessName;
  }

  public Task bpmProcessInstanceId(Long bpmProcessInstanceId) {
    this.bpmProcessInstanceId = bpmProcessInstanceId;
    return this;
  }

   /**
   * Get bpmProcessInstanceId
   * @return bpmProcessInstanceId
  **/
  @ApiModelProperty(value = "")


  public Long getBpmProcessInstanceId() {
    return bpmProcessInstanceId;
  }

  public void setBpmProcessInstanceId(Long bpmProcessInstanceId) {
    this.bpmProcessInstanceId = bpmProcessInstanceId;
  }

  public Task intakeReferralId(Long intakeReferralId) {
    this.intakeReferralId = intakeReferralId;
    return this;
  }

   /**
   * Get intakeReferralId
   * @return intakeReferralId
  **/
  @ApiModelProperty(value = "")


  public Long getIntakeReferralId() {
    return intakeReferralId;
  }

  public void setIntakeReferralId(Long intakeReferralId) {
    this.intakeReferralId = intakeReferralId;
  }

  public Task patientId(Long patientId) {
    this.patientId = patientId;
    return this;
  }

   /**
   * Get patientId
   * @return patientId
  **/
  @ApiModelProperty(value = "")


  public Long getPatientId() {
    return patientId;
  }

  public void setPatientId(Long patientId) {
    this.patientId = patientId;
  }

  public Task prescriberId(Long prescriberId) {
    this.prescriberId = prescriberId;
    return this;
  }

   /**
   * Get prescriberId
   * @return prescriberId
  **/
  @ApiModelProperty(value = "")


  public Long getPrescriberId() {
    return prescriberId;
  }

  public void setPrescriberId(Long prescriberId) {
    this.prescriberId = prescriberId;
  }

  public Task siteId(Long siteId) {
    this.siteId = siteId;
    return this;
  }

   /**
   * Get siteId
   * @return siteId
  **/
  @ApiModelProperty(value = "")


  public Long getSiteId() {
    return siteId;
  }

  public void setSiteId(Long siteId) {
    this.siteId = siteId;
  }

  public Task activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

   /**
   * Get activeIndicator
   * @return activeIndicator
  **/
  @ApiModelProperty(value = "")


  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public Task createdUserName(String createdUserName) {
    this.createdUserName = createdUserName;
    return this;
  }

   /**
   * Get createdUserName
   * @return createdUserName
  **/
  @ApiModelProperty(value = "")


  public String getCreatedUserName() {
    return createdUserName;
  }

  public void setCreatedUserName(String createdUserName) {
    this.createdUserName = createdUserName;
  }

  public Task createdTimeStamp(ZonedDateTime createdTimeStamp) {
    this.createdTimeStamp = createdTimeStamp;
    return this;
  }

   /**
   * Get createdTimeStamp
   * @return createdTimeStamp
  **/
  @ApiModelProperty(value = "")


  public ZonedDateTime getCreatedTimeStamp() {
    return createdTimeStamp;
  }

  public void setCreatedTimeStamp(ZonedDateTime createdTimeStamp) {
    this.createdTimeStamp = createdTimeStamp;
  }

  public Task updatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
    return this;
  }

   /**
   * Get updatedUserName
   * @return updatedUserName
  **/
  @ApiModelProperty(value = "")


  public String getUpdatedUserName() {
    return updatedUserName;
  }

  public void setUpdatedUserName(String updatedUserName) {
    this.updatedUserName = updatedUserName;
  }

  public Task updatedTimeStamp(ZonedDateTime updatedTimeStamp) {
    this.updatedTimeStamp = updatedTimeStamp;
    return this;
  }

   /**
   * Get updatedTimeStamp
   * @return updatedTimeStamp
  **/
  @ApiModelProperty(value = "")


  public ZonedDateTime getUpdatedTimeStamp() {
    return updatedTimeStamp;
  }

  public void setUpdatedTimeStamp(ZonedDateTime updatedTimeStamp) {
    this.updatedTimeStamp = updatedTimeStamp;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Task task = (Task) o;
    return Objects.equals(this.taskInstanceMapId, task.taskInstanceMapId) &&
        Objects.equals(this.queueTaskId, task.queueTaskId) &&
        Objects.equals(this.processInstanceMapId, task.processInstanceMapId) &&
        Objects.equals(this.bpmTaskName, task.bpmTaskName) &&
        Objects.equals(this.bpmTaskInstanceId, task.bpmTaskInstanceId) &&
        Objects.equals(this.bpmTaskStatusCode, task.bpmTaskStatusCode) &&
        Objects.equals(this.completeTaskUserId, task.completeTaskUserId) &&
        Objects.equals(this.completionTimestamp, task.completionTimestamp) &&
        Objects.equals(this.followUpTimestamp, task.followUpTimestamp) &&
        Objects.equals(this.entityId, task.entityId) &&
        Objects.equals(this.entityType, task.entityType) &&
        Objects.equals(this.bpmProcessName, task.bpmProcessName) &&
        Objects.equals(this.bpmProcessInstanceId, task.bpmProcessInstanceId) &&
        Objects.equals(this.intakeReferralId, task.intakeReferralId) &&
        Objects.equals(this.patientId, task.patientId) &&
        Objects.equals(this.prescriberId, task.prescriberId) &&
        Objects.equals(this.siteId, task.siteId) &&
        Objects.equals(this.activeIndicator, task.activeIndicator) &&
        Objects.equals(this.createdUserName, task.createdUserName) &&
        Objects.equals(this.createdTimeStamp, task.createdTimeStamp) &&
        Objects.equals(this.updatedUserName, task.updatedUserName) &&
        Objects.equals(this.updatedTimeStamp, task.updatedTimeStamp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(taskInstanceMapId, queueTaskId, processInstanceMapId, bpmTaskName, bpmTaskInstanceId, bpmTaskStatusCode, completeTaskUserId, completionTimestamp, followUpTimestamp, entityId, entityType, bpmProcessName, bpmProcessInstanceId, intakeReferralId, patientId, prescriberId, siteId, activeIndicator, createdUserName, createdTimeStamp, updatedUserName, updatedTimeStamp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Task {\n");
    
    sb.append("    taskInstanceMapId: ").append(toIndentedString(taskInstanceMapId)).append("\n");
    sb.append("    queueTaskId: ").append(toIndentedString(queueTaskId)).append("\n");
    sb.append("    processInstanceMapId: ").append(toIndentedString(processInstanceMapId)).append("\n");
    sb.append("    bpmTaskName: ").append(toIndentedString(bpmTaskName)).append("\n");
    sb.append("    bpmTaskInstanceId: ").append(toIndentedString(bpmTaskInstanceId)).append("\n");
    sb.append("    bpmTaskStatusCode: ").append(toIndentedString(bpmTaskStatusCode)).append("\n");
    sb.append("    completeTaskUserId: ").append(toIndentedString(completeTaskUserId)).append("\n");
    sb.append("    completionTimestamp: ").append(toIndentedString(completionTimestamp)).append("\n");
    sb.append("    followUpTimestamp: ").append(toIndentedString(followUpTimestamp)).append("\n");
    sb.append("    entityId: ").append(toIndentedString(entityId)).append("\n");
    sb.append("    entityType: ").append(toIndentedString(entityType)).append("\n");
    sb.append("    bpmProcessName: ").append(toIndentedString(bpmProcessName)).append("\n");
    sb.append("    bpmProcessInstanceId: ").append(toIndentedString(bpmProcessInstanceId)).append("\n");
    sb.append("    intakeReferralId: ").append(toIndentedString(intakeReferralId)).append("\n");
    sb.append("    patientId: ").append(toIndentedString(patientId)).append("\n");
    sb.append("    prescriberId: ").append(toIndentedString(prescriberId)).append("\n");
    sb.append("    siteId: ").append(toIndentedString(siteId)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    createdUserName: ").append(toIndentedString(createdUserName)).append("\n");
    sb.append("    createdTimeStamp: ").append(toIndentedString(createdTimeStamp)).append("\n");
    sb.append("    updatedUserName: ").append(toIndentedString(updatedUserName)).append("\n");
    sb.append("    updatedTimeStamp: ").append(toIndentedString(updatedTimeStamp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }




public Long getActionId() {
	return actionId;
}




public void setActionId(Long actionId) {
	this.actionId = actionId;
}

public String getActionType() {
	return actionType;
}

public void setActionType(String actionType) {
	this.actionType = actionType;
}


public Long getOutcomeId() {
	return outcomeId;
}




public void setOutcomeId(Long outcomeId) {
	this.outcomeId = outcomeId;
}




public ZonedDateTime getFollowUpDate() {
	return followUpDate;
}




public void setFollowUpDate(ZonedDateTime followUpDate) {
	this.followUpDate = followUpDate;
}




public String getComments() {
	return comments;
}




public void setComments(String comments) {
	this.comments = comments;
}




public Long getEntityBpmProcessMapId() {
	return entityBpmProcessMapId;
}




public void setEntityBpmProcessMapId(Long entityBpmProcessMapId) {
	this.entityBpmProcessMapId = entityBpmProcessMapId;
}




public String getQueueTaskStatusCode() {
	return queueTaskStatusCode;
}




public void setQueueTaskStatusCode(String queueTaskStatusCode) {
	this.queueTaskStatusCode = queueTaskStatusCode;
}




public String getNdc() {
	return ndc;
}




public void setNdc(String ndc) {
	this.ndc = ndc;
}
}

