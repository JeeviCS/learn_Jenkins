
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * AlertsLog
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class AlertsLog {
  @JsonProperty("alertLogIdentifier")
  private String alertLogIdentifier = null;

  @JsonProperty("specialtyBuisnessProcessRuleIdentifier")
  private String specialtyBuisnessProcessRuleIdentifier = null;

  @JsonProperty("alertIdentifier")
  private String alertIdentifier = null;

  @JsonProperty("alertReasonText")
  private String alertReasonText = null;

  @JsonProperty("diversionIndicator")
  private String diversionIndicator = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("specialtyBuisnessProcessBPMProcessMap")
  private SpecialtyBuisnessProcessBPMProcessMap specialtyBuisnessProcessBPMProcessMap = null;

  @JsonProperty("specialtyBuisnessProcessRules")
  private SpecialtyBuisnessProcessRules specialtyBuisnessProcessRules = null;

  public AlertsLog alertLogIdentifier(String alertLogIdentifier) {
    this.alertLogIdentifier = alertLogIdentifier;
    return this;
  }

  /**
   * Get alertLogIdentifier
   * 
   * @return alertLogIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getAlertLogIdentifier() {
    return alertLogIdentifier;
  }

  public void setAlertLogIdentifier(String alertLogIdentifier) {
    this.alertLogIdentifier = alertLogIdentifier;
  }

  public AlertsLog specialtyBuisnessProcessRuleIdentifier(
      String specialtyBuisnessProcessRuleIdentifier) {
    this.specialtyBuisnessProcessRuleIdentifier = specialtyBuisnessProcessRuleIdentifier;
    return this;
  }

  /**
   * Get specialtyBuisnessProcessRuleIdentifier
   * 
   * @return specialtyBuisnessProcessRuleIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSpecialtyBuisnessProcessRuleIdentifier() {
    return specialtyBuisnessProcessRuleIdentifier;
  }

  public void setSpecialtyBuisnessProcessRuleIdentifier(
      String specialtyBuisnessProcessRuleIdentifier) {
    this.specialtyBuisnessProcessRuleIdentifier = specialtyBuisnessProcessRuleIdentifier;
  }

  public AlertsLog alertIdentifier(String alertIdentifier) {
    this.alertIdentifier = alertIdentifier;
    return this;
  }

  /**
   * Get alertIdentifier
   * 
   * @return alertIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getAlertIdentifier() {
    return alertIdentifier;
  }

  public void setAlertIdentifier(String alertIdentifier) {
    this.alertIdentifier = alertIdentifier;
  }

  public AlertsLog alertReasonText(String alertReasonText) {
    this.alertReasonText = alertReasonText;
    return this;
  }

  /**
   * Get alertReasonText
   * 
   * @return alertReasonText
   **/
  @ApiModelProperty(value = "")

  public String getAlertReasonText() {
    return alertReasonText;
  }

  public void setAlertReasonText(String alertReasonText) {
    this.alertReasonText = alertReasonText;
  }

  public AlertsLog diversionIndicator(String diversionIndicator) {
    this.diversionIndicator = diversionIndicator;
    return this;
  }

  /**
   * Get diversionIndicator
   * 
   * @return diversionIndicator
   **/
  @ApiModelProperty(value = "")

  public String getDiversionIndicator() {
    return diversionIndicator;
  }

  public void setDiversionIndicator(String diversionIndicator) {
    this.diversionIndicator = diversionIndicator;
  }

  public AlertsLog activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public AlertsLog specialtyBuisnessProcessBPMProcessMap(
      SpecialtyBuisnessProcessBPMProcessMap specialtyBuisnessProcessBPMProcessMap) {
    this.specialtyBuisnessProcessBPMProcessMap = specialtyBuisnessProcessBPMProcessMap;
    return this;
  }

  /**
   * Get specialtyBuisnessProcessBPMProcessMap
   * 
   * @return specialtyBuisnessProcessBPMProcessMap
   **/
  @ApiModelProperty(value = "")

  @Valid

  public SpecialtyBuisnessProcessBPMProcessMap getSpecialtyBuisnessProcessBPMProcessMap() {
    return specialtyBuisnessProcessBPMProcessMap;
  }

  public void setSpecialtyBuisnessProcessBPMProcessMap(
      SpecialtyBuisnessProcessBPMProcessMap specialtyBuisnessProcessBPMProcessMap) {
    this.specialtyBuisnessProcessBPMProcessMap = specialtyBuisnessProcessBPMProcessMap;
  }

  public AlertsLog specialtyBuisnessProcessRules(
      SpecialtyBuisnessProcessRules specialtyBuisnessProcessRules) {
    this.specialtyBuisnessProcessRules = specialtyBuisnessProcessRules;
    return this;
  }

  /**
   * Get specialtyBuisnessProcessRules
   * 
   * @return specialtyBuisnessProcessRules
   **/
  @ApiModelProperty(value = "")

  @Valid

  public SpecialtyBuisnessProcessRules getSpecialtyBuisnessProcessRules() {
    return specialtyBuisnessProcessRules;
  }

  public void setSpecialtyBuisnessProcessRules(
      SpecialtyBuisnessProcessRules specialtyBuisnessProcessRules) {
    this.specialtyBuisnessProcessRules = specialtyBuisnessProcessRules;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AlertsLog alertsLog = (AlertsLog) o;
    return Objects.equals(this.alertLogIdentifier, alertsLog.alertLogIdentifier)
        && Objects.equals(
          this.specialtyBuisnessProcessRuleIdentifier,
          alertsLog.specialtyBuisnessProcessRuleIdentifier)
        && Objects.equals(this.alertIdentifier, alertsLog.alertIdentifier)
        && Objects.equals(this.alertReasonText, alertsLog.alertReasonText)
        && Objects.equals(this.diversionIndicator, alertsLog.diversionIndicator)
        && Objects.equals(this.activeIndicator, alertsLog.activeIndicator)
        && Objects.equals(
          this.specialtyBuisnessProcessBPMProcessMap,
          alertsLog.specialtyBuisnessProcessBPMProcessMap)
        && Objects
          .equals(this.specialtyBuisnessProcessRules, alertsLog.specialtyBuisnessProcessRules);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      alertLogIdentifier,
      specialtyBuisnessProcessRuleIdentifier,
      alertIdentifier,
      alertReasonText,
      diversionIndicator,
      activeIndicator,
      specialtyBuisnessProcessBPMProcessMap,
      specialtyBuisnessProcessRules);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AlertsLog {\n");

    sb.append("    alertLogIdentifier: ").append(toIndentedString(alertLogIdentifier)).append("\n");
    sb
      .append("    specialtyBuisnessProcessRuleIdentifier: ")
      .append(toIndentedString(specialtyBuisnessProcessRuleIdentifier))
      .append("\n");
    sb.append("    alertIdentifier: ").append(toIndentedString(alertIdentifier)).append("\n");
    sb.append("    alertReasonText: ").append(toIndentedString(alertReasonText)).append("\n");
    sb.append("    diversionIndicator: ").append(toIndentedString(diversionIndicator)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb
      .append("    specialtyBuisnessProcessBPMProcessMap: ")
      .append(toIndentedString(specialtyBuisnessProcessBPMProcessMap))
      .append("\n");
    sb
      .append("    specialtyBuisnessProcessRules: ")
      .append(toIndentedString(specialtyBuisnessProcessRules))
      .append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
