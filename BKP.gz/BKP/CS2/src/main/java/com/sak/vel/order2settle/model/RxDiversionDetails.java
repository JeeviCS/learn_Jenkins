package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RxDiversionDetails
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-19T16:52:21.883Z")

public class RxDiversionDetails   {
  @JsonProperty("failureConfigID")
  private Long failureConfigID = null;

  @JsonProperty("OverrideInd")
  private String overrideInd = null;

  @JsonProperty("OverrideDateTime")
  private String overrideDateTime = null;

  public RxDiversionDetails failureConfigID(Long failureConfigID) {
    this.failureConfigID = failureConfigID;
    return this;
  }

  /**
   * Get failureConfigID
   * @return failureConfigID
  **/
  @ApiModelProperty(value = "")


  public Long getFailureConfigID() {
    return failureConfigID;
  }

  public void setFailureConfigID(Long failureConfigID) {
    this.failureConfigID = failureConfigID;
  }

  public RxDiversionDetails overrideInd(String overrideInd) {
    this.overrideInd = overrideInd;
    return this;
  }

  /**
   * Get overrideInd
   * @return overrideInd
  **/
  @ApiModelProperty(value = "")


  public String getOverrideInd() {
    return overrideInd;
  }

  public void setOverrideInd(String overrideInd) {
    this.overrideInd = overrideInd;
  }

  public RxDiversionDetails overrideDateTime(String overrideDateTime) {
    this.overrideDateTime = overrideDateTime;
    return this;
  }

  /**
   * Get overrideDateTime
   * @return overrideDateTime
  **/
  @ApiModelProperty(value = "")


  public String getOverrideDateTime() {
    return overrideDateTime;
  }

  public void setOverrideDateTime(String overrideDateTime) {
    this.overrideDateTime = overrideDateTime;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RxDiversionDetails rxDiversionDetails = (RxDiversionDetails) o;
    return Objects.equals(this.failureConfigID, rxDiversionDetails.failureConfigID) &&
        Objects.equals(this.overrideInd, rxDiversionDetails.overrideInd) &&
        Objects.equals(this.overrideDateTime, rxDiversionDetails.overrideDateTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(failureConfigID, overrideInd, overrideDateTime);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RxDiversionDetails {\n");
    
    sb.append("    failureConfigID: ").append(toIndentedString(failureConfigID)).append("\n");
    sb.append("    overrideInd: ").append(toIndentedString(overrideInd)).append("\n");
    sb.append("    overrideDateTime: ").append(toIndentedString(overrideDateTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

