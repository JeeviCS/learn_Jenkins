package com.cvs.specialty.ordermaintenance.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.SbpWorkQueueTaskBpmTask;

@Repository
@Transactional
public interface CancelListOfTasksRepo extends CrudRepository<SbpWorkQueueTaskBpmTask, Long> {

	@Modifying(clearAutomatically = true)	
	@Query("UPDATE SbpWorkQueueTaskBpmTask bpm SET bpm.ptntNtfidIn = :patFlag, bpm.hltcrPrfsnNtfidIn= :MDFlag, bpm.sbpQueTaskStusCd= :status, bpm.actvIn= :actvIn, bpm.sbpQueTaskStusRsnCd= :sbpQueTaskStusRsnCd,bpm.updUsrNm= :userId WHERE bpm.sbpWrkQueTaskBpmTaskId IN :taskIdList")
	void updateTaskCancel(@Param("patFlag") String patFlag, @Param("MDFlag") String MDFlag, @Param("status") String status, @Param("actvIn") String actvIn, @Param("taskIdList") List<Long> taskIdList,@Param("sbpQueTaskStusRsnCd") String sbpQueTaskStusRsnCd,
			@Param("userId") String userId);		

}
