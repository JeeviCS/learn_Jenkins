
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.dao.TaskManualDao;
import com.cvs.specialty.ordermaintenance.model.TaskLists;
import com.cvs.specialty.ordermaintenance.repository.ListOfTasksRepo;

@Service
public class TaskManualDaoImpl implements TaskManualDao {
	@Autowired
	SpecialtyLogger serviceLogger;
	@Autowired
	ListOfTasksRepo listOfTasksRepo;


	@Override
	public List<TaskLists> getListofTasks( String orderId) {

		List<TaskLists> listOfTasks = new ArrayList<TaskLists>();
		try {
			serviceLogger.info("Getting list of tasks");
			List<Object[]> resultSet = listOfTasksRepo.findBypreOrdrHdrId(Long.parseLong(orderId));
			if (!resultSet.isEmpty() && resultSet.size()>0) {
				for (Object[] entity : resultSet) {

					TaskLists task =new TaskLists();
					if(entity[0]!=null)  {task.setQueueTaskId((Long.valueOf(entity[0].toString())));
					}if(entity[1]!=null)  {task.setProcessInstanceMapId(Long.valueOf(entity[1].toString()));
					}if(entity[2]!=null)  {task.setBpmTaskInstanceId(Long.valueOf(entity[2].toString()));
					}/*if(entity[3]!=null)  {task.setFlupTs(Timestamp.valueOf(entity[3].toString()));
					}*/if(entity[4]!=null)  {task.setQueueTaskStatusCode((String) entity[4]);
					}/*if(entity[5]!=null)  {task.setUsrCmntTx((String) entity[4]);
					}if(entity[6]!=null)  {task.setUsrCmntTx((String) entity[4]);
					}*/
					listOfTasks.add(task)	;	}
			} else {
				serviceLogger.info("No Task records found for OrderId: "+orderId);
			}

		} catch (DataAccessException ex) {
			serviceLogger.error("Failed to get list of tasks "+ ex.getMessage());
		}
		return listOfTasks;
	}

	@Override
	public List<TaskLists> getListofUnassignedTasks(String orderId) {

		List<TaskLists> listOfTasks = new ArrayList<TaskLists>();
		try {
			serviceLogger.info("Getting list of Unassigned tasks");
			List<Object[]> resultSet = listOfTasksRepo.findUnassignedTask(Long.parseLong(orderId));
			if (!resultSet.isEmpty() && resultSet.size()>0) {
				for (Object[] entity : resultSet) {

					TaskLists task =new TaskLists();
					if(entity[0]!=null)  {task.setQueueTaskId((Long.valueOf(entity[0].toString())));
					}if(entity[1]!=null)  {task.setProcessInstanceMapId(Long.valueOf(entity[1].toString()));
					}if(entity[2]!=null)  {task.setBpmTaskInstanceId(Long.valueOf(entity[2].toString()));
					}if(entity[3]!=null)  {task.setBpmTaskName(entity[3].toString());
					}if(entity[4]!=null)  {task.setQueueTaskStatusCode((String) entity[4]);
					}/*if(entity[5]!=null)  {task.setUsrCmntTx((String) entity[4]);
					}if(entity[6]!=null)  {task.setUsrCmntTx((String) entity[4]);
					}*/
					listOfTasks.add(task)	;	}
			} else {
				serviceLogger.info("No Unassigned Task found for OrderId: "+orderId);
			}

		} catch (DataAccessException ex) {
			serviceLogger.error("Failed to get list of tasks "+ ex.getMessage());
		}
		return listOfTasks;
	}

}
