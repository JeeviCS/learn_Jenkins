
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * PatientSpecialAccount
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class PatientSpecialAccount {
  @JsonProperty("patientSpecialAccountIdentifier")
  private Long patientSpecialAccountIdentifier = null;

  @JsonProperty("patientIdentifier")
  private Long patientIdentifier = null;

  @JsonProperty("sourceSystemPatientSpecialAcntNum")
  private Long sourceSystemPatientSpecialAcntNum = null;

  @JsonProperty("sourceSystemName")
  private String sourceSystemName = null;

  @JsonProperty("specialAccountCode")
  private String specialAccountCode = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public PatientSpecialAccount patientSpecialAccountIdentifier(
      Long patientSpecialAccountIdentifier) {
    this.patientSpecialAccountIdentifier = patientSpecialAccountIdentifier;
    return this;
  }

  /**
   * Get patientSpecialAccountIdentifier
   * 
   * @return patientSpecialAccountIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getPatientSpecialAccountIdentifier() {
    return patientSpecialAccountIdentifier;
  }

  public void setPatientSpecialAccountIdentifier(Long patientSpecialAccountIdentifier) {
    this.patientSpecialAccountIdentifier = patientSpecialAccountIdentifier;
  }

  public PatientSpecialAccount patientIdentifier(Long patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public Long getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(Long patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public PatientSpecialAccount sourceSystemPatientSpecialAcntNum(
      Long sourceSystemPatientSpecialAcntNum) {
    this.sourceSystemPatientSpecialAcntNum = sourceSystemPatientSpecialAcntNum;
    return this;
  }

  /**
   * Get sourceSystemPatientSpecialAcntNum
   * 
   * @return sourceSystemPatientSpecialAcntNum
   **/
  @ApiModelProperty(value = "")

  public Long getSourceSystemPatientSpecialAcntNum() {
    return sourceSystemPatientSpecialAcntNum;
  }

  public void setSourceSystemPatientSpecialAcntNum(Long sourceSystemPatientSpecialAcntNum) {
    this.sourceSystemPatientSpecialAcntNum = sourceSystemPatientSpecialAcntNum;
  }

  public PatientSpecialAccount sourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
    return this;
  }

  /**
   * Get sourceSystemName
   * 
   * @return sourceSystemName
   **/
  @ApiModelProperty(value = "")

  public String getSourceSystemName() {
    return sourceSystemName;
  }

  public void setSourceSystemName(String sourceSystemName) {
    this.sourceSystemName = sourceSystemName;
  }

  public PatientSpecialAccount specialAccountCode(String specialAccountCode) {
    this.specialAccountCode = specialAccountCode;
    return this;
  }

  /**
   * Get specialAccountCode
   * 
   * @return specialAccountCode
   **/
  @ApiModelProperty(value = "")

  public String getSpecialAccountCode() {
    return specialAccountCode;
  }

  public void setSpecialAccountCode(String specialAccountCode) {
    this.specialAccountCode = specialAccountCode;
  }

  public PatientSpecialAccount audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PatientSpecialAccount patientSpecialAccount = (PatientSpecialAccount) o;
    return Objects.equals(
      this.patientSpecialAccountIdentifier,
      patientSpecialAccount.patientSpecialAccountIdentifier)
        && Objects.equals(this.patientIdentifier, patientSpecialAccount.patientIdentifier)
        && Objects.equals(
          this.sourceSystemPatientSpecialAcntNum,
          patientSpecialAccount.sourceSystemPatientSpecialAcntNum)
        && Objects.equals(this.sourceSystemName, patientSpecialAccount.sourceSystemName)
        && Objects.equals(this.specialAccountCode, patientSpecialAccount.specialAccountCode)
        && Objects.equals(this.audit, patientSpecialAccount.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      patientSpecialAccountIdentifier,
      patientIdentifier,
      sourceSystemPatientSpecialAcntNum,
      sourceSystemName,
      specialAccountCode,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PatientSpecialAccount {\n");

    sb
      .append("    patientSpecialAccountIdentifier: ")
      .append(toIndentedString(patientSpecialAccountIdentifier))
      .append("\n");
    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb
      .append("    sourceSystemPatientSpecialAcntNum: ")
      .append(toIndentedString(sourceSystemPatientSpecialAcntNum))
      .append("\n");
    sb.append("    sourceSystemName: ").append(toIndentedString(sourceSystemName)).append("\n");
    sb.append("    specialAccountCode: ").append(toIndentedString(specialAccountCode)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
