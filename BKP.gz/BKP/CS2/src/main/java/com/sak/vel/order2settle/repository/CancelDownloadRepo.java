
package com.cvs.specialty.ordermaintenance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.CgRefCode;

@Repository
@Transactional
public interface CancelDownloadRepo extends JpaRepository<CgRefCode, Long> {

  List<CgRefCode> findByRvDomain(String reasonCode);

}
