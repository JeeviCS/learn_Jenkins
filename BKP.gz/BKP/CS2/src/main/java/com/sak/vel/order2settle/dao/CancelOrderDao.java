
package com.cvs.specialty.ordermaintenance.dao;

import java.util.List;

import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
//import com.cvs.specialty.ordermaintenance.model.Task;

public interface CancelOrderDao {

  List<CgRefCode> getCancelReason(String rvDomain, String rvHighValue);

  // List<Task> getListofTasks(String patientId,String orderId);

	//List<Task> getListofTasks(String patientId,String orderId);

	CancelOrderResponse submitCancelOrder(OrderCancelRequest cancelOrder, String userId);
} 
