
package com.cvs.specialty.ordermaintenance.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * PreOrderHeader
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class PrescriptionDispOrders {
  @JsonProperty("orderNumber")
  private String orderNumber;
  @JsonProperty("shipmentNumber")
  private String shipmentNumber;
  @JsonProperty("orderStatus")
  private String orderStatus;

  public String getOrderNumber() {
    return orderNumber;
  }

  public void setOrderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
  }

  public String getShipmentNumber() {
    return shipmentNumber;
  }

  public void setShipmentNumber(String shipmentNumber) {
    this.shipmentNumber = shipmentNumber;
  }

  public String getOrderStatus() {
    return orderStatus;
  }

  public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
  }

}
