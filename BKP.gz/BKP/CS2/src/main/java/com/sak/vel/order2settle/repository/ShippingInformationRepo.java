
package com.cvs.specialty.ordermaintenance.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.PreOrderHeader;

@Repository
@Transactional
public interface ShippingInformationRepo extends JpaRepository<PreOrderHeader, Long> {

  List<PreOrderHeader> findByPreOrdrHdrId(long preOrderHeaderID);

  PreOrderHeader findByCrteUsrNm(String name);

  // PreOrderHeader updateShippingDetails(PreOrderHeader shippingDetails);
  // PreOrderNote findByIntakeRfrlIdAndDocNm(BigDecimal intakeId, String docNm);

}
