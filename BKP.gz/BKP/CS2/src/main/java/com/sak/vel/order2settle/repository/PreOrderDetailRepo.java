
package com.cvs.specialty.ordermaintenance.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.ordermaintenance.entity.ItemEO;
import com.cvs.specialty.ordermaintenance.entity.PreOrderDetailEO;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionDispensesEO;

@Repository
@Transactional
public interface PreOrderDetailRepo extends JpaRepository<PreOrderDetailEO, Long> {

  void deleteByPreOrdrHdrIdAndRxIdAndItem(BigDecimal preOrderId, BigDecimal rxID, ItemEO item);

  void deleteByPreOrdrHdrIdAndRxId(BigDecimal preOrderId, BigDecimal bigDecimal);

  PreOrderDetailEO
      findByPreOrdrHdrIdAndRxIdAndItemAndPrescriptionDispens(BigDecimal preOrderId, BigDecimal rxId, ItemEO item,PrescriptionDispensesEO prescriptionDispensesEO);

}
