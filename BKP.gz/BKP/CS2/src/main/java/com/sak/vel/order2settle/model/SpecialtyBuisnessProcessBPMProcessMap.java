
package com.cvs.specialty.ordermaintenance.model;

import java.util.Objects;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * SpecialtyBuisnessProcessBPMProcessMap
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class SpecialtyBuisnessProcessBPMProcessMap {
  @JsonProperty("specialtyBuisnessProcessEntityBPMProcessMapIdentifier")
  private String specialtyBuisnessProcessEntityBPMProcessMapIdentifier = null;

  @JsonProperty("specailtyBuisnessProcessEntityIdentifier")
  private String specailtyBuisnessProcessEntityIdentifier = null;

  @JsonProperty("contactCommunicationIdentifier")
  private String contactCommunicationIdentifier = null;

  @JsonProperty("specialtyBusinessprocessEntityType")
  private String specialtyBusinessprocessEntityType = null;

  @JsonProperty("bpmProcessName")
  private String bpmProcessName = null;

  @JsonProperty("bpmProcessInstanceIdentifier")
  private String bpmProcessInstanceIdentifier = null;

  @JsonProperty("bpmProcessStatusCode")
  private String bpmProcessStatusCode = null;

  @JsonProperty("intakeReferralIdentifier")
  private String intakeReferralIdentifier = null;

  @JsonProperty("PatientIdentifier")
  private String patientIdentifier = null;

  @JsonProperty("healthCareProfessionalidentifier")
  private String healthCareProfessionalidentifier = null;

  @JsonProperty("siteIdentifier")
  private String siteIdentifier = null;

  @JsonProperty("targetDate")
  private String targetDate = null;

  @JsonProperty("priorityIndicator")
  private String priorityIndicator = null;

  @JsonProperty("vipIndicator")
  private String vipIndicator = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;

  @JsonProperty("audit")
  private Audit audit = null;

  public
      SpecialtyBuisnessProcessBPMProcessMap
      specialtyBuisnessProcessEntityBPMProcessMapIdentifier(
          String specialtyBuisnessProcessEntityBPMProcessMapIdentifier) {
    this.specialtyBuisnessProcessEntityBPMProcessMapIdentifier = specialtyBuisnessProcessEntityBPMProcessMapIdentifier;
    return this;
  }

  /**
   * Get specialtyBuisnessProcessEntityBPMProcessMapIdentifier
   * 
   * @return specialtyBuisnessProcessEntityBPMProcessMapIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSpecialtyBuisnessProcessEntityBPMProcessMapIdentifier() {
    return specialtyBuisnessProcessEntityBPMProcessMapIdentifier;
  }

  public void setSpecialtyBuisnessProcessEntityBPMProcessMapIdentifier(
      String specialtyBuisnessProcessEntityBPMProcessMapIdentifier) {
    this.specialtyBuisnessProcessEntityBPMProcessMapIdentifier = specialtyBuisnessProcessEntityBPMProcessMapIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap specailtyBuisnessProcessEntityIdentifier(
      String specailtyBuisnessProcessEntityIdentifier) {
    this.specailtyBuisnessProcessEntityIdentifier = specailtyBuisnessProcessEntityIdentifier;
    return this;
  }

  /**
   * Get specailtyBuisnessProcessEntityIdentifier
   * 
   * @return specailtyBuisnessProcessEntityIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSpecailtyBuisnessProcessEntityIdentifier() {
    return specailtyBuisnessProcessEntityIdentifier;
  }

  public void setSpecailtyBuisnessProcessEntityIdentifier(
      String specailtyBuisnessProcessEntityIdentifier) {
    this.specailtyBuisnessProcessEntityIdentifier = specailtyBuisnessProcessEntityIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap contactCommunicationIdentifier(
      String contactCommunicationIdentifier) {
    this.contactCommunicationIdentifier = contactCommunicationIdentifier;
    return this;
  }

  /**
   * Get contactCommunicationIdentifier
   * 
   * @return contactCommunicationIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getContactCommunicationIdentifier() {
    return contactCommunicationIdentifier;
  }

  public void setContactCommunicationIdentifier(String contactCommunicationIdentifier) {
    this.contactCommunicationIdentifier = contactCommunicationIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap specialtyBusinessprocessEntityType(
      String specialtyBusinessprocessEntityType) {
    this.specialtyBusinessprocessEntityType = specialtyBusinessprocessEntityType;
    return this;
  }

  /**
   * Get specialtyBusinessprocessEntityType
   * 
   * @return specialtyBusinessprocessEntityType
   **/
  @ApiModelProperty(value = "")

  public String getSpecialtyBusinessprocessEntityType() {
    return specialtyBusinessprocessEntityType;
  }

  public void setSpecialtyBusinessprocessEntityType(String specialtyBusinessprocessEntityType) {
    this.specialtyBusinessprocessEntityType = specialtyBusinessprocessEntityType;
  }

  public SpecialtyBuisnessProcessBPMProcessMap bpmProcessName(String bpmProcessName) {
    this.bpmProcessName = bpmProcessName;
    return this;
  }

  /**
   * Get bpmProcessName
   * 
   * @return bpmProcessName
   **/
  @ApiModelProperty(value = "")

  public String getBpmProcessName() {
    return bpmProcessName;
  }

  public void setBpmProcessName(String bpmProcessName) {
    this.bpmProcessName = bpmProcessName;
  }

  public SpecialtyBuisnessProcessBPMProcessMap bpmProcessInstanceIdentifier(
      String bpmProcessInstanceIdentifier) {
    this.bpmProcessInstanceIdentifier = bpmProcessInstanceIdentifier;
    return this;
  }

  /**
   * Get bpmProcessInstanceIdentifier
   * 
   * @return bpmProcessInstanceIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getBpmProcessInstanceIdentifier() {
    return bpmProcessInstanceIdentifier;
  }

  public void setBpmProcessInstanceIdentifier(String bpmProcessInstanceIdentifier) {
    this.bpmProcessInstanceIdentifier = bpmProcessInstanceIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap bpmProcessStatusCode(String bpmProcessStatusCode) {
    this.bpmProcessStatusCode = bpmProcessStatusCode;
    return this;
  }

  /**
   * Get bpmProcessStatusCode
   * 
   * @return bpmProcessStatusCode
   **/
  @ApiModelProperty(value = "")

  public String getBpmProcessStatusCode() {
    return bpmProcessStatusCode;
  }

  public void setBpmProcessStatusCode(String bpmProcessStatusCode) {
    this.bpmProcessStatusCode = bpmProcessStatusCode;
  }

  public SpecialtyBuisnessProcessBPMProcessMap intakeReferralIdentifier(
      String intakeReferralIdentifier) {
    this.intakeReferralIdentifier = intakeReferralIdentifier;
    return this;
  }

  /**
   * Get intakeReferralIdentifier
   * 
   * @return intakeReferralIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getIntakeReferralIdentifier() {
    return intakeReferralIdentifier;
  }

  public void setIntakeReferralIdentifier(String intakeReferralIdentifier) {
    this.intakeReferralIdentifier = intakeReferralIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap patientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
    return this;
  }

  /**
   * Get patientIdentifier
   * 
   * @return patientIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getPatientIdentifier() {
    return patientIdentifier;
  }

  public void setPatientIdentifier(String patientIdentifier) {
    this.patientIdentifier = patientIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap healthCareProfessionalidentifier(
      String healthCareProfessionalidentifier) {
    this.healthCareProfessionalidentifier = healthCareProfessionalidentifier;
    return this;
  }

  /**
   * Get healthCareProfessionalidentifier
   * 
   * @return healthCareProfessionalidentifier
   **/
  @ApiModelProperty(value = "")

  public String getHealthCareProfessionalidentifier() {
    return healthCareProfessionalidentifier;
  }

  public void setHealthCareProfessionalidentifier(String healthCareProfessionalidentifier) {
    this.healthCareProfessionalidentifier = healthCareProfessionalidentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap siteIdentifier(String siteIdentifier) {
    this.siteIdentifier = siteIdentifier;
    return this;
  }

  /**
   * Get siteIdentifier
   * 
   * @return siteIdentifier
   **/
  @ApiModelProperty(value = "")

  public String getSiteIdentifier() {
    return siteIdentifier;
  }

  public void setSiteIdentifier(String siteIdentifier) {
    this.siteIdentifier = siteIdentifier;
  }

  public SpecialtyBuisnessProcessBPMProcessMap targetDate(String targetDate) {
    this.targetDate = targetDate;
    return this;
  }

  /**
   * Get targetDate
   * 
   * @return targetDate
   **/
  @ApiModelProperty(value = "")

  public String getTargetDate() {
    return targetDate;
  }

  public void setTargetDate(String targetDate) {
    this.targetDate = targetDate;
  }

  public SpecialtyBuisnessProcessBPMProcessMap priorityIndicator(String priorityIndicator) {
    this.priorityIndicator = priorityIndicator;
    return this;
  }

  /**
   * Get priorityIndicator
   * 
   * @return priorityIndicator
   **/
  @ApiModelProperty(value = "")

  public String getPriorityIndicator() {
    return priorityIndicator;
  }

  public void setPriorityIndicator(String priorityIndicator) {
    this.priorityIndicator = priorityIndicator;
  }

  public SpecialtyBuisnessProcessBPMProcessMap vipIndicator(String vipIndicator) {
    this.vipIndicator = vipIndicator;
    return this;
  }

  /**
   * Get vipIndicator
   * 
   * @return vipIndicator
   **/
  @ApiModelProperty(value = "")

  public String getVipIndicator() {
    return vipIndicator;
  }

  public void setVipIndicator(String vipIndicator) {
    this.vipIndicator = vipIndicator;
  }

  public SpecialtyBuisnessProcessBPMProcessMap activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

  /**
   * Get activeIndicator
   * 
   * @return activeIndicator
   **/
  @ApiModelProperty(value = "")

  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public SpecialtyBuisnessProcessBPMProcessMap audit(Audit audit) {
    this.audit = audit;
    return this;
  }

  /**
   * Get audit
   * 
   * @return audit
   **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SpecialtyBuisnessProcessBPMProcessMap specialtyBuisnessProcessBPMProcessMap = (SpecialtyBuisnessProcessBPMProcessMap) o;
    return Objects.equals(
      this.specialtyBuisnessProcessEntityBPMProcessMapIdentifier,
      specialtyBuisnessProcessBPMProcessMap.specialtyBuisnessProcessEntityBPMProcessMapIdentifier)
        && Objects.equals(
          this.specailtyBuisnessProcessEntityIdentifier,
          specialtyBuisnessProcessBPMProcessMap.specailtyBuisnessProcessEntityIdentifier)
        && Objects.equals(
          this.contactCommunicationIdentifier,
          specialtyBuisnessProcessBPMProcessMap.contactCommunicationIdentifier)
        && Objects.equals(
          this.specialtyBusinessprocessEntityType,
          specialtyBuisnessProcessBPMProcessMap.specialtyBusinessprocessEntityType)
        && Objects.equals(this.bpmProcessName, specialtyBuisnessProcessBPMProcessMap.bpmProcessName)
        && Objects.equals(
          this.bpmProcessInstanceIdentifier,
          specialtyBuisnessProcessBPMProcessMap.bpmProcessInstanceIdentifier)
        && Objects.equals(
          this.bpmProcessStatusCode,
          specialtyBuisnessProcessBPMProcessMap.bpmProcessStatusCode)
        && Objects.equals(
          this.intakeReferralIdentifier,
          specialtyBuisnessProcessBPMProcessMap.intakeReferralIdentifier)
        && Objects
          .equals(this.patientIdentifier, specialtyBuisnessProcessBPMProcessMap.patientIdentifier)
        && Objects.equals(
          this.healthCareProfessionalidentifier,
          specialtyBuisnessProcessBPMProcessMap.healthCareProfessionalidentifier)
        && Objects.equals(this.siteIdentifier, specialtyBuisnessProcessBPMProcessMap.siteIdentifier)
        && Objects.equals(this.targetDate, specialtyBuisnessProcessBPMProcessMap.targetDate)
        && Objects
          .equals(this.priorityIndicator, specialtyBuisnessProcessBPMProcessMap.priorityIndicator)
        && Objects.equals(this.vipIndicator, specialtyBuisnessProcessBPMProcessMap.vipIndicator)
        && Objects
          .equals(this.activeIndicator, specialtyBuisnessProcessBPMProcessMap.activeIndicator)
        && Objects.equals(this.audit, specialtyBuisnessProcessBPMProcessMap.audit);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
      specialtyBuisnessProcessEntityBPMProcessMapIdentifier,
      specailtyBuisnessProcessEntityIdentifier,
      contactCommunicationIdentifier,
      specialtyBusinessprocessEntityType,
      bpmProcessName,
      bpmProcessInstanceIdentifier,
      bpmProcessStatusCode,
      intakeReferralIdentifier,
      patientIdentifier,
      healthCareProfessionalidentifier,
      siteIdentifier,
      targetDate,
      priorityIndicator,
      vipIndicator,
      activeIndicator,
      audit);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SpecialtyBuisnessProcessBPMProcessMap {\n");

    sb
      .append("    specialtyBuisnessProcessEntityBPMProcessMapIdentifier: ")
      .append(toIndentedString(specialtyBuisnessProcessEntityBPMProcessMapIdentifier))
      .append("\n");
    sb
      .append("    specailtyBuisnessProcessEntityIdentifier: ")
      .append(toIndentedString(specailtyBuisnessProcessEntityIdentifier))
      .append("\n");
    sb
      .append("    contactCommunicationIdentifier: ")
      .append(toIndentedString(contactCommunicationIdentifier))
      .append("\n");
    sb
      .append("    specialtyBusinessprocessEntityType: ")
      .append(toIndentedString(specialtyBusinessprocessEntityType))
      .append("\n");
    sb.append("    bpmProcessName: ").append(toIndentedString(bpmProcessName)).append("\n");
    sb
      .append("    bpmProcessInstanceIdentifier: ")
      .append(toIndentedString(bpmProcessInstanceIdentifier))
      .append("\n");
    sb.append("    bpmProcessStatusCode: ").append(toIndentedString(bpmProcessStatusCode)).append(
      "\n");
    sb
      .append("    intakeReferralIdentifier: ")
      .append(toIndentedString(intakeReferralIdentifier))
      .append("\n");
    sb.append("    patientIdentifier: ").append(toIndentedString(patientIdentifier)).append("\n");
    sb
      .append("    healthCareProfessionalidentifier: ")
      .append(toIndentedString(healthCareProfessionalidentifier))
      .append("\n");
    sb.append("    siteIdentifier: ").append(toIndentedString(siteIdentifier)).append("\n");
    sb.append("    targetDate: ").append(toIndentedString(targetDate)).append("\n");
    sb.append("    priorityIndicator: ").append(toIndentedString(priorityIndicator)).append("\n");
    sb.append("    vipIndicator: ").append(toIndentedString(vipIndicator)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
