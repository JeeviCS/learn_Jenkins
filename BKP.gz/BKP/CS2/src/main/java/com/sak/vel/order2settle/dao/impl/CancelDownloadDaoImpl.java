
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.CancelDownloadDao;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.model.CanceDownloadReasonCodes;
import com.cvs.specialty.ordermaintenance.repository.CancelDownloadRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class CancelDownloadDaoImpl implements CancelDownloadDao {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  CancelDownloadRepo cancelDownloadRepo;

  @Override
  public List<CanceDownloadReasonCodes> cancelDownloadGet(long orderId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    List<CanceDownloadReasonCodes> response = new ArrayList<CanceDownloadReasonCodes>();

    List<CgRefCode> cgRefCode = new ArrayList<CgRefCode>();

    try {

      cgRefCode = cancelDownloadRepo.findByRvDomain("CANCL_DWNLD_RSN_CODE");

      LOGGER.info(cgRefCode.toString());

      for (int i = 0; i < cgRefCode.size(); i++) {
        CanceDownloadReasonCodes canceDownloadReasonCodes = new CanceDownloadReasonCodes();
        canceDownloadReasonCodes.setCode(cgRefCode.get(i).getRvAbbreviation());
        response.add(canceDownloadReasonCodes);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
    }

    catch (DataAccessException e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "DataAccessException");

    } catch (Exception e) {

      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "Exception");

    }

    return response;

  }

  @Override
  public Void cancelDownloadPost(long preOrderId, String orderNotes) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    // TODO Auto-generated method stub

    /*
     * HttpEntity<SchedulingOrderRequestObject> requestEntity = new HttpEntity<>(requestObejct,
     * headers);
     * 
     * responseEntity = workflowRestTemplate.postForEntity(workflowRulesURL, requestEntity,
     * SchedulingOrderResponseObject.class);
     */
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return null;
  }

}
