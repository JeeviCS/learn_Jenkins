
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.ShippingInformationDao;
import com.cvs.specialty.ordermaintenance.model.PreOrderHeader;
import com.cvs.specialty.ordermaintenance.service.ShippingInformationService;

@Repository
public class ShippingInformationServiceImpl implements ShippingInformationService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  ShippingInformationDao shippingInformationDao;

  @SuppressWarnings({
      "unchecked", "rawtypes"
  })
  @Override
  public ResponseEntity<List<PreOrderHeader>> getShippingDetails(long preOrderId, String status) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<List<PreOrderHeader>> response = null;

    try {
      List<PreOrderHeader> response_list = shippingInformationDao
        .getShippingDetails(preOrderId, status);

      if (response_list == null) {
        response = new ResponseEntity(response_list, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response_list, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<List<PreOrderHeader>>(HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public ResponseEntity<Void> updateShippingDetails(Long orderId,Long patientId, PreOrderHeader shippingDetails) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    try {
      shippingInformationDao.updateShippingDetails(orderId,shippingDetails);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return null;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }

  }

@Override
public ResponseEntity<PreOrderHeader> getShippingInfo(Long preOrderHeaderId, Long patientId) {
	LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<PreOrderHeader> response = null;

    try {
      PreOrderHeader response_list = shippingInformationDao
        .getShippingInfo(preOrderHeaderId, patientId);

      if (response_list == null) {
        response = new ResponseEntity(response_list, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response_list, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<PreOrderHeader>(HttpStatus.BAD_REQUEST);
    }

}

}
