/*package com.cvs.specialty.ordermaintenance.rabbitMq.producer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

*//** * @author Z231366 * *//*
@Service
@EnableBinding(RabbitMqChannel.class)
public class New_Producer implements PatientNotesService {
	private static final String DEACTIVATE_INDICATOR = "Y";
	@Autowired
	private PatientNotesDAO patientNotesDAO;
	@Autowired
	private PatientNoteRepository patientNoteRepository;
	@Autowired
	BillGrpRepository billGrpRepository;
	@Autowired
	RabbitMqChannel mqChannel;
	private static ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public PatientNotesResponse creatPatientNotes(PatientNotesPostRequest patientNotesPostRequest,
			PatientNotesHeaders headers) throws PatientNotesException {
		if (StringUtils.isBlank(patientNotesPostRequest.getSystemSourceCode())
				|| StringUtils.isBlank(patientNotesPostRequest.getPatientSourceNo())) {
			List<PatientNoteEntity> entityList = patientNoteRepository
					.findByPatientId(patientNotesPostRequest.getPatientID());
			if (entityList.isEmpty()) {
				throw new PatientNotesException(PatientNotesErrorCode.INVALID_PATIENT_ID);
			} else {
				patientNotesPostRequest.setSystemSourceCode(entityList.get(0).getSystemSrcCd());
				patientNotesPostRequest.setPatientSourceNo(entityList.get(0).getPatientSrcNo());
			}
		}
		try {
			mqChannel.producer()
					.send(MessageBuilder.withPayload(objectMapper.writeValueAsString(patientNotesPostRequest))
							.setHeader("access-token", headers.getAccessToken()).build());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block e.printStackTrace();
		}
		return patientNotesDAO.creatPatientNotes(createObjectToEntity(patientNotesPostRequest));
	}
}*/