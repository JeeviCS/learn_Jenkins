
package com.cvs.specialty.ordermaintenance.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.UnTagOrderDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.model.UntagReasonCodes;
import com.cvs.specialty.ordermaintenance.service.UnTagOrderService;

@Repository
public class UnTagOrderServiceImpl implements UnTagOrderService {

  @Autowired
  UnTagOrderDao unTagOrderDao;

  @Autowired
  SpecialtyLogger LOGGER;

  @SuppressWarnings({
      "unchecked", "rawtypes"
  })
  @Override
  public
      ResponseEntity<List<UntagReasonCodes>>
      getUntagReasonCodes(long preOrderId, String status) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<List<UntagReasonCodes>> response = null;

    try {
      List<UntagReasonCodes> response_list = unTagOrderDao.getUntagReasonCodes(preOrderId, status);

      if (response_list == null) {
        response = new ResponseEntity(response_list, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response_list, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<List<UntagReasonCodes>>(HttpStatus.BAD_REQUEST);
    }

  }

  @Override
  public
      ResponseEntity<Void>
      unTagRxorder(List<RxDetailsList> unTagRx, long orderId, BigDecimal reasonCode) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    try {
      unTagOrderDao.unTagRxorder(unTagRx, orderId, reasonCode);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return null;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }

  }
}
