
package com.cvs.specialty.ordermaintenance.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.model.CancelReason;
import com.cvs.specialty.ordermaintenance.service.CancelOrderService;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-22T12:32:09.067Z")

@Controller
public class GetCancelReasonApiController implements GetCancelReasonApi {
  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  CancelOrderService cancelOrderService;

  public ResponseEntity<List<CancelReason>> getCancelReasonGet(
      @ApiParam(value = "access token to validate this request", required = true) @RequestHeader(value = "access-token", required = true) String accessToken,
      @ApiParam(value = "Unique identifier for the message", required = true) @RequestHeader(value = "message-id", required = true) String messageId,
      HttpServletRequest request,
      HttpServletResponse response

  ) throws OrderMaintenanceException, BindException, Exception {

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    @SuppressWarnings("unused")
    String userId = null;
    if (request.getAttribute("user-id") != null)
      userId = (String) request.getAttribute("user-id");
    if (request.getAttribute("message-id") != null)
      messageId = (String) request.getAttribute("message-id");

    List<CancelReason> cancelReason = new ArrayList<CancelReason>();

    LOGGER.info("Get Cancel Reason Request- " + messageId);
    try {
      cancelReason = cancelOrderService.getCancelReason();
      LOGGER.info("Success response");
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<List<CancelReason>>(cancelReason, HttpStatus.OK);
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<List<CancelReason>>(HttpStatus.BAD_REQUEST);
    }

  }
}
