package com.cvs.specialty.ordermaintenance.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Create Manual task request : holds input for user request and user task
 * request details
 * 
 * @author Z243590
 *
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-09T21:58:09.088Z")

@JsonInclude(Include.NON_NULL)
public class TaskManualApiCreateTaskRequest {
	public TaskManualApiCreateTaskRequest() {
		// default constructor
	}

	@JsonProperty("user")
	private UserRequest user;

	@JsonProperty("task")
	private TaskRequest task;

	/**
	 * @return the user
	 */
	public UserRequest getUser() {
		return user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(UserRequest user) {
		this.user = user;
	}

	/**
	 * @return the task
	 */
	public TaskRequest getTask() {
		return task;
	}

	/**
	 * @param task
	 *            the task to set
	 */
	public void setTask(TaskRequest task) {
		this.task = task;
	}

}
