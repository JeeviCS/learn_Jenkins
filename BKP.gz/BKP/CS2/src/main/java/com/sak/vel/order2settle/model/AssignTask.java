package com.cvs.specialty.ordermaintenance.model;


import java.time.ZonedDateTime;
import java.util.Objects;

import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeDeserializer;
import com.cvs.specialty.ordermaintenance.util.ZonedDateTimeSerializer;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModelProperty;

/**
 * AssignTask
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-02T22:17:30.322Z")

public class AssignTask   {

  @JsonProperty("bpmTaskName")
  private String bpmTaskName = null;

  @JsonProperty("bpmTaskInstanceId")
  private Long bpmTaskInstanceId = null;

  @JsonProperty("bpmProcessInstanceId")
  private Long bpmProcessInstanceId = null;

/*	@JsonProperty("followUpDate")
	@JsonSerialize(using = ZonedDateTimeSerializer.class)
	@JsonDeserialize(using = ZonedDateTimeDeserializer.class)  
	private ZonedDateTime followUpDate = null;*/
	
	

  public AssignTask bpmTaskName(String bpmTaskName) {
    this.bpmTaskName = bpmTaskName;
    return this;
  }

   /**
   * Get bpmTaskName
   * @return bpmTaskName
  **/
  @ApiModelProperty(value = "")


  public String getBpmTaskName() {
    return bpmTaskName;
  }

  public void setBpmTaskName(String bpmTaskName) {
    this.bpmTaskName = bpmTaskName;
  }

  public AssignTask bpmTaskInstanceId(Long bpmTaskInstanceId) {
    this.bpmTaskInstanceId = bpmTaskInstanceId;
    return this;
  }

   /**
   * Get bpmTaskInstanceId
   * @return bpmTaskInstanceId
  **/
  @ApiModelProperty(value = "")


  public Long getBpmTaskInstanceId() {
    return bpmTaskInstanceId;
  }

  public void setBpmTaskInstanceId(Long bpmTaskInstanceId) {
    this.bpmTaskInstanceId = bpmTaskInstanceId;
  }


/*  public Task followUpTimestamp(ZonedDateTime followUpTimestamp) {
    this.followUpTimestamp = followUpTimestamp;
    return this;
  }

   *//**
   * Get followUpTimestamp
   * @return followUpTimestamp
  **//*
  @ApiModelProperty(value = "")


  public ZonedDateTime getFollowUpTimestamp() {
    return followUpTimestamp;
  }

  public void setFollowUpTimestamp(ZonedDateTime followUpTimestamp) {
    this.followUpTimestamp = followUpTimestamp;
  }


  public Task updatedTimeStamp(ZonedDateTime updatedTimeStamp) {
    this.updatedTimeStamp = updatedTimeStamp;
    return this;
  }

   *//**
   * Get updatedTimeStamp
   * @return updatedTimeStamp
  **//*
  @ApiModelProperty(value = "")


  public ZonedDateTime getUpdatedTimeStamp() {
    return updatedTimeStamp;
  }

  public void setUpdatedTimeStamp(ZonedDateTime updatedTimeStamp) {
    this.updatedTimeStamp = updatedTimeStamp;
  }
*/

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AssignTask assigntask = (AssignTask) o;
    return Objects.equals(this.bpmTaskName, assigntask.bpmTaskName) &&
        Objects.equals(this.bpmTaskInstanceId, assigntask.bpmTaskInstanceId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(bpmTaskName, bpmTaskInstanceId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Task {\n");
    
    sb.append("    bpmTaskName: ").append(toIndentedString(bpmTaskName)).append("\n");
    sb.append("    bpmTaskInstanceId: ").append(toIndentedString(bpmTaskInstanceId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }




/*public ZonedDateTime getFollowUpDate() {
	return followUpDate;
}




public void setFollowUpDate(ZonedDateTime followUpDate) {
	this.followUpDate = followUpDate;
}
*/
}

