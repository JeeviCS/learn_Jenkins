package com.cvs.specialty.ordermaintenance.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import com.cvs.specialty.ordermaintenance.model.Audit;
import org.joda.time.LocalDate;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PrescriptionDispense
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-26T19:18:28.347Z")

public class PrescriptionDispense   {
  @JsonProperty("prescriptionDispenseIdentifier")
  private long prescriptionDispenseIdentifier;

  @JsonProperty("drugIdentifier")
  private String drugIdentifier = null;

  @JsonProperty("prescriptionIdentifier")
  private String prescriptionIdentifier = null;

  @JsonProperty("refillNumber")
  private String refillNumber = null;

  @JsonProperty("dispensedQuantity")
  private String dispensedQuantity = null;

  @JsonProperty("daysSupplyNumber")
  private String daysSupplyNumber = null;

  @JsonProperty("copayAmount")
  private String copayAmount = null;

  @JsonProperty("dispensePrice")
  private String dispensePrice = null;

/*  @JsonProperty("ortMostRecentFilledDate")
  private LocalDate ortMostRecentFilledDate = null;*/

  @JsonProperty("arriveOnBy")
  private String arriveOnBy = null;

  @JsonProperty("activeIndicator")
  private String activeIndicator = null;
  
  @JsonProperty("untagReasonCode")
  private BigDecimal untagReasonCode = null;

  public BigDecimal getUntagReasonCode() {
	return untagReasonCode;
}

public void setUntagReasonCode(BigDecimal untagReasonCode) {
	this.untagReasonCode = untagReasonCode;
}

@JsonProperty("untagReasons")
  private List<UntagReasonCodes> untagReasons = null;


public List<UntagReasonCodes> getUntagReasons() {
	return untagReasons;
}

public void setUntagReasons(List<UntagReasonCodes> untagReasons) {
	this.untagReasons = untagReasons;
}

@JsonProperty("audit")
  private Audit audit = null;

  public PrescriptionDispense prescriptionDispenseIdentifier(long prescriptionDispenseIdentifier) {
    this.prescriptionDispenseIdentifier = prescriptionDispenseIdentifier;
    return this;
  }

   /**
   * Get prescriptionDispenseIdentifier
   * @return prescriptionDispenseIdentifier
  **/
  @ApiModelProperty(value = "")


  public long getPrescriptionDispenseIdentifier() {
    return prescriptionDispenseIdentifier;
  }

  public void setPrescriptionDispenseIdentifier(long prescriptionDispenseIdentifier) {
    this.prescriptionDispenseIdentifier = prescriptionDispenseIdentifier;
  }

  public PrescriptionDispense drugIdentifier(String drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
    return this;
  }

   /**
   * Get drugIdentifier
   * @return drugIdentifier
  **/
  @ApiModelProperty(value = "")


  public String getDrugIdentifier() {
    return drugIdentifier;
  }

  public void setDrugIdentifier(String drugIdentifier) {
    this.drugIdentifier = drugIdentifier;
  }

  public PrescriptionDispense prescriptionIdentifier(String prescriptionIdentifier) {
    this.prescriptionIdentifier = prescriptionIdentifier;
    return this;
  }

   /**
   * Get prescriptionIdentifier
   * @return prescriptionIdentifier
  **/
  @ApiModelProperty(value = "")


  public String getPrescriptionIdentifier() {
    return prescriptionIdentifier;
  }

  public void setPrescriptionIdentifier(String prescriptionIdentifier) {
    this.prescriptionIdentifier = prescriptionIdentifier;
  }

  public PrescriptionDispense refillNumber(String refillNumber) {
    this.refillNumber = refillNumber;
    return this;
  }

   /**
   * Get refillNumber
   * @return refillNumber
  **/
  @ApiModelProperty(value = "")


  public String getRefillNumber() {
    return refillNumber;
  }

  public void setRefillNumber(String refillNumber) {
    this.refillNumber = refillNumber;
  }

  public PrescriptionDispense dispensedQuantity(String dispensedQuantity) {
    this.dispensedQuantity = dispensedQuantity;
    return this;
  }

   /**
   * Get dispensedQuantity
   * @return dispensedQuantity
  **/
  @ApiModelProperty(value = "")


  public String getDispensedQuantity() {
    return dispensedQuantity;
  }

  public void setDispensedQuantity(String dispensedQuantity) {
    this.dispensedQuantity = dispensedQuantity;
  }

  public PrescriptionDispense daysSupplyNumber(String daysSupplyNumber) {
    this.daysSupplyNumber = daysSupplyNumber;
    return this;
  }

   /**
   * Get daysSupplyNumber
   * @return daysSupplyNumber
  **/
  @ApiModelProperty(value = "")


  public String getDaysSupplyNumber() {
    return daysSupplyNumber;
  }

  public void setDaysSupplyNumber(String daysSupplyNumber) {
    this.daysSupplyNumber = daysSupplyNumber;
  }

  public PrescriptionDispense copayAmount(String copayAmount) {
    this.copayAmount = copayAmount;
    return this;
  }

   /**
   * Get copayAmount
   * @return copayAmount
  **/
  @ApiModelProperty(value = "")


  public String getCopayAmount() {
    return copayAmount;
  }

  public void setCopayAmount(String copayAmount) {
    this.copayAmount = copayAmount;
  }

  public PrescriptionDispense dispensePrice(String dispensePrice) {
    this.dispensePrice = dispensePrice;
    return this;
  }

   /**
   * Get dispensePrice
   * @return dispensePrice
  **/
  @ApiModelProperty(value = "")


  public String getDispensePrice() {
    return dispensePrice;
  }

  public void setDispensePrice(String dispensePrice) {
    this.dispensePrice = dispensePrice;
  }

 /* public PrescriptionDispense ortMostRecentFilledDate(LocalDate ortMostRecentFilledDate) {
    this.ortMostRecentFilledDate = ortMostRecentFilledDate;
    return this;
  }*/

   /**
   * Get ortMostRecentFilledDate
   * @return ortMostRecentFilledDate
  **/
  @ApiModelProperty(value = "")

  @Valid

/*  public LocalDate getOrtMostRecentFilledDate() {
    return ortMostRecentFilledDate;
  }

  public void setOrtMostRecentFilledDate(LocalDate ortMostRecentFilledDate) {
    this.ortMostRecentFilledDate = ortMostRecentFilledDate;
  }*/

  public PrescriptionDispense arriveOnBy(String arriveOnBy) {
    this.arriveOnBy = arriveOnBy;
    return this;
  }

   /**
   * Get arriveOnBy
   * @return arriveOnBy
  **/
  @ApiModelProperty(value = "")


  public String getArriveOnBy() {
    return arriveOnBy;
  }

  public void setArriveOnBy(String arriveOnBy) {
    this.arriveOnBy = arriveOnBy;
  }

  public PrescriptionDispense activeIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
    return this;
  }

   /**
   * Get activeIndicator
   * @return activeIndicator
  **/
  @ApiModelProperty(value = "")


  public String getActiveIndicator() {
    return activeIndicator;
  }

  public void setActiveIndicator(String activeIndicator) {
    this.activeIndicator = activeIndicator;
  }

  public PrescriptionDispense audit(Audit audit) {
    this.audit = audit;
    return this;
  }

   /**
   * Get audit
   * @return audit
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Audit getAudit() {
    return audit;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PrescriptionDispense prescriptionDispense = (PrescriptionDispense) o;
    return Objects.equals(this.prescriptionDispenseIdentifier, prescriptionDispense.prescriptionDispenseIdentifier) &&
        Objects.equals(this.drugIdentifier, prescriptionDispense.drugIdentifier) &&
        Objects.equals(this.prescriptionIdentifier, prescriptionDispense.prescriptionIdentifier) &&
        Objects.equals(this.refillNumber, prescriptionDispense.refillNumber) &&
        Objects.equals(this.dispensedQuantity, prescriptionDispense.dispensedQuantity) &&
        Objects.equals(this.daysSupplyNumber, prescriptionDispense.daysSupplyNumber) &&
        Objects.equals(this.copayAmount, prescriptionDispense.copayAmount) &&
        Objects.equals(this.dispensePrice, prescriptionDispense.dispensePrice) &&/*
        Objects.equals(this.ortMostRecentFilledDate, prescriptionDispense.ortMostRecentFilledDate)*/ 
        Objects.equals(this.arriveOnBy, prescriptionDispense.arriveOnBy) &&
        Objects.equals(this.activeIndicator, prescriptionDispense.activeIndicator) &&
        Objects.equals(this.untagReasons, prescriptionDispense.untagReasons) &&
        Objects.equals(this.audit, prescriptionDispense.audit);
  }

  /*@Override
  public int hashCode() {
    return Objects.hash(prescriptionDispenseIdentifier, drugIdentifier, prescriptionIdentifier, refillNumber, dispensedQuantity, daysSupplyNumber, copayAmount, dispensePrice, ortMostRecentFilledDate, arriveOnBy, activeIndicator, audit);
  }*/

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PrescriptionDispense {\n");
    
    sb.append("    prescriptionDispenseIdentifier: ").append(toIndentedString(prescriptionDispenseIdentifier)).append("\n");
    sb.append("    drugIdentifier: ").append(toIndentedString(drugIdentifier)).append("\n");
    sb.append("    prescriptionIdentifier: ").append(toIndentedString(prescriptionIdentifier)).append("\n");
    sb.append("    refillNumber: ").append(toIndentedString(refillNumber)).append("\n");
    sb.append("    dispensedQuantity: ").append(toIndentedString(dispensedQuantity)).append("\n");
    sb.append("    daysSupplyNumber: ").append(toIndentedString(daysSupplyNumber)).append("\n");
    sb.append("    copayAmount: ").append(toIndentedString(copayAmount)).append("\n");
    sb.append("    dispensePrice: ").append(toIndentedString(dispensePrice)).append("\n");
 /*   sb.append("    ortMostRecentFilledDate: ").append(toIndentedString(ortMostRecentFilledDate)).append("\n");*/
    sb.append("    arriveOnBy: ").append(toIndentedString(arriveOnBy)).append("\n");
    sb.append("    activeIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
    sb.append("    untagReasonCode: ").append(toIndentedString(untagReasons)).append("\n");
    sb.append("    audit: ").append(toIndentedString(audit)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

