
package com.cvs.specialty.ordermaintenance.dao.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.RxDetailsDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class RxDetailsDaoImpl implements RxDetailsDao {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  DataSource dataSource;

  /**
   * Get a database connection from the registered data source in the servlet container.
   *
   * @return a database connection
   */
  private Connection getConnection() {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    Connection conn = null;
    try {
      conn = dataSource.getConnection();
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
    }
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return conn;
  }

  @Override
  public List<RxDetailsList> rxDetailsGet(long orderId, long patientID) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    Connection con = null;
    PreparedStatement pStatement = null;
    PreparedStatement pStatement2 = null;

    List<RxDetailsList> response = new ArrayList<RxDetailsList>();

    try {

      con = getConnection();
      String query = "select  presc.rx_number,item.ITEM_NAME,item.STRENGTH_TXT, item.UNITS_QTY, pdisp.DAYS_SUPPLY, pd.RMNG_QY, pdisp.COPAY , item.ITEM_ID ITEM_ID, presc.ID RX_ID ,pdisp.ID Pres_disp_ID from prescriptions presc,pre_order_header ph ,PRE_ORDER_DETAIL pd ,PRESCRIPTION_DISPENSES pdisp,Items item where ph.PRE_ORDR_HDR_ID = pd.PRE_ORDR_HDR_ID and presc.id = pd.RX_ID and pdisp.ID = pd.RX_DSPNS_ID and item.ITEM_ID = pd.ITM_ID and presc.PATIENT_ID = ph.PTNT_ID and ph.PRE_ORDR_HDR_ID =?  and ph.PTNT_ID=? ";
    
      pStatement = con.prepareStatement(query);
      pStatement.setLong(1, orderId);
      pStatement.setLong(2, patientID);
    
      ResultSet rs = pStatement.executeQuery();
       // Expected only One Row in the response
      RxDetailsList rxDetailsList = null;
      while (rs.next()) {
        rxDetailsList = new RxDetailsList();

        rxDetailsList.setRx_rxNumber(rs.getLong(1));
        rxDetailsList.setRx_medication(rs.getString(2));
        rxDetailsList.setRx_strength(rs.getString(3));
        rxDetailsList.setRx_quantity(rs.getInt(4));
        rxDetailsList.setRx_daySupply(rs.getInt(5));
        rxDetailsList.setRx_onHand(rs.getInt(6));
        rxDetailsList.setRx_copay(rs.getInt(7));
        rxDetailsList.setDiversion(getDiversionName(orderId, patientID, rxDetailsList));
        rxDetailsList.setRx_drugIdentifier(rs.getLong(8));
        rxDetailsList.setRx_PrescriptionIdentifier(rs.getLong(9));
        rxDetailsList.setRx_PrescriptionDispenseIdentifier(rs.getLong(10));
        response.add(rxDetailsList);
      }
      rs.close();
      con.close();
    } catch (SQLException e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "SQLException");
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "Exception");
    }
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return response;

  }

  public String getDiversionName(long orderId, long patientID, RxDetailsList rxDetailsList) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    Connection con = null;
    PreparedStatement pStatement = null;
    con = getConnection();
    String diversionQuery = "\n" + "SELECT   \n" + "     cg.rv_low_value \"Alert Type\",\n"
        + "     seal.alrt_rsn_tx \"Alert\", \n" + "     it.item_name \"Drug Name\",\n"
        + "     swqt.sbp_wrk_que_task_nm \"Task\" ,\n"
        + "     swqdtc.sbp_wrk_que_dvrsn_task_nm \"Diversion\"\n"
        + "	  FROM pre_order_header prh,\n" + "     pre_order_detail pod,\n" + "     patients pt,\n"
        + "     prescriptions pr,\n" + "     prescription_dispenses pd,\n" + "     items it,\n"
        + "     health_care_profs  hcp,\n" + "     sbp_entity_bpm_process_map sebpm ,\n"
        + "     sbp_work_queue_task_bpm_task  swqtbt,\n" + "     sbp_entity_alert_log seal ,\n"
        + "     sbp_entity_rule_log serl,\n" + "     sbp_work_queue_task swqt ,\n"
        + "     sbp_wrk_que_dvrsn_task_config swqdtc,\n" + "     cg_ref_codes cg\n"
        + "	WHERE prh.pre_ordr_hdr_id=pod.pre_ordr_hdr_id\n" + "   AND prh.ptnt_id=pt.patient_id\n"
        + "   AND pod.rx_id =pr.id \n" + "   AND pod.rx_dspns_id=pd.id\n"
        + "   AND it.item_id=pd.item_id\n" + "   AND hcp.hcp_id = pr.hcp_id \n"
        + "   AND sebpm.sbp_enty_id= pod.rx_id\n" + "   AND sebpm.SBP_ENTY_TYP= 'PRESCRIPTION'\n"
        + "   AND cg.id=seal.alrt_id\n"
        + "   AND swqtbt.sbp_enty_bpm_prc_map_id=sebpm.sbp_enty_bpm_prc_map_id   \n"
        + "   AND seal.sbp_enty_rule_log_id=serl.sbp_enty_rule_log_id\n"
        + "   AND serl.sbp_enty_id=sebpm.sbp_enty_id   \n"
        + "   AND serl.bpm_prcs_instance_id = sebpm.bpm_prcs_instance_id   \n"
        + "   AND swqt.sbp_wrk_que_task_id= swqtbt.sbp_wrk_que_task_id\n"
        + "   AND swqdtc.sbp_wrk_que_task_id= swqt.sbp_wrk_que_task_id\n"
        + "   AND swqdtc.sbp_wrk_que_id= swqt.sbp_wrk_que_id\n" + "   AND sebpm.actv_in  ='Y' \n"
        + "   AND serl.actv_in  ='Y'\n" + "   AND seal.actv_in  ='Y'\n"
        + "   AND prh.PRE_ORDR_HDR_ID = ? and prh.PTNT_ID = ?";

    try {
      pStatement = con.prepareStatement(diversionQuery);
      pStatement.setLong(1, orderId);
      pStatement.setLong(2, patientID);
      ResultSet rs = pStatement.executeQuery();
      while (rs.next()) {
        rxDetailsList.setDiversion(rs.getString(5));
      }
      rs.close();
      con.close();
    } catch (SQLException e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "SQLException");
    }
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return rxDetailsList.getDiversion();
  }

}
