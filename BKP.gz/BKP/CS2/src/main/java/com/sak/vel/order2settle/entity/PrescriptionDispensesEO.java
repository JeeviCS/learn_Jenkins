package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PRESCRIPTION_DISPENSES database table.
 * 
 */
@Entity
@Table(name="PRESCRIPTION_DISPENSES")
@NamedQuery(name="PrescriptionDispensesEO.findAll", query="SELECT p FROM PrescriptionDispensesEO p")
public class PrescriptionDispensesEO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	@Column(name="AWP_AMT")
	private BigDecimal awpAmt;

	@Column(name="BILLED_RATE_HISTORY_ID")
	private BigDecimal billedRateHistoryId;

	@Column(name="BILLING_STATUS")
	private String billingStatus;

	@Column(name="BNFT_CHK_CMPLT_IN")
	private String bnftChkCmpltIn;

	@Column(name="COGNITIVE_IND")
	private String cognitiveInd;

	@Column(name="COMPOUND_FEE")
	private BigDecimal compoundFee;

	@Column(name="CONTRACT_RATE_HISTORY_ID")
	private BigDecimal contractRateHistoryId;

	private BigDecimal copay;

	@Column(name="CPM_ENROLLED")
	private String cpmEnrolled;

	@Column(name="CREATE_BY")
	private String createBy;

	@Column(name="CREATE_BY_FUNCTION")
	private String createByFunction;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_DATE")
	private Date createDate;

	@Column(name="CREATE_PHARMACARE_SYSTEM_ID")
	private BigDecimal createPharmacareSystemId;

	@Column(name="CREATE_PROCESS")
	private String createProcess;

	@Column(name="DAYS_SUPPLY")
	private BigDecimal daysSupply;

	@Column(name="DISPENSE_PROCESS")
	private String dispenseProcess;

	@Column(name="DISPENSE_STATUS")
	private String dispenseStatus;

	@Column(name="DISPENSE_TYPE")
	private String dispenseType;

	@Temporal(TemporalType.DATE)
	@Column(name="DISPENSED_DATE")
	private Date dispensedDate;

	@Column(name="DISPENSING_COMPANY_ID")
	private BigDecimal dispensingCompanyId;

	@Column(name="DISPENSING_FEE")
	private BigDecimal dispensingFee;

	@Column(name="DISPENSING_SITE_ID")
	private BigDecimal dispensingSiteId;

	@Temporal(TemporalType.DATE)
	@Column(name="DOWNLOAD_DATE")
	private Date downloadDate;

	@Temporal(TemporalType.DATE)
	@Column(name="DOWNLOAD_DATE_TIME")
	private Date downloadDateTime;

	@Temporal(TemporalType.DATE)
	@Column(name="DSPNS_CMPLTN_TRGT_DT")
	private Date dspnsCmpltnTrgtDt;

	@Column(name="ECS_HIPAA_ID")
	private BigDecimal ecsHipaaId;

	@Column(name="ECS_ORIGINAL_BILLED_AMOUNT")
	private BigDecimal ecsOriginalBilledAmount;

	@Column(name="ECS_RESPONSE_AMOUNT")
	private BigDecimal ecsResponseAmount;

	@Column(name="EDIT_FAILURE_ID")
	private BigDecimal editFailureId;

	@Column(name="ELIG_CHK_IN")
	private String eligChkIn;

	@Column(name="EPCS_IND")
	private String epcsInd;

	@Temporal(TemporalType.DATE)
	@Column(name="EXHAUST_DATE")
	private Date exhaustDate;

	@Temporal(TemporalType.DATE)
	@Column(name="FILL_ON_OR_AFTR_DT")
	private Date fillOnOrAftrDt;

	@Column(name="FLAT_TAX_PAID_AMT")
	private BigDecimal flatTaxPaidAmt;

	@Temporal(TemporalType.DATE)
	@Column(name="FOLLOW_UP_DATE")
	private Date followUpDate;

	@Column(name="HBS_PRICE")
	private BigDecimal hbsPrice;

	@Column(name="INGREDIENT_COST")
	private BigDecimal ingredientCost;

	@Column(name="INVENTORY_LOCATION_ID")
	private BigDecimal inventoryLocationId;

	@Column(name="ISP_COPAY_QUALIFIER")
	private String ispCopayQualifier;

	@Column(name="ISP_FILL_STATUS")
	private String ispFillStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="ISP_FILL_STATUS_DATE")
	private Date ispFillStatusDate;

	@Column(name="LOT_NUMBER")
	private String lotNumber;

	@Column(name="MANDATORY_PRICE_HISTORY_ID")
	private BigDecimal mandatoryPriceHistoryId;

	@Column(name="NDC_DISPENSED")
	private String ndcDispensed;

	@Column(name="PARTIAL_DISPENSE_REASON")
	private BigDecimal partialDispenseReason;

	@Column(name="PC_BASE_FORMULA_AMOUNT")
	private BigDecimal pcBaseFormulaAmount;

	@Column(name="PC_CONTRACT_PRICE")
	private BigDecimal pcContractPrice;

	@Column(name="PC_COVERAGE_TYPE_CODE")
	private String pcCoverageTypeCode;

	@Column(name="PC_DISPENSE_FEE")
	private BigDecimal pcDispenseFee;

	@Column(name="PC_EXCEPTION_CODE")
	private BigDecimal pcExceptionCode;

	@Column(name="PC_FORMULA_PERCENTAGE")
	private BigDecimal pcFormulaPercentage;

	@Column(name="PC_FORMULA_TYPE")
	private String pcFormulaType;

	@Column(name="PC_OVERRIDE_DESCRIPTION")
	private String pcOverrideDescription;

	@Column(name="PLACE_OF_SERVICE_ID")
	private BigDecimal placeOfServiceId;

	@Column(name="PRESCRIPTIONS_ID")
	private BigDecimal prescriptionsId;

	private BigDecimal price;

	@Column(name="PRICE_TYPE_IND")
	private String priceTypeInd;

	@Column(name="PRIMARY_BILL_GRP_ID")
	private BigDecimal primaryBillGrpId;

	@Column(name="PRIMARY_PBG_ID")
	private BigDecimal primaryPbgId;

	@Column(name="PRIMARY_PBU_ID")
	private BigDecimal primaryPbuId;

	@Temporal(TemporalType.DATE)
	@Column(name="PROMISE_DATE")
	private Date promiseDate;

	@Column(name="PROMISE_DATE_REASON_ID")
	private BigDecimal promiseDateReasonId;

	@Column(name="QUANTITY_DISPENSED")
	private BigDecimal quantityDispensed;

	@Column(name="REFILL_NUMBER")
	private BigDecimal refillNumber;

	private String rftype;

	@Column(name="RPH_INITIALS")
	private String rphInitials;

	@Column(name="RX_INFO_CHK_CMPLT_IN")
	private String rxInfoChkCmpltIn;

	@Column(name="RX_XFER_IND")
	private String rxXferInd;

	@Column(name="SALES_TAX_AMT")
	private BigDecimal salesTaxAmt;

	@Column(name="SALES_TAX_PAID_AMT")
	private BigDecimal salesTaxPaidAmt;

	@Column(name="SECONDARY_BILL_GRP_ID")
	private BigDecimal secondaryBillGrpId;

	@Column(name="SECONDARY_PBG_ID")
	private BigDecimal secondaryPbgId;

	@Column(name="SECONDARY_PBU_ID")
	private BigDecimal secondaryPbuId;

	@Column(name="SENT_TO_PROTOCALLS")
	private String sentToProtocalls;

	@Temporal(TemporalType.DATE)
	@Column(name="SRC_DELETE_DATE")
	private Date srcDeleteDate;

	@Column(name="STANDARD_PRICE_HISTORY_ID")
	private BigDecimal standardPriceHistoryId;

	@Column(name="TAX_AMOUNT")
	private BigDecimal taxAmount;

	@Column(name="TECH_INITIALS")
	private String techInitials;

	@Column(name="TERMINAL_NAME")
	private String terminalName;

	@Column(name="UNTAG_REASON_CODE")
	private BigDecimal untagReasonCode;

	@Column(name="UPDATE_BY")
	private String updateBy;

	@Column(name="UPDATE_BY_FUNCTION")
	private String updateByFunction;

	@Temporal(TemporalType.DATE)
	@Column(name="UPDATE_DATE")
	private Date updateDate;

	@Column(name="UPDATE_PHARMACARE_SYSTEM_ID")
	private BigDecimal updatePharmacareSystemId;

	@Column(name="UPDATE_PROCESS")
	private String updateProcess;

	@Column(name="USUAL_CUSTOMARY")
	private BigDecimal usualCustomary;

	@Column(name="WEIGHTED_AVG_OFS")
	private BigDecimal weightedAvgOfs;

	//bi-directional many-to-one association to Item
	@ManyToOne
	@JoinColumn(name="ITEM_ID")
	private ItemEO item;

	//bi-directional many-to-one association to PreOrderDetail
	@OneToMany(mappedBy="prescriptionDispens")
	private List<PreOrderDetailEO> preOrderDetails;

	public PrescriptionDispensesEO() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getAwpAmt() {
		return this.awpAmt;
	}

	public void setAwpAmt(BigDecimal awpAmt) {
		this.awpAmt = awpAmt;
	}

	public BigDecimal getBilledRateHistoryId() {
		return this.billedRateHistoryId;
	}

	public void setBilledRateHistoryId(BigDecimal billedRateHistoryId) {
		this.billedRateHistoryId = billedRateHistoryId;
	}

	public String getBillingStatus() {
		return this.billingStatus;
	}

	public void setBillingStatus(String billingStatus) {
		this.billingStatus = billingStatus;
	}

	public String getBnftChkCmpltIn() {
		return this.bnftChkCmpltIn;
	}

	public void setBnftChkCmpltIn(String bnftChkCmpltIn) {
		this.bnftChkCmpltIn = bnftChkCmpltIn;
	}

	public String getCognitiveInd() {
		return this.cognitiveInd;
	}

	public void setCognitiveInd(String cognitiveInd) {
		this.cognitiveInd = cognitiveInd;
	}

	public BigDecimal getCompoundFee() {
		return this.compoundFee;
	}

	public void setCompoundFee(BigDecimal compoundFee) {
		this.compoundFee = compoundFee;
	}

	public BigDecimal getContractRateHistoryId() {
		return this.contractRateHistoryId;
	}

	public void setContractRateHistoryId(BigDecimal contractRateHistoryId) {
		this.contractRateHistoryId = contractRateHistoryId;
	}

	public BigDecimal getCopay() {
		return this.copay;
	}

	public void setCopay(BigDecimal copay) {
		this.copay = copay;
	}

	public String getCpmEnrolled() {
		return this.cpmEnrolled;
	}

	public void setCpmEnrolled(String cpmEnrolled) {
		this.cpmEnrolled = cpmEnrolled;
	}

	public String getCreateBy() {
		return this.createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getCreateByFunction() {
		return this.createByFunction;
	}

	public void setCreateByFunction(String createByFunction) {
		this.createByFunction = createByFunction;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public BigDecimal getCreatePharmacareSystemId() {
		return this.createPharmacareSystemId;
	}

	public void setCreatePharmacareSystemId(BigDecimal createPharmacareSystemId) {
		this.createPharmacareSystemId = createPharmacareSystemId;
	}

	public String getCreateProcess() {
		return this.createProcess;
	}

	public void setCreateProcess(String createProcess) {
		this.createProcess = createProcess;
	}

	public BigDecimal getDaysSupply() {
		return this.daysSupply;
	}

	public void setDaysSupply(BigDecimal daysSupply) {
		this.daysSupply = daysSupply;
	}

	public String getDispenseProcess() {
		return this.dispenseProcess;
	}

	public void setDispenseProcess(String dispenseProcess) {
		this.dispenseProcess = dispenseProcess;
	}

	public String getDispenseStatus() {
		return this.dispenseStatus;
	}

	public void setDispenseStatus(String dispenseStatus) {
		this.dispenseStatus = dispenseStatus;
	}

	public String getDispenseType() {
		return this.dispenseType;
	}

	public void setDispenseType(String dispenseType) {
		this.dispenseType = dispenseType;
	}

	public Date getDispensedDate() {
		return this.dispensedDate;
	}

	public void setDispensedDate(Date dispensedDate) {
		this.dispensedDate = dispensedDate;
	}

	public BigDecimal getDispensingCompanyId() {
		return this.dispensingCompanyId;
	}

	public void setDispensingCompanyId(BigDecimal dispensingCompanyId) {
		this.dispensingCompanyId = dispensingCompanyId;
	}

	public BigDecimal getDispensingFee() {
		return this.dispensingFee;
	}

	public void setDispensingFee(BigDecimal dispensingFee) {
		this.dispensingFee = dispensingFee;
	}

	public BigDecimal getDispensingSiteId() {
		return this.dispensingSiteId;
	}

	public void setDispensingSiteId(BigDecimal dispensingSiteId) {
		this.dispensingSiteId = dispensingSiteId;
	}

	public Date getDownloadDate() {
		return this.downloadDate;
	}

	public void setDownloadDate(Date downloadDate) {
		this.downloadDate = downloadDate;
	}

	public Date getDownloadDateTime() {
		return this.downloadDateTime;
	}

	public void setDownloadDateTime(Date downloadDateTime) {
		this.downloadDateTime = downloadDateTime;
	}

	public Date getDspnsCmpltnTrgtDt() {
		return this.dspnsCmpltnTrgtDt;
	}

	public void setDspnsCmpltnTrgtDt(Date dspnsCmpltnTrgtDt) {
		this.dspnsCmpltnTrgtDt = dspnsCmpltnTrgtDt;
	}

	public BigDecimal getEcsHipaaId() {
		return this.ecsHipaaId;
	}

	public void setEcsHipaaId(BigDecimal ecsHipaaId) {
		this.ecsHipaaId = ecsHipaaId;
	}

	public BigDecimal getEcsOriginalBilledAmount() {
		return this.ecsOriginalBilledAmount;
	}

	public void setEcsOriginalBilledAmount(BigDecimal ecsOriginalBilledAmount) {
		this.ecsOriginalBilledAmount = ecsOriginalBilledAmount;
	}

	public BigDecimal getEcsResponseAmount() {
		return this.ecsResponseAmount;
	}

	public void setEcsResponseAmount(BigDecimal ecsResponseAmount) {
		this.ecsResponseAmount = ecsResponseAmount;
	}

	public BigDecimal getEditFailureId() {
		return this.editFailureId;
	}

	public void setEditFailureId(BigDecimal editFailureId) {
		this.editFailureId = editFailureId;
	}

	public String getEligChkIn() {
		return this.eligChkIn;
	}

	public void setEligChkIn(String eligChkIn) {
		this.eligChkIn = eligChkIn;
	}

	public String getEpcsInd() {
		return this.epcsInd;
	}

	public void setEpcsInd(String epcsInd) {
		this.epcsInd = epcsInd;
	}

	public Date getExhaustDate() {
		return this.exhaustDate;
	}

	public void setExhaustDate(Date exhaustDate) {
		this.exhaustDate = exhaustDate;
	}

	public Date getFillOnOrAftrDt() {
		return this.fillOnOrAftrDt;
	}

	public void setFillOnOrAftrDt(Date fillOnOrAftrDt) {
		this.fillOnOrAftrDt = fillOnOrAftrDt;
	}

	public BigDecimal getFlatTaxPaidAmt() {
		return this.flatTaxPaidAmt;
	}

	public void setFlatTaxPaidAmt(BigDecimal flatTaxPaidAmt) {
		this.flatTaxPaidAmt = flatTaxPaidAmt;
	}

	public Date getFollowUpDate() {
		return this.followUpDate;
	}

	public void setFollowUpDate(Date followUpDate) {
		this.followUpDate = followUpDate;
	}

	public BigDecimal getHbsPrice() {
		return this.hbsPrice;
	}

	public void setHbsPrice(BigDecimal hbsPrice) {
		this.hbsPrice = hbsPrice;
	}

	public BigDecimal getIngredientCost() {
		return this.ingredientCost;
	}

	public void setIngredientCost(BigDecimal ingredientCost) {
		this.ingredientCost = ingredientCost;
	}

	public BigDecimal getInventoryLocationId() {
		return this.inventoryLocationId;
	}

	public void setInventoryLocationId(BigDecimal inventoryLocationId) {
		this.inventoryLocationId = inventoryLocationId;
	}

	public String getIspCopayQualifier() {
		return this.ispCopayQualifier;
	}

	public void setIspCopayQualifier(String ispCopayQualifier) {
		this.ispCopayQualifier = ispCopayQualifier;
	}

	public String getIspFillStatus() {
		return this.ispFillStatus;
	}

	public void setIspFillStatus(String ispFillStatus) {
		this.ispFillStatus = ispFillStatus;
	}

	public Date getIspFillStatusDate() {
		return this.ispFillStatusDate;
	}

	public void setIspFillStatusDate(Date ispFillStatusDate) {
		this.ispFillStatusDate = ispFillStatusDate;
	}

	public String getLotNumber() {
		return this.lotNumber;
	}

	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}

	public BigDecimal getMandatoryPriceHistoryId() {
		return this.mandatoryPriceHistoryId;
	}

	public void setMandatoryPriceHistoryId(BigDecimal mandatoryPriceHistoryId) {
		this.mandatoryPriceHistoryId = mandatoryPriceHistoryId;
	}

	public String getNdcDispensed() {
		return this.ndcDispensed;
	}

	public void setNdcDispensed(String ndcDispensed) {
		this.ndcDispensed = ndcDispensed;
	}

	public BigDecimal getPartialDispenseReason() {
		return this.partialDispenseReason;
	}

	public void setPartialDispenseReason(BigDecimal partialDispenseReason) {
		this.partialDispenseReason = partialDispenseReason;
	}

	public BigDecimal getPcBaseFormulaAmount() {
		return this.pcBaseFormulaAmount;
	}

	public void setPcBaseFormulaAmount(BigDecimal pcBaseFormulaAmount) {
		this.pcBaseFormulaAmount = pcBaseFormulaAmount;
	}

	public BigDecimal getPcContractPrice() {
		return this.pcContractPrice;
	}

	public void setPcContractPrice(BigDecimal pcContractPrice) {
		this.pcContractPrice = pcContractPrice;
	}

	public String getPcCoverageTypeCode() {
		return this.pcCoverageTypeCode;
	}

	public void setPcCoverageTypeCode(String pcCoverageTypeCode) {
		this.pcCoverageTypeCode = pcCoverageTypeCode;
	}

	public BigDecimal getPcDispenseFee() {
		return this.pcDispenseFee;
	}

	public void setPcDispenseFee(BigDecimal pcDispenseFee) {
		this.pcDispenseFee = pcDispenseFee;
	}

	public BigDecimal getPcExceptionCode() {
		return this.pcExceptionCode;
	}

	public void setPcExceptionCode(BigDecimal pcExceptionCode) {
		this.pcExceptionCode = pcExceptionCode;
	}

	public BigDecimal getPcFormulaPercentage() {
		return this.pcFormulaPercentage;
	}

	public void setPcFormulaPercentage(BigDecimal pcFormulaPercentage) {
		this.pcFormulaPercentage = pcFormulaPercentage;
	}

	public String getPcFormulaType() {
		return this.pcFormulaType;
	}

	public void setPcFormulaType(String pcFormulaType) {
		this.pcFormulaType = pcFormulaType;
	}

	public String getPcOverrideDescription() {
		return this.pcOverrideDescription;
	}

	public void setPcOverrideDescription(String pcOverrideDescription) {
		this.pcOverrideDescription = pcOverrideDescription;
	}

	public BigDecimal getPlaceOfServiceId() {
		return this.placeOfServiceId;
	}

	public void setPlaceOfServiceId(BigDecimal placeOfServiceId) {
		this.placeOfServiceId = placeOfServiceId;
	}

	public BigDecimal getPrescriptionsId() {
		return this.prescriptionsId;
	}

	public void setPrescriptionsId(BigDecimal prescriptionsId) {
		this.prescriptionsId = prescriptionsId;
	}

	public BigDecimal getPrice() {
		return this.price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getPriceTypeInd() {
		return this.priceTypeInd;
	}

	public void setPriceTypeInd(String priceTypeInd) {
		this.priceTypeInd = priceTypeInd;
	}

	public BigDecimal getPrimaryBillGrpId() {
		return this.primaryBillGrpId;
	}

	public void setPrimaryBillGrpId(BigDecimal primaryBillGrpId) {
		this.primaryBillGrpId = primaryBillGrpId;
	}

	public BigDecimal getPrimaryPbgId() {
		return this.primaryPbgId;
	}

	public void setPrimaryPbgId(BigDecimal primaryPbgId) {
		this.primaryPbgId = primaryPbgId;
	}

	public BigDecimal getPrimaryPbuId() {
		return this.primaryPbuId;
	}

	public void setPrimaryPbuId(BigDecimal primaryPbuId) {
		this.primaryPbuId = primaryPbuId;
	}

	public Date getPromiseDate() {
		return this.promiseDate;
	}

	public void setPromiseDate(Date promiseDate) {
		this.promiseDate = promiseDate;
	}

	public BigDecimal getPromiseDateReasonId() {
		return this.promiseDateReasonId;
	}

	public void setPromiseDateReasonId(BigDecimal promiseDateReasonId) {
		this.promiseDateReasonId = promiseDateReasonId;
	}

	public BigDecimal getQuantityDispensed() {
		return this.quantityDispensed;
	}

	public void setQuantityDispensed(BigDecimal quantityDispensed) {
		this.quantityDispensed = quantityDispensed;
	}

	public BigDecimal getRefillNumber() {
		return this.refillNumber;
	}

	public void setRefillNumber(BigDecimal refillNumber) {
		this.refillNumber = refillNumber;
	}

	public String getRftype() {
		return this.rftype;
	}

	public void setRftype(String rftype) {
		this.rftype = rftype;
	}

	public String getRphInitials() {
		return this.rphInitials;
	}

	public void setRphInitials(String rphInitials) {
		this.rphInitials = rphInitials;
	}

	public String getRxInfoChkCmpltIn() {
		return this.rxInfoChkCmpltIn;
	}

	public void setRxInfoChkCmpltIn(String rxInfoChkCmpltIn) {
		this.rxInfoChkCmpltIn = rxInfoChkCmpltIn;
	}

	public String getRxXferInd() {
		return this.rxXferInd;
	}

	public void setRxXferInd(String rxXferInd) {
		this.rxXferInd = rxXferInd;
	}

	public BigDecimal getSalesTaxAmt() {
		return this.salesTaxAmt;
	}

	public void setSalesTaxAmt(BigDecimal salesTaxAmt) {
		this.salesTaxAmt = salesTaxAmt;
	}

	public BigDecimal getSalesTaxPaidAmt() {
		return this.salesTaxPaidAmt;
	}

	public void setSalesTaxPaidAmt(BigDecimal salesTaxPaidAmt) {
		this.salesTaxPaidAmt = salesTaxPaidAmt;
	}

	public BigDecimal getSecondaryBillGrpId() {
		return this.secondaryBillGrpId;
	}

	public void setSecondaryBillGrpId(BigDecimal secondaryBillGrpId) {
		this.secondaryBillGrpId = secondaryBillGrpId;
	}

	public BigDecimal getSecondaryPbgId() {
		return this.secondaryPbgId;
	}

	public void setSecondaryPbgId(BigDecimal secondaryPbgId) {
		this.secondaryPbgId = secondaryPbgId;
	}

	public BigDecimal getSecondaryPbuId() {
		return this.secondaryPbuId;
	}

	public void setSecondaryPbuId(BigDecimal secondaryPbuId) {
		this.secondaryPbuId = secondaryPbuId;
	}

	public String getSentToProtocalls() {
		return this.sentToProtocalls;
	}

	public void setSentToProtocalls(String sentToProtocalls) {
		this.sentToProtocalls = sentToProtocalls;
	}

	public Date getSrcDeleteDate() {
		return this.srcDeleteDate;
	}

	public void setSrcDeleteDate(Date srcDeleteDate) {
		this.srcDeleteDate = srcDeleteDate;
	}

	public BigDecimal getStandardPriceHistoryId() {
		return this.standardPriceHistoryId;
	}

	public void setStandardPriceHistoryId(BigDecimal standardPriceHistoryId) {
		this.standardPriceHistoryId = standardPriceHistoryId;
	}

	public BigDecimal getTaxAmount() {
		return this.taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getTechInitials() {
		return this.techInitials;
	}

	public void setTechInitials(String techInitials) {
		this.techInitials = techInitials;
	}

	public String getTerminalName() {
		return this.terminalName;
	}

	public void setTerminalName(String terminalName) {
		this.terminalName = terminalName;
	}

	public BigDecimal getUntagReasonCode() {
		return this.untagReasonCode;
	}

	public void setUntagReasonCode(BigDecimal untagReasonCode) {
		this.untagReasonCode = untagReasonCode;
	}

	public String getUpdateBy() {
		return this.updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public String getUpdateByFunction() {
		return this.updateByFunction;
	}

	public void setUpdateByFunction(String updateByFunction) {
		this.updateByFunction = updateByFunction;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public BigDecimal getUpdatePharmacareSystemId() {
		return this.updatePharmacareSystemId;
	}

	public void setUpdatePharmacareSystemId(BigDecimal updatePharmacareSystemId) {
		this.updatePharmacareSystemId = updatePharmacareSystemId;
	}

	public String getUpdateProcess() {
		return this.updateProcess;
	}

	public void setUpdateProcess(String updateProcess) {
		this.updateProcess = updateProcess;
	}

	public BigDecimal getUsualCustomary() {
		return this.usualCustomary;
	}

	public void setUsualCustomary(BigDecimal usualCustomary) {
		this.usualCustomary = usualCustomary;
	}

	public BigDecimal getWeightedAvgOfs() {
		return this.weightedAvgOfs;
	}

	public void setWeightedAvgOfs(BigDecimal weightedAvgOfs) {
		this.weightedAvgOfs = weightedAvgOfs;
	}

	public ItemEO getItem() {
		return this.item;
	}

	public void setItem(ItemEO item) {
		this.item = item;
	}

	public List<PreOrderDetailEO> getPreOrderDetails() {
		return this.preOrderDetails;
	}

	public void setPreOrderDetails(List<PreOrderDetailEO> preOrderDetails) {
		this.preOrderDetails = preOrderDetails;
	}

	public PreOrderDetailEO addPreOrderDetail(PreOrderDetailEO preOrderDetail) {
		getPreOrderDetails().add(preOrderDetail);
		preOrderDetail.setPrescriptionDispens(this);

		return preOrderDetail;
	}

	public PreOrderDetailEO removePreOrderDetail(PreOrderDetailEO preOrderDetail) {
		getPreOrderDetails().remove(preOrderDetail);
		preOrderDetail.setPrescriptionDispens(null);

		return preOrderDetail;
	}

}