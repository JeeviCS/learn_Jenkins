/*package com.cvs.specialty.ordermaintenance.rabbitMq.consumer;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.messaging.Message;

@EnableBinding(Sink.class)
public class New_Consumer {
	@StreamListener(Sink.INPUT)
	public void messgaeConsumer(Message<?> message) {
		System.out.println("Consumed Message from RabbitMq-Headers = " + message.getHeaders().get("access-token"));
		System.out.println("Consumed Message from RabbitMq-Payload = " + message.getPayload());
	}
}
*/