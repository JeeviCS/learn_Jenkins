
package com.cvs.specialty.ordermaintenance.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.ShippingDetailsDao;
import com.cvs.specialty.ordermaintenance.entity.HbsShipmentExtract;
import com.cvs.specialty.ordermaintenance.model.ShipmentDetails;
import com.cvs.specialty.ordermaintenance.repository.ShippingDetailsRepo;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Repository
public class ShippingDetailsDaoImpl implements ShippingDetailsDao {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  ShippingDetailsRepo shippingDetailsRepo;

  @Override
  public ShipmentDetails getShippingDetails(long preOrderId, String status, String shipmentNumber) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);

    ShipmentDetails shipmentDetails = new ShipmentDetails();
    try {
      HbsShipmentExtract shipmentDetailsEO = shippingDetailsRepo.findByShpNo(shipmentNumber);

      if (null != shipmentDetailsEO) {

        shipmentDetails.setShipmentNumber(shipmentNumber);
        shipmentDetails.setOrderDownloadDate(shipmentDetailsEO.getShpCreateDatetm());
        shipmentDetails.setOrderShippedDate(shipmentDetailsEO.getShpActDateDt());
        shipmentDetails.setOrderDownloadUserInitials(shipmentDetailsEO.getShpRph());
        shipmentDetails.setShippedLocation(shipmentDetailsEO.getShpShipLoc());
        shipmentDetails.setPpsStatus(null);
        shipmentDetails.setShippingMethodService(shipmentDetailsEO.getShpActCarrMod());
        shipmentDetails.setOrderTrackingNum1(shipmentDetailsEO.getShpTrack1());
        shipmentDetails.setOrderTrackingNum2(shipmentDetailsEO.getShpTrack2());
        shipmentDetails.setOrderTrackingNum3(shipmentDetailsEO.getShpTrack3());
        shipmentDetails.setPackOperator(null);
        shipmentDetails.setWelcomePackIndicator(null);
        shipmentDetails.setExpansionPackIndicator(null);
        // shipmentDetails.setZipExtensionCode(shipmentDetailsEO.getz);
        shipmentDetails.setCancelReason(null);
        shipmentDetails.setAddress1(shipmentDetailsEO.getShpAddr1());
        shipmentDetails.setAddress2(shipmentDetailsEO.getShpAddr2());
        shipmentDetails.setCity(shipmentDetailsEO.getShpCity());
        shipmentDetails.setState(shipmentDetailsEO.getShpState());
        shipmentDetails.setCountry(null);
        shipmentDetails.setStoreNum(shipmentDetailsEO.getShippedToStoreNumber());
        shipmentDetails.setPhoneNum(shipmentDetailsEO.getShpPhone());
        shipmentDetails.setBarcodeNum(shipmentDetailsEO.getBarcodeNo());
        shipmentDetails.setCheckInDate(shipmentDetailsEO.getInstrFormFaxByStoreDate());
        shipmentDetails.setPickUpDate(shipmentDetailsEO.getActualInStorePickupDate());
        shipmentDetails.setAnticipatedDate(shipmentDetailsEO.getAnticipatedPickupDate());
        // LOGGER.info("----------->" + shipmentDetailsEO.getShpNo());

      }
    } catch (DataAccessException e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      throw new OrderMaintenanceException(e, "DataAccessException");
    }
    LOGGER.info(LogMsgConstants.METHOD_EXIT);
    return shipmentDetails;
  }

}
