
package com.cvs.specialty.ordermaintenance.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderStatusDao;
import com.cvs.specialty.ordermaintenance.service.OrderStatusService;

@Service
public class OrderStatusServiceImpl implements OrderStatusService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  OrderStatusDao orderstat;

  @Override
  public ResponseEntity<Void> updateOrderStatus(Long preOrdrHdrId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    try {
      orderstat.updateOrderStatus(preOrdrHdrId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return new ResponseEntity<Void>(HttpStatus.OK);

    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }

  }

}
