
package com.cvs.specialty.ordermaintenance.dao.impl;
/**
 * 
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.cvs.specialty.ordermaintenance.dao.PatientIdCurrentOrdersDAO;
import com.cvs.specialty.ordermaintenance.mapper.PatientIdCurrentOrdersMapper;
import com.cvs.specialty.ordermaintenance.model.CurrentOrders;
import com.cvs.specialty.ordermaintenance.util.OrderMaintenanceException;

@Service
public class PatientIdCurrentOrdersDAOImpl implements PatientIdCurrentOrdersDAO {
  private static final Logger logger = LoggerFactory.getLogger(PatientIdCurrentOrdersDAOImpl.class);

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  private JdbcTemplate jdbcTemplate;

  @Autowired
  PatientIdCurrentOrdersMapper mapper;

  @Transactional
  public List<CurrentOrders> getCurrentOrderDetails(long patientId) throws DataAccessException {
    List<CurrentOrders> listCurrentOrdersResponse = new ArrayList();
    try {

      StringBuilder queryBuilder = new StringBuilder();

      queryBuilder.append(
        "SELECT pdo.ORDER_NUMBER, hcp.LAST_NAME ,hdr.ORDR_STUS_CD ,pdo.SHIPPED_DATE,hdr.ARV_ON_BY_CD ,pdo.NEEDS_DT, p.QUANTITY_WRITTEN "
            + " FROM pre_order_header  hdr, pre_order_detail dtl,prescriptions p,prescription_dispenses pd,prescription_disp_orders pdo,health_care_profs hcp "
            + " WHERE hdr.pre_ordr_hdr_id = dtl.pre_ordr_hdr_id AND dtl.rx_id = p.id AND pd.prescriptions_id = p.id AND pdo.prescriptions_dispenses_id = pd.id AND p.hcp_id = hcp.hcp_id");

      if (!StringUtils.isEmpty(patientId)) {
        queryBuilder.append(" AND  p.patient_id = " + patientId);
      }

      List<Map<String, Object>> queryForList = jdbcTemplate.queryForList(queryBuilder.toString());
      for (Map<String, Object> row : queryForList) {
        listCurrentOrdersResponse.add(mapper.mappingCurrentOrdersEntityToModel(row));
      }

    } catch (DataAccessException ce) {
      ce.printStackTrace();
      logger.error("Get current orders operation " + ce);

      throw new OrderMaintenanceException(ce, "DataAccessException");
    }

    return listCurrentOrdersResponse;
  }
}
