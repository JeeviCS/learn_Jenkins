
package com.cvs.specialty.ordermaintenance.api;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.ordermaintenance.model.CancelOrderResponse;
import com.cvs.specialty.ordermaintenance.model.OrderCancelRequest;
import com.cvs.specialty.ordermaintenance.service.CancelOrderService;
import com.cvs.specialty.ordermaintenance.service.impl.CancelOrderServiceImpl;

import io.swagger.annotations.ApiParam;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-02-23T04:18:50.004Z")

@Controller
public class CancelOrderApiController implements CancelOrderApi {
	@Autowired
	SpecialtyLogger serviceLogger;

	@Autowired
	CancelOrderService cancelOrderService;
	
	@Autowired 
	CancelOrderServiceImpl cancelOrderServiceImpl;
	
	/*@Autowired 
	OrderCancelRequest orderCancelRequest;*/
	
	@Autowired
	RestTemplate restTemplate;

	public ResponseEntity<CancelOrderResponse> cancelOrderPut(@ApiParam(value = "access token to validate this request" ,required=true) @RequestHeader(value="access-token", required=true) String accessToken,
			@ApiParam(value = "Unique identifier for the message" ,required=true) @RequestHeader(value="message-id", required=true) String messageId,
			@ApiParam(value = "Cancel Order JSON"  )  @Valid @RequestBody OrderCancelRequest cancelOrder, HttpServletRequest request) {
		CancelOrderResponse cancelOrderResponse=null;
		
		if (StringUtils.isEmpty(messageId)) {
			return new ResponseEntity<CancelOrderResponse>(cancelOrderResponse, HttpStatus.UNAUTHORIZED);
		}
		String userId = null;
		if (request.getAttribute("user-id") != null) {
			userId = (String) request.getAttribute("user-id");
		} else {
			userId = "TEST";
		}

		try {
			if (cancelOrder != null ) {
				cancelOrderResponse=cancelOrderService.submitCancelOrder(cancelOrder, userId, accessToken, messageId);
				serviceLogger.info("Success response");
				/*if(cancelOrderResponse.getMessage().equalsIgnoreCase("SUCCESS") && cancelOrder.getPatientNotifiedFlag()== false) {
					cancelOrderServiceImpl.callCreateServicerForPatientNotified(userId,accessToken,messageId, cancelOrder);
				}else if(cancelOrderResponse.getMessage().equalsIgnoreCase("SUCCESS") && cancelOrder.getMdNotifiedFlag()== false)
				{
					cancelOrderServiceImpl.callCreateServicerForMD_Notified(userId, accessToken, messageId, cancelOrder);
				}*/
				if(cancelOrderResponse.getMessage().equalsIgnoreCase("SUCCESS")) {
					//cancelOrderServiceImpl.callCancelTask(userId, messageId, accessToken,cancelOrder);
					if(cancelOrder.getPatientNotifiedFlag()== false) {
						cancelOrderServiceImpl.callCreateService(userId,accessToken,messageId, cancelOrder);
					}else if(cancelOrder.getMdNotifiedFlag()== false) {
						cancelOrderServiceImpl.callCreateService(userId, accessToken, messageId, cancelOrder);
					}
				}
			 return new ResponseEntity<CancelOrderResponse>(cancelOrderResponse, HttpStatus.OK);
				
			} else {
				return new ResponseEntity<CancelOrderResponse>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<CancelOrderResponse>(HttpStatus.INTERNAL_SERVER_ERROR);

		}
		
}

}
