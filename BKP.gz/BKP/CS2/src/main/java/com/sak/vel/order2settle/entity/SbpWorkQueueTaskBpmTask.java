
package com.cvs.specialty.ordermaintenance.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;

/**
 * The persistent class for the SBP_WORK_QUEUE_TASK_BPM_TASK database table.
 * 
 */
@Entity
@Table(name = "SBP_WORK_QUEUE_TASK_BPM_TASK")
@NamedQuery(name = "SbpWorkQueueTaskBpmTask.findAll", query = "SELECT s FROM SbpWorkQueueTaskBpmTask s")
public class SbpWorkQueueTaskBpmTask implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "SBP_WRK_QUE_TASK_BPM_TASK_ID")
  private long sbpWrkQueTaskBpmTaskId;

  @Column(name = "ACTV_IN")
  private String actvIn;

  @Column(name = "BPM_TASK_INSTANCE_ID")
  private BigDecimal bpmTaskInstanceId;

  @Column(name = "BPM_TASK_NM")
  private String bpmTaskNm;

  @Column(name = "CMPLT_TASK_USR_ID")
  private String cmpltTaskUsrId;

  @Column(name = "CMPLTN_TS")
  private Timestamp cmpltnTs;

  @Column(name = "CRTE_TS")
  private Timestamp crteTs;

  @Column(name = "CRTE_USR_NM")
  private String crteUsrNm;

  @Column(name = "FLUP_TS")
  private Timestamp flupTs;

  @Column(name = "HLTCR_PRFSN_NTFID_IN")
  private String hltcrPrfsnNtfidIn;

  @Column(name = "PTNT_NTFID_IN")
  private String ptntNtfidIn;

	@Column(name="SBP_ENTY_BPM_PRC_MAP_ID")
	private Long sbpEntyBpmPrcMapId;

  @Column(name = "SBP_QUE_TASK_STUS_CD")
  private String sbpQueTaskStusCd;

  @Column(name = "SBP_QUE_TASK_STUS_RSN_CD")
  private String sbpQueTaskStusRsnCd;

  @Column(name = "SBP_WRK_QUE_TASK_ID")
  private BigDecimal sbpWrkQueTaskId;

  @Column(name = "UPD_TS")
  private Timestamp updTs;

  @Column(name = "UPD_USR_NM")
  private String updUsrNm;

	public SbpWorkQueueTaskBpmTask() {
	}

  public long getSbpWrkQueTaskBpmTaskId() {
    return this.sbpWrkQueTaskBpmTaskId;
  }

  public void setSbpWrkQueTaskBpmTaskId(long sbpWrkQueTaskBpmTaskId) {
    this.sbpWrkQueTaskBpmTaskId = sbpWrkQueTaskBpmTaskId;
  }

  public String getActvIn() {
    return this.actvIn;
  }

  public void setActvIn(String actvIn) {
    this.actvIn = actvIn;
  }

  public BigDecimal getBpmTaskInstanceId() {
    return this.bpmTaskInstanceId;
  }

  public void setBpmTaskInstanceId(BigDecimal bpmTaskInstanceId) {
    this.bpmTaskInstanceId = bpmTaskInstanceId;
  }

  public String getBpmTaskNm() {
    return this.bpmTaskNm;
  }

  public void setBpmTaskNm(String bpmTaskNm) {
    this.bpmTaskNm = bpmTaskNm;
  }

  public String getCmpltTaskUsrId() {
    return this.cmpltTaskUsrId;
  }

  public void setCmpltTaskUsrId(String cmpltTaskUsrId) {
    this.cmpltTaskUsrId = cmpltTaskUsrId;
  }

  public Timestamp getCmpltnTs() {
    return this.cmpltnTs;
  }

  public void setCmpltnTs(Timestamp cmpltnTs) {
    this.cmpltnTs = cmpltnTs;
  }

  public Timestamp getCrteTs() {
    return this.crteTs;
  }

  public void setCrteTs(Timestamp crteTs) {
    this.crteTs = crteTs;
  }

  public String getCrteUsrNm() {
    return this.crteUsrNm;
  }

  public void setCrteUsrNm(String crteUsrNm) {
    this.crteUsrNm = crteUsrNm;
  }

  public Timestamp getFlupTs() {
    return this.flupTs;
  }

  public void setFlupTs(Timestamp flupTs) {
    this.flupTs = flupTs;
  }

  public String getHltcrPrfsnNtfidIn() {
    return this.hltcrPrfsnNtfidIn;
  }

  public void setHltcrPrfsnNtfidIn(String hltcrPrfsnNtfidIn) {
    this.hltcrPrfsnNtfidIn = hltcrPrfsnNtfidIn;
  }

  public String getPtntNtfidIn() {
    return this.ptntNtfidIn;
  }

  public void setPtntNtfidIn(String ptntNtfidIn) {
    this.ptntNtfidIn = ptntNtfidIn;
  }

  public Long getSbpEntyBpmPrcMapId() {
    return this.sbpEntyBpmPrcMapId;
  }

  public void setSbpEntyBpmPrcMapId(Long sbpEntyBpmPrcMapId) {
    this.sbpEntyBpmPrcMapId = sbpEntyBpmPrcMapId;
  }

  public String getSbpQueTaskStusCd() {
    return this.sbpQueTaskStusCd;
  }

  public void setSbpQueTaskStusCd(String sbpQueTaskStusCd) {
    this.sbpQueTaskStusCd = sbpQueTaskStusCd;
  }

  public String getSbpQueTaskStusRsnCd() {
    return this.sbpQueTaskStusRsnCd;
  }

  public void setSbpQueTaskStusRsnCd(String sbpQueTaskStusRsnCd) {
    this.sbpQueTaskStusRsnCd = sbpQueTaskStusRsnCd;
  }

  public BigDecimal getSbpWrkQueTaskId() {
    return this.sbpWrkQueTaskId;
  }

  public void setSbpWrkQueTaskId(BigDecimal sbpWrkQueTaskId) {
    this.sbpWrkQueTaskId = sbpWrkQueTaskId;
  }

  public Timestamp getUpdTs() {
    return this.updTs;
  }

  public void setUpdTs(Timestamp updTs) {
    this.updTs = updTs;
  }

  public String getUpdUsrNm() {
    return this.updUsrNm;
  }

  public void setUpdUsrNm(String updUsrNm) {
    this.updUsrNm = updUsrNm;
  }

}