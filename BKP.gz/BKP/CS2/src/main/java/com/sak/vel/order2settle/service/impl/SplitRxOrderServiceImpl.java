
package com.cvs.specialty.ordermaintenance.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.SplitRxOrderDao;
import com.cvs.specialty.ordermaintenance.model.RxDetailsList;
import com.cvs.specialty.ordermaintenance.service.SplitRxOrderService;

@Repository
public class SplitRxOrderServiceImpl implements SplitRxOrderService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  SplitRxOrderDao splitRxOrderDao;

  @Override
  public ResponseEntity<Void> splitRxorder(List<RxDetailsList> rxDetailsList, long preOrderId) {

    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    try {
      splitRxOrderDao.splitRxorder(rxDetailsList, preOrderId);
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return null;
    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    }

  }
}
