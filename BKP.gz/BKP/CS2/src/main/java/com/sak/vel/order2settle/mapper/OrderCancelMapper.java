package com.cvs.specialty.ordermaintenance.mapper;

import java.util.ArrayList;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.stereotype.Component;

import com.cvs.specialty.ordermaintenance.common.OrderCancelConstant;
import com.cvs.specialty.ordermaintenance.entity.CgRefCode;
import com.cvs.specialty.ordermaintenance.model.CancelReason;
@Component
public class OrderCancelMapper {
	private static final Logger logger = Logger.getLogger(OrderCancelMapper.class);
	public List<CancelReason> getCancelReason(List<CgRefCode> liCgRefCode){
		logger.info("Mapper to get Cancel Reason Info ");
		
		String rvAbbreviation=OrderCancelConstant.PreferenceTextCgLowValues.ABBREVIATION;
		String rvLowValue=OrderCancelConstant.PreferenceTextCgLowValues.LOW_VALUE;
		List<CancelReason> resultMap=new ArrayList<CancelReason>();
		for (CgRefCode objCgRefCode : liCgRefCode) {
			CancelReason map=new CancelReason();
			//map.put(objCgRefCode.getRvLowValue(), objCgRefCode.getRvAbbreviation());
			map.put(rvLowValue, objCgRefCode.getRvLowValue());
			map.put(rvAbbreviation, objCgRefCode.getRvAbbreviation());
			resultMap.add(map);
		}
		return resultMap;
	}

}
