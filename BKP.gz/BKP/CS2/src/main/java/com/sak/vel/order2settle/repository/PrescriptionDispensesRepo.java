
package com.cvs.specialty.ordermaintenance.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.ordermaintenance.entity.ItemEO;
import com.cvs.specialty.ordermaintenance.entity.PrescriptionDispensesEO;

@Repository
public interface PrescriptionDispensesRepo extends JpaRepository<PrescriptionDispensesEO, Long> {
  /*
   * @Query("select prescriptionDispens from PrescriptionDispenseEO prescriptionDispens where prescriptionDispens.prescription.id in (?1) and srcDeleteDate is null order by id desc"
   * ) List<PrescriptionDispensesEO> findByPrescription(List<Long> prescriptionIdList);
   * 
   */

  PrescriptionDispensesEO findByPrescriptionsId(BigDecimal prescriptionIdList);

  PrescriptionDispensesEO findByPrescriptionsIdAndItem(BigDecimal prescriptionIdList, ItemEO item);

  PrescriptionDispensesEO findById(long dispenseId);

}
