
package com.cvs.specialty.ordermaintenance.service.impl;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.common.logging.api.SpecialtyLogger;
import com.cvs.specialty.common.logging.util.LogMsgConstants;
import com.cvs.specialty.ordermaintenance.dao.OrderDownloadProcessDao;
import com.cvs.specialty.ordermaintenance.entity.SbpEntityBpmProcessMap;
import com.cvs.specialty.ordermaintenance.service.OrderDownloadProcessService;

@Repository
public class OrderDownloadProcessServiceImpl implements OrderDownloadProcessService {

  @Autowired
  SpecialtyLogger LOGGER;

  @Autowired
  OrderDownloadProcessDao orderDownloadProcessDao;

  @SuppressWarnings({
      "rawtypes", "unchecked"
  })
  @Override
  public
      ResponseEntity<SbpEntityBpmProcessMap>
      createInstanceId(BigDecimal orderId, BigDecimal instanceId) {
    LOGGER.info(LogMsgConstants.METHOD_ENTRY);
    ResponseEntity<SbpEntityBpmProcessMap> response = null;
    try {
      response = orderDownloadProcessDao.createProcessInstanceId(orderId, instanceId);

      if (response == null) {
        response = new ResponseEntity(response, HttpStatus.NOT_FOUND);
      } else {
        response = new ResponseEntity(response, HttpStatus.OK);
      }
      LOGGER.info(LogMsgConstants.METHOD_EXIT);
      return response;

    } catch (Exception e) {
      LOGGER.error(LogMsgConstants.EXCEPTION_OCCURED, e);
      return new ResponseEntity<SbpEntityBpmProcessMap>(HttpStatus.BAD_REQUEST);
    }

  }
}
