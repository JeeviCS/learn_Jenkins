package com.cvs.specialty.erp.schedular;

import org.springframework.context.annotation.Configuration;

//@EnableScheduling
@Configuration
public class SchedularConfig {

	/*@Bean
	public BatchSchedular myBean() {
		return new BatchSchedular();
	}

	@Bean
	public TaskScheduler taskExecutor() {
		return new ConcurrentTaskScheduler(Executors.newScheduledThreadPool(5));
	}*/
}
