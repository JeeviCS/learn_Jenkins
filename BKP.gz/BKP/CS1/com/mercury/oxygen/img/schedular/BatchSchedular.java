package com.cvs.specialty.erp.schedular;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.model.ImportShipmentTransactionsVO;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.google.gson.Gson;

public class BatchSchedular {

	private static final Logger LOG = LoggerFactory.getLogger(BatchSchedular.class);

	public void executeCreateItemRestEndpoint() {

		LOG.info("Executing Create Item Service");
		LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());
		String createItemUrl = PropertiesUtil.getProperty(AppPropertyKey.CREATE_ITEM_API);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		RestTemplate restTemplate = new RestTemplate();
		String result = "";
		HttpHeaders headers = new HttpHeaders();
		headers.set("username", userName);
		headers.set("Accept", MediaType.TEXT_HTML_VALUE);

		LOG.info("URL:" + createItemUrl);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(createItemUrl);

		HttpEntity<?> entity = new HttpEntity<>(headers);

		/*
		 * ResponseEntity<String> result = (ResponseEntity<String>) restTemplate
		 * .exchange(builder.build().encode().toUri(), HttpMethod.POST,String.class);
		 */
		try {
			result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
		} catch (RestClientException e) {
			LOG.error("RestClient Exception while Invoking Create Item  Service ", e);

		} catch (Exception e) {
			LOG.error("Unknown Exception while Invoking Create Item Service ", e);

		}
		LOG.info("Response is  " + new Date() + "  : " + result);
		System.out.println("The Response from Create Item API is  " + new Date() + "  : " + result);
	}

	public void executeUpdateItemEndpoint() {

		LOG.info("Executing Update Item Service");
		LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());
		String updateItemUrl = PropertiesUtil.getProperty(AppPropertyKey.UPDATE_ITEM_API);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		RestTemplate restTemplate = new RestTemplate();
		String result = "";
		HttpHeaders headers = new HttpHeaders();
		headers.set("username", userName);
		headers.set("Accept", MediaType.TEXT_HTML_VALUE);

		LOG.info("URL:" + updateItemUrl);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(updateItemUrl);

		HttpEntity<?> entity = new HttpEntity<>(headers);
		// ResponseEntity<String> result =
		// restTemplate.exchange(builder.build().encode().toUri(),HttpMethod.POST,
		// entity, String.class);
		try {
			result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
		} catch (RestClientException e) {
			LOG.error("RestClient Exception while Invoking Update Item  Service ", e);

		} catch (Exception e) {
			LOG.error("Unknown Exception while Invoking Update Item Service ", e);

		}

		LOG.info("Response is  " + new Date() + "  : " + result);
		System.out.println("The Response from Update Item endpoint API is  " + new Date() + "  : " + result);
	}

	public void executeImportCompShipTxnsEndpoint() {

		String importCompShipTxnsUrl = PropertiesUtil.getProperty(AppPropertyKey.IMPORT_COMP_SHIP_TXNS);
		String distinctCompanyIds = PropertiesUtil.getProperty(AppPropertyKey.DISTINCT_COMPANY_ID_S);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		String result = "";
		String companyIdList[] = distinctCompanyIds.split("\\|");

		for (String companyId : companyIdList) {

			LOG.info("Executing Import Company Shipment Transactions Service for Company:" + companyId);
			LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());
			RestTemplate restTemplate = new RestTemplate();

			HttpHeaders headers = new HttpHeaders();
			headers.set("username", userName);
			headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);

			LOG.info("URL" + importCompShipTxnsUrl + "?pCompanyId=" + companyId);
			UriComponentsBuilder builder = UriComponentsBuilder
					.fromHttpUrl(importCompShipTxnsUrl + "?pCompanyId=" + companyId);

			HttpEntity<?> entity = new HttpEntity<>(headers);
			LOG.info("URL" + builder.build().encode().toUri().toString());
			try {
				result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
			} catch (RestClientException e) {
				LOG.error("RestClient Exception while Invoking Import Company Shipment Transactions  Service ", e);

			} catch (Exception e) {
				LOG.error("Unknown Exception while Invoking Import Company Shipment Transactions  Service ", e);

			}

			LOG.info("Response is  " + new Date() + "  : " + result);
			LOG.debug("The Response from Export Company Shipment Transactions API for Company:" + companyId + "is  "
					+ new Date() + "  : " + result);
		}
	}

	public void exportCompReturnTxnsEndpoint() {

		String exportCompReturnTxnsUrl = PropertiesUtil.getProperty(AppPropertyKey.EXPORT_COMP_RETURN_TXNS);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		String result = "";
		LOG.info("Executing Export Company Return Transactions Service :");
		LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());
		RestTemplate restTemplate = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.set("username", userName);
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);

		LOG.info("URL" + exportCompReturnTxnsUrl);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(exportCompReturnTxnsUrl);

		HttpEntity<?> entity = new HttpEntity<>(headers);
		LOG.info("URL" + builder.build().encode().toUri().toString());
		try {
			result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
		} catch (RestClientException e) {
			LOG.error("RestClient Exception while Invoking Export Company Return Transactions  Service ", e);

		} catch (Exception e) {
			LOG.error("Unknown Exception while Invoking Import Company Shipment Transactions  Service ", e);

		}
		LOG.info("Response is  " + new Date() + "  : " + result);
		LOG.debug("The Response from  Export Company Return Transactions API is :" + new Date() + "  : " + result);

	}

	public void hbsPurchaseOrderEndPoint() {

		String hbsPurchaseOrderUrl = PropertiesUtil.getProperty(AppPropertyKey.HBS_PURCHASE_ORDER);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		LOG.info("Executing HBS Purchase Order Service :");
		LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());
		RestTemplate restTemplate = new RestTemplate();
		String result = "";
		HttpHeaders headers = new HttpHeaders();
		headers.set("username", userName);
		headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);

		LOG.info("URL" + hbsPurchaseOrderUrl);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(hbsPurchaseOrderUrl);

		HttpEntity<?> entity = new HttpEntity<>(headers);
		LOG.info("URL" + builder.build().encode().toUri().toString());
		try {
			result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
		} catch (RestClientException e) {
			LOG.error("RestClient Exception while Invoking HBS Purchase Order Service ", e);

		} catch (Exception e) {
			LOG.error("Unknown Exception while Invoking Import Company Shipment Transactions  Service ", e);

		}
		LOG.info("Response is  " + new Date() + "  : " + result);
		LOG.debug("The Response from HBS Purchase Order  API is :" + new Date() + "  : " + result);

	}

	public void importSPARCSShipmentTxnsEndPoint() {

		String importSparcsShipUrl = PropertiesUtil.getProperty(AppPropertyKey.IMPORT_SPARCS_SHIP_TXNS);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		String uniqueSparcsSiteNames = PropertiesUtil.getProperty(AppPropertyKey.SPARCS_SHIP_SITES);

		String uniqueHbsSiteNamesList[] = uniqueSparcsSiteNames.split("\\.");
		for (String string : uniqueHbsSiteNamesList) {

			String uniqueSparcsSiteNamesList[] = string.split("\\|");
			LOG.info("Executing SPARCS Shipments Transaction Service with Site Name:");
			LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());
			RestTemplate restTemplate = new RestTemplate();
			String result = "";
			HttpHeaders headers = new HttpHeaders();
			headers.set("username", userName);
			headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			Gson gson = new Gson();
			LOG.info("URL" + importSparcsShipUrl+ "?sitename=" + uniqueSparcsSiteNamesList[0]);
			UriComponentsBuilder builder = UriComponentsBuilder
					.fromHttpUrl(importSparcsShipUrl + "?sitename=" + uniqueSparcsSiteNamesList[0]);
			ImportShipmentTransactionsVO importShipmentTransactionsVO = new ImportShipmentTransactionsVO();
			importShipmentTransactionsVO.setOrderStatus(uniqueSparcsSiteNamesList[1]);
			importShipmentTransactionsVO.setOrganizationId(Long.parseLong(uniqueSparcsSiteNamesList[2]));
			importShipmentTransactionsVO.setSubinventoryCode(uniqueSparcsSiteNamesList[3]);
			importShipmentTransactionsVO.setTransactionUom(uniqueSparcsSiteNamesList[4]);
			importShipmentTransactionsVO.setTransactionTypeId(Long.parseLong(uniqueSparcsSiteNamesList[5]));
			importShipmentTransactionsVO.setTransactionReasonId(Long.parseLong(uniqueSparcsSiteNamesList[6]));
			importShipmentTransactionsVO.setDistributionAccountId(Long.parseLong(uniqueSparcsSiteNamesList[7]));

			String jsonInString = gson.toJson(importShipmentTransactionsVO);
			HttpEntity<?> entity = new HttpEntity<>(jsonInString, headers);
			LOG.info("URL" + builder.build().encode().toUri().toString());
			try {
				result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
			} catch (RestClientException e) {
				LOG.error("RestClient Exception while Invoking importSPARCSShipmentTxns Service ", e);

			} catch (Exception e) {
				LOG.error("Unknown Exception while Invoking importSPARCSShipmentTxns  Service ", e);

			}
			LOG.info("Response is  " + new Date() + "  : " + result);
			LOG.debug("The Response from importSPARCSShipmentTxns  API is :" + new Date() + "  : " + result);

		}

	}

	public void importHBSShipmentTxnsEndPoint() {

		String importHBSShipUrl = PropertiesUtil.getProperty(AppPropertyKey.IMPORT_HBS_SHIP_TXNS);
		String uniqueHbsSiteNames = PropertiesUtil.getProperty(AppPropertyKey.HBS_SITE_NAMES);
		String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
		String uniqueHbsSiteNamesList[] = uniqueHbsSiteNames.split("\\.");

		LOG.info("Method executed at every 5 seconds. Current time is :: " + new Date());

		for (String sitename : uniqueHbsSiteNamesList) {
			String siteParams[] = sitename.split("\\|");
			LOG.info("Executing HBS Shipments Transaction Service with Site name: " + siteParams[0]);
			RestTemplate restTemplate = new RestTemplate();
			String result = "";
			HttpHeaders headers = new HttpHeaders();
			headers.set("username", userName);
			headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			Gson gson = new Gson();
			LOG.info("URL" + importHBSShipUrl + siteParams[0]);
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(importHBSShipUrl + siteParams[0]);
			ImportShipmentTransactionsVO importShipmentTransactionsVO = new ImportShipmentTransactionsVO();
			importShipmentTransactionsVO.setOrderStatus(siteParams[1]);
			importShipmentTransactionsVO.setOrganizationId(Long.parseLong(siteParams[2]));
			importShipmentTransactionsVO.setSubinventoryCode(siteParams[3]);
			importShipmentTransactionsVO.setTransactionUom(siteParams[4]);
			importShipmentTransactionsVO.setTransactionTypeId(Long.parseLong(siteParams[5]));
			importShipmentTransactionsVO.setTransactionReasonId(Long.parseLong(siteParams[6]));
			importShipmentTransactionsVO.setDistributionAccountId(Long.parseLong(siteParams[7]));

			String jsonInString = gson.toJson(importShipmentTransactionsVO);
			HttpEntity<?> entity = new HttpEntity<>(jsonInString, headers);
			LOG.info("URL" + builder.build().encode().toUri().toString());
			try {
				result = restTemplate.postForObject(builder.build().encode().toUri(), entity, String.class);
			} catch (RestClientException e) {
				LOG.error("RestClient Exception while Invoking importHBSShipmentTxns Service ", e);

			} catch (Exception e) {
				LOG.error("Unknown Exception while Invoking importHBSShipmentTxns  Service ", e);

			}
			LOG.info("Response is  " + new Date() + "  : " + result);
			LOG.debug("The Response from importHBSShipmentTxns  API is :" + new Date() + "  : " + result);

		}

	}

}
