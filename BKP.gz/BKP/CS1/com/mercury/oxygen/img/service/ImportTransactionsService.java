package com.cvs.specialty.erp.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface ImportTransactionsService {
	
	ResponseEntity<String> importTransactions(String pCompanyId, String pSiteId,String UserName);

}
