package com.cvs.specialty.erp.service;

import com.cvs.specialty.erp.model.MckOrderReturn;

public interface MckOrderReturnsService {

	/**
	 * This method inserts a new record in to mck_order_returns table and return
	 * the primary key
	 * 
	 * @param mckOrderReturn
	 */
	void saveOrderReturn(MckOrderReturn mckOrderReturn);

	/**
	 * 
	 * @param emailMessage
	 */
	void sendemail(String emailMessage);

}
