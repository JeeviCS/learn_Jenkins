package com.cvs.specialty.erp.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cvs.specialty.erp.dao.CreateItemDao;
import com.cvs.specialty.erp.dao.HBSPurchaseOrderDao;
import com.cvs.specialty.erp.model.PharmopHeadersDTO;
import com.cvs.specialty.erp.model.PharmopLinesDTO;
import com.cvs.specialty.erp.service.HBSPurchaseOrderService;
import com.cvs.specialty.erp.utils.Constants;

@Service
public class HBSPurchaseOrderServiceImpl implements HBSPurchaseOrderService {
	private static final Logger LOG = Logger.getLogger(HBSPurchaseOrderServiceImpl.class);
	ResponseEntity<String> responseEntity = null;
	@Autowired
	HBSPurchaseOrderDao hbsPurchaseOrderDao;
	@Autowired
	CreateItemDao createItemDao;
	String responseMessage = "Process Completed Successfully";

	@Override
	public ResponseEntity<String> processhbsPurchaseOrderScreen(String username) {
		String responseMessageforNewRecords = "";
		try {

			List<Integer> userIdList = createItemDao.getUserId(username);
			// TODO Auto-generated method stub
			if (userIdList != null) {

				// ready Status records from SPARCS
				LOG.info("Retrieving the Records with Status: R");
				List<PharmopHeadersDTO> recordsWithStatusR = hbsPurchaseOrderDao.getRecordsWithStatus("R");
				responseMessageforNewRecords = processRecordStatusR(recordsWithStatusR);
				LOG.info("Retrieving the Records with Status: T");

				List<PharmopHeadersDTO> recordsWithStatusT = hbsPurchaseOrderDao.getRecordsWithStatus("T");

				processRecordStatusT(recordsWithStatusT);

				responseEntity = new ResponseEntity<String>(responseMessage + "\n" + responseMessageforNewRecords,
						HttpStatus.OK);

			} else {
				LOG.error(Constants.USER_ERROR);
				responseEntity = new ResponseEntity<String>(Constants.USER_ERROR + username, HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			LOG.error("Exception Occurred" + e.getMessage());
			responseMessage = "Exception Occurred";
			responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;

	}

	private void processRecordStatusT(List<PharmopHeadersDTO> recordsWithStatusT) {
		// TODO Auto-generated method stub
		int inserted = 0;

		for (PharmopHeadersDTO pharmopHeadersRec : recordsWithStatusT) {
			try {
				List<PharmopHeadersDTO> pharmopHeaderRec = hbsPurchaseOrderDao
						.getERPRecordwithHeaderId(pharmopHeadersRec.getPoHeaderId());
				if (!pharmopHeaderRec.isEmpty()) {
					String status = pharmopHeaderRec.get(0).getStatus();
					// check if the Record has Status other than R
					if (!status.equalsIgnoreCase("R")) {

						inserted = hbsPurchaseOrderDao.updateRecordStatusAndOtherCols(
								pharmopHeaderRec.get(0).getPoHeaderId(), status, pharmopHeaderRec.get(0).getEdidate(),
								pharmopHeaderRec.get(0).getProcessStatus(), pharmopHeaderRec.get(0).getUserMessage());
						if (inserted == 1) {
							LOG.info("Record Updated Successfully In SPARCS with Status:" + status);
							LOG.info("Record with HeaderId:" + pharmopHeadersRec.getPoHeaderId()
									+ " Updated Successfully In SPARCS with Status:" + status);
						}

					}
				}
			} catch (Exception e) {
				LOG.error("Exception Occurred while Inserting Records" + e.getMessage());
				responseMessage = "Exception Occurred";
				responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);
			}

		}

	}

	private String processRecordStatusR(List<PharmopHeadersDTO> recordsWithStatusR) {
		int insertedHeader = 0;
		int insertedLines = 0;
		int headerCount = 0;
		int linescount = 0;
		for (PharmopHeadersDTO pharmopHeadersDTO : recordsWithStatusR) {
			// insert into ERP tables
			try {
				LOG.info("Inserting Record with HeaderId: " + pharmopHeadersDTO.getPoHeaderId()
						+ " into ERP Headers Table");
				insertedHeader = hbsPurchaseOrderDao.insertIntoERPHeadertable(pharmopHeadersDTO);
				if (insertedHeader == 1) {
					// get lines for each header Id
					headerCount++;
					LOG.info("Record Inserted Successfully into ERP Headers Table");
					List<PharmopLinesDTO> pharmopLines = hbsPurchaseOrderDao
							.getSPARCSRecordswithHeaderId(pharmopHeadersDTO.getPoHeaderId());

					for (PharmopLinesDTO pharmopLinesDTO : pharmopLines) {
						LOG.info("Inserting Record with HeaderId: " + pharmopHeadersDTO.getPoHeaderId()+"and Po_number:"+pharmopHeadersDTO.getPoNumber()
								+ " into ERP Lines Table");
						
						insertedLines = hbsPurchaseOrderDao.insertIntoERPLinestable(pharmopLinesDTO);
						if (insertedLines == 1) {
							linescount++;
							LOG.info("Record Inserted Successfully into ERP LinesTable");
						}
					}
					// update the status as T

					LOG.info("Update the Status as T in SPARCS Table");
					hbsPurchaseOrderDao.updateRecordStatus(pharmopHeadersDTO.getPoHeaderId(), "T");

				}

			} catch (Exception e) {
				LOG.error("Exception Occurred while Inserting Records" + e.getMessage());
			}
		}
		LOG.info("No of Records inserted in ERP Header Table: " + headerCount + " , ERP Lines table: " + linescount);
		return "No of Records inserted in ERP Header Table: " + headerCount + " , ERP Lines table: " + linescount;

	}

}
