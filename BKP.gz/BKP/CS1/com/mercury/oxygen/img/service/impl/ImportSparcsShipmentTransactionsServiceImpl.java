package com.cvs.specialty.erp.service.impl;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.erp.dao.CreateItemDao;
import com.cvs.specialty.erp.dao.ImportSparcsShipmentTransactionsDao;
import com.cvs.specialty.erp.model.ImportShipmentTransactionsVO;
import com.cvs.specialty.erp.model.MtlParameters;
import com.cvs.specialty.erp.model.MtlTransactions;
import com.cvs.specialty.erp.model.SparcsShipmentTransaction;
import com.cvs.specialty.erp.service.ImportSparcsShipmentTransactionsService;
import com.cvs.specialty.erp.utils.Constants;

/**
 * @author Z238847
 *
 */
@Service
public class ImportSparcsShipmentTransactionsServiceImpl implements ImportSparcsShipmentTransactionsService {
	private static final Logger LOGGER = Logger.getLogger(ImportSparcsShipmentTransactionsServiceImpl.class);
	private ImportSparcsShipmentTransactionsDao importSparcsShipmentTransactionsDao;
	String responseMessage = "";
	int successCode = 0;
	int errorCode = 2;
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");

	@Autowired
	public void setImportSparcsShipmentTransactionsDao(
			ImportSparcsShipmentTransactionsDao importSparcsShipmentTransactionsDao) {
		this.importSparcsShipmentTransactionsDao = importSparcsShipmentTransactionsDao;
	}

	@Autowired
	CreateItemDao createItemDao;

	@Override
	@Transactional
	public ResponseEntity<String> importSparcsShipmentTransactions(String username, String sourceCode,
			ImportShipmentTransactionsVO importShipmentTransactionsVO, String siteName) throws Exception {
		int count = 0;
		int insertedRecordCount = 0;
		LOGGER.info("Process Transaction for Site name:" + siteName);
		try {

			// validate organization
			int registeredProcessId = createItemDao.getRegisterdProcessNumber(siteName);
			if (registeredProcessId != 0) {

				// java.sql.Date startDate =
				// createItemDao.getStartDateFromProcessTable(registeredProcessId);

				java.sql.Timestamp startDate = createItemDao.getStartDateFromProcessTable(registeredProcessId);
				List<MtlParameters> mtlParameters = importSparcsShipmentTransactionsDao
						.getMtlParameters(importShipmentTransactionsVO.getOrganizationId());
				if (mtlParameters.isEmpty()) {
					LOGGER.error("No organization found with id::" + importShipmentTransactionsVO.getOrganizationId());
					responseMessage = "Cannot Find the organization with id:"
							+ importShipmentTransactionsVO.getOrganizationId() + "Error Code" + errorCode;
					return new ResponseEntity<String>(responseMessage, HttpStatus.NO_CONTENT);
				} else if (mtlParameters.get(0).getSiteId() == 0) {
					LOGGER.error("Site is not defined for org ::" + importShipmentTransactionsVO.getOrganizationId());
					responseMessage = "Site is not defined for org ::"
							+ importShipmentTransactionsVO.getOrganizationId() + "Error Code" + errorCode;
					return new ResponseEntity<String>(responseMessage, HttpStatus.BAD_REQUEST);
				}

				// Date startDateTime = new Date(startDate.getTime());
				Date endDateTime = new Date(System.currentTimeMillis());
				
				

				List<SparcsShipmentTransaction> sparcsShipmentTransactions = importSparcsShipmentTransactionsDao
						.getSparcsShipmentTransactions(importShipmentTransactionsVO.getOrderStatus(),
								mtlParameters.get(0).getSiteId(), startDate, endDateTime);
				LOGGER.info("startDate: " + sdf.format(startDate));
				LOGGER.info("endDateTime: " + endDateTime);
				LOGGER.info("Number of Transactions found is:" + sparcsShipmentTransactions.size());
				// get userId
				List<Long> userIdList = importSparcsShipmentTransactionsDao.getUserId(username);
				if (CollectionUtils.isNotEmpty(userIdList)) {
					Long userId = userIdList.get(0);
					if (userId == null) {
						LOGGER.error("Cannot Find the User Id");
						responseMessage = "Cannot Find the UserId for User:" + username + "Error Code" + errorCode;
						return new ResponseEntity<String>(responseMessage, HttpStatus.BAD_REQUEST);
					}

					MtlTransactions mtltransactions = null;

					String l_process_flag = "Y";
					String l_transfer_ind = "Y";
					String l_error_explanation = StringUtils.EMPTY;
					for (SparcsShipmentTransaction sparcsShipmentTransaction : sparcsShipmentTransactions) {
						if (sparcsShipmentTransaction.getActualDispensed() == 0) {
							l_process_flag = "E";
							l_transfer_ind = "N";
							l_error_explanation = "Dispense quantity must not equal 0.";
						}
						mtltransactions = prepareMtlTrasactions(sourceCode, importShipmentTransactionsVO, userId,
								sparcsShipmentTransaction);
						try {
							count = importSparcsShipmentTransactionsDao.saveMtlTransactions(mtltransactions);
							if (count == 1) {
								insertedRecordCount++;
							}

						} catch (Exception e) {
							LOGGER.error("error while saving mtltransactions:" + e);
							responseMessage = "Cannot save mtltransactions:Error Code" + errorCode;
							return new ResponseEntity<String>(responseMessage, HttpStatus.BAD_REQUEST);
						}

						importSparcsShipmentTransactionsDao.updateMtlTransactions(sparcsShipmentTransaction,
								mtltransactions, l_process_flag, l_transfer_ind, l_error_explanation);
					}

					// update Process control date

					createItemDao.updateEndDateInProcessTable(
							new java.sql.Timestamp(System.currentTimeMillis() - (1000 * 60 * 60 * 24)),
							registeredProcessId);
					LOGGER.info("End date Timestamp: "
							+ new java.sql.Timestamp(System.currentTimeMillis() - (1000 * 60 * 60 * 24)));

				} else {
					LOGGER.error(Constants.USER_ERROR);
					return new ResponseEntity<String>(Constants.USER_ERROR + username, HttpStatus.BAD_REQUEST);
				}
			} else {

				LOGGER.error(Constants.PROCESS_CONTROL_ERROR);
				return new ResponseEntity<String>(Constants.PROCESS_CONTROL_ERROR, HttpStatus.BAD_REQUEST);

			}

		} catch (Exception e) {
			LOGGER.error("Exception Occurred:" + e.getMessage());
			return new ResponseEntity<String>(Constants.INVALID_REQUEST, HttpStatus.BAD_REQUEST);
		}
		LOGGER.info("Number of records inserted into ERP:" + insertedRecordCount);
		return new ResponseEntity<String>(
				"Import shipment transactions operation is completed with status code::" + successCode, HttpStatus.OK);
	}

	private MtlTransactions prepareMtlTrasactions(String sourceCode,
			ImportShipmentTransactionsVO importShipmentTransactionsVO, Long userId,
			SparcsShipmentTransaction sparcsShipmentTransaction) {
		MtlTransactions mtltransactions;
		mtltransactions = new MtlTransactions();
		mtltransactions.setSourceCode(sourceCode);
		mtltransactions.setSourceLineId(sparcsShipmentTransaction.getErpDispenseInterfaceId());
		mtltransactions.setSourceHeaderid(sparcsShipmentTransaction.getErpDispenseInterfaceId());
		mtltransactions.setProcessFlag(1L);
		mtltransactions.setTransactionMode(3L);
		mtltransactions.setLockFlag(2L);
		mtltransactions.setItemSegment2(
				StringUtils.leftPad(String.valueOf(sparcsShipmentTransaction.getItemNumber()), 7, '0'));
		mtltransactions.setInventoryItemId(null);
		mtltransactions.setOrganizationId(importShipmentTransactionsVO.getOrganizationId());
		mtltransactions.setSubinventoryCode(importShipmentTransactionsVO.getSubinventoryCode());
		mtltransactions.setTransactionQuantity(sparcsShipmentTransaction.getActualDispensed() * -1);
		mtltransactions.setTransactionUom(importShipmentTransactionsVO.getTransactionUom());
		mtltransactions.setTransactionDate(sparcsShipmentTransaction.getCreateDate());
		mtltransactions.setTransactionTypeId(importShipmentTransactionsVO.getTransactionTypeId());
		mtltransactions.setReasonId(importShipmentTransactionsVO.getTransactionReasonId());
		mtltransactions.setDistributionAccountId(importShipmentTransactionsVO.getDistributionAccountId());
		mtltransactions.setAttribute1(sparcsShipmentTransaction.getRxNumber());
		mtltransactions.setAttribute2(sparcsShipmentTransaction.getOrderNumber());
		mtltransactions.setAttribute3(sparcsShipmentTransaction.getRefillNumber());
		mtltransactions.setAttribute4(sparcsShipmentTransaction.getShipmentNumber());
		mtltransactions.setLastUpdateDate(new Date(System.currentTimeMillis()));
		mtltransactions.setLastUpdatedBy(userId);
		mtltransactions.setCreationDate(new Date(System.currentTimeMillis()));
		mtltransactions.setCreatedBy(userId);
		return mtltransactions;
	}

}
