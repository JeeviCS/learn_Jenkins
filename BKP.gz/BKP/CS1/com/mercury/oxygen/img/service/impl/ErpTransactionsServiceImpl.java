package com.cvs.specialty.erp.service.impl;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.erp.dao.ErpTransactionsDao;
import com.cvs.specialty.erp.model.CompanyTransactions;
import com.cvs.specialty.erp.service.ErpTransactionsService;

/**
 * 
 * @author Z238847
 *
 */
@Service
public class ErpTransactionsServiceImpl implements ErpTransactionsService {
	@Autowired
	private ErpTransactionsDao erpTransactionsDao;

	/**
	 * 
	 */
	@Override
	@Transactional
	public List<CompanyTransactions> getReturnTransactions() {
		return erpTransactionsDao.getReturnTransactions();
	}

	/**
	 * 
	 */
	@Override
	@Transactional
	public void updateProcessFlag(String updatedBy, String processFlag, Date updatedDate, int companyTxnsIfaceId) {
		erpTransactionsDao.updateProcessFlag(updatedBy, processFlag, updatedDate, companyTxnsIfaceId);
	}

}
