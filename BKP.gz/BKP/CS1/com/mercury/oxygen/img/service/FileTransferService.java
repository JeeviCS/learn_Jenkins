package com.cvs.specialty.erp.service;

import org.springframework.http.ResponseEntity;

public interface FileTransferService {
	ResponseEntity<String> startFileTransfer(String processName);
}
