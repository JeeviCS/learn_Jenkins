package com.cvs.specialty.erp.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.cvs.specialty.erp.dao.CheckApiStatus;
import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.model.ImportShipmentTransactionsVO;
import com.cvs.specialty.erp.service.ExportCompanyReturnTransactionsService;
import com.cvs.specialty.erp.service.HBSPurchaseOrderService;
import com.cvs.specialty.erp.service.ImportSparcsShipmentTransactionsService;
import com.cvs.specialty.erp.service.ImportTransactionsService;
import com.cvs.specialty.erp.service.ItemService;
import com.cvs.specialty.erp.service.SchedularService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.google.gson.Gson;

@Service
public class SchedularServiceImpl implements SchedularService {

	@Autowired
	ImportTransactionsService importTransactionsService;
	@Autowired
	private ImportSparcsShipmentTransactionsService importSparcsShipmentTransactionsService;
	@Autowired
	CheckApiStatus checkApiStatus;

	@Autowired
	ItemService itemService;

	@Autowired
	ExportCompanyReturnTransactionsService exportCompanyReturnTransactionsService;

	@Autowired
	HBSPurchaseOrderService hbsPurchaseOrderService;
	private static Logger LOG = Logger.getLogger(SchedularServiceImpl.class);

	public void executeImportCompShipTxnsEndpoint() {
		ResponseEntity<String> responseFromService = null;
		try {

			List<String> checkStatus = checkApiStatus.isApiActive("IMPORT_COMP_SHIP_TXNS");
			if (checkStatus.get(0).equalsIgnoreCase("N")) {
				checkApiStatus.updateStatus("IMPORT_COMP_SHIP_TXNS", "Y");

				String distinctCompanyIds = PropertiesUtil.getProperty(AppPropertyKey.DISTINCT_COMPANY_ID_S);
				String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
				String companyIdList[] = distinctCompanyIds.split("\\|");
				String siteId = null;
				String siteIdList[] = null;
				String distinctCompanyId=null;
				String distinctSiteId=null;
				for (String companyId : companyIdList) {
					if (companyId.contains(":"))
					{
						distinctCompanyId=companyId.substring(0,companyId.indexOf(":"));
				LOG.info("distinctCompanyId is : " + distinctCompanyId);
				
				distinctSiteId=companyId.substring(companyId.indexOf(":")+1);
				LOG.info("distinctSiteId is : " + distinctSiteId);
					siteIdList = distinctSiteId.split("\\,");
					for (String site: siteIdList)
					{
					responseFromService = importTransactionsService.importTransactions(distinctCompanyId, site, userName);
					LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());
					LOG.debug("The Response from Import Company Shipment Transactions API for Company:" + companyId
							+ "is  " + new Date() + "  : " + responseFromService.getBody());
					}
					}
					else 
						
					{
						responseFromService = importTransactionsService.importTransactions(companyId, siteId, userName);
					}
					LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());
					LOG.debug("The Response from Import Company Shipment Transactions API for Company:" + companyId
							+ "is  " + new Date() + "  : " + responseFromService.getBody());
				}
				
				

			} else {
				LOG.info("IMPORT_COMP_SHIP_TXNS is already Running");

			}
		}

		catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}
		try {
			checkApiStatus.updateStatus("IMPORT_COMP_SHIP_TXNS", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for IMPORT_COMP_SHIP_TXNS" + e.getMessage());
		}
	}

	@Override
	public void handleImportSparcsShipmentTransactions() {
		// TODO Auto-generated method stub

		try {

			List<String> checkStatus = checkApiStatus.isApiActive("IMPORT_SPARCS_SHIP_TXNS");
			ResponseEntity<String> responseFromService = null;
			if (checkStatus.get(0).equalsIgnoreCase("N")) {

				checkApiStatus.updateStatus("IMPORT_SPARCS_SHIP_TXNS", "Y");
				String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
				String uniqueSparcsSiteNames = PropertiesUtil.getProperty(AppPropertyKey.SPARCS_SHIP_SITES);

				String uniqueHbsSiteNamesList[] = uniqueSparcsSiteNames.split("\\.");
				for (String string : uniqueHbsSiteNamesList) {

					String uniqueSparcsSiteNamesList[] = string.split("\\|");
					LOG.info("Executing SPARCS Shipments Transaction Service with Site Name:"
							+ uniqueSparcsSiteNamesList[0]);

					// Gson gson = new Gson();
					ImportShipmentTransactionsVO importShipmentTransactionsVO = new ImportShipmentTransactionsVO();
					importShipmentTransactionsVO.setOrderStatus(uniqueSparcsSiteNamesList[1]);
					importShipmentTransactionsVO.setOrganizationId(Long.parseLong(uniqueSparcsSiteNamesList[2]));
					importShipmentTransactionsVO.setSubinventoryCode(uniqueSparcsSiteNamesList[3]);
					importShipmentTransactionsVO.setTransactionUom(uniqueSparcsSiteNamesList[4]);
					importShipmentTransactionsVO.setTransactionTypeId(Long.parseLong(uniqueSparcsSiteNamesList[5]));
					importShipmentTransactionsVO.setTransactionReasonId(Long.parseLong(uniqueSparcsSiteNamesList[6]));
					importShipmentTransactionsVO.setDistributionAccountId(Long.parseLong(uniqueSparcsSiteNamesList[7]));

					// String jsonInString = gson.toJson(importShipmentTransactionsVO);
					try {
						responseFromService = importSparcsShipmentTransactionsService.importSparcsShipmentTransactions(
								userName, Constants.CON_SPARCS_SHIP_TXN_SOURCE_CODE, importShipmentTransactionsVO,
								uniqueSparcsSiteNamesList[0]);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						LOG.error("Exception Occurred" + e.getMessage());
					}

					LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());
					LOG.debug("The Response from importSPARCSShipmentTxns  API is :" + new Date() + "  : "
							+ responseFromService.getBody());

				}
			} else {

				LOG.info("IMPORT_SPARCS_SHIP_TXNS is already Running");
			}
		} catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}

		try {
			checkApiStatus.updateStatus("IMPORT_SPARCS_SHIP_TXNS", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for IMPORT_SPARCS_SHIP_TXNS" + e.getMessage());
		}
	}

	@Override
	public void handleImportHBSShipmentTransactions() {
		// TODO Auto-generated method stub
		ResponseEntity<String> responseFromService = null;

		try {

			List<String> checkStatus = checkApiStatus.isApiActive("IMPORT_HBS_SHIP_TXNS");

			if (checkStatus.get(0).equalsIgnoreCase("N")) {

				checkApiStatus.updateStatus("IMPORT_HBS_SHIP_TXNS", "Y");

				String uniqueHbsSiteNames = PropertiesUtil.getProperty(AppPropertyKey.HBS_SITE_NAMES);
				String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
				String uniqueHbsSiteNamesList[] = uniqueHbsSiteNames.split("\\.");

				for (String sitename : uniqueHbsSiteNamesList) {
					String siteParams[] = sitename.split("\\|");
					LOG.info("Executing HBS Shipments Transaction Service with Site name: " + siteParams[0]);

					ImportShipmentTransactionsVO importShipmentTransactionsVO = new ImportShipmentTransactionsVO();
					importShipmentTransactionsVO.setOrderStatus(siteParams[1]);
					importShipmentTransactionsVO.setOrganizationId(Long.parseLong(siteParams[2]));
					importShipmentTransactionsVO.setSubinventoryCode(siteParams[3]);
					importShipmentTransactionsVO.setTransactionUom(siteParams[4]);
					importShipmentTransactionsVO.setTransactionTypeId(Long.parseLong(siteParams[5]));
					importShipmentTransactionsVO.setTransactionReasonId(Long.parseLong(siteParams[6]));
					importShipmentTransactionsVO.setDistributionAccountId(Long.parseLong(siteParams[7]));

					try {
						responseFromService = importSparcsShipmentTransactionsService.importSparcsShipmentTransactions(
								userName, Constants.CON_HBS_SHIP_TXN_SOURCE_CODE, importShipmentTransactionsVO,
								siteParams[0]);
					} catch (Exception e) {
						LOG.error("Unknown Exception while Invoking importHBSShipmentSchedularTxns  Service "
								+ e.getMessage());

					}
					LOG.debug("The Response from importHBSShipmentSchedularTxns  API is :" + new Date() + "  : "
							+ responseFromService.getBody());

				}

			}

			else {

				LOG.info("IMPORT_HBS_SHIP_TXNS is already Running");
			}
		} catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}

		try {
			checkApiStatus.updateStatus("IMPORT_HBS_SHIP_TXNS", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for IMPORT_HBS_SHIP_TXNS" + e.getMessage());
		}

	}

	@Override
	public void handleCreateItem() {
		// TODO Auto-generated method stub
		ResponseEntity<String> responseFromService = null;
		try {
			String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);

			List<String> checkStatus = checkApiStatus.isApiActive("CREATE_ITEM");
			if (checkStatus.get(0).equalsIgnoreCase("N")) {
				checkApiStatus.updateStatus("CREATE_ITEM", "Y");
				responseFromService = itemService.createItem("123", userName);
				LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());
			} else {
				LOG.info("CREATE_ITEM is already Running");

			}
		}

		catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}
		try {
			checkApiStatus.updateStatus("CREATE_ITEM", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for CREATE_ITEM" + e.getMessage());
		}

	}

	@Override
	public void handleUpdateItem() {
		// TODO Auto-generated method stub

		ResponseEntity<String> responseFromService = null;
		try {
			String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);
			List<String> checkStatus = checkApiStatus.isApiActive("UPDATE_ITEM");
			if (checkStatus.get(0).equalsIgnoreCase("N")) {
				checkApiStatus.updateStatus("UPDATE_ITEM", "Y");
				responseFromService = itemService.updateItem(userName);
				LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());

			} else {
				LOG.info("UPDATE_ITEM is already Running");

			}
		}

		catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}
		try {
			checkApiStatus.updateStatus("UPDATE_ITEM", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for UPDATE_ITEM" + e.getMessage());
		}

	}

	@Override
	public void handleExportCompanyReturnTransaction() {
		ResponseEntity<String> responseFromService = null;
		try {

			List<String> checkStatus = checkApiStatus.isApiActive("EXPORT_COMP_RETURN_TXNS");
			if (checkStatus.get(0).equalsIgnoreCase("N")) {
				checkApiStatus.updateStatus("EXPORT_COMP_RETURN_TXNS", "Y");

				String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);

				responseFromService = exportCompanyReturnTransactionsService
						.exportCompanyReturnTransactionsService(userName);

				LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());
			} else {
				LOG.info("EXPORT_COMP_RETURN_TXNS is already Running");

			}
		}

		catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}

		try {
			checkApiStatus.updateStatus("EXPORT_COMP_RETURN_TXNS", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for EXPORT_COMP_RETURN_TXNS" + e.getMessage());
		}
	}

	@Override
	public void handleHBSPurchaseOrder() {
		try {
			ResponseEntity<String> responseFromService = null;

			List<String> checkStatus = checkApiStatus.isApiActive("HBS_PURCHASE_ORDER");
			if (checkStatus.get(0).equalsIgnoreCase("N")) {
				checkApiStatus.updateStatus("HBS_PURCHASE_ORDER", "Y");

				String userName = PropertiesUtil.getProperty(AppPropertyKey.USER_NAME);

				responseFromService = hbsPurchaseOrderService.processhbsPurchaseOrderScreen(userName);

				LOG.info("Response is  " + new Date() + "  : " + responseFromService.getBody());
			} else {
				LOG.info("HBS_PURCHASE_ORDER is already Running");

			}
		}

		catch (Exception e) {

			LOG.error("Exception Occurred" + e.getMessage());
		}

		try {
			checkApiStatus.updateStatus("HBS_PURCHASE_ORDER", "N");
		} catch (Exception e) {

			LOG.error("Exception Occurred while Releasing lock for HBS_PURCHASE_ORDER" + e.getMessage());
		}

	}

}