package com.cvs.specialty.erp.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cvs.specialty.erp.dao.ScanDataDao;
import com.cvs.specialty.erp.model.ScandataRequest;
import com.cvs.specialty.erp.model.ScandataResponse;
import com.cvs.specialty.erp.model.ServiceRequest;
import com.cvs.specialty.erp.model.ServiceResponse;
import com.cvs.specialty.erp.service.ScandataService;

@Service
public class ScandataServiceImpl implements ScandataService {

	@Autowired
	ScanDataDao scanDataDao;

	@Override
	public ServiceResponse<ScandataResponse> callScandataIfc(ServiceRequest<ScandataRequest> scnRequest) {
		// TODO Auto-generated method stub

		ServiceResponse<ScandataResponse> response = null;

		ScandataRequest scanRequest = scnRequest.getBody();
		if (scanRequest != null) {

			ScandataResponse scanResponse = scanDataDao.callToScanDataSP(scanRequest);

			response = new ServiceResponse<ScandataResponse>();
			response.setBody(scanResponse);
		}

		return response;
	}
}