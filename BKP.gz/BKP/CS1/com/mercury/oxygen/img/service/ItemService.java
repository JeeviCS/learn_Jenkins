package com.cvs.specialty.erp.service;

import org.springframework.http.ResponseEntity;

public interface ItemService {

	ResponseEntity<String> createItem(String templateId, String username);

	ResponseEntity<String> updateItem(String username);

	/**
	 * 
	 * @param charSiteCode
	 * @param drugNo
	 * @param contentType 
	 * @return
	 */
	ResponseEntity<String> getItemStatus(String charSiteCode, String drugNo, String contentType);

}
