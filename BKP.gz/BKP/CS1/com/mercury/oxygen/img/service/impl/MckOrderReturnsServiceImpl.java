package com.cvs.specialty.erp.service.impl;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cvs.specialty.erp.dao.MckOrderReturnsDao;
import com.cvs.specialty.erp.model.MckOrderReturn;
import com.cvs.specialty.erp.service.MckOrderReturnsService;

/**
 * 
 * @author Z238847
 *
 */
@Service
public class MckOrderReturnsServiceImpl implements MckOrderReturnsService {
	@Autowired
	private MckOrderReturnsDao mckOrderReturnsDao;

	/**
	 * 
	 */
	@Override
	@Transactional
	public void saveOrderReturn(MckOrderReturn mckOrderReturn) {
		mckOrderReturnsDao.saveOrderReturn(mckOrderReturn);
	}

	@Override
	public void sendemail(String emailMessage) {
		mckOrderReturnsDao.sendemail(emailMessage);		
	}

}
