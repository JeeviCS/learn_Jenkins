package com.cvs.specialty.erp.service;

import org.springframework.http.ResponseEntity;

public interface HBSPurchaseOrderService {
	ResponseEntity<String> processhbsPurchaseOrderScreen(String userId);
}
