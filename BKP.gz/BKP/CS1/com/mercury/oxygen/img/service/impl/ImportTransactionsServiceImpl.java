package com.cvs.specialty.erp.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cvs.specialty.erp.dao.CreateItemDao;
import com.cvs.specialty.erp.dao.ImportCompShipmentDao;
import com.cvs.specialty.erp.model.CompTxnShipInterfaceDTO;
import com.cvs.specialty.erp.model.CompTxnTypeFromERPDTO;
import com.cvs.specialty.erp.model.MckERPShipQueue;
import com.cvs.specialty.erp.model.MckOrderODCDetails;
import com.cvs.specialty.erp.model.TransactionInterface;
import com.cvs.specialty.erp.service.ImportTransactionsService;
import com.cvs.specialty.erp.utils.SQLtoJava;

@Service
public class ImportTransactionsServiceImpl implements ImportTransactionsService {
	private static final Logger LOG = Logger.getLogger(ImportTransactionsServiceImpl.class);
	@Autowired
	ImportCompShipmentDao importCompShipmentDao;

	@Autowired
	CreateItemDao createItemDao;

	String procedureName = "PROCESS_DISPENSE_TRANSACTIONS";
	boolean isCompanySiteFound = false;
	int returnCode = 0;
	String packageName = "XXINV_CONTRACT_COMPANY_IFACES";

	@Override
	@Transactional(rollbackFor = Exception.class)
	public ResponseEntity<String> importTransactions(String pCompanyId, String pSiteId, String Username) {

		int successCode = 0;
		int warningCode = 1;
		int errorCode = 2;
		String errbuf = "";
		String errorDescription = "";
		long companyId = 0;
		long siteId = 0;
		int errorCount = 0;
		int insertCount = 0;
		int procCount = 0;
		int insCount = 0;
		int noShipmentCount = 0;
		String processFlag, transferInd = "", errorExplanation = "";
		String responseMessage = "";
		ResponseEntity<String> responseEntity = null;
		// TODO Auto-generated method stub
		List<CompTxnTypeFromERPDTO> CompTxnTypeFromERPlist = null;
		
		try {
			List<Integer> userIdList = createItemDao.getUserId(Username);
			if (userIdList == null) {
				LOG.error("User cannot be found.");
				responseMessage = "User cannot be found.";
				responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.BAD_REQUEST);
			} else {

				List<CompTxnShipInterfaceDTO> compTxnShipInterfaceList = importCompShipmentDao
						.getShipmentInfoFromSparcsTables(pCompanyId, pSiteId);

				for (CompTxnShipInterfaceDTO compTxnShipInterface : compTxnShipInterfaceList) {
					procCount++;

					if ((compTxnShipInterface.getCompanyId() != companyId)
							|| (compTxnShipInterface.getSiteId() != siteId)) {
						LOG.info("Get the organization details");
						try {
							CompTxnTypeFromERPlist = importCompShipmentDao.getTxnTypeReasonsFromERP(
									compTxnShipInterface.getCompanyId(), compTxnShipInterface.getSiteId());
							isCompanySiteFound = true;
							if (CompTxnTypeFromERPlist == null || CompTxnTypeFromERPlist.isEmpty()) {
								LOG.error("Company and Site not found in xxinv_org_txn_types_reasons table");
								errbuf = "Get the organization details- Error code:2";
								returnCode = 2;
								isCompanySiteFound = false;
							}
						} catch (Exception e) {
							returnCode = 2;
							throw new Exception(
									"Unknown Exception Occurred,All Transaction will be Rollbacked" + e.getMessage());
						}

						companyId = compTxnShipInterface.getCompanyId();
						siteId = compTxnShipInterface.getSiteId();

					}

					if (!isCompanySiteFound) {

						processFlag = "E";
						transferInd = "N";
						errorCount++;
						errorExplanation = "Company and Site not found in xxinv_org_txn_types_reasons table";
						throw new EvalidationError("Company and Site not found in xxinv_org_txn_types_reasons table");

					}
					if (compTxnShipInterface.getOdcTimeComplete() != null
							&& CompTxnTypeFromERPlist.get(0).getInactiveDate() != null) {
						int datevalue = compTxnShipInterface.getOdcTimeComplete()
								.compareTo(CompTxnTypeFromERPlist.get(0).getInactiveDate());

						if (datevalue >= 1) {
							processFlag = "Y";
							transferInd = "N";
							errorExplanation = "Company and Site expired in xxinv_org_txn_types_reasons table";
							throw new EvalidationError("Company and Site expired in xxinv_org_txn_types_reasons table");
						}
					}
					if (CompTxnTypeFromERPlist.get(0).getEnabledFlag() != null) {
						if (!CompTxnTypeFromERPlist.get(0).getEnabledFlag().equals("Y")) {
							processFlag = "N";
							transferInd = "N";
							errorExplanation = "Company And Site not active in xxinv_org_txn_types_reasons table";
							throw new EvalidationError(
									"Company And Site not active in xxinv_org_txn_types_reasons table");
						}
					}
					if (compTxnShipInterface.getOdcSiOrderStatus() != null) {
						if (compTxnShipInterface.getOdcSiOrderStatus().equals("007")) {
							LOG.info("checking If the Item is Excluded or Not");
							if (importCompShipmentDao.getLookUpCode("XXINV_MCK_INT_EXCLUDED_ITEMS",
									SQLtoJava.leftPad(compTxnShipInterface.getOdcIrc(), 7, '0'),
									compTxnShipInterface.getOdcTimeComplete())) {
								LOG.info("Item is excluded");
								processFlag = "Y";
								transferInd = "N";
								errorExplanation = "Item excluded by XXINV_MCK_INT_EXCLUDED_ITEMS lookup";
								throw new EvalidationError("Item excluded by XXINV_MCK_INT_EXCLUDED_ITEMS lookup");
							}

							LOG.info("Formatting txn_interface record");
							LOG.info("Insert into mtl_transactions_interface table");
							TransactionInterface interfaceRecord = new TransactionInterface();
							interfaceRecord.setSourceLineId(compTxnShipInterface.getMckOrderOdcDetailId());
							interfaceRecord.setSourceHeaderId(compTxnShipInterface.getMckOrderOdcDetailId());
							interfaceRecord.setItemSegment2(compTxnShipInterface.getOdcIrc());
							interfaceRecord.setOrganizationId(CompTxnTypeFromERPlist.get(0).getOrganizationId());
							interfaceRecord.setSubInventoryCode(CompTxnTypeFromERPlist.get(0).getSubInventoryCode());
							interfaceRecord.setTxnQuantity(compTxnShipInterface.getOdcQuantityPickedNum());
							interfaceRecord.setTxnUOM(CompTxnTypeFromERPlist.get(0).getUomCode());
							interfaceRecord.setTxnDate(compTxnShipInterface.getOdcTimeComplete());
							interfaceRecord.setTxnTypeId(CompTxnTypeFromERPlist.get(0).getTxnTypeId());
							interfaceRecord.setReasonId(CompTxnTypeFromERPlist.get(0).getReasonId());
							interfaceRecord.setDistAccountId(CompTxnTypeFromERPlist.get(0).getDistributionAccountId());
							interfaceRecord.setAttribute1(compTxnShipInterface.getOdcRxNumber());
							interfaceRecord.setAttribute2(compTxnShipInterface.getOdcOrderNo());
							interfaceRecord.setAttribute5(String.valueOf(compTxnShipInterface.getCompanyId()));
							interfaceRecord.setLastUpdateBy(userIdList.get(0));
							interfaceRecord.setCreateBy(userIdList.get(0));
							int x = insertIntoTxnInteraceERPTable(interfaceRecord);
							if (x == 1) {
								insertCount++;
								transferInd = "Y";
								insCount++;
							}

						} else {
							transferInd = "N";
							noShipmentCount++;

						}
					}
					processFlag = "Y";

					LOG.info("Update mck_erp_ship_queue table");
					MckERPShipQueue mckERPShipQueueRecord = new MckERPShipQueue();
					mckERPShipQueueRecord.setProcessFlag(processFlag);
					mckERPShipQueueRecord.setTransferInd(transferInd);
					mckERPShipQueueRecord.setErrorExplanation(errorExplanation);
					mckERPShipQueueRecord.setPackageName(packageName);
					mckERPShipQueueRecord.setProcedureName(procedureName);
					mckERPShipQueueRecord.setErpShipQueueId(compTxnShipInterface.getMckERPShipQueueId());
					mckERPShipQueueRecord.setOrderOdcDetailId(compTxnShipInterface.getMckOrderOdcDetailId());

					int updateERPShipQueCount = updateERPShipQueueTable(mckERPShipQueueRecord);

					if (updateERPShipQueCount == 1)

					{
						LOG.info("Record Updated Succesfully in  mck_erp_ship_queue table");

					}

					LOG.info("Update mck_order_odc_details table");
					MckOrderODCDetails mckOrderODCDetailsrecord = new MckOrderODCDetails();
					mckOrderODCDetailsrecord.setTransferInd(transferInd);
					mckOrderODCDetailsrecord.setPackageName(packageName);
					mckOrderODCDetailsrecord.setProcedureName(procedureName);
					mckOrderODCDetailsrecord.setOrderOdcDetailId(compTxnShipInterface.getMckOrderOdcDetailId());
					mckOrderODCDetailsrecord.setOrderHeaderId(compTxnShipInterface.getMckOrderHeaderId());

					int mckOrderODCDetailsCount = updateMckOrderODCDetails(mckOrderODCDetailsrecord);
					if (mckOrderODCDetailsCount == 1)

					{
						LOG.info("Record Updated Succesfully in  Update mck_order_odc_details table");

					}

				}
				responseMessage = "Completed Successfully. with Code " + returnCode;
				LOG.info("Count of Transaction: " + insertCount);
				LOG.info("Count of Transaction Inserted: " + insertCount);
				LOG.info("Count of no shipment: " + noShipmentCount);
				LOG.info("Count of no error: " + errorCount);

				LOG.info("Completed Successfully......");
				responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.OK);
			}

		} catch (EvalidationError e) {
			LOG.error("Validation failed" + e.getMessage());
			LOG.info(packageName + "-" + procedureName);
			returnCode = 2;
			responseMessage = "Validation Eror has  Occurred. with Code" + returnCode;
			responseEntity = new ResponseEntity<String>(responseMessage + " Cause: " + e.getMessage(),
					HttpStatus.BAD_REQUEST);

		} catch (Exception e) {
			LOG.error("Exception Occurred:" + e.getMessage());
			LOG.info(packageName + "-" + procedureName);
			returnCode = 2;
			responseMessage = "Exception Occurred. with Code" + returnCode;
			responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);

		}

		return responseEntity;
	}

	private int updateMckOrderODCDetails(MckOrderODCDetails mckOrderODCDetails) {
		// TODO Auto-generated method stub
		return importCompShipmentDao.updateOrderOdcDetails(mckOrderODCDetails);
	}

	private int updateERPShipQueueTable(MckERPShipQueue mckERPShipQueueRecord) {
		// TODO Auto-generated method stub

		return importCompShipmentDao.updateMckERPShipQueueRecord(mckERPShipQueueRecord);

	}

	private int insertIntoTxnInteraceERPTable(TransactionInterface interfaceRecord) {
		return importCompShipmentDao.insertIntoTxnInterfaceTable(interfaceRecord);

	}

}
