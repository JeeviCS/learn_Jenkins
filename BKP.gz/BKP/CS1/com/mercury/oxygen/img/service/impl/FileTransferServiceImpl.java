package com.cvs.specialty.erp.service.impl;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.cvs.specialty.erp.dao.CreateItemDao;
import com.cvs.specialty.erp.dao.FileTransferDao;
import com.cvs.specialty.erp.model.HostInfoDTO;
import com.cvs.specialty.erp.model.ProcessParametersDTO;
import com.cvs.specialty.erp.service.FileTransferService;
import com.cvs.specialty.erp.utils.ProgressMonitor;
import com.cvs.specialty.erp.utils.TempFileUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Service
public class FileTransferServiceImpl implements FileTransferService {
	private final Logger LOG = Logger.getLogger(FileTransferServiceImpl.class);

	@Autowired
	FileTransferDao fileTransferDao;

	@Autowired
	CreateItemDao createItemDao;

	String sparcsUserName = null;
	String sparcsPassword = null;
	String sparcsHostName = null;
	String sparcsSrcDir = null;
	String sparcsDestDir = null;
	String sparcsArchiveDir = null;

	String erpUserName = null;
	String erpPassword = null;
	String erpHostName = null;
	String erpSrcDir = null;
	String erpDestDir = null;

	String srcDatabase = null;
	String destDatabase = null;

	JSch sparcsJsch = null;
	Session sparcsSession = null;

	JSch erpJsch = null;
	Session erpSession = null;

	String erpFileFormats = null;
	String sparcsFileFormats = null;

	@Override
	public ResponseEntity<String> startFileTransfer(String processName) {

		ResponseEntity<String> responseEntity = null;

		try {

				List<ProcessParametersDTO> ProcessParametersDTO = fileTransferDao.getParametersOfProcess(processName);
				Map<String, String> serviceCache = new HashMap<>();
				for (ProcessParametersDTO processParams : ProcessParametersDTO) {
					serviceCache.put(processParams.getName(), processParams.getTextValue());

				}
				List<HostInfoDTO> hostInfo = fileTransferDao.getHostInfo("SpilErpSFTP");
				for (HostInfoDTO hostInfoDTO : hostInfo) {
					if(hostInfoDTO.getDescription().equalsIgnoreCase("sparcs")){
						sparcsUserName = hostInfoDTO.getUsername();
						sparcsPassword = hostInfoDTO.getPassword();
						sparcsHostName = hostInfoDTO.getHostName();
						
					}
					if(hostInfoDTO.getDescription().equalsIgnoreCase("erp")){
						
						erpUserName = hostInfoDTO.getUsername();
						erpPassword =  hostInfoDTO.getPassword();
						erpHostName =  hostInfoDTO.getHostName();
						
					}	
				}
				
				
				srcDatabase = serviceCache.get("SFTP_SRC_DATABASE");
				destDatabase = serviceCache.get("SFTP_DEST_DATABASE");

				sparcsSrcDir = serviceCache.get("SFTP_SPARCS_SRC_DIR");
				sparcsDestDir = serviceCache.get("SFTP_SPARCS_DEST_DIR");
				
				sparcsFileFormats = serviceCache.get("SFTP_SPARCS_FILE_FORMATS");
				sparcsArchiveDir = serviceCache.get("SFTP_SPARCS_ARCHIVE_DIR");

				erpSrcDir = serviceCache.get("SFTP_ERP_SRC_DIR");
				erpDestDir = serviceCache.get("SFTP_ERP_DEST_DIR");
				erpFileFormats = serviceCache.get("SFTP_ERP_FILE_FORMATS");
				

				if (sparcsUserName != null && sparcsPassword != null && sparcsHostName != null && erpUserName != null
						&& erpPassword != null && erpHostName != null && srcDatabase != null && destDatabase != null) {

					String responseMsg = null;
					if (srcDatabase.equalsIgnoreCase(destDatabase)) {
						LOG.info("Moving Files Within the Database: " + srcDatabase);
						if (srcDatabase.equalsIgnoreCase("SPARCS")) {
							// in SPARCS
							try {
								responseMsg = transferFilesWithinSPARCS(sparcsSrcDir, sparcsDestDir);
							} catch (Exception e) {
								e.printStackTrace();
							}
							responseEntity = new ResponseEntity<String>(responseMsg, HttpStatus.OK);
						} else {
							// in ERP
							try {
								responseMsg = transferFilesWithinERP(erpSrcDir, erpDestDir);
							} catch (Exception e) {
								e.printStackTrace();
							}

						}
						responseEntity = new ResponseEntity<String>(responseMsg, HttpStatus.OK);

					} else {

						if (srcDatabase.equalsIgnoreCase("SPARCS")) {
							// destination is ERP
							try {

								responseMsg = transferFilesfromSPARCStoERP(sparcsSrcDir, erpDestDir);

							} catch (Exception e) {
								e.printStackTrace();
							}

							responseEntity = new ResponseEntity<String>(responseMsg, HttpStatus.OK);

						} else {

							// destination is SPARCS

							try {

								responseMsg = transferFilesfromERPtoSPARCS(erpSrcDir, sparcsDestDir);

							} catch (Exception e) {
								e.printStackTrace();
							}
							responseEntity = new ResponseEntity<String>(responseMsg, HttpStatus.OK);
						}
					}
				} else {

					throw new DataBaseEntryException("Missing Required Fields From Database");

				}

		} catch (DataBaseEntryException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return responseEntity;
	}

	private String transferFilesWithinERP(String source, String target) {
		LOG.info("Moving Files from: " + source + " to: " + target);
		LOG.info("Moving Files from: " + source + " to: " + target);
		int totalCount = 0;
		int successCount = 0;
		Channel upChannel = null;
		Channel downChannel = null;
		ChannelSftp uploadChannel = null;
		ChannelSftp downloadChannel = null;
		Session session = null;
		try {
			session = openERPSFTPConnection();

			InputStream sparcsStream = null;

			if (!session.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {

				upChannel = session.openChannel("sftp");
				downChannel = session.openChannel("sftp");
				upChannel.connect();
				downChannel.connect();
				uploadChannel = (ChannelSftp) upChannel;
				downloadChannel = (ChannelSftp) downChannel;

				@SuppressWarnings("unchecked")
				Vector<ChannelSftp.LsEntry> remoteFileList = uploadChannel.ls(source);
				for (ChannelSftp.LsEntry entry : remoteFileList) {
					try {
						String fileName = entry.getFilename();
						if (!entry.getAttrs().isDir()) {

							totalCount++;

							sparcsStream = uploadChannel.get(source + "/" + fileName);

							File tempfile = TempFileUtils.createTempFile(fileName);
							downloadChannel.put(sparcsStream, target + "/" + tempfile.getName(), new ProgressMonitor(),
									ChannelSftp.OVERWRITE);

							successCount++;
							// After Processing delete the Temp File
							TempFileUtils.deleteTempFile(fileName);

							LOG.info("File:" + source + "/" + fileName + " deleted Successfully");

						}

					} catch (Exception e) {
						LOG.error("Exception", e);
					}
				}
				LOG.info("Total Number of Files in The Source Directory:" + source + ":" + totalCount);
				LOG.info("Total Number of Files Moved to Dest Directory:" + target + ":" + successCount);
				LOG.info("Number of files Failed to Transfer: " + (totalCount - successCount));
			}
		} catch (Exception e) {

			LOG.error("Exception Occurred" + e);
		} finally {
			if (upChannel != null) {
				uploadChannel.exit();
				upChannel.disconnect();
			}
			if (downChannel != null) {
				downloadChannel.exit();
				downChannel.disconnect();
			}
			if (session != null) {

				session.disconnect();
			}

		}
		return successCount + ": files Successfully moved within ERP, Failed to Transfer: "
				+ (totalCount - successCount);
	}

	@SuppressWarnings("unchecked")
	private String transferFilesfromERPtoSPARCS(String source, String target) {
		LOG.info("Moving Files from: " + source + " to: " + target);
		int totalCount = 0;
		int successCount = 0;
		int response = 0;
		String[] formats = erpFileFormats.split(",");

		Channel upChannel = null;

		ChannelSftp uploadChannel = null;

		Session session = null;
		InputStream erpStream = null;
		
		try {
			session = openERPSFTPConnection();
			if (!session.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {

				upChannel = session.openChannel("sftp");
				upChannel.connect();
				uploadChannel = (ChannelSftp) upChannel;

				uploadChannel.cd(source);

				
				Vector<ChannelSftp.LsEntry> remoteFileList = new Vector<ChannelSftp.LsEntry>();
				

				for (String format : formats) {
					remoteFileList.addAll(uploadChannel.ls(format + "*"));
					}
				

				for (ChannelSftp.LsEntry entry : remoteFileList) {
					try {
						String fileName = entry.getFilename();

						if (!entry.getAttrs().isDir()) {

							totalCount++;
							
							erpStream = uploadChannel.get(source + "/" + fileName);

							response = sendStreamFromERPtoSPARCS(erpStream, target, fileName);

							successCount++;
							// After Processing delete the Temp File
							TempFileUtils.deleteTempFile(fileName);
							

							LOG.info("File:" + source + "/" + fileName + " deleted Successfully");

						} else {
							LOG.info("No files matching the Formats in Source:" + source);
						}
					} catch (Exception e) {
						LOG.error("Exception", e);
					}
				}
				LOG.info("Total Number of successful Responses:" + response);
				LOG.info("Total Number of Files in The Source Directory:" + source + ":" + totalCount);
				LOG.info("Total Number of Files Moved to Dest Directory:" + target + ":" + successCount);
				LOG.info("Number of files Failed to Transfer: " + (totalCount - successCount));
			}
		} catch (Exception e) {
			LOG.error("Exception has Occurred" + e.getMessage());

		} finally {
			if (upChannel != null) {
				uploadChannel.exit();
				upChannel.disconnect();
			}

			if (session != null) {

				session.disconnect();
			}

		}
		return successCount + ": files Successfully moved to SPARCS from ERP, Failed to Transfer:"
				+ (totalCount - successCount);
	}

	private int sendStreamFromERPtoSPARCS(InputStream erpStream, String target, String fileName) {
		
		int successcount = 0;

		Session erpsession = null;

		Channel downChannel = null;
		ChannelSftp downloadChannel = null;
		try {
			File tempfile = TempFileUtils.createTempFile(fileName);
			erpsession = openSPARCSSFTPConnection();
			if (!erpsession.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {

				downChannel = erpsession.openChannel("sftp");
				downChannel.connect();
				downloadChannel = (ChannelSftp) downChannel;

				downloadChannel.put(erpStream, target + "/" + tempfile.getName(), new ProgressMonitor(),
						ChannelSftp.OVERWRITE);
				successcount = downloadChannel.getId();

				LOG.info("Successfully Moved the File to SPARCS: " + fileName);

				// After Processing delete the Temp File
				TempFileUtils.deleteTempFile(fileName);
				// Remove the Copied File from the Src Directory

			}

		} catch (Exception e) {
			LOG.error("Exception has Occurred" + e.getMessage());

		} finally {

			if (downChannel != null) {
				downloadChannel.exit();
				downChannel.disconnect();
			}
			if (erpsession != null) {

				erpsession.disconnect();
			}
		}
		return successcount;

	}

	@SuppressWarnings("unchecked")
	private String transferFilesfromSPARCStoERP(String source, String target) {
		LOG.info("Moving Files from: " + source + " to: " + target);
		int totalCount = 0;
		int successCount = 0;
		int response=0;
		String[] formats = sparcsFileFormats.split(",");

		Channel upChannel = null;
		String archiveResponsMsg = null;

		ChannelSftp uploadChannel = null;

		Session session = null;
		InputStream sparcsStream = null;
		
		try {
			session = openSPARCSSFTPConnection();
			if (!session.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {

				upChannel = session.openChannel("sftp");
				upChannel.connect();
				uploadChannel = (ChannelSftp) upChannel;
				uploadChannel.cd(source);

		
				Vector<ChannelSftp.LsEntry> remoteFileList = new Vector<ChannelSftp.LsEntry>();

				for (String format : formats) {
					remoteFileList.addAll(uploadChannel.ls(format + "*"));

				}

				for (ChannelSftp.LsEntry entry : remoteFileList) {
					try {
						String fileName = entry.getFilename();

						if (!entry.getAttrs().isDir()) {
							
							totalCount++;
							
							sparcsStream = uploadChannel.get(source + "/" + fileName);

							response = sendStreamFromSPARCStoERP(sparcsStream, target, fileName);

							successCount++;
							// After Processing delete the Temp File
							TempFileUtils.deleteTempFile(fileName);


							LOG.info("successCount:" + successCount);
							LOG.info("File:" + source + "/" + fileName + " deleted Successfully");

						}

					} catch (Exception e) {
						LOG.error("Exception", e);
					}
				}
				archiveResponsMsg = transferFilesWithinSPARCS(source, sparcsArchiveDir);
				LOG.info("Total Number of successful Responses:" + response);
				LOG.info("Total Number of Files in The Source Directory:" + source + ":" + totalCount);
				LOG.info("Total Number of Files Moved to Dest Directory:" + target + ":" + successCount);
				LOG.info("Number of files Failed to Transfer: " + (totalCount - successCount));
				LOG.info("Achived: " + archiveResponsMsg);
			}
		} catch (Exception e) {
			LOG.error("Exception has Occurred" + e.getMessage());

		} finally {
			if (upChannel != null) {
				uploadChannel.exit();
				upChannel.disconnect();
			}

			if (session != null) {

				session.disconnect();
			}

		}
		return successCount + ": files Successfully moved to ERP from SPARCS, Failed to Transfer: "
				+ (totalCount - successCount);
	}

	private int sendStreamFromSPARCStoERP(InputStream sparcsStream, String target, String fileName) {
	
		int successcount = 0;

		Session erpsession = null;

		Channel downChannel = null;
		ChannelSftp downloadChannel = null;
		try {
			File tempfile = TempFileUtils.createTempFile(fileName);
			erpsession = openERPSFTPConnection();
			if (!erpsession.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {

				downChannel = erpsession.openChannel("sftp");
				downChannel.connect();
				downloadChannel = (ChannelSftp) downChannel;

				downloadChannel.put(sparcsStream, target + "/" + tempfile.getName(), new ProgressMonitor(),
						ChannelSftp.OVERWRITE);
				successcount = downloadChannel.getId();
				
				LOG.info("Successfully Moved the File to ERP: " + fileName);

				// Remove the Copied File from the Src Directory
				TempFileUtils.deleteTempFile(fileName);

			}

		} catch (Exception e) {
			LOG.error("Exception has Occurred" + e.getMessage());

		} finally {

			if (downChannel != null) {
				downloadChannel.exit();
				downChannel.disconnect();
			}
			if (erpsession != null) {

				erpsession.disconnect();
			}
		}
		return successcount;

	}

	// Moving Files using Unix commands
	public void moveFiles(String source, String target) throws Exception {
		LOG.info("COMMAND: mv " + source + " " + target);

		ChannelExec exec = null;
		Session session = null;

		try {
			session = openSPARCSSFTPConnection();
			if (!sparcsSession.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {
				exec = (ChannelExec) session.openChannel("exec");
				LOG.info("Before Moving the Files:");
				String command = "mv " + source + "/*  " + target;
				exec.setCommand(command);
				exec.connect();
				LOG.info("Files Moved Successfully:");
			}

		} catch (JSchException e) {
			LOG.error("Auth failure", e);
			throw new Exception(e);
		} catch (Exception e) {
			LOG.error("Exception", e);

		} finally {
			if (session != null) {
				session.disconnect();
			}
			if (exec != null) {
				exec.disconnect();
			}
		}

		LOG.info("Method Exit: MoveFiles to Destination within SPARCS");
	}

	// Moving Files using Temp File storage and the moving
	@SuppressWarnings("unchecked")
	public String transferFilesWithinSPARCS(String source, String target) throws Exception {
		LOG.info("Moving Files from: " + source + " to: " + target);
		int totalCount = 0;
		int successCount = 0;
		Channel upChannel = null;
		Channel downChannel = null;
		ChannelSftp uploadChannel = null;
		ChannelSftp downloadChannel = null;
		Session session = openSPARCSSFTPConnection();
		InputStream sparcsStream = null;
		String[] formats = sparcsFileFormats.split(",");
		
		try {
			if (!session.isConnected()) {
				LOG.error("Session is not connected");
				throw new Exception("Session is not connected...");
			} else {

				upChannel = session.openChannel("sftp");
				downChannel = session.openChannel("sftp");
				upChannel.connect();
				downChannel.connect();
				uploadChannel = (ChannelSftp) upChannel;
				downloadChannel = (ChannelSftp) downChannel;
				uploadChannel.cd(source);

				Vector<ChannelSftp.LsEntry> remoteFileList=new Vector<ChannelSftp.LsEntry>();
				for (String format : formats)
				{
					remoteFileList.addAll(uploadChannel.ls(format+"*"));
					
				}
				
				for (ChannelSftp.LsEntry entry : remoteFileList) {
					try {
						String fileName = entry.getFilename();
					
						if (!entry.getAttrs().isDir()) {
							totalCount++;
							
							sparcsStream = uploadChannel.get(source + "/" + fileName);

							File tempfile = TempFileUtils.createTempFile(fileName);
							downloadChannel.put(sparcsStream, target + "/" + tempfile.getName(), new ProgressMonitor(),
									ChannelSftp.OVERWRITE);

							successCount++;
							// After Processing delete the Temp File
							TempFileUtils.deleteTempFile(fileName);
							// Remove the Copied File from the Src Directory
							uploadChannel.rm(source + "/" + fileName);
						

							LOG.info("File:" + source + "/" + fileName + " deleted Successfully");

						} else {
							LOG.error("Cannot Move the File: " + source + "/" + fileName);

						}

					} catch (Exception e) {
						LOG.error("Exception", e);
					}
				}
				LOG.info("Total Number of Files in The Source Directory:" + source + ":" + totalCount);
				LOG.info("Total Number of Files Moved to Dest Directory:" + target + ":" + successCount);
				LOG.info("Number of files Failed to Transfer: " + (totalCount - successCount));
			}
		} catch (Exception e) {
			LOG.error("Exception has occured", e);
		} finally {
			if (upChannel != null) {
				uploadChannel.exit();
				upChannel.disconnect();
			}
			if (downChannel != null) {
				downloadChannel.exit();
				downChannel.disconnect();
			}
			if (session != null) {

				session.disconnect();
			}

		}
		return successCount + ": files Successfully moved within SPARCS, Failed to Transfer: "
				+ (totalCount - successCount);
	}

	/**
	 * This method used to open the SFTP connection to the box where
	 * StateResidencyFeed available
	 * 
	 * @throws Exception
	 */
	private Session openSPARCSSFTPConnection() throws Exception {
		LOG.info("Method Entry: openSFTPConnection");
		sparcsJsch = new JSch();
		sparcsSession = sparcsJsch.getSession(sparcsUserName, sparcsHostName);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
		sparcsSession.setConfig(config);
		sparcsSession.setPassword(sparcsPassword);
		sparcsSession.connect();

		LOG.info("Method Exit: openSFTPConnection");
		return sparcsSession;
	}

	private Session openERPSFTPConnection() throws Exception {
		LOG.info("Method Entry: openSFTPConnection");
		erpJsch = new JSch();
		erpSession = erpJsch.getSession(erpUserName, erpHostName);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
		erpSession.setConfig(config);
		erpSession.setPassword(erpPassword);
		erpSession.connect();
		LOG.info("Method Exit: openSFTPConnection");
		return erpSession;

	}

}
