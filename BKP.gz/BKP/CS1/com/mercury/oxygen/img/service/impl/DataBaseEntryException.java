package com.cvs.specialty.erp.service.impl;

public class DataBaseEntryException extends Exception {
	private static final long serialVersionUID = 3149397261703020372L;
	String message;

	public DataBaseEntryException(String message) {

		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
