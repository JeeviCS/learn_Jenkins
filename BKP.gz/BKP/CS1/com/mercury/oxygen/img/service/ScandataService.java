package com.cvs.specialty.erp.service;

import org.springframework.stereotype.Service;

import com.cvs.specialty.erp.model.ScandataRequest;
import com.cvs.specialty.erp.model.ScandataResponse;
import com.cvs.specialty.erp.model.ServiceRequest;
import com.cvs.specialty.erp.model.ServiceResponse;

@Service
public interface ScandataService {

	ServiceResponse<ScandataResponse> callScandataIfc(ServiceRequest<ScandataRequest> scnRequest);
}
