package com.cvs.specialty.erp.service;

public interface SchedularService {
	void executeImportCompShipTxnsEndpoint();

	void handleImportSparcsShipmentTransactions();

	void handleImportHBSShipmentTransactions();

	void handleCreateItem();

	void handleUpdateItem();

	void handleExportCompanyReturnTransaction();

	void handleHBSPurchaseOrder();

}
