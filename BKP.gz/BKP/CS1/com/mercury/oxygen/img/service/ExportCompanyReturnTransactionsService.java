package com.cvs.specialty.erp.service;

import org.springframework.http.ResponseEntity;

/**
 * 
 * @author Z238847
 *
 */
public interface ExportCompanyReturnTransactionsService {
	/**
	 * 
	 * @param username
	 * @return
	 */
	ResponseEntity<String> exportCompanyReturnTransactionsService(String username);

}
