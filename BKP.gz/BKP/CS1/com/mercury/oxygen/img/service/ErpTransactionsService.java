package com.cvs.specialty.erp.service;

import java.sql.Date;
import java.util.List;

import com.cvs.specialty.erp.model.CompanyTransactions;

public interface ErpTransactionsService {
	/**
	 * This method returns the list of company transactions
	 * 
	 * @param CompanyTransactions
	 */
	List<CompanyTransactions> getReturnTransactions();

	/**
	 * This method updates the flags
	 * 
	 * @param updatedBy
	 * @param processFlag
	 * @param updatedDate
	 * @param companyTxnsIfaceId
	 */
	void updateProcessFlag(String updatedBy, String processFlag, Date updatedDate, int companyTxnsIfaceId);

}
