package com.cvs.specialty.erp.service.impl;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.erp.dao.CreateItemDao;
import com.cvs.specialty.erp.dao.LookUpItemStatusDao;
import com.cvs.specialty.erp.dao.UpdateItemDao;
import com.cvs.specialty.erp.model.CreateERPItemDTO;
import com.cvs.specialty.erp.model.CreateItemDTO;
import com.cvs.specialty.erp.model.ItemStatusDTO;
import com.cvs.specialty.erp.model.UpdateErpItemDTO;
import com.cvs.specialty.erp.model.UpdateItemDTO;
import com.cvs.specialty.erp.service.ItemService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.SQLtoJava;
import com.google.gson.Gson;

@Service
public class ItemServiceImpl implements ItemService {
	private static final Logger LOG = Logger.getLogger(ItemServiceImpl.class);
	ResponseEntity<String> responseEntity = null;
	@Autowired
	CreateItemDao createItemDao;
	@Autowired
	UpdateItemDao updateItemDao;
	@Autowired
	LookUpItemStatusDao lookUpItemStatusDao;

	String activeInd = "Y";
	int masterOrganizationId = 122;
	int erpItemprocessFlag = 1;
	String erpItemPrimaryUOMCode = "EA";
	int erpItemProcessId = 100;

	int successCode = 0;
	int warningCode = 1;
	int errorCode = 2;

	String responseMessage = "";
	String transactionType = "CREATE";

	@Override
	@Transactional
	public ResponseEntity<String> createItem(String templateId, String username) {
		LOG.debug("Inside Create Item Process:");

		// TODO Auto-generated method stub
		try {

			int registeredProcessId = createItemDao.getRegisterdProcessNumber(Constants.CREATE_ITEM_PROCESS_NAME);

			List<Integer> userIdList = createItemDao.getUserId(username);
			if (userIdList != null) {

				if (registeredProcessId != 0) {
					java.sql.Timestamp startDate = createItemDao.getStartDateFromProcessTable(registeredProcessId);
					if (startDate != null) {
						java.sql.Timestamp endDate = new java.sql.Timestamp(new java.util.Date().getTime());
						List<CreateItemDTO> sparcsItemList = createItemDao.getItemsFromSparcsItemTable(startDate,
								endDate, activeInd);

						List<CreateItemDTO> nonExistingItemList = getListofItemsNotAlreadyAdded(sparcsItemList);

						int noOfRecordsInserted = insertIntoERPItemInterfaceTable(nonExistingItemList, templateId,
								userIdList.get(0));
						createItemDao.updateEndDateInProcessTable(endDate, registeredProcessId);
						LOG.info("No Of records Inserted: " + noOfRecordsInserted);
						responseEntity = new ResponseEntity<String>(Constants.SUCCESS_MESSAGE, HttpStatus.OK);

					} else {
						LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
						LOG.error(Constants.START_DATE_ERROR);
						responseEntity = new ResponseEntity<String>(Constants.START_DATE_ERROR, HttpStatus.BAD_REQUEST);
					}
				} else {
					LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
					LOG.error(Constants.CREATE_ITEM_PROCESS_NAME + "|" + Constants.PROCESS_CONTROL_ERROR);
					responseEntity = new ResponseEntity<String>(Constants.PROCESS_CONTROL_ERROR,
							HttpStatus.BAD_REQUEST);

				}
			} else {
				LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
				LOG.error(Constants.USER_ERROR);
				responseEntity = new ResponseEntity<String>(Constants.USER_ERROR + username, HttpStatus.BAD_REQUEST);
			}

		} catch (Exception e) {
			LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
			LOG.error("Exception Occurred:" + e.getMessage());

			responseEntity = new ResponseEntity<String>(Constants.EXCEPTION_MESSAGE, HttpStatus.INTERNAL_SERVER_ERROR);

		}
		return responseEntity;

	}

	private int insertIntoERPItemInterfaceTable(List<CreateItemDTO> nonExistingItemList, String templateId,
			int userId) {
		int intValueOfTemplateId = (templateId == "") ? 0 : Integer.parseInt(templateId);
		int noOfRecordsInserted = 0;

		// TODO Auto-generated method stub
		if (nonExistingItemList != null) {
			for (CreateItemDTO itemDTO : nonExistingItemList) {
				try {
					if (itemDTO.getTransactionType().equalsIgnoreCase(transactionType)) {
						CreateERPItemDTO erpItemDto = new CreateERPItemDTO();
						erpItemDto.setOrganizationId(masterOrganizationId);
						erpItemDto.setSegment2(SQLtoJava.leftPad(itemDTO.getItemNumber(), 7, '0'));
						erpItemDto.setDescription(itemDTO.getItemName());
						erpItemDto.setTemplateId(intValueOfTemplateId);
						erpItemDto.setAttribute2(itemDTO.getNdcNo());
						erpItemDto.setMarketPrice(itemDTO.getAwpAmount());
						erpItemDto.setLastUpdateBy(userId);
						erpItemDto.setCreatedBy(userId);
						int successCount = createItemDao.insertIntoERPItemInterfaceTable(erpItemDto);
						if (successCount == 1) {
							noOfRecordsInserted++;
						}

					} else {
						LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
						LOG.error("Unknown Transaction Type");
					}

				} catch (Exception e) {
					LOG.error("Exception in Adding the Record:" + e.getMessage());
				}
			}
		}
		return noOfRecordsInserted;
	}

	private List<CreateItemDTO> getListofItemsNotAlreadyAdded(List<CreateItemDTO> sparcsItemList) {
		List<CreateItemDTO> nonExistingItemList = new ArrayList<>();
		for (CreateItemDTO item : sparcsItemList) {
			int resultCount = createItemDao.checkIfExistsinErpItemsInterfaceTable(item.getItemNumber(),
					masterOrganizationId);
			if (resultCount == 0) {
				nonExistingItemList.add(item);
			}
		}
		return nonExistingItemList;
	}

	@Override
	@Transactional
	public ResponseEntity<String> updateItem(String username) {
		try {
			LOG.info("Inside Update Item Process:");
			int registeredProcessId = createItemDao.getRegisterdProcessNumber(Constants.UPDATE_ITEM_PROCESS_NAME);
			if (registeredProcessId != 0) {
				List<Integer> userIdList = createItemDao.getUserId(username);
				if (userIdList != null) {

					java.sql.Timestamp startDate = createItemDao.getStartDateFromProcessTable(registeredProcessId);
					if (startDate != null) {
						java.sql.Timestamp endDate = new java.sql.Timestamp(System.currentTimeMillis());
						List<UpdateItemDTO> updateitemsList = updateItemDao.getUpdateItemsFromSparcs(startDate,
								endDate);

						List<UpdateErpItemDTO> sparcsList = getMatchingrecordsInSPARCS(updateitemsList);

						int noOfRecordsUpdated = checkAndProcessInERP(sparcsList, userIdList.get(0));
						// createItemDao.updateEndDateInProcessTable(endDate,
						// registeredProcessId);
						LOG.info("No Of records Inserted: " + noOfRecordsUpdated);
						responseEntity = new ResponseEntity<String>(Constants.SUCCESS_MESSAGE, HttpStatus.OK);
						createItemDao.updateEndDateInProcessTable(endDate, registeredProcessId);
					}

					else {
						LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
						LOG.error(Constants.START_DATE_ERROR);
						responseEntity = new ResponseEntity<String>(Constants.START_DATE_ERROR, HttpStatus.BAD_REQUEST);
					}

				} else {
					LOG.error(Constants.USER_ERROR);
					responseEntity = new ResponseEntity<String>(Constants.USER_ERROR + username,
							HttpStatus.BAD_REQUEST);
				}
			} else {
				LOG.error(Constants.ITEM_PACKAGE_NAME_DESC);
				LOG.error(Constants.UPDATE_ITEM_PROCESS_NAME + ":" + Constants.PROCESS_CONTROL_ERROR);
				responseEntity = new ResponseEntity<String>(Constants.PROCESS_CONTROL_ERROR, HttpStatus.BAD_REQUEST);

			}

		} catch (Exception e) {
			LOG.error("Exception Occurred:" + e.getMessage());
			responseEntity = new ResponseEntity<String>(Constants.EXCEPTION_MESSAGE, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return responseEntity;
	}

	private List<UpdateErpItemDTO> getMatchingrecordsInSPARCS(List<UpdateItemDTO> updateitemsList) {
		List<UpdateErpItemDTO> updateERPitemsList = new ArrayList<UpdateErpItemDTO>();
		for (UpdateItemDTO updateItemDTO : updateitemsList) {

			try {
				UpdateErpItemDTO updateERPItemDTO = new UpdateErpItemDTO();
				updateERPItemDTO.setUpdateitemDTO(updateItemDTO);
				List<Double> marketPriceList = getMarketPriceMtlSystemItems(updateItemDTO.getItemNumber());
				if (marketPriceList != null) {

					if (marketPriceList.get(0) != null) {
						updateERPItemDTO.setMarketPrice(marketPriceList.get(0));
						updateERPItemDTO.setSysSrcCode(updateItemDTO.getItemSrcCode());
						updateERPItemDTO.setItemNumber(updateItemDTO.getItemNumber());
						updateERPitemsList.add(updateERPItemDTO);
					}
				} else {

					LOG.info(Constants.MARKET_PRICE_NOT_NULL);
				}
			} catch (Exception e) {
				LOG.error("Exception Occurred while Retrieving Update Item Records from SPARCS" + e.getMessage());

			}

		}
		return updateERPitemsList;
	}

	public int checkAndProcessInERP(List<UpdateErpItemDTO> updateERPitemsList, int userId) {
		int noOfRecordsUpdated = 0;

		List<Double> awpAmountList = null;

		for (UpdateErpItemDTO updateErpItemDTO : updateERPitemsList) {

			List<Integer> itemList = updateItemDao.getItemId(updateErpItemDTO.getSysSrcCode());
			if (itemList != null) {

				// set context here
				callToSetItemContextSP(itemList.get(0));
				awpAmountList = updateItemDao.getAWPAmount(itemList.get(0), updateErpItemDTO.getMarketPrice());
				// Removing the Context
				callToSetItemContextSP(0);

				if (awpAmountList != null && awpAmountList.size() == 1) {
					try {

						int successCount = updateItemDao.noOfUpdatedRecords(
								SQLtoJava.leftPad(updateErpItemDTO.getItemNumber(), 7, '0'), awpAmountList.get(0),
								userId);
						if (successCount == 1) {
							noOfRecordsUpdated++;
						}
					} catch (Exception e) {
						LOG.error("Exception In Adding Record:" + e.getMessage());

					}

				}

				else if (awpAmountList != null && awpAmountList.size() > 1) {

					LOG.error("Select Statement for Getting AWP amount from SPARCS Retriving more than one Results: "
							+ awpAmountList.size());
				} else {
					LOG.info("Select Statement for Getting AWP amount from SPARCS Returned NULL value ");

				}
			} else {

				LOG.error("Select Statement for Getting AWP amount from SPARCS Returned NULL value ");
			}

		}
		return noOfRecordsUpdated;
	}

	private void callToSetItemContextSP(int itemId) {
		// TODO Auto-generated method stub
		updateItemDao.executeSetItemContextSP(itemId);
	}

	private List<Double> getMarketPriceMtlSystemItems(String itemNumber) {
		// TODO Auto-generated method stub
		return updateItemDao.getMarketPriceFromERPMTLSystems(itemNumber, masterOrganizationId);

	}

	/**
	 * 
	 */
	@Override
	public ResponseEntity<String> getItemStatus(String charSiteCode, String drugNo, String contentType) {
		if (StringUtils.isNotBlank(charSiteCode) && StringUtils.isNotBlank(drugNo)) {
			try {

				List<ItemStatusDTO> itemStatusDTO = lookUpItemStatusDao.getItemStatus(charSiteCode, drugNo);
				if (itemStatusDTO.isEmpty() || itemStatusDTO == null) {
					responseMessage = "No Data Found";
					LOG.info("ResponseMessage:" + responseMessage + drugNo);
					// responseEntity = new ResponseEntity<String>(responseMessage,
					// HttpStatus.NO_CONTENT);

				} else {
					LOG.debug("itemStatusDTO ::" + itemStatusDTO);
					responseMessage = "success";
					LOG.info("ResponseMessage:" + responseMessage);
				}
				String response = StringUtils.EMPTY;
				if (contentType.equals(MediaType.APPLICATION_JSON_VALUE)) {
					response = new Gson().toJson(itemStatusDTO);
				} else if (contentType.equals(MediaType.APPLICATION_XML_VALUE)) {
					JAXBContext jaxbContext = JAXBContext.newInstance(ItemStatusDTO.class);
					Marshaller marshaller = jaxbContext.createMarshaller();
					marshaller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);
					StringWriter stringWriter = new StringWriter();
					try {
						if(itemStatusDTO!=null &&  !itemStatusDTO.isEmpty())
						{
						marshaller.marshal(itemStatusDTO.get(0), stringWriter);
						response = stringWriter.toString();
						}
						else {
							response="<item-status-lookup-response>\r\n" + 
									"    <inventory_item_id></inventory_item_id>\r\n" + 
									"    <organization_id></organization_id>\r\n" + 
									"    <enabled_flag></enabled_flag>\r\n" + 
									"    <inventory_item_status_code></inventory_item_status_code>\r\n" + 
									"    <mtl_system_items_ind></mtl_system_items_ind>\r\n" + 
									"</item-status-lookup-response>";
						}
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						LOG.error("Exception Occurred while marshalling XML response" + e);
					}
				}

				responseEntity = new ResponseEntity<String>(response, HttpStatus.OK);

				// }

			}

			catch (Exception e) {
				LOG.error("Exception Occurred:" + e.getMessage());
				responseMessage = "Exception Occurred With Code:" + errorCode;
				responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} else {
			LOG.error("charSiteCode:" + charSiteCode + "and drugNo:" + drugNo + " must not be empty");
			responseMessage = "charSiteCode:" + charSiteCode + "and drugNo:" + drugNo + " must not be empty";
			responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}

}
