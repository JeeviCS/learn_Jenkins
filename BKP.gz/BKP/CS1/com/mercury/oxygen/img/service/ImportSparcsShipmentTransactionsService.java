package com.cvs.specialty.erp.service;

import org.springframework.http.ResponseEntity;

import com.cvs.specialty.erp.model.ImportShipmentTransactionsVO;

/**
 * 
 * @author Z238847
 *
 */
public interface ImportSparcsShipmentTransactionsService {

	/**
	 * 
	 * @param username
	 * @param sourceCode
	 * @param importShipmentTransactionsVO
	 * @return
	 * @throws Exception
	 */
	ResponseEntity<String> importSparcsShipmentTransactions(String username, String sourceCode,
			ImportShipmentTransactionsVO importShipmentTransactionsVO,String siteName) throws Exception;

}
