package com.cvs.specialty.erp.service.impl;

import org.apache.log4j.Logger;

public class EvalidationError extends Exception {

	private static final long serialVersionUID = -5823745267717334044L;
	private static final Logger LOG = Logger.getLogger(EvalidationError.class);

	String message;
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public EvalidationError(String string) {
		LOG.error("Validation Error has Occured:"+string);
		this.message=string;
		
	}

	public String getmessage() {
		return null;
		
	}
}
