/**
 * 
 */
package com.cvs.specialty.erp.service.impl;

import java.sql.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cvs.specialty.erp.model.CompanyTransactions;
import com.cvs.specialty.erp.model.MckOrderReturn;
import com.cvs.specialty.erp.service.ErpTransactionsService;
import com.cvs.specialty.erp.service.ExportCompanyReturnTransactionsService;
import com.cvs.specialty.erp.service.MckOrderReturnsService;

/**
 * @author Z238847
 *
 */
@Service
public class ExportCompanyReturnTransactionsServiceImpl implements ExportCompanyReturnTransactionsService {
	private static final Logger LOGGER = Logger.getLogger(ExportCompanyReturnTransactionsServiceImpl.class);

	private MckOrderReturnsService mckOrderReturnsService;
	private ErpTransactionsService erpTransactionsService;
	ResponseEntity<String> responseEntity = null;
	String responseMessage = "";
	int successCode = 0;
	int errorCode = 2;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.cvs.specialty.tls.service.ExportCompanyReturnTransactionsService#
	 * exportCompanyReturnTransactionsService()
	 */
	@Override
	@Transactional
	public ResponseEntity<String> exportCompanyReturnTransactionsService(String username) {
		responseMessage = "Export company return transactions operation is successful with successcode ::"
				+ successCode;
		responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.OK);
		int recordsCount = 0;
		Date currentDate = new Date(System.currentTimeMillis());
		try {

			List<CompanyTransactions> returnTransactions = erpTransactionsService.getReturnTransactions();
			MckOrderReturn mckOrderReturn = null;
			for (CompanyTransactions companyTransaction : returnTransactions) {
				mckOrderReturn = new MckOrderReturn();
				mckOrderReturn.setCompanyTxnsIfaceId(companyTransaction.getCompanyTxnsIfaceId());
				mckOrderReturn.setTransactionId(companyTransaction.getTransactionId());
				mckOrderReturn.setTransactionDate(companyTransaction.getTransactionDate());
				mckOrderReturn.setTransactionTypeName(companyTransaction.getTransactionTypeName());
				mckOrderReturn.setTransactionReasonName(companyTransaction.getTransactionReasonName());
				mckOrderReturn.setSiteId(companyTransaction.getSiteId());
				mckOrderReturn.setOrderNumber(companyTransaction.getOrderNumber());
				mckOrderReturn.setRxNumber(companyTransaction.getRxNumber());
				mckOrderReturn.setItemNumber(companyTransaction.getItemNumber());
				mckOrderReturn.setNdc(companyTransaction.getNdc());
				mckOrderReturn.setItemDescription(companyTransaction.getItemDescription());
				mckOrderReturn.setTransactionQuantity(companyTransaction.getTransactionQuantity());
				mckOrderReturn.setTransactionUom(companyTransaction.getTransactionUom());
				mckOrderReturn.setOrderByCompanyId(companyTransaction.getOrderByCompanyId());
				mckOrderReturn.setCreateBy(username);
				mckOrderReturn.setCreateDate(currentDate);
				mckOrderReturn.setUpdateBy(username);
				mckOrderReturn.setUpdateDate(currentDate);
				mckOrderReturn.setCreateBySystem("SPARCS");
				mckOrderReturn.setCreateByProcessFunction("TLS1.2 . exportCompanyTransactions");
				mckOrderReturn.setUpdateBySystem("NULL");
				mckOrderReturn.setUpdateByProcessFunction("NULL");
				mckOrderReturn.setTransactionReference(companyTransaction.getTransactionReference());
				mckOrderReturnsService.saveOrderReturn(mckOrderReturn);
				erpTransactionsService.updateProcessFlag(username, "Y", currentDate,
						companyTransaction.getCompanyTxnsIfaceId());
				recordsCount += 1;
			}

		} catch (Exception e) {
			LOGGER.info("Count of records inserted into mck_order_returns table:" + recordsCount);
			LOGGER.error("Export company return transactions operation is failed::" + e);
			responseMessage = "Export company return transactions operation is failed  with errorcode ::" + errorCode;
			responseEntity = new ResponseEntity<String>(responseMessage, HttpStatus.INTERNAL_SERVER_ERROR);
			// send errors email
			String emailMessage = "An error occurred at spilERPhandleExportCompReturnTxns API while creating daily invoice file. Please refer to API Logging on "
					+ currentDate + " for further details";
			mckOrderReturnsService.sendemail(emailMessage);
		}

		return responseEntity;
	}

	/**
	 * 
	 * @param mckOrderReturnsService
	 */
	@Autowired
	public void setMckOrderReturnsService(MckOrderReturnsService mckOrderReturnsService) {
		this.mckOrderReturnsService = mckOrderReturnsService;
	}

	/**
	 * 
	 * @param erpTransactionsService
	 */
	@Autowired
	public void setErpTransactionsService(ErpTransactionsService erpTransactionsService) {
		this.erpTransactionsService = erpTransactionsService;
	}

}
