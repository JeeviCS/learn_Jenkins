package com.cvs.specialty.erp.model;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component
public class SparcsShipmentTransaction {

	private long erpDispenseInterfaceId;
	private long rxNumber;
	private long refillNumber;
	private long orderNumber;
	private long shipmentNumber;
	private long itemNumber;
	private long actualDispensed;
	private long quantityDispensed;
	private Date createDate;

	public long getActualDispensed() {
		return actualDispensed;
	}

	public void setActualDispensed(long actualDispensed) {
		this.actualDispensed = actualDispensed;
	}

	public long getErpDispenseInterfaceId() {
		return erpDispenseInterfaceId;
	}

	public void setErpDispenseInterfaceId(long erpDispenseInterfaceId) {
		this.erpDispenseInterfaceId = erpDispenseInterfaceId;
	}

	public long getRxNumber() {
		return rxNumber;
	}

	public void setRxNumber(long rxNumber) {
		this.rxNumber = rxNumber;
	}

	public long getRefillNumber() {
		return refillNumber;
	}

	public void setRefillNumber(long refillNumber) {
		this.refillNumber = refillNumber;
	}

	public long getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(long orderNumber) {
		this.orderNumber = orderNumber;
	}

	public long getShipmentNumber() {
		return shipmentNumber;
	}

	public void setShipmentNumber(long shipmentNumber) {
		this.shipmentNumber = shipmentNumber;
	}

	public long getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(long itemNumber) {
		this.itemNumber = itemNumber;
	}

	public long getQuantityDispensed() {
		return quantityDispensed;
	}

	public void setQuantityDispensed(long quantityDispensed) {
		this.quantityDispensed = quantityDispensed;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}
