package com.cvs.specialty.erp.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

@Component
@XmlRootElement(name = "item-status-lookup-response")
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemStatusDTO {
	private Long inventory_item_id;
	private Long organization_id;
	private String enabled_flag;
	private String inventory_item_status_code;
	private String mtl_system_items_ind;

	public Long getInventory_item_id() {
		return inventory_item_id;
	}

	public void setInventory_item_id(Long inventory_item_id) {
		this.inventory_item_id = inventory_item_id;
	}

	public Long getOrganization_id() {
		return organization_id;
	}

	public void setOrganization_id(Long organization_id) {
		this.organization_id = organization_id;
	}

	public String getEnabled_flag() {
		return enabled_flag;
	}

	public void setEnabled_flag(String enabled_flag) {
		this.enabled_flag = enabled_flag;
	}

	public String getInventory_item_status_code() {
		return inventory_item_status_code;
	}

	public void setInventory_item_status_code(String inventory_item_status_code) {
		this.inventory_item_status_code = inventory_item_status_code;
	}

	public String getMtl_system_items_ind() {
		return mtl_system_items_ind;
	}

	public void setMtl_system_items_ind(String mtl_system_items_ind) {
		this.mtl_system_items_ind = mtl_system_items_ind;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
