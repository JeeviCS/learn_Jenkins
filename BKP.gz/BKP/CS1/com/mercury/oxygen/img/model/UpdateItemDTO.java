package com.cvs.specialty.erp.model;

public class UpdateItemDTO {

	String itemNumber;
	String itemSrcCode;
	String itemName;
	String ndcnumber;

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getItemSrcCode() {
		return itemSrcCode;
	}

	public void setItemSrcCode(String itemSrcCode) {
		this.itemSrcCode = itemSrcCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getNdcnumber() {
		return ndcnumber;
	}

	public void setNdcnumber(String ndcnumber) {
		this.ndcnumber = ndcnumber;
	}

}
