package com.cvs.specialty.erp.model;

public class MckERPShipQueue {
	String processFlag;
	String transferInd;
	String errorExplanation;
	String packageName;
	String procedureName;
	String updateBySytem;
	long erpShipQueueId;
	long orderOdcDetailId;
	public String getProcessFlag() {
		return processFlag;
	}
	public void setProcessFlag(String processFlag) {
		this.processFlag = processFlag;
	}
	public String getTransferInd() {
		return transferInd;
	}
	public void setTransferInd(String transferInd) {
		this.transferInd = transferInd;
	}
	public String getErrorExplanation() {
		return errorExplanation;
	}
	public void setErrorExplanation(String errorExplanation) {
		this.errorExplanation = errorExplanation;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getProcedureName() {
		return procedureName;
	}
	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}
	public String getUpdateBySytem() {
		return updateBySytem;
	}
	public void setUpdateBySytem(String updateBySytem) {
		this.updateBySytem = updateBySytem;
	}
	public long getErpShipQueueId() {
		return erpShipQueueId;
	}
	public void setErpShipQueueId(long erpShipQueueId) {
		this.erpShipQueueId = erpShipQueueId;
	}
	public long getOrderOdcDetailId() {
		return orderOdcDetailId;
	}
	public void setOrderOdcDetailId(long orderOdcDetailId) {
		this.orderOdcDetailId = orderOdcDetailId;
	}
	
	
	

}
