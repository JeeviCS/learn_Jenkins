package com.cvs.specialty.erp.model;

public class MtlParameters {

	private Long siteId;
	private Long oraganizationId;

	public Long getSiteId() {
		return siteId;
	}

	public void setSiteId(Long siteId) {
		this.siteId = siteId;
	}

	public Long getOraganizationId() {
		return oraganizationId;
	}

	public void setOraganizationId(Long oraganizationId) {
		this.oraganizationId = oraganizationId;
	}
}
