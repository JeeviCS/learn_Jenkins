package com.cvs.specialty.erp.model;

public class ServiceRequest<T> {
	
	Long eventId;
	Long startingEventId;
	Long eventTypeId;
	String serviceRequestId;
	
	T body;

	public Long getStartingEventId() {
		return startingEventId;
	}
	public void setStartingEventId(Long startingEventId) {
		this.startingEventId = startingEventId;
	}
	public String getServiceRequestId() {
		return serviceRequestId;
	}
	public void setServiceRequestId(String serviceRequestId) {
		this.serviceRequestId = serviceRequestId;
	}

	public T getBody() {
		return body;
	}
	public void setBody(T body) {
		this.body = body;
	}
	public Long getEventTypeId() {
		return eventTypeId;
	}
	public void setEventTypeId(Long eventTypeId) {
		this.eventTypeId = eventTypeId;
	}
	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}
	
}
