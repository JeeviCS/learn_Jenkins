package com.cvs.specialty.erp.model;

public class UpdateErpItemDTO {

	UpdateItemDTO updateitemDTO;
	double marketPrice;
	String sysSrcCode;
	String itemNumber;
	

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getSysSrcCode() {
		return sysSrcCode;
	}

	public void setSysSrcCode(String sysSrcCode) {
		this.sysSrcCode = sysSrcCode;
	}

	public UpdateItemDTO getUpdateitemDTO() {
		return updateitemDTO;
	}

	public void setUpdateitemDTO(UpdateItemDTO updateitemDTO) {
		this.updateitemDTO = updateitemDTO;
	}

	public double getMarketPrice() {
		return marketPrice;
	}

	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}

}
