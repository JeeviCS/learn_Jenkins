package com.cvs.specialty.erp.model;

import java.sql.Date;

public class MtlTransactions {

	private String sourceCode;
	private Long sourceLineId;
	private Long sourceHeaderid;
	private Long processFlag;
	private Long transactionMode;
	private Long lockFlag;
	private String itemSegment2;
	private Long inventoryItemId;
	private Long organizationId;
	private String subinventoryCode;
	private Long transactionQuantity;
	private String transactionUom;
	private Date transactionDate;
	private Long transactionTypeId;
	private Long reasonId;
	private Long distributionAccountId;
	private Long attribute1;
	private Long attribute2;
	private Long attribute3;
	private Long attribute4;
	private Date lastUpdateDate;
	private Long lastUpdatedBy;
	private Date creationDate;
	private Long createdBy;

	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	public Long getSourceLineId() {
		return sourceLineId;
	}

	public void setSourceLineId(Long sourceLineId) {
		this.sourceLineId = sourceLineId;
	}

	public Long getSourceHeaderid() {
		return sourceHeaderid;
	}

	public void setSourceHeaderid(Long sourceHeaderid) {
		this.sourceHeaderid = sourceHeaderid;
	}

	public Long getProcessFlag() {
		return processFlag;
	}

	public void setProcessFlag(Long processFlag) {
		this.processFlag = processFlag;
	}

	public Long getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(Long transactionMode) {
		this.transactionMode = transactionMode;
	}

	public Long getLockFlag() {
		return lockFlag;
	}

	public void setLockFlag(Long lockFlag) {
		this.lockFlag = lockFlag;
	}

	public String getItemSegment2() {
		return itemSegment2;
	}

	public void setItemSegment2(String itemSegment2) {
		this.itemSegment2 = itemSegment2;
	}

	public Long getInventoryItemId() {
		return inventoryItemId;
	}

	public void setInventoryItemId(Long inventoryItemId) {
		this.inventoryItemId = inventoryItemId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getSubinventoryCode() {
		return subinventoryCode;
	}

	public void setSubinventoryCode(String subinventoryCode) {
		this.subinventoryCode = subinventoryCode;
	}

	public Long getTransactionQuantity() {
		return transactionQuantity;
	}

	public void setTransactionQuantity(Long transactionQuantity) {
		this.transactionQuantity = transactionQuantity;
	}

	public String getTransactionUom() {
		return transactionUom;
	}

	public void setTransactionUom(String transactionUom) {
		this.transactionUom = transactionUom;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Long getTransactionTypeId() {
		return transactionTypeId;
	}

	public void setTransactionTypeId(Long transactionTypeId) {
		this.transactionTypeId = transactionTypeId;
	}

	public Long getReasonId() {
		return reasonId;
	}

	public void setReasonId(Long reasonId) {
		this.reasonId = reasonId;
	}

	public Long getDistributionAccountId() {
		return distributionAccountId;
	}

	public void setDistributionAccountId(Long distributionAccountId) {
		this.distributionAccountId = distributionAccountId;
	}

	public Long getAttribute1() {
		return attribute1;
	}

	public void setAttribute1(Long attribute1) {
		this.attribute1 = attribute1;
	}

	public Long getAttribute2() {
		return attribute2;
	}

	public void setAttribute2(Long attribute2) {
		this.attribute2 = attribute2;
	}

	public Long getAttribute3() {
		return attribute3;
	}

	public void setAttribute3(Long attribute3) {
		this.attribute3 = attribute3;
	}

	public Long getAttribute4() {
		return attribute4;
	}

	public void setAttribute4(Long attribute4) {
		this.attribute4 = attribute4;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(Long userId) {
		this.lastUpdatedBy = userId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

}
