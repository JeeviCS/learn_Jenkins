package com.cvs.specialty.erp.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "scandata-request")
@XmlAccessorType(XmlAccessType.FIELD)
public class ScandataRequest {

	@XmlElement(name = "p-string-in")
	String pStringIn;

	@XmlElement(name = "p-calling-user-in")
	String pcallingUserIn;

	@XmlElement(name = "p-calling-process-in")
	String pcallingProcessIn;

	public String getpStringIn() {
		return pStringIn;
	}

	public void setpStringIn(String pStringIn) {
		this.pStringIn = pStringIn;
	}

	public String getPcallingUserIn() {
		return pcallingUserIn;
	}

	public void setPcallingUserIn(String pcallingUserIn) {
		this.pcallingUserIn = pcallingUserIn;
	}

	public String getPcallingProcessIn() {
		return pcallingProcessIn;
	}

	public void setPcallingProcessIn(String pcallingProcessIn) {
		this.pcallingProcessIn = pcallingProcessIn;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub

		final int prime = 31;
		int result = 1;
		result = prime * result + ((pStringIn == null) ? 0 : pStringIn.hashCode());
		result = prime * result + ((pcallingUserIn == null) ? 0 : pcallingUserIn.hashCode());
		result = prime * result + ((pcallingProcessIn == null) ? 0 : pcallingProcessIn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		ScandataRequest other = (ScandataRequest) obj;

		if (pStringIn == null) {
			if (other.pStringIn != null)
				return false;
		} else if (!pStringIn.equals(other.pStringIn))
			return false;

		if (pcallingUserIn == null) {
			if (other.pcallingUserIn != null)
				return false;
		} else if (!pcallingUserIn.equals(other.pcallingUserIn))
			return false;

		if (pcallingProcessIn == null) {
			if (other.pcallingProcessIn != null)
				return false;
		} else if (!pcallingProcessIn.equals(other.pcallingProcessIn))
			return false;
		return true;
	}

}
