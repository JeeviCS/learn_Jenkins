package com.cvs.specialty.erp.model;

public class CreateItemDTO {
	
	String transactionType;
	String itemNumber;
	String itemName;
	String ndcNo;
	String itemSrcCode;
	String systemSrcCode;
	public String getItemSrcCode() {
		return itemSrcCode;
	}
	public void setItemSrcCode(String itemSrcCode) {
		this.itemSrcCode = itemSrcCode;
	}
	public String getSystemSrcCode() {
		return systemSrcCode;
	}
	public void setSystemSrcCode(String systemSrcCode) {
		this.systemSrcCode = systemSrcCode;
	}
	float awpAmount;
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getNdcNo() {
		return ndcNo;
	}
	public void setNdcNo(String ndcNo) {
		this.ndcNo = ndcNo;
	}
	public float getAwpAmount() {
		return awpAmount;
	}
	public void setAwpAmount(float awpAmount) {
		this.awpAmount = awpAmount;
	}
	
	
	

}
