package com.cvs.specialty.erp.model;

import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "scandata-response")
@XmlAccessorType(XmlAccessType.FIELD)
public class ScandataResponse {

	@XmlElement(name = "p-string-out")
	String pStringOut;
	@XmlElement(name = "p-status-out")
	String pStatusOut;
	@XmlElement(name = "p-message-out")
	String pMessageOut;

	public String getpStringOut() {
		return pStringOut;
	}

	public void setpStringOut(String pStringOut) {
		this.pStringOut = pStringOut;
	}

	public String getpStatusOut() {
		return pStatusOut;
	}

	public void setpStatusOut(String pStatusOut) {
		this.pStatusOut = pStatusOut;
	}

	public String getpMessageOut() {
		return pMessageOut;
	}

	public void setpMessageOut(String pMessageOut) {
		this.pMessageOut = pMessageOut;
	}

	@SuppressWarnings("unused")
	private void beforeMarshal(Marshaller marshaller) {
        if(null == pStringOut) {
        	pStringOut = "";
        }
        
        if(null == pStatusOut) {
        	pStatusOut = "";
         }
        
        if(null == pMessageOut) {
        	pMessageOut = "";
        }
    }

    @SuppressWarnings("unused")
	private void afterMarshal(Marshaller marshaller) {
        if("".equals(pStringOut)) {
        	pStringOut = null;
        }
        
        if("".equals(pStatusOut)) {
        	pStatusOut = null;
        }
        
        if("".equals(pMessageOut)) {
        	pMessageOut = null;
        }
    }
}
