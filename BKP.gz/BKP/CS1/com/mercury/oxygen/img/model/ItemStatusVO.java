package com.cvs.specialty.erp.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "item-status-lookup-request")
@XmlAccessorType(XmlAccessType.FIELD)
public class ItemStatusVO {

	// @XmlElement(name = "charSiteCode")
	private String charSiteCode;
	// @XmlElement(name = "drugNo")
	private String drugNo;

	public String getCharSiteCode() {
		return charSiteCode;
	}

	public void setCharSiteCode(String charSiteCode) {
		this.charSiteCode = charSiteCode;
	}

	public String getDrugNo() {
		return drugNo;
	}

	public void setDrugNo(String drugNo) {
		this.drugNo = drugNo;
	}

}
