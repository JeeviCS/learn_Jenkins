package com.cvs.specialty.erp.model;

import org.springframework.stereotype.Component;

@Component
public class ImportShipmentTransactionsVO {
	private String orderStatus;
	private Long organizationId;
	private String subinventoryCode;
	private String transactionUom;
	private Long transactionTypeId;
	private Long transactionReasonId;
	private Long distributionAccountId;

	public ImportShipmentTransactionsVO(String orderStatus, String startDate, String endDate, Long organizationId,
			String subinventoryCode, String transactionUom, Long transactionTypeId, Long transactionReasonId,
			Long distributionAccountId) {
		super();
		this.orderStatus = orderStatus;
		this.organizationId = organizationId;
		this.subinventoryCode = subinventoryCode;
		this.transactionUom = transactionUom;
		this.transactionTypeId = transactionTypeId;
		this.transactionReasonId = transactionReasonId;
		this.distributionAccountId = distributionAccountId;
	}

	public ImportShipmentTransactionsVO() {
		super();
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getSubinventoryCode() {
		return subinventoryCode;
	}

	public void setSubinventoryCode(String subinventoryCode) {
		this.subinventoryCode = subinventoryCode;
	}

	public String getTransactionUom() {
		return transactionUom;
	}

	public void setTransactionUom(String transactionUom) {
		this.transactionUom = transactionUom;
	}

	public Long getTransactionTypeId() {
		return transactionTypeId;
	}

	public void setTransactionTypeId(Long transactionTypeId) {
		this.transactionTypeId = transactionTypeId;
	}

	public Long getTransactionReasonId() {
		return transactionReasonId;
	}

	public void setTransactionReasonId(Long transactionReasonId) {
		this.transactionReasonId = transactionReasonId;
	}

	public Long getDistributionAccountId() {
		return distributionAccountId;
	}

	public void setDistributionAccountId(Long distributionAccountId) {
		this.distributionAccountId = distributionAccountId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public boolean validateRequest() {
		boolean isValid = true;

		if (orderStatus == null || "".equals(orderStatus) || organizationId == null || "".equals(organizationId)
				|| subinventoryCode == null || "".equals(subinventoryCode) || transactionUom == null
				|| "".equals(transactionUom) || orderStatus == null || "".equals(orderStatus)
				|| transactionTypeId == null || "".equals(transactionTypeId) || distributionAccountId == null
				|| "".equals(distributionAccountId)) {
			isValid = false;
		}

		return isValid;
	}
}
