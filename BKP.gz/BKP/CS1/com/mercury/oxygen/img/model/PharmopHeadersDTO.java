package com.cvs.specialty.erp.model;

public  class PharmopHeadersDTO {


	
	
	long poHeaderId;
	String poNumber;
	long apothecaryVendorId;
	int storeNo;
	String buyer;
	String description;
	String status;
	java.sql.Date edidate;
	java.sql.Date cancelDate;
	String createBy;
	java.sql.Date createDate;
	String updateBy;
	java.sql.Date updateDate;
	String cancelReason;
	String processStatus;
	String userMessage;
	public long getPoHeaderId() {
		return poHeaderId;
	}
	public void setPoHeaderId(long poHeaderId) {
		this.poHeaderId = poHeaderId;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public long getApothecaryVendorId() {
		return apothecaryVendorId;
	}
	public void setApothecaryVendorId(long apothecaryVendorId) {
		this.apothecaryVendorId = apothecaryVendorId;
	}
	public int getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(int storeNo) {
		this.storeNo = storeNo;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public java.sql.Date getEdidate() {
		return edidate;
	}
	public void setEdidate(java.sql.Date edidate) {
		this.edidate = edidate;
	}
	public java.sql.Date getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(java.sql.Date cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public java.sql.Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(java.sql.Date createDate) {
		this.createDate = createDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public java.sql.Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(java.sql.Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	public String getUserMessage() {
		return userMessage;
	}
	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}
	
	
	
	
}
