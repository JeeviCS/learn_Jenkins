package com.cvs.specialty.erp.model;

public class CompTxnShipInterfaceDTO {
	
	long mckERPShipQueueId;
	long mckOrderOdcDetailId;
	long mckOrderHeaderId;
	String odcOrderNo;
	String odcSiOrderStatus;
	long companyId;
	long siteId;
	String odcIrc;
	String odcRxNumber;
	Double odcQuantityPickedNum;
	java.sql.Date odcTimeComplete;
	public long getMckERPShipQueueId() {
		return mckERPShipQueueId;
	}
	public void setMckERPShipQueueId(long mckERPShipQueueId) {
		this.mckERPShipQueueId = mckERPShipQueueId;
	}
	public long getMckOrderOdcDetailId() {
		return mckOrderOdcDetailId;
	}
	public void setMckOrderOdcDetailId(long mckOrderOdcDetailId) {
		this.mckOrderOdcDetailId = mckOrderOdcDetailId;
	}
	public long getMckOrderHeaderId() {
		return mckOrderHeaderId;
	}
	public void setMckOrderHeaderId(long mckOrderHeaderId) {
		this.mckOrderHeaderId = mckOrderHeaderId;
	}
	public String getOdcOrderNo() {
		return odcOrderNo;
	}
	public void setOdcOrderNo(String odcOrderNo) {
		this.odcOrderNo = odcOrderNo;
	}
	public String getOdcSiOrderStatus() {
		return odcSiOrderStatus;
	}
	public void setOdcSiOrderStatus(String odcSiOrderStatus) {
		this.odcSiOrderStatus = odcSiOrderStatus;
	}
	public long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}
	public long getSiteId() {
		return siteId;
	}
	public void setSiteId(long siteId) {
		this.siteId = siteId;
	}
	public String getOdcIrc() {
		return odcIrc;
	}
	public void setOdcIrc(String odcIrc) {
		this.odcIrc = odcIrc;
	}
	public String getOdcRxNumber() {
		return odcRxNumber;
	}
	public void setOdcRxNumber(String odcRxNumber) {
		this.odcRxNumber = odcRxNumber;
	}
	public Double getOdcQuantityPickedNum() {
		return odcQuantityPickedNum;
	}
	public void setOdcQuantityPickedNum(Double odcQuantityPickedNum) {
		this.odcQuantityPickedNum = odcQuantityPickedNum;
	}
	public java.sql.Date getOdcTimeComplete() {
		return odcTimeComplete;
	}
	public void setOdcTimeComplete(java.sql.Date odcTimeComplete) {
		this.odcTimeComplete = odcTimeComplete;
	}
	
	
	

}
