package com.cvs.specialty.erp.model;

import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Response {

	@SerializedName("validationResponse")
	@Expose
	private Map<String, String> validation;

	public Map<String, String> getValidation() {
		return validation;
	}

	public void setValidation(Map<String, String> validation) {
		this.validation = validation;
	}

	@Override
	public String toString() {
		return "Response [validation=" + validation + "]";
	}
	
	
	
}
