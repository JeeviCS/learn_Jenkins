package com.cvs.specialty.erp.model;

public class CompTxnTypeFromERPDTO {

	int organizationId;
	String subInventoryCode;
	long txnTypeId;
	int reasonId;
	long distributionAccountId;

	String uomCode;
	java.sql.Date inactiveDate;
	String EnabledFlag;

	public int getOrganizationId() {
		return organizationId;
	}
	public long getDistributionAccountId() {
		return distributionAccountId;
	}

	public void setDistributionAccountId(long distributionAccountId) {
		this.distributionAccountId = distributionAccountId;
	}

	public void setOrganizationId(int organizationId) {
		this.organizationId = organizationId;
	}

	public String getSubInventoryCode() {
		return subInventoryCode;
	}

	public void setSubInventoryCode(String subInventoryCode) {
		this.subInventoryCode = subInventoryCode;
	}

	public long getTxnTypeId() {
		return txnTypeId;
	}

	public void setTxnTypeId(long txnTypeId) {
		this.txnTypeId = txnTypeId;
	}

	public int getReasonId() {
		return reasonId;
	}

	public void setReasonId(int reasonId) {
		this.reasonId = reasonId;
	}



	public String getUomCode() {
		return uomCode;
	}

	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}

	public java.sql.Date getInactiveDate() {
		return inactiveDate;
	}

	public void setInactiveDate(java.sql.Date inactiveDate) {
		this.inactiveDate = inactiveDate;
	}

	public String getEnabledFlag() {
		return EnabledFlag;
	}

	public void setEnabledFlag(String enabledFlag) {
		EnabledFlag = enabledFlag;
	}

}
