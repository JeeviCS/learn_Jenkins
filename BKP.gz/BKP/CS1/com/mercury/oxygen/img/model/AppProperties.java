package com.cvs.specialty.erp.model;

import java.util.EnumMap;


public class AppProperties {
	
	private EnumMap<AppPropertyKey, Object> propertyMap;

	public EnumMap<AppPropertyKey, Object> getPropertyMap() {
		return propertyMap;
	}

	public void setPropertyMap(EnumMap<AppPropertyKey, Object> propertyMap) {
		this.propertyMap = propertyMap;
	}
}
