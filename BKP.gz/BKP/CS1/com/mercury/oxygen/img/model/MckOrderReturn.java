package com.cvs.specialty.erp.model;

import java.sql.Date;

public class MckOrderReturn {

	private int mckOrderReturnId;
	private int companyTxnsIfaceId;
	private Long transactionId;
	private Date transactionDate;
	private String transactionTypeName;
	private String transactionReasonName;
	private int siteId;
	private String orderNumber;
	private String rxNumber;
	private String itemNumber;
	private String ndc;
	private String itemDescription;
	private int transactionQuantity;
	private String transactionUom;
	private int orderByCompanyId;
	private String createBy;
	private Date createDate;
	private String updateBy;
	private Date updateDate;
	private String createBySystem;
	private String createByProcessFunction;
	private String updateBySystem;
	private String updateByProcessFunction;
	private String transactionReference;

	public int getMckOrderReturnId() {
		return mckOrderReturnId;
	}

	public void setMckOrderReturnId(int mckOrderReturnId) {
		this.mckOrderReturnId = mckOrderReturnId;
	}

	public int getCompanyTxnsIfaceId() {
		return companyTxnsIfaceId;
	}

	public void setCompanyTxnsIfaceId(int companyTxnsIfaceId) {
		this.companyTxnsIfaceId = companyTxnsIfaceId;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionTypeName() {
		return transactionTypeName;
	}

	public void setTransactionTypeName(String transactionTypeName) {
		this.transactionTypeName = transactionTypeName;
	}

	public String getTransactionReasonName() {
		return transactionReasonName;
	}

	public void setTransactionReasonName(String transactionReasonName) {
		this.transactionReasonName = transactionReasonName;
	}

	public int getSiteId() {
		return siteId;
	}

	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getRxNumber() {
		return rxNumber;
	}

	public void setRxNumber(String rxNumber) {
		this.rxNumber = rxNumber;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getNdc() {
		return ndc;
	}

	public void setNdc(String ndc) {
		this.ndc = ndc;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public int getTransactionQuantity() {
		return transactionQuantity;
	}

	public void setTransactionQuantity(int transactionQuantity) {
		this.transactionQuantity = transactionQuantity;
	}

	public String getTransactionUom() {
		return transactionUom;
	}

	public void setTransactionUom(String transactionUom) {
		this.transactionUom = transactionUom;
	}

	public int getOrderByCompanyId() {
		return orderByCompanyId;
	}

	public void setOrderByCompanyId(int orderByCompanyId) {
		this.orderByCompanyId = orderByCompanyId;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getCreateBySystem() {
		return createBySystem;
	}

	public void setCreateBySystem(String createBySystem) {
		this.createBySystem = createBySystem;
	}

	public String getCreateByProcessFunction() {
		return createByProcessFunction;
	}

	public void setCreateByProcessFunction(String createByProcessFunction) {
		this.createByProcessFunction = createByProcessFunction;
	}

	public String getUpdateBySystem() {
		return updateBySystem;
	}

	public void setUpdateBySystem(String updateBySystem) {
		this.updateBySystem = updateBySystem;
	}

	public String getUpdateByProcessFunction() {
		return updateByProcessFunction;
	}

	public void setUpdateByProcessFunction(String updateByProcessFunction) {
		this.updateByProcessFunction = updateByProcessFunction;
	}

	public String getTransactionReference() {
		return transactionReference;
	}

	public void setTransactionReference(String transactionReference) {
		this.transactionReference = transactionReference;
	}

}
