package com.cvs.specialty.erp.model;

public class PharmopLinesDTO {


	
	
	long poLineId;
	long lineNumber;
	long poHeaderId;
	long itemId;
	long quantity;
	String mfgAuthorizationNo;
	String createBy;
	java.sql.Date createDate;
	String updateBy;
	java.sql.Date updateDate;
	String erpReceiptInd;
	java.sql.Date erpProcessDate;
	double unitPrice;
	
	public long getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(long lineNumber) {
		this.lineNumber = lineNumber;
	}
	
	public long getPoLineId() {
		return poLineId;
	}
	public void setPoLineId(long poLineId) {
		this.poLineId = poLineId;
	}
	public long getPoHeaderId() {
		return poHeaderId;
	}
	public void setPoHeaderId(long poHeaderId) {
		this.poHeaderId = poHeaderId;
	}
	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public String getMfgAuthorizationNo() {
		return mfgAuthorizationNo;
	}
	public void setMfgAuthorizationNo(String mfgAuthorizationNo) {
		this.mfgAuthorizationNo = mfgAuthorizationNo;
	}
	public String getCreateBy() {
		return createBy;
	}
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	public java.sql.Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(java.sql.Date createDate) {
		this.createDate = createDate;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public java.sql.Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(java.sql.Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getErpReceiptInd() {
		return erpReceiptInd;
	}
	public void setErpReceiptInd(String erpReceiptInd) {
		this.erpReceiptInd = erpReceiptInd;
	}
	public java.sql.Date getErpProcessDate() {
		return erpProcessDate;
	}
	public void setErpProcessDate(java.sql.Date erpProcessDate) {
		this.erpProcessDate = erpProcessDate;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	
	
	
	
}
