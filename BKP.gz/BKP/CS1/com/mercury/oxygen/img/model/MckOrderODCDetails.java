package com.cvs.specialty.erp.model;

public class MckOrderODCDetails {
	
	String transferInd;
	String packageName;
	String procedureName;
	long orderOdcDetailId;
	long orderHeaderId;
	public String getTransferInd() {
		return transferInd;
	}
	public void setTransferInd(String transferInd) {
		this.transferInd = transferInd;
	}

	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getProcedureName() {
		return procedureName;
	}
	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}
	public long getOrderOdcDetailId() {
		return orderOdcDetailId;
	}
	public void setOrderOdcDetailId(long orderOdcDetailId) {
		this.orderOdcDetailId = orderOdcDetailId;
	}
	public long getOrderHeaderId() {
		return orderHeaderId;
	}
	public void setOrderHeaderId(long orderHeaderId) {
		this.orderHeaderId = orderHeaderId;
	}
	

}
