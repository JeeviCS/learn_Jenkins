package com.cvs.specialty.erp.model;

import java.util.HashMap;
import java.util.Map;

public class ServiceResponse<T> {

	T body;
	Map<String, Object> responseHeaders;
	
	public T getBody() {
		return body;
	}
	public void setBody(T body) {
		this.body = body;
	}
	public Map<String, Object> getResponseHeaders() {
		if (responseHeaders == null) {
			responseHeaders = new HashMap<String, Object>();
		}
		return responseHeaders;
	}
	public void setResponseHeaders(Map<String, Object> responseHeaders) {
		this.responseHeaders = responseHeaders;
	}
}
