package com.cvs.specialty.erp.model;

public class TransactionInterface {
	
	long sourceLineId;
	long  sourceHeaderId;
	String itemSegment2;
	long organizationId;
	String subInventoryCode;
	Double txnQuantity;
	String txnUOM;
	java.sql.Date txnDate;
	long txnTypeId;
	long reasonId;
	long distAccountId;
	String attribute1;
	String attribute2;
	String attribute5;
	int lastUpdateBy;
	int createBy;
	public long getSourceLineId() {
		return sourceLineId;
	}
	public void setSourceLineId(long sourceLineId) {
		this.sourceLineId = sourceLineId;
	}
	public long getSourceHeaderId() {
		return sourceHeaderId;
	}
	public void setSourceHeaderId(long sourceHeaderId) {
		this.sourceHeaderId = sourceHeaderId;
	}
	public String getItemSegment2() {
		return itemSegment2;
	}
	public void setItemSegment2(String itemSegment2) {
		this.itemSegment2 = itemSegment2;
	}
	
	public Double getTxnQuantity() {
		return txnQuantity;
	}
	public void setTxnQuantity(Double txnQuantity) {
		this.txnQuantity = txnQuantity;
	}
	public long getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(long organizationId) {
		this.organizationId = organizationId;
	}
	public String getSubInventoryCode() {
		return subInventoryCode;
	}
	public void setSubInventoryCode(String subInventoryCode) {
		this.subInventoryCode = subInventoryCode;
	}

	public String getTxnUOM() {
		return txnUOM;
	}
	public void setTxnUOM(String txnUOM) {
		this.txnUOM = txnUOM;
	}
	public java.sql.Date getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(java.sql.Date txnDate) {
		this.txnDate = txnDate;
	}
	public long getTxnTypeId() {
		return txnTypeId;
	}
	public void setTxnTypeId(long txnTypeId) {
		this.txnTypeId = txnTypeId;
	}
	public long getReasonId() {
		return reasonId;
	}
	public void setReasonId(long reasonId) {
		this.reasonId = reasonId;
	}
	public long getDistAccountId() {
		return distAccountId;
	}
	public void setDistAccountId(long distAccountId) {
		this.distAccountId = distAccountId;
	}
	public String getAttribute1() {
		return attribute1;
	}
	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}
	public String getAttribute2() {
		return attribute2;
	}
	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}
	public String getAttribute5() {
		return attribute5;
	}
	public void setAttribute5(String attribute5) {
		this.attribute5 = attribute5;
	}
	public int getLastUpdateBy() {
		return lastUpdateBy;
	}
	public void setLastUpdateBy(int lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}
	public int getCreateBy() {
		return createBy;
	}
	public void setCreateBy(int createBy) {
		this.createBy = createBy;
	}
	
	
	
	

}
