package com.cvs.specialty.erp.model;

public class ProcessParametersDTO {

	
	String name;
	String textValue;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTextValue() {
		return textValue;
	}
	public void setTextValue(String textValue) {
		this.textValue = textValue;
	}
	
	
}
