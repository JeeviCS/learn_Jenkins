package com.cvs.specialty.erp.api.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cvs.specialty.erp.api.FileTransferAPI;
import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.service.FileTransferService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.cvs.specialty.erp.utils.Utilities;
import com.cvshealth.specialty.spil.monitor.TransactionMonitorUtil;

@Controller
public class FileTransferController implements FileTransferAPI {
	private static Logger LOG = Logger.getLogger(FileTransferController.class);
	ResponseEntity<String> responseEntity = null;
	@Autowired
	FileTransferService fileTransferService;

	@RequestMapping(value = "/transferFiles", method = RequestMethod.POST, produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String transferFiles(@RequestParam(value = "processName", required = true) String processName) {

		LOG.info("Service Method Entry: spilERPServiceFileTransfer ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = "Error Occurred While Moving Files";

		try {
			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.FILE_TRANSFER_SERVICE_ACTIVE))) {

				responseEntity = fileTransferService.startFileTransfer(processName);
				if (responseEntity != null) {
					responseMessage = responseEntity.getBody();
				} else {
					responseMessage = "Bad Request";
				}
				if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
					errorStatus = true;
				}
				if (responseEntity != null && responseEntity.getBody() != null) {
					responseMessage = responseEntity.getBody();
				}
			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);
				responseMessage = responseEntity.getBody();
			}
		} catch (Exception e) {
			LOG.error("Exception in spilERPFileTransferServiceItem: " + e);
			errorStatus=true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);  
		}
		LOG.info("Service Method Exit: spilERPFileTransferServiceItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPFileTransferService", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return Utilities.sanitizeResponse(responseMessage);
	}
}
