package com.cvs.specialty.erp.api;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

public interface TLSAPI {

	@RequestMapping(value = "/item", method = RequestMethod.POST, produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE,MediaType.TEXT_HTML_VALUE })
	@ResponseBody
	public String createOrUpdateitem(
			@RequestParam(value = "pTemplateId", required = false) String pTemplateId,
			@RequestHeader(value = "username", required = true) String userId, HttpServletRequest request);

	@RequestMapping(value = "/importTransactions", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String importTransactions(
			@RequestParam(value = "pCompanyId", required = false) String pCompanyId,
			@RequestParam(value = "pSiteId", required = false) String pSiteId,
			@RequestHeader(value = "username", required = true) String userId, HttpServletRequest request);

	@RequestMapping(value = "/scandata", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String scandataInterface(
			@RequestBody(required = true) String scandataInput,
			@RequestHeader(value = "username", required = true) String userId, HttpServletRequest request);
	
	@RequestMapping(value = "/hbsPurchaseOrder", method = RequestMethod.POST, 
			produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String hbsPurchaseOrder(
			@RequestHeader(value = "username", required = true) String username, HttpServletRequest request);
	
}
 