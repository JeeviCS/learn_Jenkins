package com.cvs.specialty.erp.api.impl;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.cvs.specialty.erp.api.TLSAPI;
import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.model.ScandataRequest;
import com.cvs.specialty.erp.model.ScandataResponse;
import com.cvs.specialty.erp.model.ServiceRequest;
import com.cvs.specialty.erp.model.ServiceResponse;
import com.cvs.specialty.erp.service.FileTransferService;
/*import com.cvs.specialty.erp.service.FileTransferService;*/
import com.cvs.specialty.erp.service.HBSPurchaseOrderService;
import com.cvs.specialty.erp.service.ImportTransactionsService;
import com.cvs.specialty.erp.service.ItemService;
import com.cvs.specialty.erp.service.ScandataService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.cvs.specialty.erp.utils.Utilities;
import com.cvs.specialty.erp.utils.XmlDeserializer;
import com.cvs.specialty.erp.utils.XmlSerializer;
import com.cvshealth.specialty.spil.monitor.TransactionMonitorUtil;

@Controller
public class TLSAPIController implements TLSAPI {
	private static Logger LOG = Logger.getLogger(TLSAPIController.class);
	@Autowired
	ItemService itemService;

	@Autowired
	ImportTransactionsService importTxnService;

	@Autowired
	ScandataService scandataService;

	@Autowired
	HBSPurchaseOrderService hbsPurchaseOrderService;

	@Autowired
	FileTransferService fileTransferService;

	@RequestMapping(value = "/item", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.TEXT_HTML_VALUE })
	@ResponseBody
	public String createOrUpdateitem(@RequestParam(value = "pTemplateId", required = false) String pTemplateId,
			@RequestHeader(value = "username", required = true) String userName, HttpServletRequest request) {

		LOG.info("Service Method Entry: spilERPServiceItem");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseSupport = "<error>There was an internal error</error>";
		ResponseEntity<String> responseEntity = null;

		try {
			if (request.getParameterMap().isEmpty()) {
				// call update Item process

				if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.UPDATE_ITEM_ACTIVE))) {

					responseEntity = itemService.updateItem(userName);
				} else {
					responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);
				}
			} else if (request.getParameterMap().containsKey("pTemplateId") && !pTemplateId.isEmpty()
					&& pTemplateId != null) {
				// call create Item process

				if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.CREATE_ITEM_ACTIVE))) {

					responseEntity = itemService.createItem(pTemplateId, userName);
				} else {
					responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);
				}
			} else {
				responseEntity = new ResponseEntity<String>(Constants.INVALID_REQUEST, HttpStatus.BAD_REQUEST);
			}
			if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
				errorStatus = true;
			}
			if (responseEntity != null && responseEntity.getBody() != null) {
				responseSupport = responseEntity.getBody();
			}
		} catch (Exception e) {
			LOG.error("Exception in spilERPServiceItem: " + e);
			errorStatus = true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOG.info("Service Method Exit: spilERPServiceItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPServiceItem", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return Utilities.sanitizeResponse(responseSupport);

	}

	@Override
	@RequestMapping(value = "/importTransactions", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String importTransactions(String pCompanyId, String pSiteId,
			@RequestHeader(value = "username", required = true) String username, HttpServletRequest request) {
		// TODO Auto-generated method stub

		LOG.info("Service Method Entry: spilERPImportTransactions ");
		String companyId = null;
		String siteId = null;

		String responseSupport = "<error>There was an internal error</error>";
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		ResponseEntity<String> responseEntity = null;

		try {
			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.IMPORT_COMP_SHIP_TXNS_ACTIVE))) {

				if (request.getParameterMap().containsKey("pCompanyId") && pCompanyId != "") {

					companyId = pCompanyId;
				}

				if (request.getParameterMap().containsKey("pSiteId") && pSiteId != "") {

					siteId = pSiteId;
				}

				responseEntity = importTxnService.importTransactions(companyId, siteId, username);

				if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
					errorStatus = true;
				} else if (responseEntity != null && responseEntity.getBody() != null) {
					responseSupport = responseEntity.getBody();
				} else {
					responseEntity = new ResponseEntity<String>("Bad Request", HttpStatus.BAD_REQUEST);
					responseSupport = responseEntity.getBody();
				}
			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);
				responseSupport = responseEntity.getBody();
			}
		} catch (Exception e) {
			LOG.error("Exception in spilERPImportTransactions: " + e);
			errorStatus = true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		LOG.info("Service Method Exit: spilERPImportTransactions  - " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPImportTransactions", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return responseSupport;
	}

	@Override
	@RequestMapping(value = "/scandata", method = RequestMethod.POST, produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String scandataInterface(@RequestBody(required = true) String scandataInput,
			@RequestHeader(value = "username", required = true) String userId, HttpServletRequest request) {
		// TODO Auto-generated method stub

		LOG.info("Service Method Entry: spilERPScanDataInterface");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseSupport = "<error>There was an internal error</error>";
		ResponseEntity<String> responseEntity = null;
		ServiceResponse<ScandataResponse> response = null;
		ServiceRequest<ScandataRequest> httpRequest = new ServiceRequest<ScandataRequest>();

		try {
			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.SCAN_DATA_API_ACTIVE))) {

				if (!scandataInput.isEmpty()) {
					ScandataRequest sdr = XmlDeserializer.xmlDeserializer(scandataInput);
					httpRequest.setBody(sdr);

					response = scandataService.callScandataIfc(httpRequest);

					if (response != null) {
						responseEntity = new ResponseEntity<String>(XmlSerializer.xmlSerializer(response.getBody()),
								HttpStatus.OK);

					} else {
						responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);
						responseSupport = responseEntity.getBody();
					}
				} else {
					responseEntity = new ResponseEntity<String>("Bad Request ", HttpStatus.BAD_REQUEST);
					responseSupport = responseEntity.getBody();
				}
			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);

			}
		} catch (Exception e) {
			LOG.error("Exception in spilERPScanDataInterface: " + e);
			errorStatus = true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);

		}

		if (responseEntity != null && responseEntity.getBody() != null) {
			LOG.info("Response XML is: " + Utilities.sanitizeData(responseEntity.getBody()));
			responseSupport = responseEntity.getBody();
		}

		LOG.info("Service Method Exit: spilERPScanDataInterface  - " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPScanDataInterface", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return responseSupport;

	}

	@Override
	@RequestMapping(value = "/hbsPurchaseOrder", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String hbsPurchaseOrder(@RequestHeader(value = "username", required = true) String username,
			HttpServletRequest request) {

		LOG.info("Service Method Entry: spilERP_HBSPurchaseOrder ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseSupport = "<error>There was an internal error</error>";
		ResponseEntity<String> responseEntity = null;

		try {
			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.HBS_PURCHASE_ORDER_ACTIVE))) {

				responseEntity = hbsPurchaseOrderService.processhbsPurchaseOrderScreen(username);
			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);

			}
		} catch (Exception e) {
			LOG.error("Exception in spilERP_HBSPurchaseOrder: " + e);
			errorStatus = true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (responseEntity != null && responseEntity.getBody() != null) {
			responseSupport = responseEntity.getBody();
		}

		LOG.info("Service Method Exit: spilERP_HBSPurchaseOrder  - " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERP_HBSPurchaseOrder", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return Utilities.sanitizeResponse(responseSupport);
	}

}
