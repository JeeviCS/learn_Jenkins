package com.cvs.specialty.erp.api.impl;

import java.io.StringReader;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import com.cvs.specialty.erp.api.ItemStatusLookUpController;
import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.model.ItemStatusVO;
import com.cvs.specialty.erp.model.ScandataRequest;
import com.cvs.specialty.erp.service.ItemService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.cvs.specialty.erp.utils.Utilities;
import com.cvshealth.specialty.spil.monitor.TransactionMonitorUtil;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

@Controller
public class ItemStatusLookUpControllerImpl implements ItemStatusLookUpController {
	private static final Logger LOGGER = Logger.getLogger(ItemStatusLookUpController.class);

	@Autowired
	ItemService itemService;

	@RequestMapping(value = "/itemActiveStatusLookup", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }, consumes = {
					MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Override
	public String handleItemStatusLookUp(HttpServletRequest request, @RequestBody String srcSiteNDrugNo) {

		LOGGER.info("Service Method Entry: spilActiveItemStatusLookup ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		ResponseEntity<String> responseEntity = null;
		String responseSupport = "<error>There was an internal error</error>";
		String contentType = request.getContentType();
		try {
			ItemStatusVO itemStatusVO = convertInputToVo(srcSiteNDrugNo, contentType);

			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.ACTIVE_ITEM_STATUS_LOOKUP_ACTIVE))) {
				if (itemStatusVO != null) {
					responseEntity = itemService.getItemStatus(itemStatusVO.getCharSiteCode(), itemStatusVO.getDrugNo(),
							contentType);

					if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
						errorStatus = true;
					} else if (responseEntity != null && responseEntity.getBody() != null) {
						responseSupport = responseEntity.getBody();
					}
				} else {
					responseEntity = new ResponseEntity<String>("Bad Request", HttpStatus.BAD_REQUEST);
					responseSupport = responseEntity.getBody();
				}

			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception in spilERspilActiveItemStatusLookupPServiceItem: " + e);
			errorStatus = true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LOGGER.info("Service Method Exit: spilERPServiceItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERspilActiveItemStatusLookupPServiceItem",
				errorStatus, (System.currentTimeMillis() - startTimeMillis), 2000);

		return Utilities.sanitizeResponse(responseSupport);
	}

	private ItemStatusVO convertInputToVo(String srcSiteNDrugNo, String contentType) {
		ItemStatusVO itemStatusVO = null;
		if (contentType.equals(MediaType.APPLICATION_JSON_VALUE)) {
			try {
				itemStatusVO = new Gson().fromJson(srcSiteNDrugNo, ItemStatusVO.class);
			} catch (JsonSyntaxException jse) {
				LOGGER.error("exception occured while marshelling input request:", jse);
			}
		} else if (contentType.equals(MediaType.APPLICATION_XML_VALUE)) {

			// XML and Java binding
			try {
				SAXParserFactory spf = SAXParserFactory.newInstance();
				spf.setFeature("http://xml.org/sax/features/external-general-entities", false);
				spf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
				spf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

				Source xmlSource = new SAXSource(spf.newSAXParser().getXMLReader(),
						new InputSource(new StringReader(srcSiteNDrugNo)));
				JAXBContext jaxbContext = JAXBContext.newInstance(ItemStatusVO.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				itemStatusVO = (ItemStatusVO) jaxbUnmarshaller.unmarshal(xmlSource);
			} catch (JAXBException | ParserConfigurationException | SAXException e) {
				LOGGER.error("exception occured while marshelling input request:", e);
			}

		}
		return itemStatusVO;
	}

}
