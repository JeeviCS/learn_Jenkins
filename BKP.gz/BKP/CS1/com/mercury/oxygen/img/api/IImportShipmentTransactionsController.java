package com.cvs.specialty.erp.api;

/**
 * @author Z238847
 *
 */

public interface IImportShipmentTransactionsController {

	/**
	 * 
	 * @param username
	 * @param srcImportShipmentTransaction
	 * @return
	 * @throws Exception
	 */
	String handleImportSparcsShipmentTransactions(String username, String srcImportShipmentTransaction,String siteName)
			throws Exception;

	/**
	 * 
	 * @param username
	 * @param srcImportShipmentTransaction
	 * @return
	 * @throws Exception
	 */

	String handleImportHBSSiteShipmentTransactions(String username, String srcImportShipmentTransaction,String siteName)
			throws Exception;

}
