package com.cvs.specialty.erp.api.impl;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;

/**
 * Custom request factory to trust certificates from the service
 *
 */
@Component
public class CustomClientRequestFactory extends SimpleClientHttpRequestFactory {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CustomClientRequestFactory.class);

	@Autowired
	private HostnameVerifier verifier;

	/**
	 * Method prepareConnection.
	 * @param connection HttpURLConnection
	 * @param httpMethod String
	
	 * @throws IOException */
	@Override
	protected void prepareConnection(HttpURLConnection connection,
			String httpMethod) throws IOException {

		// Security.setProperty("jdk.tls.disabledAlgorithms", "");

		if (connection instanceof HttpsURLConnection) {
			((HttpsURLConnection) connection).setHostnameVerifier(verifier);
			((HttpsURLConnection) connection)
					.setSSLSocketFactory(trustSelfSignedSSL()
							.getSocketFactory());
			((HttpsURLConnection) connection).setAllowUserInteraction(true);
		}

		super.prepareConnection(connection, httpMethod);
	}

	/**
	 * Method trustSelfSignedSSL.
	
	 * @return SSLContext */
	private SSLContext trustSelfSignedSSL() {
		SSLContext ctx = null;

		try {
			ctx = SSLContext.getInstance("TLS");
			X509TrustManager tm = new X509TrustManager() {

				public void checkClientTrusted(X509Certificate[] xcs,
						String string) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] xcs,
						String string) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			SSLContext.setDefault(ctx);
		} catch (Exception ex) {
			LOGGER.error("Exception while creating SSL context", ex);
		}
		return ctx;

	}

}
