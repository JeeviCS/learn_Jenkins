package com.cvs.specialty.erp.api.impl;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.springframework.stereotype.Component;

/**
 * Custom HostName verifier to return always true
 *
 */
@Component
public class NullHostnameVerifier implements HostnameVerifier {

	/**
	 * Method verify.
	 * @param hostname String
	 * @param session SSLSession
	
	
	
	
	 * @return boolean * @see javax.net.ssl.HostnameVerifier#verify(String, SSLSession) * @see javax.net.ssl.HostnameVerifier#verify(String, SSLSession) * @see javax.net.ssl.HostnameVerifier#verify(String, SSLSession) * @see javax.net.ssl.HostnameVerifier#verify(String, SSLSession)
	 */
	public boolean verify(String hostname, SSLSession session) {
		return true;
	}

}
