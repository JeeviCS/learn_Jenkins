package com.cvs.specialty.erp.api.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cvs.specialty.erp.api.IExportCompanyReturnTransactionsController;
import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.service.ExportCompanyReturnTransactionsService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.cvshealth.specialty.spil.monitor.TransactionMonitorUtil;

/**
 * @author Z238847
 *
 */
@Controller
public class ExportCompanyReturnTransactionsController implements IExportCompanyReturnTransactionsController {
	private static final Logger LOGGER = Logger.getLogger(ExportCompanyReturnTransactionsController.class);
	private ExportCompanyReturnTransactionsService exportCompanyReturnTransactionsService;
	ResponseEntity<String> responseEntity = null;
	String responseMessage = "";
	int successCode = 0;
	int errorCode = 2;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cvs.specialty.tls.api.IExportCompanyReturnTransactionsController#
	 * handleExportCompanyReturnTransactions()
	 */
	@RequestMapping(value = "/exportCompanyReturnTransaction", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Override
	public String handleExportCompanyReturnTransactions(
			@RequestHeader(value = "username", required = true) String username) {

		LOGGER.info("Service Method Entry: spilERPhandleExportCompReturnTxns ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseSupport = "<error>There was an internal error</error>";
		try {
			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.EXPORT_COMP_RETURN_TXNS_ACTIVE))) {

				responseEntity = exportCompanyReturnTransactionsService
						.exportCompanyReturnTransactionsService(username);

				if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
					errorStatus = true;
				}
				if (responseEntity != null && responseEntity.getBody() != null) {
					responseSupport = responseEntity.getBody();
				}
			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception in spilERPhandleExportCompReturnTxns: " + e);
			errorStatus=true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);  
		}
		LOGGER.info("Service Method Exit: spilERPhandleExportCompReturnTxns  - " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPhandleExportCompReturnTxns", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return responseSupport;
	}

	/**
	 * 
	 * @param exportCompanyReturnTransactionsService
	 */
	@Autowired
	public void setExportCompanyReturnTransactionsService(
			ExportCompanyReturnTransactionsService exportCompanyReturnTransactionsService) {
		this.exportCompanyReturnTransactionsService = exportCompanyReturnTransactionsService;
	}
}
