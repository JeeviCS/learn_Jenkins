package com.cvs.specialty.erp.api.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cvs.specialty.erp.api.IImportShipmentTransactionsController;
import com.cvs.specialty.erp.model.AppPropertyKey;
import com.cvs.specialty.erp.model.ImportShipmentTransactionsVO;
import com.cvs.specialty.erp.service.ImportSparcsShipmentTransactionsService;
import com.cvs.specialty.erp.utils.Constants;
import com.cvs.specialty.erp.utils.PropertiesUtil;
import com.cvs.specialty.erp.utils.Utilities;
import com.cvshealth.specialty.spil.monitor.TransactionMonitorUtil;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

/**
 * @author Z238847
 *
 */
@Controller
public class ImportShipmentTransactionsController implements IImportShipmentTransactionsController {
	private static final Logger LOGGER = Logger.getLogger(ImportShipmentTransactionsController.class);
	private ImportSparcsShipmentTransactionsService importSparcsShipmentTransactionsService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.cvs.specialty.tls.api.IImportSparcsShipmentTransactionsController#
	 * handleImportSparcsShipmentTransactions()
	 */
	@RequestMapping(value = "/importSparcsShipmentTransactions", method = RequestMethod.POST, produces = {
			MediaType.TEXT_HTML_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Override
	public String handleImportSparcsShipmentTransactions(
			@RequestHeader(value = "username", required = true) String username,
			@RequestBody String srcImportShipmentTransaction,
			@RequestParam(value = "sitename", required = true) String siteName) throws Exception {

		LOGGER.info("Service Method Entry: spilERPhandleImportSPARCSShipTxns ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		boolean isValidRequest = false;
		String sanData = null;
		ResponseEntity<String> responseEntity = null;
		String responseSupport = "<error>There was an internal error</error>";
		LOGGER.info("handleImportSparcsShipmentTransactions Method Entry");
		sanData = Utilities.sanitizeJsonRequest(srcImportShipmentTransaction);
		ImportShipmentTransactionsVO importShipmentTransactionsVO = null;
		try {
			if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.IMPORT_SPARCS_SHIP_TXNS_ACTIVE))) {
				try {
					importShipmentTransactionsVO = new Gson().fromJson(sanData, ImportShipmentTransactionsVO.class);
				} catch (JsonSyntaxException jse) {
					LOGGER.error("exception occured while marshelling input request:", jse);
				}
				if (importShipmentTransactionsVO != null) {
					isValidRequest = importShipmentTransactionsVO.validateRequest();
					if (isValidRequest) {
						responseEntity = importSparcsShipmentTransactionsService.importSparcsShipmentTransactions(username,
								Constants.CON_SPARCS_SHIP_TXN_SOURCE_CODE, importShipmentTransactionsVO, siteName);
						if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
							errorStatus = true;
						} else if (responseEntity != null && responseEntity.getBody() != null) {
							responseSupport = responseEntity.getBody();
						}
					} else {
						responseEntity = new ResponseEntity<String>("Bad Request", HttpStatus.BAD_REQUEST);
					}

				} else {
					responseEntity = new ResponseEntity<String>("Bad Request", HttpStatus.BAD_REQUEST);
				}
			} else {
				responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);

			}
		} catch (Exception e) {
			LOGGER.error("Exception in spilERPhandleImportSPARCSShipTxns: " + e);
			errorStatus=true;
			responseEntity = new ResponseEntity<String>("Unclassified Error", HttpStatus.INTERNAL_SERVER_ERROR);  
		}

		responseSupport = responseEntity.getBody();
		LOGGER.info("Service Method Exit: spilERPhandleImportSPARCSShipTxns  - " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPhandleImportSPARCSShipTxns", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);

		return Utilities.sanitizeResponse(responseSupport);
	}

	/**
	 * 
	 * @param importSparcsShipmentTransactionsService
	 */
	@Autowired
	public void setImportSparcsShipmentTransactionsService(
			ImportSparcsShipmentTransactionsService importSparcsShipmentTransactionsService) {
		this.importSparcsShipmentTransactionsService = importSparcsShipmentTransactionsService;
	}

	@RequestMapping(value = "/importHBSSiteShipmentTransactions", method = RequestMethod.POST, produces = {
			MediaType.TEXT_HTML_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Override
	public String handleImportHBSSiteShipmentTransactions(
			@RequestHeader(value = "username", required = true) String username,
			@RequestBody String srcImportShipmentTransaction,
			@RequestParam(value = "sitename", required = true) String siteName) throws Exception {
		LOGGER.info("Service Method Entry: spilERPhandleImportHBSShipTxns ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String sanData = null;
		ResponseEntity<String> responseEntity = null;
		String responseSupport = "<error>There was an internal error</error>";
		LOGGER.info("handleImportHBSSiteShipmentTransactions Method Entry");
		sanData = Utilities.sanitizeJsonRequest(srcImportShipmentTransaction);
		ImportShipmentTransactionsVO importShipmentTransactionsVO = null;

		if (Boolean.valueOf(PropertiesUtil.getProperty(AppPropertyKey.IMPORT_HBS_SHIP_TXNS_ACTIVE))) {

			try {
				importShipmentTransactionsVO = new Gson().fromJson(sanData, ImportShipmentTransactionsVO.class);
			} catch (JsonSyntaxException jse) {
				LOGGER.error("exception occured while marshelling input request:", jse);
			}
			if (importShipmentTransactionsVO != null) {
				responseEntity = importSparcsShipmentTransactionsService.importSparcsShipmentTransactions(username,
						Constants.CON_HBS_SHIP_TXN_SOURCE_CODE, importShipmentTransactionsVO, siteName);
				if (responseEntity.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
					errorStatus = true;
				} else if (responseEntity != null && responseEntity.getBody() != null) {
					responseSupport = responseEntity.getBody();
				}
			} else {
				responseEntity = new ResponseEntity<String>("Bad Request", HttpStatus.BAD_REQUEST);
			}
		} else {
			responseEntity = new ResponseEntity<String>(Constants.API_NOT_ACTIVE_MESSAGE, HttpStatus.OK);
		}
		responseSupport = responseEntity.getBody();
		LOGGER.info("Service Method Exit: spilERPhandleImportHBSShipTxns  - " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPhandleImportHBSShipTxns", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return Utilities.sanitizeResponse(responseSupport);
	}

}
