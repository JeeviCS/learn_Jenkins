package com.cvs.specialty.erp.api;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

public interface SchedularAPI {

	@RequestMapping(value = "schedular/importTransactions", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.TEXT_HTML_VALUE })
	@ResponseBody
	public String importTransactions();
	
	@RequestMapping(value = "schedular/importSparcsShipmentTransactions", method = RequestMethod.GET)
	@ResponseBody
	public String handleImportSparcsShipmentTransactions();
	
	@RequestMapping(value = "schedular/importHBSSiteShipmentTransactions", method = RequestMethod.GET)
	@ResponseBody
	public String importHBSShipmentTxnsEndPoint();
	
	
	@RequestMapping(value = "schedular/createitem", method = RequestMethod.GET)
	@ResponseBody
	public String createitem();
	
	
	
	@RequestMapping(value = "schedular/updateitem", method = RequestMethod.GET)
	@ResponseBody
	public String updateitem();
	
	
	
	@RequestMapping(value = "schedular/exportCompanyReturnTransaction", method = RequestMethod.GET)
	@ResponseBody

	public String companyReturnTransactions();
	
	
	@RequestMapping(value = "schedular/hbsPurchaseOrder", method = RequestMethod.GET)
	@ResponseBody
	public String hbsPurchaseOrder();
	
	
	
}
