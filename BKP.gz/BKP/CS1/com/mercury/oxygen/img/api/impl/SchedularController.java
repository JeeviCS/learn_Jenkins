package com.cvs.specialty.erp.api.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.cvs.specialty.erp.api.SchedularAPI;
import com.cvs.specialty.erp.service.SchedularService;
import com.cvshealth.specialty.spil.monitor.TransactionMonitorUtil;

@Controller
public class SchedularController implements SchedularAPI {
	private static Logger LOG = Logger.getLogger(SchedularController.class);
	@Autowired
	SchedularService schedularService = null;

	@Override
	public String importTransactions() {
		// TODO Auto-generated method stub

		LOG.info("Service Method Entry: spilERPSchedularImportTxns");
		long startTimeMillis = System.currentTimeMillis();
		String responseMessage = null;
		boolean errorStatus = false;
		try {
			schedularService.executeImportCompShipTxnsEndpoint();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in spilERPSchedularImportTxns API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}
		LOG.info("Service Method Exit: spilERPServiceItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPSchedularImportTxns", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;
	}

	@Override
	public String handleImportSparcsShipmentTransactions() {
		LOG.info("Service Method Entry: spilERPSchedularImportSPARCSshipTxns");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = null;
		try {
			schedularService.handleImportSparcsShipmentTransactions();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in spilERPSchedularImportTxns API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}

		LOG.info("Service Method Exit: spilERPServiceItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPSchedularImportSPARCSshipTxns", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;
	}

	@Override
	public String importHBSShipmentTxnsEndPoint() {
		LOG.info("Service Method Entry: spilERPSchedularImportHBSshipTxns");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = null;
		try {
			schedularService.handleImportHBSShipmentTransactions();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in spilERPSchedularImportTxns API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}

		LOG.info("Service Method Exit: spilERPServiceItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPSchedularImportHBSshipTxns", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;
	}

	@Override
	public String createitem() {
		LOG.info("Service Method Entry: spilERPCreate Item");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = null;
		try {
			schedularService.handleCreateItem();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in spilERPSchedularCreateItem API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}

		LOG.info("Service Method Exit: spilERPSchedularCreateItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPSchedularCreateItem", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;
	}

	@Override
	public String updateitem() {
		// TODO Auto-generated method stub
		LOG.info("Service Method Entry: spilERPUpdate Item");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = null;
		try {
			schedularService.handleUpdateItem();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in spilERPSchedularUpdateItem API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}

		LOG.info("Service Method Exit: spilERPSchedularUpdateItem  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("spilERPSchedularUpdateItem", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;
	}

	@Override
	public String companyReturnTransactions() {
		LOG.info("Service Method Entry: SchedularcompanyReturnTransactions ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = null;
		try {
			schedularService.handleExportCompanyReturnTransaction();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in SchedularcompanyReturnTransactions API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}

		LOG.info("Service Method Exit: SchedularcompanyReturnTransactions  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("SchedularcompanyReturnTransactions", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;
	}

	@Override
	public String hbsPurchaseOrder() {
		LOG.info("Service Method Entry: SchedularhbsPurchaseOrder ");
		long startTimeMillis = System.currentTimeMillis();
		boolean errorStatus = false;
		String responseMessage = null;
		try {
			schedularService.handleHBSPurchaseOrder();
			responseMessage = "Completed Successfully";
		} catch (Exception e) {

			LOG.error("Exception Occurred in SchedularhbsPurchaseOrder API call: " + e.getMessage());
			errorStatus = true;
			responseMessage = "Exception Occured";
		}

		LOG.info("Service Method Exit: SchedularhbsPurchaseOrder  " + errorStatus);
		TransactionMonitorUtil.getInstance().monitorTransaction("SchedularhbsPurchaseOrder", errorStatus,
				(System.currentTimeMillis() - startTimeMillis), 2000);
		return responseMessage;

	}

}
