package com.cvs.specialty.erp.api;

import javax.servlet.http.HttpServletRequest;

public interface ItemStatusLookUpController {

	/**
	 * 
	 * @param charSiteCode
	 * @param drugNo
	 * @return
	 * @throws Exception
	 */
	String handleItemStatusLookUp(HttpServletRequest request,String srcSiteNDrugNo) throws Exception;

}
