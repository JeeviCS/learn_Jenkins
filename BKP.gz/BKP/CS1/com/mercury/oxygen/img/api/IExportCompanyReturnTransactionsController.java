package com.cvs.specialty.erp.api;

/**
 * @author Z238847
 *
 */
public interface IExportCompanyReturnTransactionsController {

	/**
	 * 
	 * @param username
	 * @return
	 */
	String handleExportCompanyReturnTransactions(String username);

}
