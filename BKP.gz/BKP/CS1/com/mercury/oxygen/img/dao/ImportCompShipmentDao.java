package com.cvs.specialty.erp.dao;

import java.util.List;

import com.cvs.specialty.erp.model.CompTxnShipInterfaceDTO;
import com.cvs.specialty.erp.model.CompTxnTypeFromERPDTO;
import com.cvs.specialty.erp.model.MckERPShipQueue;
import com.cvs.specialty.erp.model.MckOrderODCDetails;
import com.cvs.specialty.erp.model.TransactionInterface;

public interface ImportCompShipmentDao {

	
	List<CompTxnShipInterfaceDTO> getShipmentInfoFromSparcsTables(String companyId,String siteId);
	List<CompTxnTypeFromERPDTO>  getTxnTypeReasonsFromERP(long companyId,long siteId);
	boolean getLookUpCode(String lookUpType, String lookUpCode, java.sql.Date startDateActive);
	int insertIntoTxnInterfaceTable(TransactionInterface interfaceRecord);
	int updateMckERPShipQueueRecord(MckERPShipQueue mckERPShipQueueRecord);
	int updateOrderOdcDetails(MckOrderODCDetails mckOrderODCDetailsrecord);
}
