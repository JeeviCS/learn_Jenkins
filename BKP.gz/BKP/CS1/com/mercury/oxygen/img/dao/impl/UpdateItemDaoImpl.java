package com.cvs.specialty.erp.dao.impl;

import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.UpdateItemDao;
import com.cvs.specialty.erp.model.UpdateItemDTO;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class UpdateItemDaoImpl implements UpdateItemDao {

	private DataSource sparcsDataSource;
	private DataSource erpDataSource;
	private JdbcTemplate sparcsJdbcTemplate;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;
	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;

	@Autowired
	@Required
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;
		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);
	}

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	public DataSource getErpDataSource() {
		return erpDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);
		sparcsJdbcTemplate = new JdbcTemplate(sparcsDataSource);

	}

	@Override

	public List<UpdateItemDTO> getUpdateItemsFromSparcs(java.sql.Timestamp startDate, java.sql.Timestamp endDate) {
		// TODO Auto-generated method stub
		Map<String, Object> namedParameters = new HashMap<String, Object>();
		namedParameters.put("STARTDATE", startDate);
		SqlParameterSource params = new MapSqlParameterSource(namedParameters);
		return sparcsNamedJdbcTemplate.query(Constants.SQL_SELECT_ITEM_UPDATE, params, new UpdateItemMapper());

	}

	@Override

	public List<Double> getMarketPriceFromERPMTLSystems(String itemNumber, int organizationId) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("itemNumber", itemNumber);
		parameters.addValue("organizationId", organizationId);
		List<Double> strLst = erpNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_ITEM_UPDATE_ERP_MTL, parameters,
				Double.class);

		return strLst.isEmpty() ? null : strLst;

	}

	@Override
	public List<Integer> getItemId(String itemSrcCode) {
		// TODO Auto-generated method stub
		List<Integer> itemList = sparcsNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_ITEM_ID_SPARCS_ITEM,
				new MapSqlParameterSource().addValue("itemSrcCode", itemSrcCode), Integer.class);
		return itemList.isEmpty() ? null : itemList;
	}

	@Override
	public List<Double> getAWPAmount(int itemid, Double marketprice) {
		// TODO Auto-generated method stub
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("itemId", itemid);
		parameters.addValue("marketPrice", marketprice);
		List<Double> awpAmountList = sparcsNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_ITEM_UPDATE_AWPAMT,
				parameters, Double.class);
		return awpAmountList.isEmpty() ? null : awpAmountList;

	}

	@Override
	public int noOfUpdatedRecords(String itemNumber, Double awpAmount, int userid) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("segment2", itemNumber);
		parameters.addValue("market_price", awpAmount);
		parameters.addValue("last_updated_by", userid);
		return erpNamedJdbcTemplate.update(Constants.SQL_INSERT_ITEM_UPDATE_ERP, parameters);

	}

	@Override
	public void executeSetItemContextSP(int itemId) {

		if (itemId != 0) {
			/*
			 * this.sparcsJdbcTemplate.
			 * update("call contract_rate_utilities.set_item_context(:pItemid)", new
			 * MapSqlParameterSource().addValue("pItemId",itemId ));
			 */

			this.sparcsJdbcTemplate.update(Constants.SQL_ITEM_UPDATE_CONTEXT_PROC, new Object[] { itemId });
		} else {
			/*
			 * this.sparcsJdbcTemplate.
			 * update("call contract_rate_utilities.REFRESH_ACTORS_SUMMARY(:pItemid)", new
			 * MapSqlParameterSource().addValue("pItemid",Types.NULL));
			 */
			this.sparcsJdbcTemplate.update(Constants.SQL_ITEM_UPDATE_CONTEXT_PROC, new Object[] { Types.NULL });

		}

	}

}
