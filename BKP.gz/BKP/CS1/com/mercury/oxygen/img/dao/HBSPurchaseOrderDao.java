package com.cvs.specialty.erp.dao;

import java.util.List;

import com.cvs.specialty.erp.model.PharmopHeadersDTO;
import com.cvs.specialty.erp.model.PharmopLinesDTO;

public interface HBSPurchaseOrderDao {

	List<PharmopHeadersDTO> getRecordsWithStatus(String status);
	int insertIntoERPHeadertable(PharmopHeadersDTO list);
	List<PharmopLinesDTO> getSPARCSRecordswithHeaderId(long id);
	int insertIntoERPLinestable(PharmopLinesDTO list);
	int updateRecordStatus(long id,String status);
	
	int updateRecordStatusAndOtherCols(long id,String status,java.sql.Date ediDate,String processStatus,String processMessage);
	List<PharmopHeadersDTO> getERPRecordwithHeaderId(long id);
}
