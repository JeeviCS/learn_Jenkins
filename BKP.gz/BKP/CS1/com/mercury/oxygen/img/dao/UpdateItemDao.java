package com.cvs.specialty.erp.dao;

import java.util.List;

import com.cvs.specialty.erp.model.UpdateItemDTO;

public interface UpdateItemDao {
	List<UpdateItemDTO> getUpdateItemsFromSparcs(java.sql.Timestamp startDate,java.sql.Timestamp endDate);
	List<Double> getMarketPriceFromERPMTLSystems(String itemNumber, int organizationId);
	List<Integer> getItemId(String itemSrcCode);
	List<Double> getAWPAmount(int itemid, Double marketprice);
	int noOfUpdatedRecords(String itemNumber,Double awpAmount,int userid);
	void executeSetItemContextSP(int itemId);

	
	
}
