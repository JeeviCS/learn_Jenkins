package com.cvs.specialty.erp.dao;

import java.util.List;

import com.cvs.specialty.erp.model.HostInfoDTO;
import com.cvs.specialty.erp.model.ProcessParametersDTO;

public interface FileTransferDao {

	
	List<ProcessParametersDTO> getParametersOfProcess(String processName);
	List<HostInfoDTO> getHostInfo(String sparcsOrErp);
}
