package com.cvs.specialty.erp.dao.impl;

import java.sql.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.Validate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.ErpTransactionsDao;
import com.cvs.specialty.erp.model.CompanyTransactions;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class ErpTransactionsDaoImpl implements ErpTransactionsDao {
	private static final Logger LOGGER = Logger.getLogger(ErpTransactionsDaoImpl.class);

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("erpDS")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * 
	 */
	@Override
	public List<CompanyTransactions> getReturnTransactions() {
		return jdbcTemplate.query(Constants.SQL_SELECT_TO_GET_UNPROCESSED_RECORDS, new ErpTransactionsRowMapper() {

		});

	}

	/**
	 * 
	 * @param updatedBy
	 * @param processFlag
	 * @param updatedDate
	 * @param companyTxnsIfaceId
	 */
	@Override
	public void updateProcessFlag(String updatedBy, String processFlag, Date updatedDate, int companyTxnsIfaceId) {
		LOGGER.debug("Parameters Received in updateProcessFlag");
		Validate.notEmpty(updatedBy, "updatedBy must not be empty");
		Validate.notEmpty(processFlag, "processflag must not be emlpty");
		Validate.notNull(updatedDate, "updatedDate must not be empty");
		Validate.notNull(companyTxnsIfaceId, "companyTxnsIfaceId must not be empty");
		jdbcTemplate.update(Constants.SQL_UPDATE_PROCESS_FLAG, processFlag, updatedBy, updatedDate, companyTxnsIfaceId);
	}

}
