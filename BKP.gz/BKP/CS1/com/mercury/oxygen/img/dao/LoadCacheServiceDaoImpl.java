/*package com.cvs.specialty.erp.dao;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cvs.specialty.erp.utils.CacheManager;

public class LoadCacheServiceDaoImpl implements LoadCacheServiceDao  {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LoadCacheServiceDaoImpl.class);

	static Map<String, String> resultMap = new HashMap<String, String>();


	@Override
	public Map<String, String> getAppProperties() {
		LOGGER.info("Method Entry: getAppProperties ");
		long t1 = System.currentTimeMillis();
		List<ProcessParameters> processParamList=processParamRepo.getProcessParameters();
		if(processParamList !=null){
			for(ProcessParameters processParam: processParamList){
				resultMap.put(processParam.getName(), processParam.getTextValue());
			}
		}
		
		LOG.info("Method Exit: getAppProperties-"+"||"+resultMap.size()+"||"+(System.currentTimeMillis()-t1)+"||");
		return resultMap;
	}
	
}*/
