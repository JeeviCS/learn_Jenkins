package com.cvs.specialty.erp.dao;

import java.util.Map;

public interface LoadCacheServiceDao {
	public Map<String, String> getAppProperties();
}
