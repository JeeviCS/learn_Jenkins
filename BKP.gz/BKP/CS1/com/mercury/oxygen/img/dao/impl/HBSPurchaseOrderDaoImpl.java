package com.cvs.specialty.erp.dao.impl;

import java.sql.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.HBSPurchaseOrderDao;
import com.cvs.specialty.erp.model.PharmopHeadersDTO;
import com.cvs.specialty.erp.model.PharmopLinesDTO;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class HBSPurchaseOrderDaoImpl implements HBSPurchaseOrderDao {
	private DataSource sparcsDataSource;
	private DataSource erpDataSource;
	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;

	@Autowired
	@Required
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;

		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);
	}

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	public DataSource getErpDataSource() {
		return erpDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);

	}

	@Override
	public List<PharmopHeadersDTO> getRecordsWithStatus(String status) {
		// TODO Auto-generated method stub

		List<PharmopHeadersDTO> itemList = sparcsNamedJdbcTemplate.query(Constants.SQL_SELECT_PHARMOP_SPARCS,
				new MapSqlParameterSource().addValue("status", status), new PharmopHeadersMapper());
		return itemList;
	}

	@Override
	public List<PharmopLinesDTO> getSPARCSRecordswithHeaderId(long id) {
		// TODO Auto-generated method stub
		List<PharmopLinesDTO> itemList = sparcsNamedJdbcTemplate.query(Constants.SQL_SELECT_PHARM_LINES_SPARCS,
				new MapSqlParameterSource().addValue("headerId", id), new PharmopLinesMapper());
		return itemList;
	}

	@Override
	public int insertIntoERPHeadertable(PharmopHeadersDTO record) {
		// TODO Auto-generated method stub

		// :headerId,:poNumber,:apothcaryVendorId,:storeNo,:buyer,:description,:status,:ediDate,:cancelDate,:createBy,:createDate,:updateBy,:updateDate,:cancelReason,:processStatus,:userMessage)

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("headerId", record.getPoHeaderId());
		parameters.addValue("poNumber", record.getPoNumber());
		parameters.addValue("apothcaryVendorId", record.getApothecaryVendorId());
		parameters.addValue("storeNo", record.getStoreNo());

		parameters.addValue("buyer", record.getBuyer());
		parameters.addValue("description", record.getDescription());
		parameters.addValue("status", record.getStatus());
		parameters.addValue("ediDate", record.getEdidate());
		parameters.addValue("cancelDate", record.getCancelDate());

		parameters.addValue("createBy", record.getCreateBy());
		parameters.addValue("createDate", record.getCreateDate());
		parameters.addValue("updateBy", record.getUpdateBy());
		parameters.addValue("updateDate", record.getUpdateDate());

		parameters.addValue("cancelReason", record.getCancelReason());
		parameters.addValue("processStatus", record.getProcessStatus());
		parameters.addValue("userMessage", record.getUserMessage());

		return erpNamedJdbcTemplate.update(Constants.SQL_INSERT_PHARMOP_TABLE, parameters);

	}

	@Override
	public int insertIntoERPLinestable(PharmopLinesDTO record) {
		// TODO Auto-generated method stub
		// :poLineId,:lineNumber,:poHeaderId,:itemId,:quantity,:mfgAuthorizationNo,:createBy,:createDate,:updateBy,:updateDate,:erpReceiptInd,:erpProcessDate,:unitPrice)

		MapSqlParameterSource parameters = new MapSqlParameterSource();

		parameters.addValue("poLineId", record.getPoLineId());
		parameters.addValue("lineNumber", record.getLineNumber());
		parameters.addValue("poHeaderId", record.getPoHeaderId());
		parameters.addValue("itemId", record.getItemId());
		parameters.addValue("quantity", record.getQuantity());
		parameters.addValue("mfgAuthorizationNo", record.getMfgAuthorizationNo());
		parameters.addValue("createBy", record.getCreateBy());
		parameters.addValue("createDate", record.getCreateDate());
		parameters.addValue("updateBy", record.getUpdateBy());
		parameters.addValue("updateDate", record.getUpdateDate());
		parameters.addValue("erpReceiptInd", record.getErpReceiptInd());
		parameters.addValue("erpProcessDate", record.getErpProcessDate());
		parameters.addValue("unitPrice", record.getUnitPrice());
		return erpNamedJdbcTemplate.update(Constants.SQL_INSERT_PHARM_LINES_TABLE, parameters);
	}

	@Override
	public int updateRecordStatus(long id, String status) {
		// TODO Auto-generated method stub
		// UPDATE PHARMOP_PO_HEADERS SET STATUS=:status WHERE PO_HEADER_ID=:poHeaderId

		MapSqlParameterSource parameters = new MapSqlParameterSource();

		parameters.addValue("status", status);
		parameters.addValue("poHeaderId", id);
		return sparcsNamedJdbcTemplate.update(Constants.SQL_UPDATE_PHARMOP_TABLE1, parameters);
	}

	@Override
	public int updateRecordStatusAndOtherCols(long id, String status, Date ediDate, String processStatus,
			String processMessage) {
		// TODO Auto-generated method stub
//UPDATE PHARMOP_PO_HEADERS SET STATUS=:status,EDI_DATE= :ediDate,PROCESS_STATUS=:processStatus, USER_MESSAGE=:userMessage WHERE PO_HEADER_ID=:poHeaderId";
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		parameters.addValue("status", status);
		parameters.addValue("poHeaderId", id);
		parameters.addValue("ediDate", ediDate);
		parameters.addValue("processStatus", processStatus);
		parameters.addValue("userMessage", processMessage);
		
		return sparcsNamedJdbcTemplate.update(Constants.SQL_UPDATE_PHARMOP_TABLE2, parameters);
	}

	@Override
	public List<PharmopHeadersDTO> getERPRecordwithHeaderId(long id) {
		// TODO Auto-generated method stub

		List<PharmopHeadersDTO> itemList = erpNamedJdbcTemplate.query(Constants.SQL_SELECT_PHARMOP_RECORD_SPARCS,
				new MapSqlParameterSource().addValue("headerId", id),new PharmopHeadersMapper());
		
		
		return itemList;
	}

}
