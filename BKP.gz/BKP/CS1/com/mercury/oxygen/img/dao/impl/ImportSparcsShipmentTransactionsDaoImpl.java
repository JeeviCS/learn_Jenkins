package com.cvs.specialty.erp.dao.impl;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.Validate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.ImportSparcsShipmentTransactionsDao;
import com.cvs.specialty.erp.model.MtlParameters;
import com.cvs.specialty.erp.model.MtlTransactions;
import com.cvs.specialty.erp.model.SparcsShipmentTransaction;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class ImportSparcsShipmentTransactionsDaoImpl implements ImportSparcsShipmentTransactionsDao {
	private static final Logger LOGGER = Logger.getLogger(ImportSparcsShipmentTransactionsDaoImpl.class);
	private DataSource sparcsDataSource;
	private JdbcTemplate sparcsJdbcTemplate;
	private JdbcTemplate erpJdbcTemplate;
	private DataSource erpDataSource;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;

	@Autowired
	@Required
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;
		erpJdbcTemplate = new JdbcTemplate(erpDataSource);
		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);

	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsJdbcTemplate = new JdbcTemplate(sparcsDataSource);

	}

	@Override
	public List<SparcsShipmentTransaction> getSparcsShipmentTransactions(String orderStatus, Long siteId,
			Timestamp startDate, Date endDate) {
		LOGGER.info("getSparcsShipmentTransactions::startDate=" + startDate + " and endDate=" + endDate
				+ " and orderStatus=" + orderStatus + " and siteId=" + siteId);
		return sparcsJdbcTemplate.query(Constants.SQL_SELECT_SPARCS_SHIPMENT_TRANSACTIONS,
				// new Object[] { orderStatus, siteId, startDate, endDate, startDate, endDate },
				new Object[] { orderStatus, siteId, startDate, startDate }, // modified by Chinna
				new SparcsShipmentTransactionRowMapper());
	}

	@Override
	public List<MtlParameters> getMtlParameters(Long organizationId) {
		return erpJdbcTemplate.query(Constants.SQL_SELECT_SITE_ID_APPS_MTL_PARAMETERS, new Object[] { organizationId },
				new MtlParametersRowMapper());

	}

	/**
	 * 
	 */
	@Override
	public int saveMtlTransactions(final MtlTransactions mtlTransactions) {
		LOGGER.debug("received mtlTransactions ::" + mtlTransactions);
		Validate.notNull(mtlTransactions);

		int count = erpJdbcTemplate.update(Constants.SQL_INSERT_MTL_TRANSACTIONS, new Object[] {
				mtlTransactions.getSourceCode(), mtlTransactions.getSourceLineId(), mtlTransactions.getSourceHeaderid(),
				mtlTransactions.getProcessFlag(), mtlTransactions.getTransactionMode(), mtlTransactions.getLockFlag(),
				mtlTransactions.getLastUpdateDate(), mtlTransactions.getLastUpdatedBy(),
				mtlTransactions.getCreationDate(), mtlTransactions.getCreatedBy(), mtlTransactions.getInventoryItemId(),
				mtlTransactions.getItemSegment2(), mtlTransactions.getOrganizationId(),
				mtlTransactions.getTransactionQuantity(), mtlTransactions.getTransactionUom(),
				mtlTransactions.getTransactionDate(), mtlTransactions.getSubinventoryCode(),
				mtlTransactions.getTransactionTypeId(), mtlTransactions.getReasonId(),
				mtlTransactions.getDistributionAccountId(), mtlTransactions.getAttribute1(),
				mtlTransactions.getAttribute2(), mtlTransactions.getAttribute3(), mtlTransactions.getAttribute4(), });

		LOGGER.debug("MtlTransactions are saved succesfully with mtlTransactions ::" + mtlTransactions);
		return count;

	}

	@Override
	public List<Long> getUserId(String username) {

		List<Long> userList = erpNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_USER_ID,
				new MapSqlParameterSource().addValue("Username", username), Long.class);
		return userList.isEmpty() ? null : userList;

	}

	@Override
	public int updateMtlTransactions(SparcsShipmentTransaction sparcsShipmentTransaction,
			MtlTransactions mtlTransactions, String l_process_flag, String l_transfer_ind, String l_error_explanation) {

		return sparcsJdbcTemplate.update(Constants.SQL_UPDATE_SPARCS_SHIPMENT_TRANSACTIONS,
				new Object[] { sparcsShipmentTransaction.getQuantityDispensed(), mtlTransactions.getOrganizationId(),
						mtlTransactions.getSubinventoryCode(), mtlTransactions.getTransactionTypeId(),
						mtlTransactions.getReasonId(), mtlTransactions.getDistributionAccountId(), l_error_explanation,
						l_process_flag, l_transfer_ind, "ImportSparcsShipmentTransactions",
						sparcsShipmentTransaction.getErpDispenseInterfaceId() });
	}

}
