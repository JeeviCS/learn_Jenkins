package com.cvs.specialty.erp.dao;

import java.util.List;

import com.cvs.specialty.erp.model.MckOrderReturn;

public interface MckOrderReturnsDao {
	/**
	 * This method inserts a new record in to mck_order_returns table and return
	 * the primary key
	 * 
	 * @param mckOrderReturn
	 */
	int saveOrderReturn(MckOrderReturn mckOrderReturn);

	/**
	 * This method gets the saved record based on the returnId
	 * 
	 * @param orderReturnId
	 * @return
	 */
	MckOrderReturn getOrderReturn(int orderReturnId);

	List<Integer> getRegisterdProcessNumber(String processName);

	void sendemail(String emailMessage);

}
