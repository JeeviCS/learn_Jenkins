package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.CreateERPItemDTO;

public class CreateERPItemMapper implements RowMapper<CreateERPItemDTO> {

	@Override
	public CreateERPItemDTO mapRow(ResultSet rs, int rowNo) throws SQLException {
		// TODO Auto-generated method stub

		CreateERPItemDTO erpitemDto = new CreateERPItemDTO();

		erpitemDto.setOrganizationId(rs.getInt("ORGANIZATION_ID"));
		erpitemDto.setSegment2(rs.getString("SEGMENT2"));
		erpitemDto.setDescription(rs.getString("DESCRIPTION"));
		erpitemDto.setTemplateId(rs.getInt("TEMPLATE_ID"));
		erpitemDto.setAttribute2(rs.getString("ATTRIBUTE2"));
		erpitemDto.setMarketPrice(rs.getDouble("MARKET_PRICE"));
		erpitemDto.setLastUpdateBy(rs.getInt("LAST_UPDATE_BY"));
		erpitemDto.setCreatedBy(rs.getInt("CREATED_BY"));

		return erpitemDto;
	}

}
