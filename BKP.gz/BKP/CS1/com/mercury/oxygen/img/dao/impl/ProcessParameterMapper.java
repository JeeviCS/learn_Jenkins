package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.ProcessParametersDTO;

public class ProcessParameterMapper implements RowMapper<ProcessParametersDTO> {


	@Override
	public ProcessParametersDTO mapRow(ResultSet rs, int arg1) throws SQLException {

		ProcessParametersDTO processParameter = new ProcessParametersDTO();
		processParameter.setName(rs.getString("NAME"));
		processParameter.setTextValue(rs.getString("TEXT_VALUE"));
		return processParameter;
	}

}
