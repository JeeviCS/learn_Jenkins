package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.PharmopHeadersDTO;

public class PharmopHeadersMapper implements RowMapper<PharmopHeadersDTO> {

	@Override
	public PharmopHeadersDTO mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub

		PharmopHeadersDTO pharmopHeadersDTO = new PharmopHeadersDTO();
		pharmopHeadersDTO.setPoHeaderId(rs.getLong("PO_HEADER_ID"));
		pharmopHeadersDTO.setPoNumber(rs.getString("PO_NUMBER"));
		pharmopHeadersDTO.setApothecaryVendorId(rs.getLong("APOTHECARY_VENDOR_ID"));
		pharmopHeadersDTO.setStoreNo(rs.getInt("STORE_NO"));
		pharmopHeadersDTO.setBuyer(rs.getString("BUYER"));
		pharmopHeadersDTO.setDescription(rs.getString("DESCRIPTION"));
		pharmopHeadersDTO.setStatus(rs.getString("STATUS"));
		pharmopHeadersDTO.setEdidate(rs.getDate("EDI_DATE"));
		pharmopHeadersDTO.setCancelDate(rs.getDate("CANCEL_DATE"));
		pharmopHeadersDTO.setCreateBy(rs.getString("CREATE_BY"));
		pharmopHeadersDTO.setCreateDate(rs.getDate("CREATE_DATE"));
		pharmopHeadersDTO.setUpdateBy(rs.getString("UPDATE_BY"));
		pharmopHeadersDTO.setUpdateDate(rs.getDate("UPDATE_DATE"));
		pharmopHeadersDTO.setCancelReason(rs.getString("CANCEL_REASON"));
		pharmopHeadersDTO.setProcessStatus(rs.getString("PROCESS_STATUS"));
		pharmopHeadersDTO.setUserMessage(rs.getString("USER_MESSAGE"));

		return pharmopHeadersDTO;
	}

}
