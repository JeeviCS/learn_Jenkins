package com.cvs.specialty.erp.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.LookUpItemStatusDao;
import com.cvs.specialty.erp.model.ItemStatusDTO;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class LookUpItemStatusDaoImpl implements LookUpItemStatusDao {
	private DataSource erpDataSource;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;

	@Autowired
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;
		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);
	}

	/**
	 * 
	 */
	@Override
	public List<ItemStatusDTO> getItemStatus(String charSiteCode, String drugNo) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("charSiteCode", charSiteCode);
		parameters.addValue("drugNo", drugNo);
		return erpNamedJdbcTemplate.query(Constants.SQL_LOOKUP_ITEM_STATUS, parameters,
				new LookUpItemStatusRowMapper());
	}

}
