package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.PharmopLinesDTO;

public class PharmopLinesMapper implements RowMapper<PharmopLinesDTO> {

	@Override
	public PharmopLinesDTO mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub

		
		
		PharmopLinesDTO pharmopLinesDTO= new PharmopLinesDTO();
		pharmopLinesDTO.setPoLineId(rs.getLong("PO_LINE_ID"));
		pharmopLinesDTO.setLineNumber(rs.getLong("LINE_NUMBER"));
		pharmopLinesDTO.setPoHeaderId(rs.getLong("PO_HEADER_ID"));
		pharmopLinesDTO.setItemId(rs.getLong("ITEM_ID"));
		pharmopLinesDTO.setQuantity(rs.getLong("QUANTITY"));
		pharmopLinesDTO.setMfgAuthorizationNo(rs.getString("MFG_AUTHORIZATION_NUMBER"));
		pharmopLinesDTO.setCreateBy(rs.getString("CREATE_BY"));
		pharmopLinesDTO.setCreateDate(rs.getDate("CREATE_DATE"));
		pharmopLinesDTO.setUpdateBy(rs.getString("UPDATE_BY"));
		pharmopLinesDTO.setUpdateDate(rs.getDate("UPDATE_DATE"));
		pharmopLinesDTO.setErpReceiptInd(rs.getString("ERP_RECEIPT_IND"));
		pharmopLinesDTO.setErpProcessDate(rs.getDate("ERP_PROCESS_DATE"));
		pharmopLinesDTO.setUnitPrice(rs.getDouble("UNIT_PRICE"));
		
		return pharmopLinesDTO;
	}

}
