package com.cvs.specialty.erp.dao;

import java.util.List;

public interface CompanyIdSchedularDao {

	List<Integer> getDistinctCompanyId();
}
