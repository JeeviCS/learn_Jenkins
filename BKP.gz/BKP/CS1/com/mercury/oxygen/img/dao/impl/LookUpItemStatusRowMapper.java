package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.ItemStatusDTO;
import com.cvs.specialty.erp.utils.Constants;

public class LookUpItemStatusRowMapper implements RowMapper<ItemStatusDTO> {
	@Override
	public ItemStatusDTO mapRow(ResultSet rs, int index) throws SQLException {
		ItemStatusDTO itemStatusDTO = new ItemStatusDTO();
		itemStatusDTO.setEnabled_flag(rs.getString(Constants.ENABLED_FLAG));
		itemStatusDTO.setInventory_item_id(rs.getLong(Constants.INVENTORY_ITEM_ID));
		itemStatusDTO.setInventory_item_status_code(rs.getString(Constants.INVENTORY_ITEM_STATUS_CODE));
		itemStatusDTO.setMtl_system_items_ind(rs.getString(Constants.MTL_SYSTEM_ITEMS_IND));
		itemStatusDTO.setOrganization_id(rs.getLong(Constants.ORGANIZATION_ID));
		return itemStatusDTO;
	}

}
