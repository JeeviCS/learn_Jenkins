package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.cvs.specialty.erp.model.CreateItemDTO;

public class CreateItemExtractor implements ResultSetExtractor<List<CreateItemDTO>> {

	@Override
	public List<CreateItemDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {
		// TODO Auto-generated method stub
		
		List<CreateItemDTO> itemList= new ArrayList<CreateItemDTO>();
		
		while(rs.next()) {
			CreateItemDTO itemDto= new CreateItemDTO();

			itemDto.setTransactionType(rs.getString("TRANSACTION_TYPE"));
			itemDto.setItemNumber(rs.getString("ITEM_NUMBER"));
			itemDto.setItemName(rs.getString("ITEM_NAME"));
			/*itemDto.setItemSrcCode(rs.getString("ITEM_SRC_CODE"));
			itemDto.setSystemSrcCode(rs.getString("SYSTEM_SRC_CODE"));
			*/
			itemDto.setNdcNo(rs.getString("NDC_NUMBER"));
			
			
			itemDto.setAwpAmount(rs.getFloat("AWP_AMT"));
			
			itemList.add(itemDto);
		}
		
		return itemList;
	}

}
