package com.cvs.specialty.erp.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.lang.Validate;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.MckOrderReturnsDao;
import com.cvs.specialty.erp.model.MckOrderReturn;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class MckOrderReturnsDaoImpl implements MckOrderReturnsDao {
	private static final Logger LOGGER = Logger.getLogger(MckOrderReturnsDaoImpl.class);

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("sparcsDS")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * 
	 */
	@Override
	public int saveOrderReturn(final MckOrderReturn mckOrderReturn) {
		LOGGER.debug("received mckOrderReturn ::" + mckOrderReturn);
		Validate.notNull(mckOrderReturn);

		int count = jdbcTemplate.update(Constants.SQL_INSERT_TRANSACTIONS,
				new Object[] { mckOrderReturn.getCompanyTxnsIfaceId(), mckOrderReturn.getTransactionId(),
						mckOrderReturn.getTransactionDate(), mckOrderReturn.getTransactionTypeName(),
						mckOrderReturn.getTransactionReasonName(), mckOrderReturn.getSiteId(),
						mckOrderReturn.getOrderNumber(), mckOrderReturn.getRxNumber(), mckOrderReturn.getItemNumber(),
						mckOrderReturn.getNdc(), mckOrderReturn.getItemDescription(),
						mckOrderReturn.getTransactionQuantity(), mckOrderReturn.getTransactionUom(),
						mckOrderReturn.getOrderByCompanyId(), mckOrderReturn.getCreateBy(),
						mckOrderReturn.getCreateDate(), mckOrderReturn.getUpdateBy(), mckOrderReturn.getUpdateDate(),
						mckOrderReturn.getCreateBySystem(), mckOrderReturn.getCreateByProcessFunction(),
						mckOrderReturn.getUpdateBySystem(), mckOrderReturn.getUpdateByProcessFunction(),
						mckOrderReturn.getTransactionReference() });

		LOGGER.debug("OrderReturn is saved succesfully with mckOrderReturn ::" + mckOrderReturn);
		return count;

	}

	/**
	 * 	
	 */
	@Override
	public MckOrderReturn getOrderReturn(int orderReturnId) {
		LOGGER.debug("getOrderReturn::received orderReturnId ::" + orderReturnId);
		return (MckOrderReturn) jdbcTemplate.queryForObject(Constants.SQL_SELECT_TRANSACTIONS,
				new Object[] { orderReturnId }, new BeanPropertyRowMapper<>(MckOrderReturn.class));
	}

	@Override
	public List<Integer> getRegisterdProcessNumber(String processName) {
		String processNameQuery = Constants.SQL_SELECT_PROCESS_ID;
		return jdbcTemplate.queryForList(processNameQuery, new String[] { processName }, Integer.class);

	}

	@Override
	public void sendemail(String emailMessage) {
		jdbcTemplate.update(Constants.SQL_EMAIL_PROCEDURE, new Object[] { "ERP_INTERFACE_UTILITIES",
				"ispghsparcsproductionsupport@caremark.com", "EXTRACT_TRANSACTIONS", emailMessage });
	}

}
