package com.cvs.specialty.erp.dao;

public interface TLSDao {

	String executeCreateItemStoredProc(String templateId);
}
