package com.cvs.specialty.erp.dao;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import com.cvs.specialty.erp.model.MtlParameters;
import com.cvs.specialty.erp.model.MtlTransactions;
import com.cvs.specialty.erp.model.SparcsShipmentTransaction;

public interface ImportSparcsShipmentTransactionsDao {

	/**
	 * 
	 * @param siteId
	 * @param orderStatus
	 * @param startDate
	 * @param endDate
	 * @param organizationId
	 * @return
	 */
	List<SparcsShipmentTransaction> getSparcsShipmentTransactions(String orderStatus, Long siteId, Timestamp startDate,
			Date endDate);

	/**
	 * 
	 * @param organizationId
	 * @return
	 */

	List<MtlParameters> getMtlParameters(Long organizationId);

	/**
	 * 
	 * @param mtlTransactions
	 * @return
	 */
	int saveMtlTransactions(MtlTransactions mtlTransactions);

	/**
	 * 
	 * @param username
	 * @return
	 */
	List<Long> getUserId(String username);

	/**
	 * 
	 * @param sparcsShipmentTransaction
	 * @param mtlTransactions
	 * @param l_transfer_ind
	 * @param l_process_flag
	 * @param l_error_explanation
	 * @return
	 */
	int updateMtlTransactions(SparcsShipmentTransaction sparcsShipmentTransaction, MtlTransactions mtlTransactions,
			String l_process_flag, String l_transfer_ind, String l_error_explanation);

}
