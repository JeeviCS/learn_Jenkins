package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.CompTxnShipInterfaceDTO;



public class CompShipInterfaceMapper implements RowMapper<CompTxnShipInterfaceDTO>{

	@Override
	public CompTxnShipInterfaceDTO mapRow(ResultSet rs, int num) throws SQLException {
		
		CompTxnShipInterfaceDTO compTxnShipInterface= new CompTxnShipInterfaceDTO();
		compTxnShipInterface.setMckERPShipQueueId(rs.getLong("MCK_ERP_SHIP_QUEUE_ID"));
		compTxnShipInterface.setMckOrderOdcDetailId(rs.getLong("MCK_ORDER_ODC_DETAIL_ID"));
		compTxnShipInterface.setMckOrderHeaderId(rs.getLong("MCK_ORDER_HEADER_ID"));
		compTxnShipInterface.setOdcOrderNo(rs.getString("ODC_ORDER_NUMBER"));
		compTxnShipInterface.setOdcSiOrderStatus(rs.getString("ODC_SI_ORDER_STATUS"));
		compTxnShipInterface.setCompanyId(rs.getLong("COMPANY_ID"));
		compTxnShipInterface.setSiteId(rs.getLong("SITE_ID"));
		compTxnShipInterface.setOdcIrc(rs.getString("ODC_IRC"));
		compTxnShipInterface.setOdcRxNumber(rs.getString("ODC_RX_NUMBER"));
		compTxnShipInterface.setOdcQuantityPickedNum(rs.getDouble("ODC_QUANTITY_PICKED_NUM"));
		compTxnShipInterface.setOdcTimeComplete(rs.getDate("ODC_TIME_COMPLETE"));
		

		return compTxnShipInterface;
	}

}
