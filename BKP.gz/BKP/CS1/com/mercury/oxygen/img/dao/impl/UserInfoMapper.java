package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.HostInfoDTO;

public class UserInfoMapper implements RowMapper<HostInfoDTO> {

	@Override
	public HostInfoDTO mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		

		HostInfoDTO hostInfoDTO = new HostInfoDTO();
		hostInfoDTO.setHostName(rs.getString("HOST_NAME"));
		hostInfoDTO.setUsername(rs.getString("USER_NAME"));
		hostInfoDTO.setPassword(rs.getString("PASSWORD"));
		hostInfoDTO.setDescription(rs.getString("DESCRIPTION"));
		return hostInfoDTO;
		
	}

}
