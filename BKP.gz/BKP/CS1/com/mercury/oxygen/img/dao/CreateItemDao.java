package com.cvs.specialty.erp.dao;


import java.sql.Timestamp;
import java.util.List;

import com.cvs.specialty.erp.model.CreateERPItemDTO;
import com.cvs.specialty.erp.model.CreateItemDTO;



public interface CreateItemDao {

	public int getRegisterdProcessNumber(String processName);

	public Timestamp getStartDateFromProcessTable(int registeredProcessId);

	public void updateEndDateInProcessTable(Timestamp endDate, int registeredProcessNo);

	public List<CreateItemDTO> getItemsFromSparcsItemTable(Timestamp startDate, Timestamp endDate, String activeInd);

	public int checkIfExistsinErpItemsInterfaceTable(String itemNumber, int organizationId);
	
	public int insertIntoERPItemInterfaceTable(CreateERPItemDTO newitemsFromSparcs);
	
	public List<Integer> getUserId(String Username);
	
	

}
