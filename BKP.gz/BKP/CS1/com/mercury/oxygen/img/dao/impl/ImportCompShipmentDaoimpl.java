package com.cvs.specialty.erp.dao.impl;

import java.sql.Date;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.ImportCompShipmentDao;
import com.cvs.specialty.erp.model.CompTxnShipInterfaceDTO;
import com.cvs.specialty.erp.model.CompTxnTypeFromERPDTO;
import com.cvs.specialty.erp.model.MckERPShipQueue;
import com.cvs.specialty.erp.model.MckOrderODCDetails;
import com.cvs.specialty.erp.model.TransactionInterface;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class ImportCompShipmentDaoimpl implements ImportCompShipmentDao {

	private DataSource sparcsDataSource;
	private DataSource erpDataSource;
	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;

	@Autowired
	@Required
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;

		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);
	}

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	public DataSource getErpDataSource() {
		return erpDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);

	}

	@Override
	public List<CompTxnShipInterfaceDTO> getShipmentInfoFromSparcsTables(String companyId, String siteId) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("companyId", companyId==null||companyId.equalsIgnoreCase("0") ?null:Integer.parseInt(companyId));
		parameters.addValue("siteId", siteId==null|| siteId.equalsIgnoreCase("0")?null:Integer.parseInt(siteId));
		List<CompTxnShipInterfaceDTO> compTxnShipInterfaceList = sparcsNamedJdbcTemplate.query(
				Constants.SQL_SELECT_IMPORT_SHIPMENTS_1 + Constants.SQL_SELECT_IMPORT_SHIPMENTS_2, parameters,
				new CompShipInterfaceMapper());

		return compTxnShipInterfaceList;
	}

	@Override
	public List<CompTxnTypeFromERPDTO> getTxnTypeReasonsFromERP(long companyId, long siteId) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("curCompanyId", companyId==0?null:companyId);
		parameters.addValue("curSiteId", siteId==0?null:siteId);
		List<CompTxnTypeFromERPDTO> compTxnShipInterfaceList = erpNamedJdbcTemplate
				.query(Constants.SQL_SELECT_ERP_TXN_REASONS, parameters, new CompTxnReasonMapper());

		return compTxnShipInterfaceList;
	}

	@Override
	public boolean getLookUpCode(String lookUpType, String lookUpCode, Date startDateActive) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("exclusionLoop", lookUpType);
		parameters.addValue("itemNumber", lookUpCode);
		parameters.addValue("criteriaDate", startDateActive);
		List<String> lookUpList = erpNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_ERP_LOOKUP_CODE, parameters,
				String.class);

		return lookUpList.isEmpty() ? false : true;
	}

	@Override
	public int insertIntoTxnInterfaceTable(TransactionInterface interfaceRecord) {
		// TODO Auto-generated method stub
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("curOdcDetailId", interfaceRecord.getSourceLineId());
		parameters.addValue("curOdcDetailId", interfaceRecord.getSourceLineId());
		parameters.addValue("curOdcIrc", interfaceRecord.getItemSegment2());
		parameters.addValue("organizationId", interfaceRecord.getOrganizationId());
		parameters.addValue("subInventoryCode", interfaceRecord.getSubInventoryCode());
		parameters.addValue("odcQuantityPickedNo", interfaceRecord.getTxnQuantity());
		parameters.addValue("uomCode", interfaceRecord.getTxnUOM());
		parameters.addValue("curOdcTimeComplete", interfaceRecord.getTxnDate());
		parameters.addValue("txnTypeId", interfaceRecord.getTxnTypeId());
		parameters.addValue("reasonId", interfaceRecord.getReasonId());
		parameters.addValue("distributionAcctId", interfaceRecord.getDistAccountId());
		parameters.addValue("curOdcRxNo", interfaceRecord.getAttribute1());
		parameters.addValue("curOdcOrderNo", interfaceRecord.getAttribute2());
		parameters.addValue("curCompId", interfaceRecord.getAttribute5());
		parameters.addValue("userId", interfaceRecord.getLastUpdateBy());
		parameters.addValue("userId", interfaceRecord.getCreateBy());

		return erpNamedJdbcTemplate
				.update(Constants.SQL_INSERT_ERP_TXN_INTERFACE1 + Constants.SQL_INSERT_ERP_TXN_INTERFACE2, parameters);

	}

	@Override
	public int updateMckERPShipQueueRecord(MckERPShipQueue mckERPShipQueueRecord) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("processFlag", mckERPShipQueueRecord.getProcessFlag());
		parameters.addValue("transferInd", mckERPShipQueueRecord.getTransferInd());
		parameters.addValue("errorExplanation", mckERPShipQueueRecord.getErrorExplanation());
		parameters.addValue("packageName", mckERPShipQueueRecord.getPackageName());
		parameters.addValue("procedureName", mckERPShipQueueRecord.getProcedureName());
		parameters.addValue("curErpShipQueueId", mckERPShipQueueRecord.getErpShipQueueId());
		parameters.addValue("curOrderOdcDetailId", mckERPShipQueueRecord.getOrderOdcDetailId());
		return sparcsNamedJdbcTemplate.update(Constants.SQL_UPDATE_SPARCS_SHIP_QUEUE, parameters);

	}

	@Override
	public int updateOrderOdcDetails(MckOrderODCDetails mckOrderODCDetailsrecord) {
		// TODO Auto-generated method stub
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("transferInd", mckOrderODCDetailsrecord.getTransferInd());
		parameters.addValue("packageName", mckOrderODCDetailsrecord.getPackageName());
		parameters.addValue("procedureName", mckOrderODCDetailsrecord.getProcedureName());
		parameters.addValue("orderOdcDetailId", mckOrderODCDetailsrecord.getOrderOdcDetailId());
		parameters.addValue("orderHeaderId", mckOrderODCDetailsrecord.getOrderHeaderId());
		
		return sparcsNamedJdbcTemplate.update(Constants.SQL_UPDATE_SPARCS_ODC_DETAILS, parameters);


	}

}
