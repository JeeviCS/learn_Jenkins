package com.cvs.specialty.erp.dao.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.CreateItemDao;
import com.cvs.specialty.erp.model.CreateERPItemDTO;
import com.cvs.specialty.erp.model.CreateItemDTO;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class CreateItemDaoImpl implements CreateItemDao {

	private DataSource sparcsDataSource;
	private JdbcTemplate sparcsJdbcTemplate;
	private JdbcTemplate erpJdbcTemplate;
	private DataSource erpDataSource;
	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;

	@Autowired
	@Required
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;
		erpJdbcTemplate = new JdbcTemplate(erpDataSource);
		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);
	}

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	public DataSource getErpDataSource() {
		return erpDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsJdbcTemplate = new JdbcTemplate(sparcsDataSource);
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);

	}

	@Override
	public int getRegisterdProcessNumber(String processName) {
		String processNameQuery = Constants.SQL_SELECT_PROCESS_ID;
		return sparcsJdbcTemplate.queryForObject(processNameQuery, new String[] { processName }, Integer.class);

	}

	@Override
	public Timestamp getStartDateFromProcessTable(int registeredProcessId) {
		String dateQuery = Constants.SQL_SELECT_DATE_OF_PROCESS;
		java.sql.Timestamp startDateTime = sparcsJdbcTemplate.queryForObject(dateQuery,
				new Integer[] { registeredProcessId }, java.sql.Timestamp.class);
		return startDateTime;
	}

	public void updateEndDateInProcessTable(java.sql.Timestamp endDate, int registeredProcessNo) {
		String updateDateQuery = Constants.SQL_UPDATE_DATE_OF_PROCESS;
		sparcsJdbcTemplate.update(updateDateQuery, new Object[] { endDate, registeredProcessNo });
	}

	@Override
	public List<CreateItemDTO> getItemsFromSparcsItemTable(Timestamp startDate, Timestamp endDate, String activeInd) {
		// TODO Auto-generated method stub

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("STARTDATE", startDate);
		parameters.addValue("ACTIVEIND", activeInd);

		List<CreateItemDTO> list = sparcsNamedJdbcTemplate.query(Constants.SQL_CREATE_ITEM_FETCH_SPARCS, parameters,
				new CreateItemMapper());

		// List<CreateItemDTO> list= sparcsNamedJdbcTemplate.query(
		// Constants.SQL_CREATE_ITEM_FETCH_SPARCS, parameters,new CreateItemExtractor())
		// ;
		return list;
	}

	@Override
	public int checkIfExistsinErpItemsInterfaceTable(String itemNumber, int organizationId) {
		// TODO Auto-generated method stub
		String checkSelectERPStatement = Constants.SQL_SELECT_ITEM_EXISTS_ERP;
		return erpJdbcTemplate.queryForObject(checkSelectERPStatement, new Object[] { itemNumber, organizationId },
				Integer.class);

	}

	@Override
	public int insertIntoERPItemInterfaceTable(CreateERPItemDTO newitemsFromSparcs) {
		String updateERPStatement = Constants.SQL_INSERT_ITEM_IN_ERP;

		int updateCount = erpJdbcTemplate.update(updateERPStatement,
				new Object[] { newitemsFromSparcs.getOrganizationId(), newitemsFromSparcs.getSegment2(),
						newitemsFromSparcs.getDescription(), newitemsFromSparcs.getTemplateId(),
						newitemsFromSparcs.getAttribute2(), newitemsFromSparcs.getMarketPrice(),
						newitemsFromSparcs.getLastUpdateBy(), newitemsFromSparcs.getCreatedBy()

				});

		return updateCount;

	}

	@Override
	public List<Integer> getUserId(String Username) {
		// TODO Auto-generated method stub

		List<Integer> userList = erpNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_USER_ID,
				new MapSqlParameterSource().addValue("Username", Username), Integer.class);
		return userList.isEmpty() ? null : userList;

	}

}
