package com.cvs.specialty.erp.dao.impl;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.ScanDataDao;
import com.cvs.specialty.erp.model.ScandataRequest;
import com.cvs.specialty.erp.model.ScandataResponse;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class ScandataDaoImpl implements ScanDataDao {

	private DataSource sparcsDataSource;
	private DataSource erpDataSource;
	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;
	private NamedParameterJdbcTemplate erpNamedJdbcTemplate;
	private JdbcTemplate sparcsJdbcTemplate;

	@Autowired
	@Required
	@Qualifier("erpDS")
	public void setErpDataSource(DataSource erpDataSource) {
		this.erpDataSource = erpDataSource;

		erpNamedJdbcTemplate = new NamedParameterJdbcTemplate(erpDataSource);
	}

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	public DataSource getErpDataSource() {
		return erpDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);
		sparcsJdbcTemplate = new JdbcTemplate(sparcsDataSource);
	}

	@Override
	public ScandataResponse callToScanDataSP(ScandataRequest scanrequest) {
		// TODO Auto-generated method stub

		// Pass jdbcTemlate and name of the stored Procedure.
		ScandataStoredProcedure myStoredProcedure = new ScandataStoredProcedure(sparcsJdbcTemplate,
				Constants.SCAN_DATA_IFC_PROC);

		// Sql parameter mapping
		SqlParameter pStringIn = new SqlParameter("p_string_in", Types.VARCHAR);
		SqlParameter pCallingUserIn = new SqlParameter("p_calling_user_in", Types.VARCHAR);
		SqlParameter pCallingProcessIn = new SqlParameter("p_calling_process_in", Types.VARCHAR);

		SqlOutParameter pStringOut = new SqlOutParameter("p_string_out", Types.VARCHAR);
		SqlOutParameter pStatusOut = new SqlOutParameter("p_status_out", Types.VARCHAR);
		SqlOutParameter pMessageOut = new SqlOutParameter("p_message_out", Types.VARCHAR);

		SqlParameter pTimeOutIn = new SqlParameter("p_timeout_in", Types.VARCHAR);
		SqlParameter pSiteType = new SqlParameter("p_site_type", Types.VARCHAR);

		SqlParameter[] paramArray = { pStringIn, pCallingUserIn, pCallingProcessIn, pStringOut, pStatusOut, pMessageOut,
				pTimeOutIn, pSiteType };

		myStoredProcedure.setParameters(paramArray);
		myStoredProcedure.compile();

		Map<String, Object> storedProcResult = myStoredProcedure.execute(scanrequest.getpStringIn(),
				scanrequest.getPcallingUserIn(), scanrequest.getPcallingProcessIn(), null, Constants.SITE_TYPE_PARAM);
		ScandataResponse response = new ScandataResponse();

		response.setpStringOut((String) storedProcResult.get("p_string_out"));
		response.setpStatusOut((String) storedProcResult.get("p_status_out"));
		response.setpMessageOut((String) storedProcResult.get("p_message_out"));

		/*
		 * SimpleJdbcCall call = new
		 * SimpleJdbcCall(sparcsJdbcTemplate).withSchemaName("dsparcs")
		 * .withCatalogName("scandata_interface").withProcedureName(
		 * "erp_orders_talk_to_intfc");
		 * Map<String, Object> inParamMap = new HashMap<String, Object>();
		 * inParamMap.put("p_string_in", scanrequest.getpStringIn());
		 * inParamMap.put("p_calling_user_in", scanrequest.getPcallingUserIn());
		 * 
		 * inParamMap.put("p_calling_process_in", scanrequest.getPcallingProcessIn());
		 * inParamMap.put("p_timeout_in",0); inParamMap.put("p_site_type",
		 * OracleTypes.P); Map<String, Object> simpleJdbcCallResult =
		 * call.execute(inParamMap);
		 * System.out.println(simpleJdbcCallResult);SqlParameterSource in = new
		 * MapSqlParameterSource(inParamMap); .declareParameters(new
		 * SqlParameter("p_string_in", Types.VARCHAR), new
		 * SqlParameter("p_calling_user_in", Types.VARCHAR), new
		 * SqlParameter("p_calling_process_in", Types.VARCHAR), new
		 * SqlOutParameter("p_string_out", Types.VARCHAR), new
		 * SqlOutParameter("p_status_out", Types.VARCHAR), new
		 * SqlOutParameter("p_message_out", Types.VARCHAR), new
		 * SqlParameter("p_timeout_in", Types.INTEGER), new SqlParameter("p_site_type",
		 * Types.VARCHAR));
		 * Map<String, Object> spResponse = call.execute( new
		 * MapSqlParameterSource("p_string_in", scanrequest.getpStringIn()), new
		 * MapSqlParameterSource("p_calling_user_in", scanrequest.getPcallingUserIn()),
		 * new MapSqlParameterSource("p_calling_process_in",
		 * scanrequest.getPcallingProcessIn()), new
		 * MapSqlParameterSource("p_timeout_in", null), new
		 * MapSqlParameterSource("p_site_type", "PGH"));
		 */

		return response;
	}

}
