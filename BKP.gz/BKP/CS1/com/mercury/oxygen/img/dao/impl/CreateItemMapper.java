package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.CreateItemDTO;

public class CreateItemMapper implements RowMapper<CreateItemDTO> {

	
	//"SELECT 'CREATE' transaction_type, LPAD(TRIM(si.item_src_cd),7,'0') item_number,si.item_name, si.ndc_number, si.item_src_cd, si.system_src_cd FROM items si  WHERE si.create_dt BETWEEN TO_DATE(:startDate,'YYYY-MM-DD') AND TO_DATE(:endDate,'YYYY-MM-DD') AND si.active_ind = :activeInd";
	
	@Override
	public CreateItemDTO mapRow(ResultSet rs, int rowNo) throws SQLException {
		// TODO Auto-generated method stub
		CreateItemDTO itemDto = new CreateItemDTO();

		itemDto.setTransactionType(rs.getString("TRANSACTION_TYPE"));
		itemDto.setItemNumber(rs.getString("ITEM_NUMBER"));
		itemDto.setItemName(rs.getString("ITEM_NAME"));
		/*itemDto.setItemSrcCode(rs.getString("ITEM_SRC_CODE"));
		itemDto.setSystemSrcCode(rs.getString("SYSTEM_SRC_CODE"));
		*/
		itemDto.setNdcNo(rs.getString("NDC_NUMBER"));
		
		
		itemDto.setAwpAmount(rs.getFloat("AWP_AMT"));
		

		return itemDto;
	}

}
