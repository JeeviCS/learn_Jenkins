package com.cvs.specialty.erp.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.FileTransferDao;
import com.cvs.specialty.erp.model.HostInfoDTO;
import com.cvs.specialty.erp.model.ProcessParametersDTO;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class FileTransferDaoImpl implements FileTransferDao {

	private DataSource sparcsDataSource;

	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);

	}

	@Override
	public List<ProcessParametersDTO> getParametersOfProcess(String processName) {
		// TODO Auto-generated method stub
		
		return	sparcsNamedJdbcTemplate.query(Constants.SQL_SELECT_PROCESS_PARAMETRS, new MapSqlParameterSource().addValue("processName", processName),
				new ProcessParameterMapper());
		
	}

	@Override
	public List<HostInfoDTO> getHostInfo(String sparcsOrErp) {
		// TODO Auto-generated method stub
		return sparcsNamedJdbcTemplate.query(Constants.SQL_SELECT_HOST_INFO, new MapSqlParameterSource().addValue("sparcsOrErp", sparcsOrErp),new UserInfoMapper());
	}

}
