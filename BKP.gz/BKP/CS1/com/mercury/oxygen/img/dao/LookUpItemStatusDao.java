package com.cvs.specialty.erp.dao;

import java.util.List;

import com.cvs.specialty.erp.model.ItemStatusDTO;

public interface LookUpItemStatusDao {
	/**
	 * 
	 * @param charSiteCode
	 * @param drugNo
	 * @return
	 */
	List<ItemStatusDTO> getItemStatus(String charSiteCode, String drugNo);

}
