package com.cvs.specialty.erp.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.CheckApiStatus;
import com.cvs.specialty.erp.model.CompanyTransactions;
import com.cvs.specialty.erp.utils.Constants;

@Repository
public class CheckApiStatusImpl implements CheckApiStatus {

	
	private static final Logger LOGGER = Logger.getLogger(CheckApiStatus.class);

	private DataSource sparcsDataSource;
	private NamedParameterJdbcTemplate sparcsNamedJdbcTemplate;
	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsNamedJdbcTemplate = new NamedParameterJdbcTemplate(sparcsDataSource);

	}


	@Override
	public List<String> isApiActive(String ApiName) {
		// TODO Auto-generated method stub
		
		
		List<String> userList = sparcsNamedJdbcTemplate.queryForList(Constants.SQL_SELECT_CHECK_IF_API_ACTIVE,
				new MapSqlParameterSource().addValue("lowVal", ApiName), String.class);
		return userList.isEmpty() ? null : userList;
		
	}


	@Override
	public String isApiRunning(String apiName) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void updateStatus(String apiName,String status) {
		// TODO Auto-generated method stub
		sparcsNamedJdbcTemplate.update(Constants.SQL_UPDATE_API_STATUS,
				new MapSqlParameterSource().addValue("lowVal", apiName).addValue("ind" , status)
			
				);
	}


	
}
