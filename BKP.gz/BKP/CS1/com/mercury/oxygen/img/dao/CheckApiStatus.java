package com.cvs.specialty.erp.dao;

import java.util.List;

public interface CheckApiStatus {

	
	List<String> isApiActive(String apiName);
	void updateStatus(String apiName, String status);
	String isApiRunning(String apiName);
}
