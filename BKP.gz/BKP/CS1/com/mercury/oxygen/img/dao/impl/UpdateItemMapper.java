package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.UpdateItemDTO;

public class UpdateItemMapper implements RowMapper<UpdateItemDTO> {

	@Override
	public UpdateItemDTO mapRow(ResultSet rs, int rowno) throws SQLException {
		// TODO Auto-generated method stub
		UpdateItemDTO updateitemDTO = new UpdateItemDTO();
		updateitemDTO.setItemNumber(rs.getString("ITEM_NUMBER"));
		updateitemDTO.setItemSrcCode(rs.getString("ITEM_SRC_CD"));
		updateitemDTO.setItemName(rs.getString("ITEM_NAME"));
		updateitemDTO.setNdcnumber(rs.getString("NDC_NUMBER"));
		return updateitemDTO;
	}

}
