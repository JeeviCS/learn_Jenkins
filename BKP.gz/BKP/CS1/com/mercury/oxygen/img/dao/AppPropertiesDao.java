package com.cvs.specialty.erp.dao;

import com.cvs.specialty.erp.model.AppProperties;

public interface AppPropertiesDao {
	
	public AppProperties loadProperties();
	//public Map<String, String> loadfileTransferProperties(String processName);

}
