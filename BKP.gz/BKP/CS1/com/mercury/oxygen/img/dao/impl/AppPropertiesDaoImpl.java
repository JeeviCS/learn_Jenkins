package com.cvs.specialty.erp.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.stereotype.Repository;

import com.cvs.specialty.erp.dao.AppPropertiesDao;
import com.cvs.specialty.erp.model.AppProperties;
import com.cvs.specialty.erp.model.AppPropertyKey;

@Repository("appPropertiesDaoImpl")
public class AppPropertiesDaoImpl implements AppPropertiesDao {

	private static final Logger logger = Logger.getLogger(AppPropertiesDaoImpl.class);

	private static final String SQL_QUERY_GET_APP_PROPERTIES = "select pp.name, pp.text_value from process_parameters pp"
			+ " join registered_processes rp on rp.registered_process_id = pp.registered_process_id and rp.process_name = ?";
	//static Map<String, String> resultMap = new HashMap<String, String>();
	private DataSource dataSource;
	static Map<String, String> resultMap = new HashMap<String, String>();
	@Autowired
	@Qualifier("sparcsDS")
	@Required
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	private JdbcTemplate jdbcTemplate;

	@Override
	public AppProperties loadProperties() {
		AppProperties appProps = new AppProperties();
		appProps.setPropertyMap(new EnumMap<AppPropertyKey, Object>(AppPropertyKey.class));
		logger.info("Executing load Properties");
		String sql = SQL_QUERY_GET_APP_PROPERTIES;
		try {
			appProps = jdbcTemplate.execute(sql, new PreparedStatementCallback<AppProperties>() {
				@Override
				public AppProperties doInPreparedStatement(PreparedStatement preparedStatement) throws SQLException, DataAccessException {
					AppProperties props = new AppProperties();
					EnumMap<AppPropertyKey, Object> propertyMap = new EnumMap<AppPropertyKey, Object>(AppPropertyKey.class);

					preparedStatement.setString(1, "SPIL_ERP_API");
					ResultSet rs = preparedStatement.executeQuery();
					while (rs.next()) {
						String name = rs.getString("name");
						String value = rs.getString("text_value");
						try {
							propertyMap.put(AppPropertyKey.valueOf(name), value);
							if(AppPropertyKey.valueOf(name) == AppPropertyKey.MONITOR_SERVICE_URL){
								System.setProperty("monitor_service_url", value);
							}
						} catch (IllegalArgumentException e) {
							logger.error(e);
						}
					}
					props.setPropertyMap(propertyMap);
					return props;
				}
			});
		} catch (Exception e) {
			logger.error("Error in loadProperties", e);
		}
		return appProps;
	}

	

}
