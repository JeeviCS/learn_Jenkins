package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.CompanyTransactions;
import com.cvs.specialty.erp.utils.Constants;

public class ErpTransactionsRowMapper implements RowMapper<CompanyTransactions> {

	public CompanyTransactions mapRow(ResultSet rs, int rowNum) throws SQLException {
		CompanyTransactions transactions = new CompanyTransactions();
		transactions.setCompanyTxnsIfaceId(rs.getInt(Constants.COMPANY_TXNS_IFACE_ID));
		transactions.setTransactionId(rs.getLong(Constants.TRANSACTION_ID));
		transactions.setTransactionDate(rs.getDate(Constants.TRANSACTION_DATE));
		transactions.setTransactionTypeName(rs.getString(Constants.TRANSACTION_TYPE_NAME));
		transactions.setTransactionReasonName(rs.getString(Constants.TRANSACTION_REASON_NAME));
		transactions.setSiteId(rs.getInt(Constants.SITE_ID));
		transactions.setOrderNumber(rs.getString(Constants.ORDER_NUMBER));
		transactions.setRxNumber(rs.getString(Constants.RX_NUMBER));
		transactions.setItemNumber(rs.getString(Constants.ITEM_NUMBER));
		transactions.setNdc(rs.getString(Constants.NDC));
		transactions.setItemDescription(rs.getString(Constants.ITEM_DESCRIPTION));
		transactions.setTransactionQuantity(rs.getInt(Constants.TRANSACTION_QUANTITY));
		transactions.setTransactionUom(rs.getString(Constants.TRANSACTION_UOM));
		transactions.setOrderByCompanyId(rs.getInt(Constants.ORDER_BY_COMPANY_ID));
		transactions.setTransactionReference(rs.getString(Constants.TRANSACTION_REFERENCE));

		return transactions;
	}
}
