package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.SparcsShipmentTransaction;
import com.cvs.specialty.erp.utils.Constants;

public class SparcsShipmentTransactionRowMapper implements RowMapper<SparcsShipmentTransaction> {

	@Override
	public SparcsShipmentTransaction mapRow(ResultSet rs, int rowNo) throws SQLException {
		SparcsShipmentTransaction shipmentTransaction = new SparcsShipmentTransaction();
		shipmentTransaction.setErpDispenseInterfaceId(rs.getLong(Constants.ERP_DISPENSE_INTERFACE_ID));
		shipmentTransaction.setRxNumber(rs.getLong(Constants.RX_NUMBER));
		shipmentTransaction.setRefillNumber(rs.getLong(Constants.REFILL_NUMBER));
		shipmentTransaction.setOrderNumber(rs.getLong(Constants.ORDER_NUMBER));
		shipmentTransaction.setShipmentNumber(rs.getLong(Constants.SHIPMENT_NUMBER));
		shipmentTransaction.setItemNumber(rs.getLong(Constants.ITEM_NUMBER));
		shipmentTransaction.setActualDispensed(rs.getLong(Constants.ACTUAL_DISPENSED));
		shipmentTransaction.setQuantityDispensed(rs.getLong(Constants.QUANTITY_DISPENSED));
		shipmentTransaction.setCreateDate(rs.getDate(Constants.CREATE_DATE));

		return shipmentTransaction;
	}

}
