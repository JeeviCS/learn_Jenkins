package com.cvs.specialty.erp.dao;

import com.cvs.specialty.erp.model.ScandataRequest;
import com.cvs.specialty.erp.model.ScandataResponse;

public interface ScanDataDao {
ScandataResponse callToScanDataSP(ScandataRequest scanrequest);
}
