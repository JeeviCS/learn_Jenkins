package com.cvs.specialty.erp.dao;

import java.sql.Date;
import java.util.List;

import com.cvs.specialty.erp.model.CompanyTransactions;

public interface ErpTransactionsDao {
	/**
	 * This method reads the record as a list and gets the company return
	 * transactions
	 * 
	 * @return
	 */
	List<CompanyTransactions> getReturnTransactions();

	/**
	 * This method updates the flags
	 * 
	 * @param updatedBy
	 * @param processFlag
	 * @param updatedDate
	 * @param companyTxnsIfaceId
	 */
	void updateProcessFlag(String updatedBy, String processFlag, Date updatedDate, int companyTxnsIfaceId);

}
