package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.CompTxnTypeFromERPDTO;

public class CompTxnReasonMapper implements RowMapper<CompTxnTypeFromERPDTO>{

	@Override
	public CompTxnTypeFromERPDTO mapRow(ResultSet rs, int no) throws SQLException {
		// TODO Auto-generated method stub
		CompTxnTypeFromERPDTO compTxnTypeFromERP= new CompTxnTypeFromERPDTO();
		compTxnTypeFromERP.setOrganizationId(rs.getInt("ORGANIZATION_ID"));
		compTxnTypeFromERP.setSubInventoryCode(rs.getString("SUBINVENTORY_CODE"));
		compTxnTypeFromERP.setTxnTypeId(rs.getLong("TRANSACTION_TYPE_ID"));
		compTxnTypeFromERP.setReasonId(rs.getInt("REASON_ID"));
		compTxnTypeFromERP.setDistributionAccountId(rs.getLong("DISTRIBUTION_ACCOUNT_ID"));
		compTxnTypeFromERP.setUomCode(rs.getString("UOM_CODE"));
		compTxnTypeFromERP.setInactiveDate(rs.getDate("INACTIVE_DATE"));
		compTxnTypeFromERP.setEnabledFlag(rs.getString("ENABLED_FLAG"));
		return compTxnTypeFromERP;
	}

}
