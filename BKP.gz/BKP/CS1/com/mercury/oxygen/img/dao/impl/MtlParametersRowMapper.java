package com.cvs.specialty.erp.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cvs.specialty.erp.model.MtlParameters;
import com.cvs.specialty.erp.utils.Constants;

public class MtlParametersRowMapper implements RowMapper<MtlParameters> {

	@Override
	public MtlParameters mapRow(ResultSet rs, int rowNo) throws SQLException {

		MtlParameters mtlParameters = new MtlParameters();

		mtlParameters.setOraganizationId(rs.getLong(Constants.ORGANIZATION_ID));
		mtlParameters.setSiteId(rs.getLong(Constants.SITE_ID));
		return mtlParameters;
	}

}
