package com.cvs.specialty.erp.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;

import com.cvs.specialty.erp.dao.CompanyIdSchedularDao;
import com.cvs.specialty.erp.utils.Constants;

public class CompanyIdSchedularDaoImpl implements CompanyIdSchedularDao {

	private DataSource sparcsDataSource;
	private JdbcTemplate sparcsJdbcTemplate;

	public DataSource getSparcsDataSource() {
		return sparcsDataSource;
	}

	@Autowired
	@Required
	@Qualifier("sparcsDS")
	public void setSparcsDataSource(DataSource sparcsDataSource) {
		this.sparcsDataSource = sparcsDataSource;
		sparcsJdbcTemplate = new JdbcTemplate(sparcsDataSource);

	}

	@Override
	public List<Integer> getDistinctCompanyId() {
		// TODO Auto-generated method stub
		return sparcsJdbcTemplate.queryForList(Constants.SQL_SELECT_DISTINCT_COMPANY_ID, Integer.class);
	}

}
