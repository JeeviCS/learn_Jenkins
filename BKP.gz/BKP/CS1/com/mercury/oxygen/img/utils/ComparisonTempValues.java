package com.cvs.specialty.erp.utils;

public class ComparisonTempValues {
	
	private String lastTs ;
	private Integer QualityIndicator = null;
	private String value = null;
	
	public String getLastTs() {
		return lastTs;
	}
	public void setLastTs(String lastTs) {
		this.lastTs = lastTs;
	}
	public Integer getQualityIndicator() {
		return QualityIndicator;
	}
	public void setQualityIndicator(Integer qualityIndicator) {
		QualityIndicator = qualityIndicator;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((QualityIndicator == null) ? 0 : QualityIndicator.hashCode());
		result = prime * result + ((lastTs == null) ? 0 : lastTs.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ComparisonTempValues other = (ComparisonTempValues) obj;
		if (QualityIndicator == null) {
			if (other.QualityIndicator != null)
				return false;
		} else if (!QualityIndicator.equals(other.QualityIndicator))
			return false;
		if (lastTs == null) {
			if (other.lastTs != null)
				return false;
		} else if (!lastTs.equals(other.lastTs))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "ComparisonTempValues [lastTs=" + lastTs + ", QualityIndicator="
				+ QualityIndicator + ", value=" + value + "]";
	}
	
	

}
