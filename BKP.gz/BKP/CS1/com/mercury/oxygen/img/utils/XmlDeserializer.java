package com.cvs.specialty.erp.utils;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import com.cvs.specialty.erp.model.ScandataRequest;

public class XmlDeserializer {

	//private static final Logger LOG = Logger.getLogger(PrescriberManagerDAOImpl.class);
	
	public static ScandataRequest xmlDeserializer(String xml){
		ScandataRequest slnRequest = null;
		try{
			JAXBContext jaxbContext = JAXBContext.newInstance(ScandataRequest.class);
			Unmarshaller jbUnMarsh = jaxbContext.createUnmarshaller();
			StreamSource ss = new StreamSource(new StringReader(xml));
			slnRequest = (ScandataRequest) jbUnMarsh.unmarshal(ss);
		
		}catch(JAXBException jbE){
			//LOG.error("Exception occured while trying to deserialize XML :"+ jbE);
		}
		
		return slnRequest;
	}
}
