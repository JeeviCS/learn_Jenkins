package com.cvs.specialty.erp.utils;

import java.util.HashMap;
import java.util.Map;

public class Constants {

	/*****
	 * 
	 * Columns from mck_order_returns table from SPARCS.
	 */

	public static final String MCK_ORDER_RETURN_ID = "MCK_ORDER_RETURN_ID";
	public static final String COMPANY_TXNS_IFACE_ID = "COMPANY_TXNS_IFACE_ID";
	public static final String TRANSACTION_ID = "TRANSACTION_ID";
	public static final String TRANSACTION_DATE = "TRANSACTION_DATE";
	public static final String TRANSACTION_TYPE_NAME = "TRANSACTION_TYPE_NAME";
	public static final String TRANSACTION_REASON_NAME = "TRANSACTION_REASON_NAME";
	public static final String SITE_ID = "SITE_ID";
	public static final String ORDER_NUMBER = "ORDER_NUMBER";
	public static final String RX_NUMBER = "RX_NUMBER";
	public static final String ITEM_NUMBER = "ITEM_NUMBER";
	public static final String NDC = "NDC";
	public static final String ITEM_DESCRIPTION = "ITEM_DESCRIPTION";
	public static final String TRANSACTION_QUANTITY = "TRANSACTION_QUANTITY";
	public static final String TRANSACTION_UOM = "TRANSACTION_UOM";
	public static final String ORDER_BY_COMPANY_ID = "ORDER_BY_COMPANY_ID";
	public static final String CREATE_DATE = "CREATE_DATE";
	public static final String UPDATE_DATE = "UPDATE_DATE";
	public static final String CREATE_BY_SYSTEM = "CREATE_BY_SYSTEM";
	public static final String CREATE_BY_PROCESS_FUNCTION = "CREATE_BY_PROCESS_FUNCTION";
	public static final String UPDATE_BY_SYSTEM = "UPDATE_BY_SYSTEM";
	public static final String UPDATE_BY_PROCESS_FUNCTION = "UPDATE_BY_PROCESS_FUNCTION";
	public static final String TRANSACTION_REFERENCE = "TRANSACTION_REFERENCE";

	/*****
	 * 
	 * Columns from erp_dispenses_interface table from SPARCS.
	 */

	public static final String ERP_DISPENSE_INTERFACE_ID = "ERP_DISPENSE_INTERFACE_ID";
	public static final String REFILL_NUMBER = "REFILL_NUMBER";
	public static final String SHIPMENT_NUMBER = "SHIPMENT_NUMBER";
	public static final String ACTUAL_DISPENSED = "ACTUAL_DISPENSED";
	public static final String QUANTITY_DISPENSED = "QUANTITY_DISPENSED";
	public static final String ORGANIZATION_ID = "ORGANIZATION_ID";

	/*****
	 * 
	 * Columns from INV.MTL_SYSTEM_ITEMS_B table from ERP.
	 */

	public static final String ENABLED_FLAG = "ENABLED_FLAG";
	public static final String INVENTORY_ITEM_ID = "INVENTORY_ITEM_ID";
	public static final String INVENTORY_ITEM_STATUS_CODE = "INVENTORY_ITEM_STATUS_CODE";
	public static final String MTL_SYSTEM_ITEMS_IND = "MTL_SYSTEM_ITEMS_IND";

	/****
	 * 
	 * Columns from XREf Cross reference table from SPARCS
	 */

	public static final String XREF_HCP_EXTERNAL_XREF_ID = "HCP_EXTERNAL_XREF_ID";
	public static final String XREF_EXTERNAL_DOCTOR_ID = "EXTERNAL_DOCTOR_ID";
	public static final String XREF_EXTERNAL_ADDRESS_ID = "EXTERNAL_ADDRESS_ID";
	public static final String XREF_HCP_ID = "HCP_ID";
	public static final String XREF_SOURCE_SYSTEM_NAME = "SOURCE_SYSTEM_NAME";
	public static final String XREF_SRC_DELETE_DATE = "SRC_DELETE_DATE";
	public static final String XREF_CREATE_BY = "CREATE_BY";
	public static final String XREF_CREATE_BY_PROCESS = "CREATE_BY_PROCESS";
	public static final String XREF_CREATE_DATE = "CREATE_DATE";
	public static final String XREF_UPDATE_BY = "UPDATE_BY";
	public static final String XREF_UPDATE_BY_PROCESS = "UPDATE_BY_PROCESS";
	public static final String XREF_UPDATE_DATE = "UPDATE_DATE";

	/***
	 * 
	 * General Constants
	 */
	public static final String UPDATE_BY_PROCESS = "API";
	public static final String SOURCE_SYS_NAME = "PDM";
	public static final int MATCHING_LOGIC_ATTEMPTS = 6;
	public static final String INVALID_KEY = "invalid";
	public static final int COLUMN_LENGTH_LIMIT_20 = 20;

	/****
	 * 
	 * Address Number constants
	 */

	public static final Map<String, String> NUMBERS = new HashMap<String, String>();

	/***
	 * Note limits
	 * 
	 */
	public static final int COMMENT_TX_LIMIT = 4000;

	/****
	 * Json request elements
	 * 
	 */
	public static final String JSON_PRESCRIBER = "prescriber";
	public static final String JSON_CONTACT_POINTS = "contactPoints";

	/***
	 * request Cross Reference type vaues
	 * 
	 */
	public static final String NPI_TYPE = "1";
	public static final String DEA_TYPE = "2";
	public static final String SLN_TYPE = "3";

	public static final String CROSS_STATUS_ACTIVE = "1"; // temp
	public static final String CROSS_STATUS_INACTIVE = "0"; // temp
	/*
	 * B Bad -> soft deleted. -> DS DS Approved -> active, 2 good� -> D
	 * Duplicate -> only in phone and faxes. -> G Golden -> active, 1 Best -> U
	 * Unverified -> active, 3 not so good. ->
	 * 
	 */

	public static final String QUALITY_INDICATOR_BAD = "B";

	public static final Map<String, Integer> QUALITY_INDCATOR = new HashMap<String, Integer>();

	/***
	 * FAX and PHONE TYPE values
	 */
	public static final String PHONE_TYPE = "PHONE";
	public static final String FAX_TYPE = "FAX";

	/*****
	 * 
	 * HCP Type Code Map
	 */
	public static final Map<Integer, String> HCP_TYPE_CODES = new HashMap<Integer, String>();
	public static final int MAX_TYPE_CD_LENGTH = 5;

	/****
	 * SQL scripts
	 * 
	 */

	// Export Company Return Transaction
	public static final String SQL_INSERT_TRANSACTIONS = "INSERT INTO mck_order_returns (mck_order_return_id,company_txns_iface_id,transaction_id,transaction_date,transaction_type_name,transaction_reason_name,site_id,order_number,rx_number,item_number,ndc,item_description,transaction_quantity,transaction_uom,order_by_company_id,create_by,create_date,update_by,update_date,create_by_system,create_by_process_function,update_by_system,update_by_process_function,transaction_reference) VALUES (plvdyn.nextseq ('mck_order_return_id_seq'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String SQL_SELECT_TRANSACTIONS = "select * from mck_order_returns where mck_order_return_id=?";
	public static final String SQL_SELECT_TO_GET_UNPROCESSED_RECORDS = "SELECT * FROM xxinv_company_txns_iface where process_flag='N'";
	public static final String SQL_UPDATE_PROCESS_FLAG = "UPDATE xxinv_company_txns_iface SET process_flag= ?, update_by = ? , update_date = ? WHERE xxinv_company_txns_iface.company_txns_iface_id = ? AND xxinv_company_txns_iface.process_flag = 'N'";
	public static final String SQL_LOOKUP_ITEM_STATUS = "SELECT i.inventory_item_id,i.organization_id,i.enabled_flag,i.inventory_item_status_code,i.attribute4 mtl_system_items_ind FROM INV.MTL_SYSTEM_ITEMS_B i, STADT.PEN_LOCATION p WHERE p.PENLOC = :charSiteCode AND p.ORGANIZATION_ID = i.ORGANIZATION_ID AND i.SEGMENT2 = TO_NUMBER(:drugNo)";
	public static final String SQL_EMAIL_PROCEDURE = "call ERP_INTERFACE_UTILITIES.send_email (?,?,?,?)";
	// Import SPARCS Shipment Transaction
	public static final String SQL_SELECT_SPARCS_SHIPMENT_TRANSACTIONS = "SELECT edi.erp_dispense_interface_id, edi.rx_number, edi.refill_number, edi.order_number, edi.shipment_number, edi.item_number, NVL(pdo.actual_dispensed,0) actual_dispensed, edi.quantity_dispensed, edi.create_date FROM erp_dispenses_interface edi, prescription_disp_orders pdo WHERE pdo.id = edi.prescription_disp_order_id AND edi.order_status = ? AND edi.SITE_ID = ? AND edi.process_flag = 'N' AND edi.inserted_date BETWEEN trunc(?) AND trunc(SYSDATE) AND edi.create_date BETWEEN ? AND SYSDATE-(2/(60*24))";
//	public static final String SQL_SELECT_SPARCS_SHIPMENT_TRANSACTIONS = "SELECT edi.erp_dispense_interface_id, edi.rx_number, edi.refill_number, edi.order_number, edi.shipment_number, edi.item_number, NVL(pdo.actual_dispensed,0) actual_dispensed, edi.quantity_dispensed, edi.create_date FROM erp_dispenses_interface edi, prescription_disp_orders pdo WHERE pdo.id = edi.prescription_disp_order_id AND edi.order_status = ? AND edi.SITE_ID = ? AND edi.process_flag = 'N' AND edi.inserted_date BETWEEN ? AND ? AND edi.create_date BETWEEN ? AND ?";
	public static final String SQL_SELECT_SITE_ID_APPS_MTL_PARAMETERS = "SELECT NVL(attribute5, 0 ) SITE_ID,organization_id  FROM apps.mtl_parameters WHERE organization_id = ?";
	public static final String SQL_INSERT_MTL_TRANSACTIONS = "INSERT INTO inv.mtl_transactions_interface(source_code,source_line_id,source_header_id,process_flag,transaction_mode,lock_flag,last_update_date,last_updated_by,creation_date,created_by,inventory_item_id,item_segment2,organization_id,transaction_quantity,transaction_uom,transaction_date,subinventory_code,transaction_type_id,reason_id,distribution_account_id,attribute1,attribute2,attribute3,attribute4) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String SQL_UPDATE_SPARCS_SHIPMENT_TRANSACTIONS = "UPDATE erp_dispenses_interface SET quantity_dispensed = ?, organization_id = ?,subinventory_code = ?, transaction_type_id = ?,reason_id = ?,distribution_account_id = ?,error_explanation = ?,process_flag = ?,process_date = SYSDATE,transfer_ind = ?,update_date = SYSDATE,update_by = ? WHERE erp_dispense_interface_id = ?";
	public static final String CON_SPARCS_SHIP_TXN_SOURCE_CODE = "SPARCS Dispenses";

	public static final String CON_HBS_SHIP_TXN_SOURCE_CODE = "SALES INTERFACE";
	// items insert
	public static final String CREATE_ITEM_PROCESS_NAME = "ERP.XXINV_SPARCS_ITEMS_IFACE.IMPORT_ITEMS";
	public static final String SQL_CREATE_ITEM_FETCH_SPARCS = "SELECT 'CREATE' TRANSACTION_TYPE, LPAD(TRIM(SI.ITEM_SRC_CD),7,'0') ITEM_NUMBER,SI.ITEM_NAME, SI.NDC_NUMBER, ITEMS_UTILITIES.GET_ITEM_AWP_AMT(SI.ITEM_SRC_CD, SI.SYSTEM_SRC_CD,TRUNC (SYSDATE))AWP_AMT  FROM ITEMS SI  WHERE SI.CREATE_DT BETWEEN :STARTDATE AND SYSDATE AND SI.ACTIVE_IND = :ACTIVEIND";
	public static final String SQL_SELECT_PROCESS_ID = "select registered_process_id from registered_processes where process_name=?";
	public static final String SQL_SELECT_DATE_OF_PROCESS = "select control_date_1 from proc_mgr.process_control  where registered_process_id=?";
	public static final String SQL_UPDATE_DATE_OF_PROCESS = "update proc_mgr.process_control set control_date_1=? where registered_process_id=?";
	public static final String SQL_SELECT_ITEM_EXISTS_ERP = "SELECT count(*) FROM apps.mtl_system_items msi  WHERE msi.segment2 = ? AND msi.organization_id = ?";
	public static final String SQL_INSERT_ITEM_IN_ERP = "INSERT INTO inv.mtl_system_items_interface(ORGANIZATION_ID,SEGMENT2,DESCRIPTION,TRANSACTION_TYPE,PROCESS_FLAG,PRIMARY_UOM_CODE,SET_PROCESS_ID,TEMPLATE_ID,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,MARKET_PRICE,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATED_BY) VALUES (?,?,?,'CREATE',1,'EA',100,?,NULL,?,'F','A',?,SYSDATE,?,SYSDATE,?)";
	public static final String SQL_SELECT_USER_ID = "select user_id from applsys.fnd_user where user_name = :Username";
	// items update
	public static final String UPDATE_ITEM_PROCESS_NAME = "ERP.XXINV_SPARCS_ITEMS_UPD_IFACE.IMPORT_ITEMS_UPD";
	public static final String SQL_SELECT_ITEM_UPDATE = "SELECT LPAD(TRIM(SI.ITEM_SRC_CD),7,'0') ITEM_NUMBER,SI.ITEM_SRC_CD,SI.ITEM_NAME,SI.NDC_NUMBER FROM ITEMS SI WHERE SI.ACTIVE_IND = 'Y'   AND SI.UPDATE_DT BETWEEN :STARTDATE AND SYSDATE ORDER BY 1,2";
	public static final String SQL_SELECT_ITEM_UPDATE_ERP_MTL = "select nvl(msi.market_price,0) market_price from  apps.mtl_system_items msi where msi.segment2 = LPAD(TRIM(:itemNumber),7,'0') AND msi.organization_id = :organizationId AND msi.inventory_item_status_code = 'Active'";
	public static final String SQL_SELECT_ITEM_ID_SPARCS_ITEM = " SELECT item_id FROM items WHERE  item_src_cd = :itemSrcCode";
	public static final String SQL_SELECT_ITEM_UPDATE_AWPAMT = "SELECT iahv.awp_amt FROM item_awp_history_extended_vw iahv WHERE iahv.item_id= :itemId AND TRUNC (SYSDATE) BETWEEN iahv.item_awp_start_date AND iahv.item_awp_end_date AND iahv.awp_amt <> :marketPrice";
	public static final String SQL_INSERT_ITEM_UPDATE_ERP = "INSERT INTO INV.MTL_SYSTEM_ITEMS_INTERFACE(organization_id, segment2,transaction_type, process_flag,set_process_id, market_price, last_update_date, last_updated_by) values(122,:segment2,'UPDATE',1,110,:market_price,SYSDATE,:last_updated_by)";
	public static final String SQL_ITEM_UPDATE_CONTEXT_PROC = "call contract_rate_utilities.set_item_context(?)";
	// import company Shipment
//	public static final String SQL_SELECT_IMPORT_SHIPMENTS_1 = "  SELECT mesiq.mck_erp_ship_queue_id,mood.mck_order_odc_detail_id,moh.mck_order_header_id,moh.odc_order_number,moh.odc_si_order_status,moh.company_id,moh.site_id,mood.odc_irc,mood.odc_rx_number,mood.odc_quantity_picked_num,mood.odc_time_complete_dt odc_time_complete FROM dsparcs.mck_erp_ship_queue mesiq,dsparcs.mck_order_odc_details mood,dsparcs.mck_order_headers moh ";
//	public static final String SQL_SELECT_IMPORT_SHIPMENTS_2 = " WHERE mesiq.process_flag = 'N' AND mesiq.mck_order_odc_detail_id = mood.mck_order_odc_detail_id AND mood.mck_order_header_id = moh.mck_order_header_id AND moh.company_id = NVL(:companyId, moh.company_id) AND ((moh.site_id IS NULL AND :siteId IS NULL) OR  moh.site_id = :siteId) ORDER BY moh.company_id, moh.site_id,mesiq.mck_erp_ship_queue_id";
	//JC Proposed changes
//	public static final String SQL_SELECT_IMPORT_SHIPMENTS_1 = " SELECT mesiq.mck_erp_ship_queue_id,mood.mck_order_odc_detail_id,moh.mck_order_header_id,moh.odc_order_number,moh.odc_si_order_status,moh.company_id,moh.site_id,mood.odc_irc,mood.odc_rx_number,mood.odc_quantity_picked_num,mood.odc_time_complete_dt odc_time_complete FROM mck_erp_ship_queue mesiq,mck_order_odc_details mood,mck_order_headers moh,company_fulfill_config cfc,sites s ";
//	public static final String SQL_SELECT_IMPORT_SHIPMENTS_2 = " WHERE mesiq.process_flag = 'N' AND mesiq.mck_order_odc_detail_id = mood.mck_order_odc_detail_id AND mood.mck_order_header_id = moh.mck_order_header_id AND moh.company_id = NVL(:companyId, moh.company_id) AND moh.company_id = cfc.company_id AND cfc.global_default_site = s.location_alpha_cd AND NVL(moh.shipping_site_id, s.site_id) = :siteId ORDER BY moh.company_id, moh.site_id,mesiq.mck_erp_ship_queue_id";
	public static final String SQL_SELECT_IMPORT_SHIPMENTS_1 = " SELECT mesiq.mck_erp_ship_queue_id,mood.mck_order_odc_detail_id,moh.mck_order_header_id,moh.odc_order_number,moh.odc_si_order_status,moh.company_id,nvl(moh.shipping_site_id, s.site_id) site_id,mood.odc_irc,mood.odc_rx_number,mood.odc_quantity_picked_num,mood.odc_time_complete_dt odc_time_complete FROM mck_erp_ship_queue mesiq,mck_order_odc_details mood, mck_order_headers moh,company_fulfill_config cfc, sites s ";
	public static final String SQL_SELECT_IMPORT_SHIPMENTS_2 = " WHERE mesiq.process_flag = 'N' AND mesiq.mck_order_odc_detail_id = mood.mck_order_odc_detail_id AND mood.mck_order_header_id = moh.mck_order_header_id AND moh.company_id = nvl(:companyId,moh.company_id) AND moh.company_id = cfc.company_id AND cfc.global_default_site = s.location_alpha_cd  AND nvl(moh.shipping_site_id,s.site_id) =:siteId ORDER BY moh.company_id, nvl(moh.shipping_site_id, s.site_id), mesiq.mck_erp_ship_queue_id";
//	public static final String SQL_SELECT_ERP_TXN_REASONS = "SELECT  xottr.organization_id, xottr.subinventory_code,xottr.transaction_type_id, xottr.reason_id,xottr.distribution_account_id,xottr.uom_code,xottr.inactive_date,xottr.enabled_flag FROM xxinv_org_txn_types_reasons xottr WHERE xottr.process_id = 2 AND xottr.qualifier_1 = :curCompanyId AND ((xottr.qualifier_2 IS NULL AND :curSiteId IS NULL ) OR xottr.qualifier_2 = :curSiteId)";
	public static final String SQL_SELECT_ERP_TXN_REASONS = "SELECT xottr.organization_id,xottr.subinventory_code,xottr.transaction_type_id,xottr.reason_id,xottr.distribution_account_id,xottr.uom_code,xottr.inactive_date,xottr.enabled_flag FROM xxinv_org_txn_types_reasons xottr WHERE xottr.process_id = 2 AND xottr.qualifier_1 =:curCompanyId AND xottr.qualifier_2 =:curSiteId ";
	public static final String SQL_SELECT_ERP_LOOKUP_CODE = "SELECT flv.lookup_code FROM apps.fnd_lookup_values_vl flv WHERE flv.lookup_type = :exclusionLoop AND flv.lookup_code = :itemNumber AND flv.enabled_flag = 'Y' AND flv.start_date_active <=  :criteriaDate AND (flv.end_date_active IS NULL OR  flv.end_date_active >= :criteriaDate )";
	public static final String SQL_INSERT_ERP_TXN_INTERFACE1 = " INSERT INTO inv.mtl_transactions_interface(  SOURCE_CODE,SOURCE_LINE_ID,SOURCE_HEADER_ID,PROCESS_FLAG,TRANSACTION_MODE,LOCK_FLAG,ITEM_SEGMENT2,INVENTORY_ITEM_ID, ORGANIZATION_ID,SUBINVENTORY_CODE,TRANSACTION_QUANTITY,TRANSACTION_UOM,TRANSACTION_DATE, TRANSACTION_TYPE_ID,  REASON_ID,DISTRIBUTION_ACCOUNT_ID,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3, ATTRIBUTE4,ATTRIBUTE5,LAST_UPDATE_DATE,LAST_UPDATED_BY,CREATION_DATE,CREATED_BY)";
	public static final String SQL_INSERT_ERP_TXN_INTERFACE2 = " VALUES('Contract Companies Dispenses',:curOdcDetailId,:curOdcDetailId,1,3,2,LPAD(:curOdcIrc,7,'0'),NULL,:organizationId,:subInventoryCode,(:odcQuantityPickedNo)* -1,:uomCode,:curOdcTimeComplete,:txnTypeId,:reasonId,:distributionAcctId,:curOdcRxNo,:curOdcOrderNo,NULL,NULL,:curCompId,SYSDATE,:userId,SYSDATE,:userId)";
	public static final String SQL_UPDATE_SPARCS_SHIP_QUEUE = "UPDATE dsparcs.mck_erp_ship_queue  mesq SET mesq.process_flag= :processFlag ,mesq.process_date= SYSDATE ,mesq.transfer_ind = :transferInd,mesq.error_explanation= :errorExplanation,mesq.update_by = :packageName||'.'||:procedureName,mesq.update_date = SYSDATE,mesq.update_by_system= 'ERP',mesq.update_by_process_function = :packageName||'.'||:procedureName WHERE mesq.mck_erp_ship_queue_id= :curErpShipQueueId AND mesq.mck_order_odc_detail_id= :curOrderOdcDetailId ";
	public static final String SQL_UPDATE_SPARCS_ODC_DETAILS = " UPDATE dsparcs.mck_order_odc_details mood SET mood.erp_process_date= SYSDATE,mood.erp_transfer_ind= :transferInd,mood.update_by= :packageName||'.'||:procedureName,mood.update_date= SYSDATE,mood.update_by_system= 'ERP',mood.update_by_process_function = :packageName||'.'||:procedureName WHERE mood.mck_order_odc_detail_id= :orderOdcDetailId AND mood.mck_order_header_id = :orderHeaderId";

	// Scan Data
	public static final String SCAN_DATA_IFC_PROC = "dsparcs.scandata_interface.erp_orders_talk_to_intfc";
	public static final String STRING_IN = "p_string_in";
	public static final String CALLING_USER_IN = "p_calling_user_in";
	public static final String CALLING_PROCESS_IN = "p_calling_process_inc";
	public static final String TIME_OUT_IN = "p_timeout_in";
	public static final String SITE_TYPE_IN = "p_site_type";

	public static final String STRING_OUT = "p_string_out";
	public static final String PROCESS_OUT = "p_status_out";
	public static final String MESSAGE_OUT = "p_message_out";

	public static final String SITE_TYPE_PARAM = "PGH";

	// HBS purchase Order
	public static final String SQL_SELECT_PHARMOP_SPARCS = "SELECT * FROM PHARMOP_PO_HEADERS WHERE  STATUS=:status";
	public static final String SQL_SELECT_PHARMOP_RECORD_SPARCS = "SELECT * FROM PHARMOP_PO_HEADERS WHERE PO_HEADER_ID=:headerId";
	public static final String SQL_INSERT_PHARMOP_TABLE = "INSERT INTO PHARMOP_PO_HEADERS(PO_HEADER_ID,PO_NUMBER,APOTHECARY_VENDOR_ID,STORE_NO,BUYER,DESCRIPTION,STATUS,EDI_DATE,CANCEL_DATE,CREATE_BY,CREATE_DATE,UPDATE_BY,UPDATE_DATE,CANCEL_REASON,PROCESS_STATUS,USER_MESSAGE) VALUES(:headerId,:poNumber,:apothcaryVendorId,:storeNo,:buyer,:description,:status,:ediDate,:cancelDate,:createBy,:createDate,:updateBy,:updateDate,:cancelReason,:processStatus,:userMessage)";
	public static final String SQL_SELECT_PHARM_LINES_SPARCS = "SELECT * FROM PHARMOP_PO_LINES WHERE PO_HEADER_ID=:headerId";
	public static final String SQL_INSERT_PHARM_LINES_TABLE = "INSERT INTO PHARMOP_PO_LINES(PO_LINE_ID,LINE_NUMBER,PO_HEADER_ID,ITEM_ID,QUANTITY,MFG_AUTHORIZATION_NUMBER,CREATE_BY,CREATE_DATE,UPDATE_BY,UPDATE_DATE,ERP_RECEIPT_IND,ERP_PROCESS_DATE,UNIT_PRICE) VALUES(:poLineId,:lineNumber,:poHeaderId,:itemId,:quantity,:mfgAuthorizationNo,:createBy,:createDate,:updateBy,:updateDate,:erpReceiptInd,:erpProcessDate,:unitPrice)";
	public static final String SQL_UPDATE_PHARMOP_TABLE1 = "UPDATE PHARMOP_PO_HEADERS SET STATUS=:status WHERE PO_HEADER_ID=:poHeaderId";
	public static final String SQL_UPDATE_PHARMOP_TABLE2 = "UPDATE PHARMOP_PO_HEADERS SET STATUS=:status,EDI_DATE= :ediDate,PROCESS_STATUS=:processStatus, USER_MESSAGE=:userMessage WHERE PO_HEADER_ID=:poHeaderId";

	// Schedular
	public static final String SQL_SELECT_DISTINCT_COMPANY_ID = "select distinct company_id from  dsparcs.mck_order_headers";
	public static final String SQL_SELECT_IF_API_IS_RUNNING = "select distinct company_id from  dsparcs.mck_order_headers";
	
	public static final String SQL_SELECT_CHECK_IF_API_ACTIVE="select ACTIVE_INDICATOR from cg_ref_codes where RV_DOMAIN='SPIL_ERP_SERVICE' and RV_LOW_VALUE=:lowVal ";
	public static final String SQL_UPDATE_API_STATUS="update cg_ref_codes set active_indicator=:ind where RV_DOMAIN='SPIL_ERP_SERVICE' and RV_LOW_VALUE=:lowVal";

	// checking if API is Valid..
	public static final String API_NOT_ACTIVE_MESSAGE = "API is currently Disabled, Please update the Status to TRUE";

	/***
	 * Error Messages
	 */

	public static final String EXCEPTION_MESSAGE = "Exception Occurred With Error Code: 2 ";
	public static final String START_DATE_ERROR = "The Start Date is Undefined: 2";
	public static final String PROCESS_CONTROL_ERROR = "Process Control Not Successful: 2 ";
	public static final String USER_ERROR = "Cannot find User: ";
	public static final String SUCCESS_MESSAGE = "Completed Successfully with Code: 0 ";
	public static final String ITEM_PACKAGE_ERROR = "Completed Successfully with Code: ";
	public static final String ITEM_PACKAGE_NAME_DESC = "--------------XXINV_SPARCS_ITEMS_IFACE--------------------";
	public static final String MARKET_PRICE_NOT_NULL = "Market Price is Null, Hence Skipping this Record";
	public static final String INVALID_REQUEST = "Bad Request";

	public static final String FIRST_NAME_ERROR = "First name cannot be null or empty";
	public static final String LAST_NAME_ERROR = "Last name cannot be null or empty";
	public static final String CITY_ERROR = "invalid city for address";
	public static final String STREET_DETAILS = "invalid street details for address";
	public static final String STATE = "invalid state for address";
	public static final String ZIP_CODE = "invalid zip code for address";
	public static final String ADDRESS_QUALITY_CODE = "invalid quality code for address";
	public static final String XREF_QUALITY_CODE = "invalid quality code for crossReference";
	public static final String XREF_VALUE = "invalid value for crossReference";
	public static final String XREF_REF_CODE = "invalid RefCode for crossReference";
	public static final String XREF_STATE = "invalid state for crossReference";
	public static final String TP_QUALITY_CODE = "invalid quality code for Type code";
	public static final String TP_VALUE = "invalid value for type code";
	public static final String NOTE_TEXT = "invalid note text";

	// File Transfer
	public static final String SQL_SELECT_PROCESS_PARAMETRS = "select pp.name, pp.text_value from process_parameters pp join registered_processes rp on rp.registered_process_id = pp.registered_process_id and rp.process_name = :processName";
	public static final String SQL_SELECT_HOST_INFO = "select host_name,user_name,password,description from host_information where use_of=:sparcsOrErp";

}
