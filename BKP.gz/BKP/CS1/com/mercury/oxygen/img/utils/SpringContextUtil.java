package com.cvs.specialty.erp.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.cvs.specialty.erp.dao.AppPropertiesDao;

@Component
public class SpringContextUtil implements ApplicationContextAware {

	private static ApplicationContext appContext;

	public void setApplicationContext(ApplicationContext context) throws BeansException {
		appContext = context;
	}

	public static ApplicationContext getApplicationContext(Object request) {
		return appContext;
	}

	public static AppPropertiesDao getAppPropertiesDao() {
		return (AppPropertiesDao) appContext.getBean("appPropertiesDaoImpl");
	}

//	public static MetadataService getMetadataService() {
//		return (MetadataService) appContext.getBean("metadataServiceImpl");
//	}
}
