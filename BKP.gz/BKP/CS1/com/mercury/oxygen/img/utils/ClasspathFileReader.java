package com.cvs.specialty.erp.utils;

import java.nio.file.Files;
import java.nio.file.Paths;

public class ClasspathFileReader {

	private static ClasspathFileReader instance;
	
	private ClasspathFileReader(){ }
	
	public static ClasspathFileReader getInstance() {
		if(instance == null)
			instance = new ClasspathFileReader();
		return instance;
	}
	
	public String readFileFromClasspath(final String fileName)  {
	    try {
			return new String(Files.readAllBytes(
			            Paths.get(getClass().getClassLoader()
			                    .getResource(fileName)
			                    .toURI())));
		} catch (Exception e) {
			e.printStackTrace();
		}
	    return null;
	}
}
