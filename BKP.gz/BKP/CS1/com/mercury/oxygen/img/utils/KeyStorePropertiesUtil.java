package com.cvs.specialty.erp.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.log4j.Logger;

public class KeyStorePropertiesUtil {
	private static final Logger LOG = Logger.getLogger(KeyStorePropertiesUtil.class);

	private static final String FILEPATH = "/home/user/catsjproc/properties/"; 
	private static final String FILENAME = ".tprcne";

	public static String getContent()
	{
		String sCurrentLine = null;
		String content = null;
		try (BufferedReader br = new BufferedReader(new FileReader(FILEPATH+FILENAME)))	{
			while ((sCurrentLine = br.readLine()) != null) { 
				content = sCurrentLine;
			}
		} catch (IOException e) {
			LOG.error("KeyStorePropertiesUtil::Error in getContent - ", e);
		}
		return content;
	}
}
