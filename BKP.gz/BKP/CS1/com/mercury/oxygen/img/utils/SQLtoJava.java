package com.cvs.specialty.erp.utils;

public class SQLtoJava {
	

	public static String leftPad(String originalString, int length, char padCharacter) {
		String paddedString = originalString;
		while (paddedString.length() < length) {
			paddedString = padCharacter + paddedString;
		}
		return paddedString;
	}

}
