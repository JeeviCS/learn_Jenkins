package com.cvs.specialty.erp.utils;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;

import com.cvs.specialty.erp.dao.impl.ScandataDaoImpl;
import com.cvs.specialty.erp.model.ScandataResponse;

public class XmlSerializer {

private static final Logger LOG = Logger.getLogger(ScandataDaoImpl.class);
	
	public static String xmlSerializer(ScandataResponse slnResponse){
		String response = "";
		if(slnResponse != null){			
			try{
				JAXBContext jaxbContext = JAXBContext.newInstance(ScandataResponse.class);
				Marshaller jbMarsh = jaxbContext.createMarshaller();
				jbMarsh.setProperty("com.sun.xml.bind.xmlHeaders",""); 
				jbMarsh.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
				jbMarsh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, false);
				StringWriter sw = new StringWriter();
				jbMarsh.marshal(slnResponse, sw);
				response = sw.toString();
			}catch(JAXBException jbE){
				LOG.error("Exception occured while trying to Serialize XML :"+ jbE);
			}
		}
		return response;
	}
}
