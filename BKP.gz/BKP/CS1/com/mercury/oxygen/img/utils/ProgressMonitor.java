package com.cvs.specialty.erp.utils;

import org.apache.log4j.Logger;

import com.jcraft.jsch.SftpProgressMonitor;

public class ProgressMonitor implements SftpProgressMonitor {
	private final Logger LOG = Logger.getLogger(ProgressMonitor.class);
	private long max = 0;
	private long count = 0;
	private long percent = 0;

	public ProgressMonitor() {
	}

	public void init(int op, java.lang.String src, java.lang.String dest, long max) {
		this.max = max;
		LOG.debug("Starting file Transfer....");
		LOG.debug("Destination:" + dest);
	}

	@Override
	public boolean count(long bytes) {
		this.count += bytes;
		long percentNow = this.count * 100 / max;
		if (percentNow > this.percent) {
			this.percent = percentNow;

		}

		return (true);
	}

	public void end() {
		LOG.debug("File Transfer Completed....");
		LOG.debug("Total Bytes Processed:" + this.count);

	}

}
