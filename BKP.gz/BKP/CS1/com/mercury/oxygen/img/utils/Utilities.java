package com.cvs.specialty.erp.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;



public class Utilities {
	private static Logger LOG = Logger.getLogger(Utilities.class);

	
	
	public static boolean isLeftAfterRight(String date1, String date2){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss");
		try {
			Date dateOne = format.parse(date1);
			Date dateTwo = format.parse(date2);
			return dateOne.after(dateTwo);
		} catch (Exception ex) {
			LOG.error("Error occurred while Comparing TS from Utility",ex);
		}
		return false;
	}
	
	 /**
	    * Security Scan: CRLF injection fix
	    * @param data
	    * @return String
	    */
	    public static String sanitizeData(String data){
	    	String sanData=null;
	    	if(data!=null){
	    		sanData = ESAPI.encoder().encodeForXML(data);
	    	}
	    	return sanData;
	    } 
	    
	    /**
		    * Security Scan: XSS vulnerabilities fix
		    * @param data
		    * @return String
		    */
		    public static String sanitizeHtmlResponse(String data){
		    	String sanData=null;
		    	if(data!=null){
		    		sanData = ESAPI.encoder().encodeForHTML(data);
		    	}
		    	return sanData;
		    } 
		    
		    public static String sanitizeJsonRequest(String data){
		    	String sanData=null;
		    	if(data!=null){
		    		sanData = ESAPI.encoder().canonicalize(data);
		    	}
		    	return sanData;
		    } 
		    
		    public static String sanitizeResponse(String data){
		    	String sanData=null;
		    	if(data!=null){
		    		sanData = ESAPI.encoder().canonicalize(data);
		    	}
		    	return sanData;
		    } 

}
