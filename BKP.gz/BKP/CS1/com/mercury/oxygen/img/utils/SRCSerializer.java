package com.cvs.specialty.erp.utils;

import java.lang.reflect.Type;

import com.cvs.specialty.erp.model.Response;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;


public class SRCSerializer implements JsonSerializer<Response>{

	@Override
	public JsonElement serialize(final Response response, final Type type, final JsonSerializationContext context)throws JsonParseException{
		

		Gson gson = new GsonBuilder().enableComplexMapKeySerialization().setPrettyPrinting().create();		
	    
		return gson.toJsonTree(response.getValidation());
	}
	
	
}
