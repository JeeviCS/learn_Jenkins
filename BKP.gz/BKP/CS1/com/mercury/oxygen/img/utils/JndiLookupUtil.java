package com.cvs.specialty.erp.utils;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.jndi.JndiObjectFactoryBean;

import com.ibm.websphere.management.AdminService;
import com.ibm.websphere.management.AdminServiceFactory;

public class JndiLookupUtil extends JndiObjectFactoryBean {
	private static AdminService adminService;

	// This jndiName is provided from the Spring context file
	// e.g.) <property name="jndiName" value="Variable_name"/>
	private String jndiName;
	// This JNDI appender has been takes as per WAS Team's addition of JNDI Entries
	// cell/persistent/ context is added by WAS Server
	// Variable_name is provided by Developer and this is what is added in Spring
	// context file
	// Namebindings.xml file will have JNDI/<CELL_NAME>/<Variable_name>
	// So final lookup will be of format cell/persistent/JNDI/<CELL_NAME>/Variable
	// name
	private static String jndiAppender = "cell/persistent/JNDI";

	public String getJndiName() {
		return jndiName;
	}

	public void setJndiName(String jndiName) {
		this.jndiName = jndiName;
	}

	private static AdminService getAdminService() {
		if (adminService == null)
			adminService = AdminServiceFactory.getAdminService();
		return adminService;
	}

	/**
	 * Overriding the lookup Method to provide a local implementation of WAS Server
	 * lookup
	 */
	@Override
	protected Object lookup() throws NamingException {
		InitialContext context = new InitialContext();
		// This method can only be called from a JEE application, if called from simple
		// JVM it will fail
		jndiName = jndiAppender + "/" + getAdminService().getCellName() + "/" + jndiName;
		System.out.println(" Doing Look Up for : " + jndiName);
		// If look up fails it will throw Naming Exception

		// 04/02/2015 - Changes for password encryption
		Object val = context.lookup(jndiName);
		if (jndiName.contains("sparcs/db/pwd") || jndiName.contains("erp/db/pwd") || jndiName.contains("sparcs/db/erp/pwd")) {
			try {
				long t1 = System.currentTimeMillis();
				logger.info("Decrypting password for: " + jndiName);
				val = SpilEncryptUtility.decryptString(val.toString());
				logger.info("Time taken for decrypting password: " + (System.currentTimeMillis() - t1));
			} catch (Exception e) {
				logger.error("Exception occurred when decrypting the value for: " + jndiName, e);
			}
		}
		return val;
	}
}
