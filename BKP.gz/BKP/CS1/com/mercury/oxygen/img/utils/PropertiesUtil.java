package com.cvs.specialty.erp.utils;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import com.cvs.specialty.erp.model.AppProperties;
import com.cvs.specialty.erp.model.AppPropertyKey;

public class PropertiesUtil extends Timer {

	private static PropertiesUtil propsUtil = null;

	private static final long refreshInterval = 30 * 60 * 1000;

	private AppProperties propsCache = null;
	
	private PropertiesUtil() {
		// Just to defeat Instantiation
	}

	public static PropertiesUtil getInstance() {
		if (propsUtil == null) {
			synchronized (PropertiesUtil.class) {
				propsUtil = new PropertiesUtil();
			}
		}
		return propsUtil;
	}

	public AppProperties getAppProperties() {
		if (propsCache == null) {
				propsCache = SpringContextUtil.getAppPropertiesDao().loadProperties();	
				schedule(new TimerTask() {
					@Override
					public void run() {
						resetAppProperties();
					}
				}, getInitialDelay(), refreshInterval);
		}
		return propsCache;
	}
	
	public void resetAppProperties() {
		AppProperties tempProps = SpringContextUtil.getAppPropertiesDao().loadProperties();
		if (tempProps != null && tempProps.getPropertyMap() != null && !tempProps.getPropertyMap().isEmpty()) {
			propsCache = tempProps;
		}
	}

	private static long getInitialDelay() {
		int result = 0;
		int currentMin = Calendar.getInstance().get(Calendar.MINUTE);
		if (currentMin < 30)
			result = (30 - currentMin) * 60 * 1000;
		else
			result = (60 - currentMin) * 60 * 1000;
		return result;
	}

	public static String getProperty(AppPropertyKey key) {
		return (String) PropertiesUtil.getInstance().getAppProperties().getPropertyMap().get(key);
	}
	public static long getLongProperty(AppPropertyKey key) {
		return Long.parseLong((String)PropertiesUtil.getInstance().getAppProperties().getPropertyMap().get(key));
	}
}
