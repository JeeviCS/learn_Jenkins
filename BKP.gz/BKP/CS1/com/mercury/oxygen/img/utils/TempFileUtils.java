package com.cvs.specialty.erp.utils;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TempFileUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(TempFileUtils.class);

	public static File createTempFile(String filename) {

		File file = null;
		try {
			String tempDir = System.getProperty("java.io.tmpdir");
			file = new File(tempDir + filename);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file;
	}

	public static void deleteTempFile(String filename) {

		try {

			File doomedFile = new File(System.getProperty("java.io.tmpdir"), filename);
			if (doomedFile.exists()) {
				if (doomedFile.delete()) {
					LOGGER.info("File:" + filename + " is deleted Succssfully");

				} else {

					LOGGER.error("File:" + filename + " Failed to Delete");
				}
			} else {
				LOGGER.info("File:" + filename + " cannot Be found, May be already Deleted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
