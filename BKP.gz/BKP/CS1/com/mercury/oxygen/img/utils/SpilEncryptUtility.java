package com.cvs.specialty.erp.utils;

import java.io.File;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;

public class SpilEncryptUtility {
	private static final Logger LOG = Logger.getLogger(SpilEncryptUtility.class);

	private static final String KEY_STORE_PATH = "/appl/client_server/vers/shared/keystore/";
	private static final String KEY_STORE_NAME = "specialty.jks";
	private static final String KEY_STORE_TYPE = "JKS";
	private static final String KEYSTORE_ALIAS = "spil-cert";
	private static PrivateKey privateKey = null;

	static{
		try {
			String pw = KeyStorePropertiesUtil.getContent();
			KeyStore keystore = SpilKeyStoreUtil.loadKeyStore(
					new File(KEY_STORE_PATH+KEY_STORE_NAME), pw, KEY_STORE_TYPE);
			KeyPair keypair = SpilKeyStoreUtil.getKeyPair(keystore, KEYSTORE_ALIAS, pw);
			privateKey = keypair.getPrivate();
		} catch (KeyStoreException | NoSuchAlgorithmException
				| CertificateException | IOException | UnrecoverableKeyException e) {
			LOG.error("Exception during loading keystore and getting keys", e);
		}
	}

	public static String decryptString(String value) throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException,
			NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, IOException {
		String decryptedVal = null;
		if (value != null) {
			byte[] encryptedByteValue = DatatypeConverter.parseBase64Binary(value);
			decryptedVal = decrypt(encryptedByteValue);
		}
		return decryptedVal;
	}

	private static String decrypt(byte[] dataToDecrypt) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException,
			NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		String decryptedData = null;
		Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		decryptedData = new String(cipher.doFinal(dataToDecrypt));
		return decryptedData;
	}
}
