package com.cvs.specialty.erp.utils;
/*package com.cvs.specialty.tls.utils;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cvs.specialty.tls.model.Address;
import com.cvs.specialty.tls.model.PrescriberRequest;
import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;


public class SRCDeserializer implements JsonDeserializer<PrescriberRequest>{

	@Override
	public PrescriberRequest deserialize(JsonElement je, Type type, JsonDeserializationContext jdc)throws JsonParseException{
		
		final Gson gson = new Gson();
	    final JsonObject obj = je.getAsJsonObject(); 
	    final JsonElement dataElement = obj.get(Constants.JSON_PRESCRIBER);	    
	    final List<Address> addresses = new ArrayList<Address>();
	    final JsonElement addressesJsonMap = dataElement.getAsJsonObject().get(Constants.JSON_CONTACT_POINTS);
	    Type type2 = new TypeToken<Map<String, JsonElement>>(){}.getType();
	    Map<String, JsonElement> addressMap = gson.fromJson(addressesJsonMap, type2);
	    List<JsonElement> addressJson = new ArrayList<JsonElement>(addressMap.values());
	    for(JsonElement jsonAddress : addressJson){    	
		    Address addressTemp = gson.fromJson(jsonAddress, Address.class);
	    	addresses.add(addressTemp);
	    }
    
	    PrescriberRequest prescriber = gson.fromJson(dataElement, PrescriberRequest.class);
	    prescriber.setAddresses(addresses);
	    
		return prescriber;
	}
	
	
}*/
